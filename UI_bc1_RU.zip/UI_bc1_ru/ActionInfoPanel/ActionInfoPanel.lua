--==========================================================
-- Re-written by bc1 using Notepad++
-- Action info panel now merges end turn button,
-- notifications, and civilization ribbon
-- code is common using _bCiv5GK and _bCiv5BNW switches
--==========================================================
Events.SequenceGameInitComplete.Add(function()

include "UserInterfaceSettings"
local UserInterfaceSettings = UserInterfaceSettings

include "GameInfoCache" -- warning! booleans are true, not 1, and use iterator ONLY with table field conditions, NOT string SQL query
local GameInfo = GameInfoCache

include "IconHookup"
local CivIconHookup = CivIconHookup
local IconHookup = IconHookup
local Color = Color
local PrimaryColors = PrimaryColors

include "CityStateStatusHelper"
local GetActiveQuestText = GetActiveQuestText
local UpdateCityStateStatusIconBG = UpdateCityStateStatusIconBG

--==========================================================
-- Minor lua optimizations
--==========================================================
local ipairs = ipairs
local floor = math.floor
local huge = math.huge
local min = math.min
local pairs = pairs
local print = print
local pcall = pcall
local concat = table.concat
local insert = table.insert
local remove = table.remove
local tostring = tostring
local unpack = unpack

local ACTIONSUBTYPE_BUILD = ActionSubTypes.ACTIONSUBTYPE_BUILD
local ButtonPopupTypes = ButtonPopupTypes
local ContextPtr = ContextPtr
local Controls = Controls
local EndTurnBlockingTypes = EndTurnBlockingTypes
local Events = Events
local FROM_UI_DIPLO_EVENT_HUMAN_NEGOTIATE_PEACE = FromUIDiploEventTypes.FROM_UI_DIPLO_EVENT_HUMAN_NEGOTIATE_PEACE
local Game = Game
local GameInfoActions = GameInfoActions
local GameInfoTypes = GameInfoTypes
local GetActivePlayer = Game.GetActivePlayer
local GetActiveTeam = Game.GetActiveTeam
local GetAutoUnitCycle = OptionsManager.GetAutoUnitCycle
local GetPlot = Map.GetPlot
local GetPlotByIndex = Map.GetPlotByIndex
local HexToWorld = HexToWorld
local L = Locale.ConvertTextKey
local LookUpControl = LookUpControl
local LuaEvents = LuaEvents
local MAX_CIV_PLAYERS = GameDefines.MAX_CIV_PLAYERS
local MAX_MAJOR_CIVS = GameDefines.MAX_MAJOR_CIVS
local MINOR_CIV_QUEST_KILL_CAMP = MinorCivQuestTypes.MINOR_CIV_QUEST_KILL_CAMP
local MajorCivApproachTypes = MajorCivApproachTypes
local Matchmaking = Matchmaking
local Mouse = Mouse
local Network = Network
local NotificationTypes = NotificationTypes
local Players = Players
local PlotDistance = Map.PlotDistance
local RESOURCEUSAGE_LUXURY = ResourceUsageTypes.RESOURCEUSAGE_LUXURY
local RESOURCEUSAGE_STRATEGIC = ResourceUsageTypes.RESOURCEUSAGE_STRATEGIC
local Teams = Teams
local ToGridFromHex = ToGridFromHex
local ToHexFromGrid = ToHexFromGrid
local ToLower = Locale.ToLower
local ToNumber = Locale.ToNumber
local TradeableItems = TradeableItems
local UI = UI
local UIManager = UIManager

--==========================================================
-- Globals
--==========================================================
local _bCiv5GK = Game.GetReligionName ~= nil
local _bCiv5BNW = Game.GetActiveLeague ~= nil
local _tScratchDeal = UI.GetScratchDeal()

local _bHotSeatGame = PreGame.IsHotSeatGame()
local _bNetworkMultiPlayer = PreGame.IsMultiplayerGame()

local _cRecycleBin = Controls.Scrap
local _cSmallStack = Controls.SmallStack

local _tMinorControlTable = {}
local _tMajorControlTable = {}

local _iActivePlayer = GetActivePlayer()
local _pActivePlayer = Players[ _iActivePlayer ]
local _iActiveTeam = GetActiveTeam()
local _pActiveTeam = Teams[ _iActiveTeam ]

local _tColorWar = Color( 1, 0, 0, 1 )		-- "Red"
local _tColorDenounce = Color( 1, 0, 1, 1 )	-- "Magenta"
local _tColorHuman = Color( 1, 1, 1, 1 )	-- "White"
local _tColorMajorCivApproach = {
	[ MajorCivApproachTypes.MAJOR_CIV_APPROACH_WAR or -1] = _tColorWar,
	[ MajorCivApproachTypes.MAJOR_CIV_APPROACH_HOSTILE or -1] = Color( 1, 0.5, 1, 1 ),		-- "Orange"
	[ MajorCivApproachTypes.MAJOR_CIV_APPROACH_GUARDED or -1] = Color( 1, 1, 0.5, 1 ),		-- "Yellow"
	[ MajorCivApproachTypes.MAJOR_CIV_APPROACH_AFRAID or -1] = Color( 1, 1, 0.5, 1 ),		-- "Yellow"
	[ MajorCivApproachTypes.MAJOR_CIV_APPROACH_FRIENDLY or -1] = Color( 0.5, 1, 0.5, 1 ),	-- "Green"
	[ MajorCivApproachTypes.MAJOR_CIV_APPROACH_NEUTRAL or -1] = Color( 1, 1, 1, 1 ),		-- "White"
}_tColorMajorCivApproach[-1]=nil

local _tLeaderPopups = { LookUpControl( "/LeaderHeadRoot" ), LookUpControl( "/LeaderHeadRoot/DiploTrade" ), LookUpControl( "/LeaderHeadRoot/DiscussionDialog" ) }
local _iLeaderMode, _iLeader, _iMaxTotalStackHeight, _bCivilizationRibbon, _bWorkerFocus, _bChatOpen
local _ , _iScreenHeight = UIManager:GetScreenSizeVal()
local _iChatPanelHeight = 170
local _iDiploButtonsHeight = 108
local _iCivPanelOffsetY = _iDiploButtonsHeight
local _sAlertMessageTitle = ""
local _sAlertMessages = ""
local _bAlertMessages = true

local _tSpareNotifications = {}
local _tActiveNotificationGroups = {}
local _tActiveNotifications = {}
local _tNotificationNames = {}
local _tNotificationGroups = {}
local _tNotificationGroupNames = {}
local _tNotificationTexture1 = {}
local _tNotificationTexture2 = {}

local NO_FLASHING         = 0
local FLASHING_END_TURN   = 1
local FLASHING_SCIENCE    = 2
local FLASHING_PRODUCTION = 3
local FLASHING_FREE_TECH  = 4

--==========================================================
-- Icon Notifications
--==========================================================

for notificationType,								name,					group
in ([[
NOTIFICATION_POLICY									SocialPolicy			SocialPolicy
NOTIFICATION_MET_MINOR								CityState				CityState
NOTIFICATION_MINOR									CityState				CityState
NOTIFICATION_MINOR_QUEST							CityState				CityState
NOTIFICATION_ENEMY_IN_TERRITORY						EnemyInTerritory		EnemyInTerritory
NOTIFICATION_REBELS									EnemyInTerritory		EnemyInTerritory
NOTIFICATION_CITY_RANGE_ATTACK						CityCanBombard			CityCanBombard
NOTIFICATION_BARBARIAN								Barbarian				Barbarian
NOTIFICATION_GOODY									AncientRuins			AncientRuins
NOTIFICATION_BUY_TILE								BuyTile					BuyTile
NOTIFICATION_CITY_GROWTH							CityGrowth				CityGrowth
NOTIFICATION_CITY_TILE								CityTile				CityTile
NOTIFICATION_DEMAND_RESOURCE						DemandResource			DemandResource
NOTIFICATION_UNIT_PROMOTION							UnitPromoted			UnitPromoted
NOTIFICATION_WONDER_STARTED							WonderConstructed		Wonder
NOTIFICATION_WONDER_COMPLETED_ACTIVE_PLAYER			WonderConstructed		Wonder
NOTIFICATION_WONDER_COMPLETED						WonderConstructed		Wonder
NOTIFICATION_WONDER_BEATEN							WonderConstructed		Wonder
NOTIFICATION_GOLDEN_AGE_BEGUN_ACTIVE_PLAYER			GoldenAge				GoldenAge
NOTIFICATION_GOLDEN_AGE_BEGUN						GoldenAge				GoldenAge
NOTIFICATION_GOLDEN_AGE_ENDED_ACTIVE_PLAYER			GoldenAgeComplete		GoldenAgeComplete
NOTIFICATION_GOLDEN_AGE_ENDED						GoldenAgeComplete		GoldenAgeComplete
NOTIFICATION_GREAT_PERSON_ACTIVE_PLAYER				GreatPerson				GreatPerson
NOTIFICATION_GREAT_PERSON							GreatPerson				GreatPerson
NOTIFICATION_STARVING								CityStarving			CityStarving
NOTIFICATION_WAR_ACTIVE_PLAYER						War						War
NOTIFICATION_WAR									WarOther				WarOther
NOTIFICATION_PEACE_ACTIVE_PLAYER					Peace					Peace
NOTIFICATION_PEACE									PeaceOther				PeaceOther
NOTIFICATION_VICTORY								Victory
NOTIFICATION_UNIT_DIED								UnitDied
NOTIFICATION_CITY_LOST								CapitalLost				CapitalLost
NOTIFICATION_CAPITAL_LOST_ACTIVE_PLAYER				CapitalLost				CapitalLost
NOTIFICATION_CAPITAL_LOST							CapitalLost				CapitalLost
NOTIFICATION_CAPITAL_RECOVERED						CapitalRecovered		CapitalRecovered
NOTIFICATION_PLAYER_KILLED							CapitalLost				CapitalLost
NOTIFICATION_DISCOVERED_LUXURY_RESOURCE				LuxuryResource			DiscoveredResource
NOTIFICATION_DISCOVERED_STRATEGIC_RESOURCE			StrategicResource		DiscoveredResource
NOTIFICATION_DISCOVERED_BONUS_RESOURCE				BonusResource			DiscoveredResource
NOTIFICATION_POLICY_ADOPTION						Generic					Disabled
NOTIFICATION_DIPLO_VOTE								DiplomacyVote
NOTIFICATION_RELIGION_RACE							ReligionFounded			Religion
NOTIFICATION_EXPLORATION_RACE						NaturalWonder			NaturalWonder			
NOTIFICATION_DIPLOMACY_DECLARATION					Diplomacy				Diplomacy
NOTIFICATION_DEAL_EXPIRED_GPT						DiplomacyX				DealExpired
NOTIFICATION_DEAL_EXPIRED_RESOURCE					DiplomacyX				DealExpired
NOTIFICATION_DEAL_EXPIRED_OPEN_BORDERS				DiplomacyX				DealExpired
NOTIFICATION_DEAL_EXPIRED_DEFENSIVE_PACT			DiplomacyX				DealExpired
NOTIFICATION_DEAL_EXPIRED_RESEARCH_AGREEMENT		ResearchAgreementX
NOTIFICATION_DEAL_EXPIRED_TRADE_AGREEMENT			DiplomacyX				DealExpired
NOTIFICATION_TECH_AWARD								TechAward
NOTIFICATION_PLAYER_DEAL							Diplomacy
NOTIFICATION_PLAYER_DEAL_RECEIVED					Diplomacy
NOTIFICATION_PLAYER_DEAL_RESOLVED					Diplomacy
NOTIFICATION_PROJECT_COMPLETED						ProjectConstructed		Project

NOTIFICATION_TECH									Tech
NOTIFICATION_PRODUCTION								Production
NOTIFICATION_FREE_TECH								FreeTech
NOTIFICATION_FREE_POLICY							FreePolicy
NOTIFICATION_FREE_GREAT_PERSON						FreeGreatPerson			FreeGreatPerson

NOTIFICATION_DENUNCIATION_EXPIRED					Diplomacy				Diplomacy
NOTIFICATION_FRIENDSHIP_EXPIRED						FriendshipX				FriendshipX

NOTIFICATION_FOUND_PANTHEON							FoundPantheon
NOTIFICATION_FOUND_RELIGION							FoundReligion
NOTIFICATION_PANTHEON_FOUNDED_ACTIVE_PLAYER			PantheonFounded			Religion
NOTIFICATION_PANTHEON_FOUNDED						PantheonFounded			Religion
NOTIFICATION_RELIGION_FOUNDED_ACTIVE_PLAYER			ReligionFounded			Religion
NOTIFICATION_RELIGION_FOUNDED						ReligionFounded			Religion
NOTIFICATION_ENHANCE_RELIGION						EnhanceReligion			Religion
NOTIFICATION_RELIGION_ENHANCED_ACTIVE_PLAYER		ReligionEnhanced		Religion
NOTIFICATION_RELIGION_ENHANCED						ReligionEnhanced		Religion
NOTIFICATION_RELIGION_SPREAD						ReligionSpread			Religion
NOTIFICATION_RELIGION_SPREAD_NATURAL				ReligionNaturalSpread	Religion
NOTIFICATION_REFORMATION_BELIEF_ADDED_ACTIVE_PLAYER	ReformationBeliefAdded	Religion
NOTIFICATION_REFORMATION_BELIEF_ADDED				ReformationBeliefAdded	Religion
NOTIFICATION_ADD_REFORMATION_BELIEF					AddReformationBelief
NOTIFICATION_CAN_BUILD_MISSIONARY					EnoughFaith				AutomaticFaith
NOTIFICATION_AUTOMATIC_FAITH_PURCHASE_STOPPED		AutomaticFaithStop		AutomaticFaith

NOTIFICATION_INTRIGUE_BUILDING_SNEAK_ATTACK_ARMY						Spy	Spy
NOTIFICATION_INTRIGUE_BUILDING_SNEAK_ATTACK_AMPHIBIOUS					Spy	Spy
NOTIFICATION_INTRIGUE_SNEAK_ATTACK_ARMY_AGAINST_KNOWN_CITY_UNKNOWN		Spy	Spy
NOTIFICATION_INTRIGUE_SNEAK_ATTACK_ARMY_AGAINST_KNOWN_CITY_KNOWN		Spy	Spy
NOTIFICATION_INTRIGUE_SNEAK_ATTACK_ARMY_AGAINST_YOU_CITY_UNKNOWN		Spy	Spy
NOTIFICATION_INTRIGUE_SNEAK_ATTACK_ARMY_AGAINST_YOU_CITY_KNOWN			Spy	Spy
NOTIFICATION_INTRIGUE_SNEAK_ATTACK_ARMY_AGAINST_UNKNOWN					Spy	Spy
NOTIFICATION_INTRIGUE_SNEAK_ATTACK_AMPHIB_AGAINST_KNOWN_CITY_UNKNOWN	Spy	Spy
NOTIFICATION_INTRIGUE_SNEAK_ATTACK_AMPHIB_AGAINST_KNOWN_CITY_KNOWN		Spy	Spy
NOTIFICATION_INTRIGUE_SNEAK_ATTACK_AMPHIB_AGAINST_YOU_CITY_UNKNOWN		Spy	Spy
NOTIFICATION_INTRIGUE_SNEAK_ATTACK_AMPHIB_AGAINST_YOU_CITY_KNOWN		Spy	Spy
NOTIFICATION_INTRIGUE_SNEAK_ATTACK_AMPHIB_AGAINST_UNKNOWN				Spy	Spy
NOTIFICATION_INTRIGUE_CONSTRUCTING_WONDER								Spy	Spy

NOTIFICATION_SPY_CREATED_ACTIVE_PLAYER				NewSpy				Spy
NOTIFICATION_SPY_STOLE_TECH							StealTech
NOTIFICATION_SPY_CANT_STEAL_TECH					SpyCannotSteal		SpyCannotSteal
NOTIFICATION_SPY_EVICTED							Spy					Spy
NOTIFICATION_TECH_STOLEN_SPY_DETECTED				Spy					Spy
NOTIFICATION_TECH_STOLEN_SPY_IDENTIFIED				Spy					Spy
NOTIFICATION_SPY_KILLED_A_SPY						SpyKilledASpy		Spy
NOTIFICATION_SPY_WAS_KILLED							SpyWasKilled		Spy
NOTIFICATION_SPY_REPLACEMENT						Spy					Spy
NOTIFICATION_SPY_PROMOTION							SpyPromotion		SpyPromotion
NOTIFICATION_INTRIGUE_DECEPTION						Spy					Spy

NOTIFICATION_SPY_RIG_ELECTION_SUCCESS				Spy					Spy
NOTIFICATION_SPY_RIG_ELECTION_FAILURE				Spy					Spy
NOTIFICATION_SPY_RIG_ELECTION_ALERT					Spy					Spy
NOTIFICATION_SPY_YOU_STAGE_COUP_SUCCESS				Spy					Spy
NOTIFICATION_SPY_YOU_STAGE_COUP_FAILURE				SpyWasKilled		Spy
NOTIFICATION_SPY_STAGE_COUP_SUCCESS					Spy					Spy
NOTIFICATION_SPY_STAGE_COUP_FAILURE					Spy					Spy
NOTIFICATION_DIPLOMAT_EJECTED						Diplomat			Spy

NOTIFICATION_OTHER_PLAYER_NEW_ERA					NewEra				NewEra
NOTIFICATION_MAYA_LONG_COUNT						FreeGreatPerson		FreeGreatPerson
NOTIFICATION_FAITH_GREAT_PERSON						FreeGreatPerson		FreeGreatPerson

NOTIFICATION_EXPANSION_PROMISE_EXPIRED				Diplomacy			Diplomacy
NOTIFICATION_BORDER_PROMISE_EXPIRED					Diplomacy			Diplomacy

NOTIFICATION_TRADE_ROUTE							TradeRoute			TradeRoute
NOTIFICATION_TRADE_ROUTE_BROKEN						TradeRouteBroken	TradeRouteBroken

NOTIFICATION_MINOR_BUYOUT							CityStateBuyout

NOTIFICATION_REQUEST_RESOURCE						RequestResource		RequestResource

NOTIFICATION_LEAGUE_CALL_FOR_PROPOSALS				LeagueCallForProposals

NOTIFICATION_CHOOSE_ARCHAEOLOGY						ChooseArchaeology
NOTIFICATION_LEAGUE_CALL_FOR_VOTES					LeagueCallForVotes

NOTIFICATION_GREAT_WORK_COMPLETED_ACTIVE_PLAYER		GreatWork

NOTIFICATION_LEAGUE_VOTING_DONE						LeagueVoting
NOTIFICATION_LEAGUE_VOTING_SOON						LeagueVoting		LeagueVoting

NOTIFICATION_CULTURE_VICTORY_SOMEONE_INFLUENTIAL		CultureVictoryNegative	CultureVictory
NOTIFICATION_CULTURE_VICTORY_WITHIN_TWO					CultureVictoryNegative	CultureVictory
NOTIFICATION_CULTURE_VICTORY_WITHIN_TWO_ACTIVE_PLAYER	CultureVictoryPositive	CultureVictory
NOTIFICATION_CULTURE_VICTORY_WITHIN_ONE					CultureVictoryNegative	CultureVictory
NOTIFICATION_CULTURE_VICTORY_WITHIN_ONE_ACTIVE_PLAYER	CultureVictoryPositive	CultureVictory
NOTIFICATION_CULTURE_VICTORY_NO_LONGER_INFLUENTIAL		CultureVictoryNegative	CultureVictory

NOTIFICATION_CHOOSE_IDEOLOGY							ChooseIdeology
NOTIFICATION_IDEOLOGY_CHOSEN							IdeologyChosen			IdeologyChosen

NOTIFICATION_LIBERATED_MAJOR_CITY						CapitalRecovered		CapitalRecovered
NOTIFICATION_RESURRECTED_MAJOR_CIV						CapitalRecovered		CapitalRecovered

NOTIFICATION_PLAYER_RECONNECTED							PlayerReconnected		Network
NOTIFICATION_PLAYER_DISCONNECTED						PlayerDisconnected		Network
NOTIFICATION_TURN_MODE_SEQUENTIAL						SequentialTurns			Network
NOTIFICATION_TURN_MODE_SIMULTANEOUS						SimultaneousTurns		Network
NOTIFICATION_HOST_MIGRATION								HostMigration			Network
NOTIFICATION_PLAYER_CONNECTING							PlayerConnecting		Network
NOTIFICATION_PLAYER_KICKED								PlayerKicked			Network

NOTIFICATION_CITY_REVOLT_POSSIBLE						GenericRed
NOTIFICATION_CITY_REVOLT								GenericRed

NOTIFICATION_LEAGUE_PROJECT_COMPLETE					LeagueProject
NOTIFICATION_LEAGUE_PROJECT_PROGRESS					LeagueProject

NOTIFICATION_EVENT_CHOICE_CITY							CityEventChoice
NOTIFICATION_EVENT_CHOICE								EventChoice
NOTIFICATION_INSTANT_YIELD								InstantYield			InstantYield
NOTIFICATION_PRODUCTION_COST_MODIFIERS_FROM_RESOURCES	BonusResource			BonusResourceModifier

]]):gmatch("(%S+)[^%S\n\r]*(%S*)[^%S\n\r]*(%S*)[^\n\r]*") do
	notificationType = NotificationTypes[notificationType]
	if notificationType then
		_tNotificationNames[ notificationType ] = name
		local n = Controls[ name ] and name or group ~= "" and group
		if n then
			_tNotificationGroupNames[ notificationType ] = n
			_tNotificationGroups[ n ] = {}
		end
	end
end

--==========================================================
-- Icon Notification Textures
--==========================================================
for alias,				name, 		texture1,									texture2
in ([[
Generic					Generic		NotificationGeneric.dds						NotificationGenericGlow.dds
SocialPolicy			Generic		SocialPolicy80.dds							SocialPolicyActive80.dds
CityCanBombard			Generic		NotificationCityCanBombard80.dds			NotificationCityCanBombardGlow80.dds
Barbarian				GenericRed	NotificationBarbarian.dds					NotificationBarbarianGlow.dds
AncientRuins			Generic		NotificationAncientRuins.dds				NotificationAncientRuinsGlow.dds
GoldenAge				Generic		NotificationGoldenAge.dds					NotificationGoldenAgeGlow.dds
CityGrowth				Generic		NotificationCityGrowth.dds					NotificationCityGrowthGlow.dds
CityStarving			GenericRed	NotificationRed.dds							NotificationCityGrowthRed.dds
CityStarves				GenericRed	NotificationCityGrowthRed.dds				NotificationCityGrowthRedGlow.dds
ReligionFounded			Generic		NotificationReligion80.dds					NotificationReligionGlow80.dds
PantheonFounded			Generic		NotificationPantheon80.dds					NotificationPantheonGlow80.dds
ReligionEnhanced		Generic		NotificationEnhanceReligion80.dds			NotificationEnhanceReligionGlow80.dds
ReligionSpread			Generic		NotificationSpreadReligionForced80.dds		NotificationSpreadReligionForcedGlow80.dds
ReligionNaturalSpread	Generic		NotificationSpreadReligion80.dds			NotificationSpreadReligionGlow80.dds
ReformationBeliefAdded	Generic		NotificationReformationBeliefAdded80.dds	NotificationReformationBeliefAddedGlow80.dds
EnoughFaith				Generic		NotificationIconsFaith80.dds				NotificationIconsFaithGlow80.dds
AutomaticFaithStop		Generic		NotificationFaithStopped80.dds				NotificationFaithStoppedGlow80.dds

Spy						Generic		EspionageSpyIcons80_Expansion.dds			NotificationSpyGlow80.dds
NewSpy					Generic		NotificationIconsSpyNew80.dds				NotificationIconsSpyNewGlow80.dds
SpyKilledASpy			Generic		NotificationIconsSpyKilled80.dds			NotificationIconsSpyKilledGlow80.dds
SpyWasKilled			GenericRed	NotificationIconsRedSpyKilled.dds			NotificationIconsRedSpyKilledGlow2.dds
Diplomat				Generic		NotificationDiplomat80.dds					NotificationDiplomatGlow80.dds
NewEra					Generic		NotificationIconsNewEra80_Expansion.dds		NotificationIconsNewEraGLow80.dds
TradeRoute				Generic		NotificationTradeRoute80.dds				NotificationTradeRouteGlow80.dds
TradeRouteBroken		GenericRed	NotificationTradeRouteCanceled80.dds		NotificationTradeRouteCanceledGlow80.dds

CityStateBuyout			GenericRed	NotificationDiploMarriage80.dds				NotificationDiploMarriageGlow80.dds
LeagueVoting			Generic		NotificationIconsWCVote80.dds				NotificationIconsWCVoteGlow80.dds
CultureVictoryPositive	Generic		NotificationIconsInfluenceGained80.dds		NotificationIconsInfluenceGainedGlow80.dds
CultureVictoryNegative	GenericRed	NotificationInfluenceLost80.dds				NotificationInfluenceLostGlow80.dds
IdeologyChosen			Generic		IdeologyPortrait80.dds						IdeologyPortraitGlow80.dds
LeagueProject			Generic		NotificationIconsInternationalProject80.dds	NotificationIconsInternationalProjectGlow80.dds

PlayerReconnected		Generic		NotificationIconsMP_PConnected80.dds		NotificationIconsMP_PConnectedGlow80.dds
PlayerDisconnected		GenericRed	NotificationPlayerDisconnected80.dds		NotificationPlayerDisconnectedGlow80.dds
SequentialTurns			Generic		NotificationIconsMP_Sequential80.dds		NotificationIconsMP_SequentialGlow80.dds
SimultaneousTurns		Generic		NotificationIconsMP_Simultaneous80.dds		NotificationIconsMP_SimultaneousGlow80.dds
HostMigration			GenericRed	NotificationIconsMP_NewGameHost80.dds		NotificationIconsMP_NewGameHostGlow80.dds
PlayerConnecting		Generic		NotificationIconsMP_PConnecting80.dds		NotificationIconsMP_PConnectingGlow80.dds
PlayerKicked			GenericRed	NotificationPlayerBooted80.dds				NotificationPlayerBootedGlow80.dds

BonusResource			Resource	blank.dds
LuxuryResource			Resource	NotificationHappyFace.dds
StrategicResource		Resource	NotificationStrategic.dds
RequestResource			Resource	NotificationCitizenSmall.dds
DemandResource			Resource	CheckX.dds

GenericNaturalWonder	Generic		NotificationNaturalWonder.dds				NotificationNaturalWonderGlow.dds

InstantYield			Generic		InstantYieldNotification80.dds				InstantYieldNotificationGlow80.dds
]]):gmatch("(%S+)[^%S\n\r]*(%S*)[^%S\n\r]*(%S*)[^%S\n\r]*(%S*)[^\n\r]*") do
	for notificationType, v in pairs( _tNotificationNames ) do
		if v == alias then
			_tNotificationNames[ notificationType ] = name
			_tNotificationTexture1[ notificationType ] = texture1
			_tNotificationTexture2[ notificationType ] = texture2
		end
	end
end

--for k,v in pairs(NotificationTypes) do print( k, v, _tNotificationNames[v], _tNotificationGroupNames[v], _tNotificationTexture1[v], _tNotificationTexture2[v] ) end

--==========================================================
-- Utilities
--==========================================================
local function SetEndTurnFlashing( eFlashingState )
	Controls.EndTurnButtonEndTurnAlpha:SetHide( eFlashingState ~= FLASHING_END_TURN )
	Controls.EndTurnButtonScienceAlpha:SetHide( eFlashingState ~= FLASHING_SCIENCE )
	Controls.EndTurnButtonFreeTechAlpha:SetHide( eFlashingState ~= FLASHING_FREE_TECH )
	Controls.EndTurnButtonProductionAlpha:SetHide( eFlashingState ~= FLASHING_PRODUCTION )
	Controls.EndTurnButtonMouseOverAlpha:SetHide( eFlashingState == FLASHING_END_TURN )
end

local function GotoPlot( plot, s )
	if plot and not _iLeaderMode then
		UI.LookAt( plot )
		local hex = ToHexFromGrid{ x=plot:GetX(), y=plot:GetY() }
		if s then
			Events.AddPopupTextEvent( HexToWorld( hex ), s )
		end
		return Events.GameplayFX( hex.x, hex.y, -1 )
	end
end

local function GotoUnit( unit, ... )
	if unit then
		UI.SelectUnit( unit )
		return GotoPlot( unit:GetPlot(), ... )
	end
end

local function GotoFirstReadyUnit( player, b )
	local unit = UI.GetHeadSelectedUnit()
	if b or GetAutoUnitCycle() then
		if not unit or unit:IsAutomated() or unit:IsDelayedDeath() or not unit:IsReadyToMove() then
			unit = player:GetFirstReadyUnit()
		elseif not b then
			return
		end
	end
	if unit then
		return GotoUnit( unit, b and unit:GetName() ) --ToLower"TXT_KEY_UNIT_NEEDS_ORDERS" )
	end
end

local function GetNotificationStr()
	local player = Players[GetActivePlayer()]
	local iBlockingNotificationIndex = player:GetEndTurnBlockingNotificationIndex()
	for i = player:GetNumNotifications() - 1, 0, -1 do
		if player:GetNotificationIndex(i) == iBlockingNotificationIndex then
			return player:GetNotificationSummaryStr(i), player:GetNotificationStr(i)
		end
	end
end

--==========================================================
-- Map Notifications
--==========================================================
do
	local sForestCreated = "[COLOR_POSITIVE_TEXT]"..L"TXT_KEY_FEATURE_FOREST"
	local sJungleCreated = "[COLOR_POSITIVE_TEXT]"..L"TXT_KEY_FEATURE_JUNGLE"
	local sForestRemoved = "[COLOR_NEGATIVE_TEXT]"..L"TXT_KEY_FEATURE_FOREST" --"TXT_KEY_BUILD_REMOVE_FOREST"
	local sJungleRemoved = "[COLOR_NEGATIVE_TEXT]"..L"TXT_KEY_FEATURE_JUNGLE" --"TXT_KEY_BUILD_REMOVE_JUNGLE"
	local sRoadRemoved = "[COLOR_NEGATIVE_TEXT]"..L"TXT_KEY_ROUTE_ROAD"

	local function ChangeFeature( hexX, hexY, s, f, ... )
		local plot = GetPlot( ToGridFromHex( hexX, hexY ) )
		if plot and plot:IsActiveVisible() then
			if f then
				s = f( plot, ... )
			end
			if s then
				Events.AddPopupTextEvent( HexToWorld( { x=hexX, y=hexY } ), tostring(s), 0.4 )
			end
		end
	end
	local function ChangeImprovement( plot, eImprovement )
		local row = GameInfo.Improvements[ eImprovement ]
		if row then
			if plot:IsImprovementPillaged() then
				return "[COLOR_NEGATIVE_TEXT]"..tostring(row._Name)
			elseif plot:GetRevealedImprovementType( GetActiveTeam() ) == eImprovement then
				return "[COLOR_POSITIVE_TEXT]"..tostring(row._Name)
			end
		end
	end
	local function ChangeRoad( plot )
		local row = GameInfo.Routes[ plot:GetRevealedRouteType( GetActiveTeam() ) ]
		if row then
			if plot:IsRoutePillaged() then
				return "[COLOR_NEGATIVE_TEXT]"..tostring(row._Name)
			else
				return "[COLOR_POSITIVE_TEXT]"..tostring(row._Name)
			end
		end
	end
	Events.SerialEventImprovementIconCreated.Add( function( hexX, hexY, eImprovement, eRawResource, eImprovementState ) -- eImprovementState = 1(AnyState) | 2(Under Construction) | 4(Constructed) | 8(Pillaged)
		return ChangeFeature( hexX, hexY, nil, ChangeImprovement, eImprovement )
	end)
	Events.SerialEventForestCreated.Add( function( hexX, hexY )
		return ChangeFeature( hexX, hexY, sForestCreated )
	end)
	Events.SerialEventJungleCreated.Add( function( hexX, hexY )
		return ChangeFeature( hexX, hexY, sJungleCreated )
	end)
	Events.SerialEventForestRemoved.Add( function( hexX, hexY )
		return ChangeFeature( hexX, hexY, sForestRemoved )
	end)
	Events.SerialEventJungleRemoved.Add( function( hexX, hexY )
		return ChangeFeature( hexX, hexY, sJungleRemoved )
	end)
	Events.SerialEventRoadCreated.Add( function( hexX, hexY, iPlayer, iRoadStatus )
		return ChangeFeature( hexX, hexY, nil, ChangeRoad )
	end)
	Events.SerialEventRoadDestroyed.Add( function( hexX, hexY ) --??, iPlayer, iRoadStatus )
		return ChangeFeature( hexX, hexY, sRoadRemoved )
	end)
end

--==========================================================
-- Stack Sizes for Notification and Civilization Icons
--==========================================================
local function ProcessStackSizes( resetCivPanelElevator )

	local maxTotalStackHeight, smallStackHeight
	if _iLeaderMode then
		maxTotalStackHeight = _iScreenHeight
		smallStackHeight = 0
	else
		Controls.BigStack:CalculateSize()
		_cSmallStack:CalculateSize()
		maxTotalStackHeight = _iMaxTotalStackHeight - Controls.BigStack:GetSizeY()
		smallStackHeight = _cSmallStack:GetSizeY()
	end

	if _bCivilizationRibbon then
		Controls.MinorStack:CalculateSize()
		Controls.MajorStack:CalculateSize()
		Controls.CivStack:CalculateSize()
		local halfTotalStackHeight = floor(maxTotalStackHeight / 2)
		local civStackHeight = Controls.CivStack:GetSizeY()

		if smallStackHeight + civStackHeight <= maxTotalStackHeight then
			halfTotalStackHeight = false
		elseif civStackHeight <= halfTotalStackHeight then
			smallStackHeight = maxTotalStackHeight - civStackHeight
			halfTotalStackHeight = false
		elseif smallStackHeight <= halfTotalStackHeight then
			civStackHeight = maxTotalStackHeight - smallStackHeight
		else
			civStackHeight = halfTotalStackHeight
			smallStackHeight = halfTotalStackHeight
		end

		Controls.CivScrollPanel:SetHide( not halfTotalStackHeight )
		if halfTotalStackHeight then
			Controls.CivStack:ChangeParent( Controls.CivScrollPanel )
			Controls.CivScrollPanel:SetSizeY( civStackHeight )
			Controls.CivScrollPanel:CalculateInternalSize()
			if resetCivPanelElevator then
				Controls.CivScrollPanel:SetScrollValue( 0 )
			end
		else
			Controls.CivStack:ChangeParent( Controls.CivPanel )
		end
		Controls.CivPanel:ReprocessAnchoring()
		Controls.DarkBorders:SetSizeY( civStackHeight + _iCivPanelOffsetY )
--		Controls.CivPanel:SetSizeY( civStackHeight )
	else
		smallStackHeight = min( smallStackHeight, maxTotalStackHeight )
	end

	if not _iLeaderMode then
		Controls.SmallScrollPanel:SetSizeY( smallStackHeight )
		Controls.SmallScrollPanel:ReprocessAnchoring()
		Controls.SmallScrollPanel:CalculateInternalSize()
		if Controls.SmallScrollPanel:GetRatio() < 1 then
			Controls.SmallScrollPanel:SetOffsetX( 18 )
		else
			Controls.SmallScrollPanel:SetOffsetX( 0 )
		end
		Controls.OuterStack:CalculateSize()
		Controls.OuterStack:ReprocessAnchoring()
	end
end

--==========================================================
-- Setup Notifications
--==========================================================

local _tNotificationControls = {
	UnitIcon = function( control, notification )
		local portraitOffset, portraitAtlas = UI.GetUnitPortraitIcon( notification.Data1, notification.PlayerID )
		return IconHookup( portraitOffset, 80, portraitAtlas, control )
	end,
	BuildingIcon = function( control, notification )
		local row = GameInfo.Buildings[ notification.Data1 ] or {}
		return IconHookup( row.PortraitIndex, 80, row.IconAtlas, control )
	end,
	ResourceIcon = function( control, notification )
		local row = GameInfo.Resources[ notification.Data1 ] or {}
		return IconHookup( row.PortraitIndex, 80, row.IconAtlas, control )
	end,
	FeatureIcon = function( control, notification )
		local row = GameInfo.Features[ notification.Data1 ] or {}
		return IconHookup( row.PortraitIndex, 80, row.IconAtlas, control )
	end,
	ProjectIcon = function( control, notification )
		local row = GameInfo.Projects[ notification.Data1 ] or {}
		return IconHookup( row.PortraitIndex, 80, row.IconAtlas, control )
	end,
	TechIcon = function( control, notification )
		local row = GameInfo.Technologies[ notification.Data2 ] or {}
		return IconHookup( row.PortraitIndex, 80, row.IconAtlas, control )
	end,
	Civ1Icon = function( control, notification, instance )
		CivIconHookup( notification.Data1, 45, control, instance.Civ1IconBG, instance.Civ1IconShadow )
		local team = Teams[ notification.Data2 ]
		return CivIconHookup( team and team:GetLeaderID(), 45, instance.Civ2Icon, instance.Civ2IconBG, instance.Civ2IconShadow )
	end,
	CivIcon1 = function( control, notification, instance )
		return CivIconHookup( notification.Data1, 80, control, instance.CivIconBG, instance.CivIconShadow )
	end,
	CivIcon2 = function( control, notification, instance )
		return CivIconHookup( notification.Data2, 45, control, instance.CivIconBG, instance.CivIconShadow )
	end,
	TileIcon2 = function( control, notification, instance )
		local plot = GetPlotByIndex( notification.Data1 )
		local row, terrainInfo, texture, s
		if plot then
			terrainInfo = GameInfo.Terrains[plot:GetTerrainType()]
			instance.TileIcon1:SetTextureSizeVal( 256, 256 )
			row = GameInfo.Resources[plot:GetResourceType( _iActiveTeam )]
			texture = row and row._Texture
			if texture then
				control:SetTextureSizeVal( 196, 196 )
				control:SetTextureOffsetVal( 30, 30 )
				s = row.ResourceUsage==1 and plot:GetNumResource()
			else
				control:SetTextureSizeVal( 256, 256 )
				control:SetTextureOffsetVal( 0, 0 )
				texture = GameInfo.Features[plot:GetFeatureType()]
				texture = texture and texture._Texture or plot:IsMountain() and "sv_mountains.dds" or plot:IsHills() and "sv_hills.dds"
			end
		end
		instance.TileIcon1:SetTexture( terrainInfo and terrainInfo._Texture or "blank.dds" )
		control:SetTexture( texture or "blank.dds" )
		instance.TileResourceCount:SetText( s )
	end,
	Texture1 = function( control, notification )
		control:SetTexture( _tNotificationTexture1[notification.Type] or "NotificationGeneric.dds" )
	end,
	Texture2 = function( control, notification )
		control:SetTexture( _tNotificationTexture2[notification.Type] or "NotificationGenericGlow.dds" )
	end,
	FingerTitle = function( control, notification )
		control:SetText( notification.Summary )
	end
}

local function SetupNotificationDisplay( instance, notification )
	if instance then
		local control
		for k, f in pairs( _tNotificationControls ) do
			control = instance[k]
			if control then
				f( control, notification, instance )
			end
		end
	end
end

local function SetupNotificationTooltip( instance, notificationGroup )
	if instance and notificationGroup then
		local tips = {}
		local n = #notificationGroup
		local sequence = notificationGroup.Sequence
		local notification, sSummary, sToolTip
		for i = 1, n do
			notification = notificationGroup[i]
			sSummary = notification.Summary
			if i == sequence then
				insert( tips, n==1 and sSummary or (i..") "..sSummary) )
				sToolTip = notification.ToolTip
				if sToolTip ~= sSummary then
					insert( tips, sToolTip )
				end
			else
				insert( tips, "[COLOR_LIGHT_GREY]"..i..") "..sSummary.."[ENDCOLOR]" )
			end
		end
		instance.Button:SetToolTipString( concat( tips, "[NEWLINE]" ) )
	end
end

--==========================================================
-- Notification Click Handlers
--==========================================================

local function SelectCity( notification )
	local player = Players[ notification.PlayerID ]
	local city = player and player:GetCityByID( notification.Data1 )
	if city then
		UI.DoSelectCityAtPlot( city:Plot() )
		Events.AddPopupTextEvent( HexToWorld( ToHexFromGrid{ x=city:GetX(), y=city:GetY() } ), notification.Summary )
--		return GotoPlot( city:Plot(), notification.Summary )
	end
end

local g_ActivateNotification = {
	[ NotificationTypes.NOTIFICATION_MINOR_QUEST or -1 ] = function( notification )
		-- Special kludge to work around DLL's nuisance city state popups
		local minorPlayer = Players[ notification.Data1 ]
		if minorPlayer then
			local city = minorPlayer:GetCapitalCity()
			local plot = city and city:Plot()
			if notification.Summary == L( "TXT_KEY_NOTIFICATION_SUMMARY_QUEST_KILL_CAMP", minorPlayer:GetCivilizationShortDescriptionKey() ) then --MINOR_CIV_QUEST_KILL_CAMP
				plot = GetPlot( minorPlayer:GetQuestData1( _iActivePlayer, MINOR_CIV_QUEST_KILL_CAMP ), minorPlayer:GetQuestData2( _iActivePlayer, MINOR_CIV_QUEST_KILL_CAMP ) ) or plot
			end
			GotoPlot( plot, notification.Summary )
		end
	end,
	[ NotificationTypes.NOTIFICATION_CITY_GROWTH or -1 ] = SelectCity,
	[ NotificationTypes.NOTIFICATION_CITY_REVOLT_POSSIBLE or -1 ] = SelectCity,
	[ NotificationTypes.NOTIFICATION_UNIT_PROMOTION or -1 ] = function( notification )
		local player = Players[ notification.PlayerID ]
		if player then
			local unit = player:GetUnitByID( notification.Data2 )
			if unit then
				GotoUnit( unit, notification.Summary )
			end
		end
	end,
}

local function ActivateNotification( Id )
	local notification = _tActiveNotifications[ Id ]
	local activateNotification = notification and g_ActivateNotification[ notification.Type ]
--print("ActivateNotification", Id, notification, activateNotification)
	if activateNotification then
		activateNotification( notification )
	else
		UI.ActivateNotification( Id )
	end
end

local function NotificationLeftClick( Id )
--print( "NotificationLeftClick1", Id )
	if UserInterfaceSettings.NotificationAutoDismiss ~= 0 then
		ActivateNotification( Id )
		UI.RemoveNotification( Id )
		local b
		for i = _pActivePlayer:GetNumNotifications() - 1, 0, -1 do
			if _pActivePlayer:GetNotificationIndex(i) == Id then
				b = _pActivePlayer:GetNotificationDismissed( i )
				break
			end
		end
--print( "NotificationLeftClick2", Id , b )
		if b then return end
	end
	local notificationGroup = _tActiveNotificationGroups[ Id ]
	if notificationGroup then
		local n = #notificationGroup
		if n > 1 then
			local sequence = notificationGroup.Sequence % n + 1
			notificationGroup.Sequence = sequence
			local notification = notificationGroup[ sequence ]
			local instance = notificationGroup.Instance
			SetupNotificationDisplay( instance, notification )
			Id = notification.Id
			instance.Button:SetVoid1( Id )
			SetupNotificationTooltip( instance, notificationGroup )
		end
	end
--print( "NotificationLeftClick3", Id )
	if UserInterfaceSettings.NotificationAutoDismiss == 0 then
		return ActivateNotification( Id )
	end
end

local function NotificationRightClick ( Id )
	if UI.CtrlKeyDown() then --UI.ShiftKeyDown() or UI.AltKeyDown() or 
		local notificationGroup = _tActiveNotificationGroups[ Id ]
		if notificationGroup and #notificationGroup > 0 then
			local t = {}
			for _, notification in ipairs(notificationGroup) do
				insert( t, notification.Id )
			end
			for _, Id in pairs(t) do
				UI.RemoveNotification( Id )
			end
			return
		end
	end
	UI.RemoveNotification( Id )
end

for Id, button in pairs( _tNotificationNames ) do
	button = Controls[ button ]
	if button and button.ClearCallback then
		button:RegisterCallback( Mouse.eLClick, NotificationLeftClick )
		button:RegisterCallback( Mouse.eRClick, NotificationRightClick )
		if UI.IsTouchScreenEnabled() then
			button:RegisterCallback( Mouse.eLDblClick, NotificationRightClick )
		end
		button:SetVoid1( Id )
	end
end

--==========================================================
-- Add Notification
--==========================================================
Events.NotificationAdded.Add(
function( Id, iType, sToolTip, sSummary, Data1, Data2, iPlayer )

--print( "NotificationAdded", Id, iType, sToolTip, sSummary, Data1, Data2, iPlayer )
	if not _tActiveNotifications[ Id ] then
		local name = _tNotificationNames[ iType ] or "Generic"
		local notificationGroup = _tNotificationGroups[ _tNotificationGroupNames[ iType ] ] or {}
		local notification = { Id = Id, Type = iType, ToolTip = sToolTip, Summary = sSummary, Data1 = Data1, Data2 = Data2, PlayerID = iPlayer }
		insert( notificationGroup, notification )
		_tActiveNotificationGroups[ Id ] = notificationGroup
		_tActiveNotifications[ Id ] = notification
		local instance = notificationGroup.Instance
		if not instance then
			local button = Controls[ name ]
			if button then
				button:SetHide( false )
				instance = { Button = button }
			else
				instance = _tSpareNotifications[ name ]
				instance = instance and remove( instance )
				if instance then
					instance.Container:ChangeParent( _cSmallStack )
					button = instance.Button
				else
					instance = {}
					ContextPtr:BuildInstanceForControl( name, instance, _cSmallStack )
					instance.Name = name
					button = instance.Button
					button:RegisterCallback( Mouse.eLClick, NotificationLeftClick )
					button:RegisterCallback( Mouse.eRClick, NotificationRightClick )
					if UI.IsTouchScreenEnabled() then
						button:RegisterCallback( Mouse.eLDblClick, NotificationRightClick )
					end
				end
				instance.Container:BranchResetAnimation()
				SetupNotificationDisplay( instance, notification )
			end
			button:SetVoid1( Id )
			notificationGroup.Instance = instance
			notificationGroup.Sequence = 1
		end
		SetupNotificationTooltip( instance, notificationGroup )
		return ProcessStackSizes( true )
	end
end)

--==========================================================
-- Activate Notification
--==========================================================
Events.NotificationActivated.Add(
function( Id, iType, sToolTip, x , y, _, iPlayer )
--print( "NotificationActivated1", Id, iType, sToolTip, x , y, _, iPlayer )
	local notification = _tActiveNotifications[ Id ]
	if notification then
		local plot = GetPlot( x, y )
		local sSummary = tostring(notification.Summary)
		if plot then
--print( "NotificationActivated2", plot )
			return Events.AddPopupTextEvent( HexToWorld( ToHexFromGrid{ x=x, y=y } ), sSummary )
		else
			local index = 9999
			local bias = 0
			local p
			local s = sSummary .. sToolTip
			local function SearchName( ss )
				local i = s:find( ss )
				if i and i + bias < index then
					index = i + bias
					plot = p
				end
			end
			local function SearchCities( player )
				if player and player:IsAlive() then
					for city in player:Cities() do
						p = city:Plot()
						if p:IsRevealed( GetActiveTeam() ) then
							SearchName( city:GetName() )
						end
					end
				end
			end
			for _, player in ipairs( Players ) do
				if player:IsAlive() then
					bias = player:IsMinorCiv() and 0 or 99
					SearchCities( player )
					p = player:GetCapitalCity()
					p = p and p:Plot()
					if p and p:IsRevealed( GetActiveTeam() ) then
						SearchName( player:GetCivilizationShortDescription() )
						SearchName( player:GetName() )
					end
				end
			end
--print( "NotificationActivated3", plot )
			if plot and plot:IsRevealed( GetActiveTeam() ) then
				return GotoPlot( plot, sSummary )
			end
			_bAlertMessages = false
			return Events.GameplayAlertMessage( sToolTip )
		end
	end
end)

--==========================================================
-- Remove Notification
--==========================================================
local function RemoveNotificationID( Id )

	local notificationGroup = _tActiveNotificationGroups[ Id ]
	_tActiveNotifications[ Id ] = nil
	_tActiveNotificationGroups[ Id ] = nil
	if notificationGroup then
		local n = #notificationGroup
		for i = 1, n do
			-- Remove bundle item which corresponds to Id
			if notificationGroup[i].Id == Id then
				remove( notificationGroup, i )
				n = n-1
				break
			end
		end
		local instance = notificationGroup.Instance
		-- Is group now empty ?
		if n < 1 then
			notificationGroup.Instance = nil
			local name = instance.Name
			if name then
				local spares = _tSpareNotifications[ name ]
				if not spares then
					spares = {}
					_tSpareNotifications[ name ] = spares
				end
				insert( spares, instance )
				instance.Container:ChangeParent( _cRecycleBin )
			else
				instance.Button:SetHide( true )
			end
		-- Update notification group
		else
			local sequence = notificationGroup.Sequence
			if sequence > n then
				sequence = 1
				notificationGroup.Sequence = 1
			end
			local notification = notificationGroup[ sequence ]
			instance.Button:SetVoid1( notification.Id )
			SetupNotificationDisplay( instance, notification )
			return SetupNotificationTooltip( instance, notificationGroup )
		end
	end
end

Events.NotificationRemoved.Add(
function( Id ) --, iPlayer )

--print( "removing Notification " .. Id .. " " .. tostring( _tActiveNotificationGroups[ Id ] ) .. " " .. tostring( _tNotificationNames[ _tActiveNotificationGroups[ Id ] ] ) )
	RemoveNotificationID( Id )
	ProcessStackSizes()
end)

--==========================================================
-- Additional Notifications
--==========================================================
local function onSetPopulation( x, y, oldPopulation, newPopulation )
--print( "GameEvents.SetPopulation", x, y, oldPopulation, newPopulation )
	if newPopulation > 5			-- game engine already does up to 5 pop
		and newPopulation > oldPopulation	-- growth only
		and _pActivePlayer
	then
		local plot = GetPlot( x, y )
		local city = plot and plot:GetPlotCity()
		local iPlayer = city and city:GetOwner()
--print("Player#", iPlayer, "City:", city and city:GetName(), x, y, plot)
		if iPlayer
			and iPlayer == _iActivePlayer	-- active player only
			and not city:IsPuppet()			-- who cares ? nothing to be done
			and not city:IsResistance()		-- who cares ? nothing to be done
			and Game.GetGameTurn() > city:GetGameTurnAcquired() -- inhibit upon city creation & capture
		then
			_pActivePlayer:AddNotification( NotificationTypes.NOTIFICATION_CITY_GROWTH,
				L("TXT_KEY_NOTIFICATION_CITY_GROWTH", city:GetName(), newPopulation ),
				L("TXT_KEY_NOTIFICATION_SUMMARY_CITY_GROWTH", city:GetName() ), x, y, city:GetID() )
--print( "Notification sent:", NotificationTypes.NOTIFICATION_CITY_GROWTH, sTip, sTitle, x, y )
		end
	end
end
local function OnSetPopulation( ... )
	return pcall( onSetPopulation, ... )-- !!! GameEvents is bugged and must go through pcall
end

local function onCityBoughtPlot( iPlayer, cityID, x, y, isWithGold, isWithFaithOrCulture )
--print( "GameEvents.CityBoughtPlot", iPlayer, cityID, x, y, isWithGold, isWithFaithOrCulture )
	if isWithFaithOrCulture and iPlayer == _iActivePlayer and _pActivePlayer then
--print( "Border growth at coordinates: ", x, y, "iPlayer:", iPlayer, "isWithGold", isWithGold, "isWithFaithOrCulture", isWithFaithOrCulture )
		local plot = GetPlot( x, y )
		local city = _pActivePlayer:GetCityByID( cityID )
--print( "CityTileNotification:", city and city:GetName(), x, y, plot, city and city:GetCityPlotIndex(plot) )

		if plot and city and ( ( plot:GetWorkingCity() and not city:IsPuppet() ) or Game.GetResourceUsageType( plot:GetResourceType( _iActiveTeam ) ) > 0 )
		-- valid plot, either worked by city which is not a puppet, or has some kind of resource we can use
		then
			_pActivePlayer:AddNotification( NotificationTypes.NOTIFICATION_CITY_TILE,
				L( "TXT_KEY_NOTIFICATION_CITY_CULTURE_ACQUIRED_NEW_PLOT", city:GetName() ),
				L( "TXT_KEY_NOTIFICATION_SUMMARY_CITY_CULTURE_ACQUIRED_NEW_PLOT", city:GetName() ), x, y, plot:GetPlotIndex() )
--print( "CityTileNotification sent:", NotificationTypes.NOTIFICATION_CITY_TILE, city:GetName(), x, y )
		end
	end
end
local function OnCityBoughtPlot( ... )
	return pcall( onCityBoughtPlot, ... )-- !!! GameEvents is bugged and must go through pcall !!!
end

local function HookupNewNotifications()
--print("HookupNewNotifications")
	GameEvents.SetPopulation.Add( OnSetPopulation )
	GameEvents.CityBoughtPlot.Add( OnCityBoughtPlot )
end

--==========================================================
-- End Turn Button Handler
--==========================================================
local tEndTurnState = {
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_POLICY or -1] =
		{ FLASHING_END_TURN, L"TXT_KEY_CHOOSE_POLICY", L(Game.IsOption(GameInfoTypes.GAMEOPTION_POLICY_SAVING) and "TXT_KEY_NOTIFICATION_ENOUGH_CULTURE_FOR_POLICY_DISMISS" or "TXT_KEY_NOTIFICATION_ENOUGH_CULTURE_FOR_POLICY") },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_RESEARCH or -1] =
		{ FLASHING_SCIENCE, L"TXT_KEY_CHOOSE_RESEARCH", L"TXT_KEY_CHOOSE_RESEARCH_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_PRODUCTION or -1] =
		{ FLASHING_PRODUCTION, L"TXT_KEY_CHOOSE_PRODUCTION", L"TXT_KEY_CHOOSE_PRODUCTION_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_UNITS or -1] =
		{ NO_FLASHING, L"TXT_KEY_UNIT_NEEDS_ORDERS", L"TXT_KEY_UNIT_NEEDS_ORDERS_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_DIPLO_VOTE or -1] =
		{ FLASHING_END_TURN, L"TXT_KEY_DIPLO_VOTE", L"TXT_KEY_DIPLO_VOTE_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_MINOR_QUEST or -1] =
	function() -- civ vanilla only
		return FLASHING_END_TURN, GetNotificationStr()
	end,
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_FREE_TECH or -1] =
		{ FLASHING_FREE_TECH, L"TXT_KEY_CHOOSE_FREE_TECH", L"TXT_KEY_CHOOSE_FREE_TECH_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_STACKED_UNITS or -1] =
		{ FLASHING_END_TURN, L"TXT_KEY_MOVE_STACKED_UNIT", L"TXT_KEY_MOVE_STACKED_UNIT_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_UNIT_NEEDS_ORDERS or -1] =
		{ FLASHING_END_TURN, L"TXT_KEY_UNIT_NEEDS_ORDERS", L"TXT_KEY_UNIT_NEEDS_ORDERS_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_UNIT_PROMOTION or -1] =
		{ FLASHING_END_TURN, L"TXT_KEY_UNIT_PROMOTION", L"TXT_KEY_UNIT_PROMOTION_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_CITY_RANGE_ATTACK or -1] =
		{ FLASHING_END_TURN, L"TXT_KEY_CITY_RANGE_ATTACK", L"TXT_KEY_CITY_RANGE_ATTACK_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_FREE_POLICY or -1] =
		{ FLASHING_PRODUCTION, L"TXT_KEY_CHOOSE_POLICY", L"TXT_KEY_NOTIFICATION_FREE_POLICY" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_FREE_ITEMS or -1] =
	function()
		return FLASHING_PRODUCTION, GetNotificationStr()
	end,
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_FOUND_PANTHEON or -1] =
		{ FLASHING_PRODUCTION, L"TXT_KEY_NOTIFICATION_SUMMARY_ENOUGH_FAITH_FOR_PANTHEON", L"TXT_KEY_NOTIFICATION_ENOUGH_FAITH_FOR_PANTHEON" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_FOUND_RELIGION or -1] =
		{ FLASHING_PRODUCTION, L"TXT_KEY_NOTIFICATION_SUMMARY_FOUND_RELIGION", L"TXT_KEY_NOTIFICATION_FOUND_RELIGION" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_ENHANCE_RELIGION or -1] =
		{ FLASHING_PRODUCTION, L"TXT_KEY_NOTIFICATION_SUMMARY_ENHANCE_RELIGION", L"TXT_KEY_NOTIFICATION_ENHANCE_RELIGION" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_STEAL_TECH or -1] =
		{ FLASHING_FREE_TECH, L"TXT_KEY_NOTIFICATION_SPY_STEAL_BLOCKING", L"TXT_KEY_NOTIFICATION_SPY_STEAL_BLOCKING_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_MAYA_LONG_COUNT or -1] =
		{ FLASHING_FREE_TECH, L"TXT_KEY_NOTIFICATION_MAYA_LONG_COUNT", L"TXT_KEY_NOTIFICATION_MAYA_LONG_COUNT_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_FAITH_GREAT_PERSON or -1] =
		{ FLASHING_FREE_TECH, L"TXT_KEY_NOTIFICATION_FAITH_GREAT_PERSON", L"TXT_KEY_NOTIFICATION_FAITH_GREAT_PERSON_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_ADD_REFORMATION_BELIEF or -1] =
		{ FLASHING_PRODUCTION, L"TXT_KEY_NOTIFICATION_SUMMARY_ADD_REFORMATION_BELIEF", L"TXT_KEY_NOTIFICATION_ADD_REFORMATION_BELIEF" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_CHOOSE_ARCHAEOLOGY or -1] =
		{ FLASHING_PRODUCTION, L"TXT_KEY_NOTIFICATION_SUMMARY_CHOOSE_ARCHAEOLOGY", L"TXT_KEY_NOTIFICATION_CHOOSE_ARCHAEOLOGY" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_LEAGUE_CALL_FOR_PROPOSALS or -1] =
	function()
		local league = Game.GetNumActiveLeagues() > 0 and Game.GetActiveLeague()
		return FLASHING_PRODUCTION, L"TXT_KEY_NOTIFICATION_LEAGUE_PROPOSALS_NEEDED", league and L("TXT_KEY_NOTIFICATION_LEAGUE_PROPOSALS_NEEDED_TT", league:GetName())
	end,
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_LEAGUE_CALL_FOR_VOTES or -1] =
	function()
		local league = Game.GetNumActiveLeagues() > 0 and Game.GetActiveLeague()
		return FLASHING_END_TURN, L"TXT_KEY_NOTIFICATION_LEAGUE_VOTES_NEEDED", league and L("TXT_KEY_NOTIFICATION_LEAGUE_VOTES_NEEDED_TT", league:GetName() )
	end,
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_CHOOSE_IDEOLOGY or -1] =
	function()
		local player = Players[GetActivePlayer()]
		return FLASHING_END_TURN, L"TXT_KEY_NOTIFICATION_SUMMARY_CHOOSE_IDEOLOGY", L( player and player:GetCurrentEra() > GameInfoTypes.ERA_INDUSTRIAL and "TXT_KEY_NOTIFICATION_CHOOSE_IDEOLOGY_ERA" or "TXT_KEY_NOTIFICATION_CHOOSE_IDEOLOGY_FACTORIES" )
	end,
	-- CPP
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_PENDING_DEAL or -1] =
		{ FLASHING_END_TURN, L"TXT_KEY_NOTIFICATION_SUMMARY_DIPLOMATIC_REQUEST", L"TXT_KEY_NOTIFICATION_SUMMARY_DIPLOMATIC_REQUEST_TT" },
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_EVENT_CHOICE or -1] =
		{ FLASHING_END_TURN, L"TXT_KEY_NOTIFICATION_SUMMARY_CHOOSE_EVENT", L"TXT_KEY_NOTIFICATION_SUMMARY_CHOOSE_EVENT_TT" },
}tEndTurnState[-1] = nil

do
	local mt = { __call = function( t ) return unpack( t ) end }
	for _, v in pairs( tEndTurnState ) do if type(v) == "table" then local a, b, c = unpack(v); setmetatable( v, { __call = function() return a, b, c end } ) end end
end

local tEndTurnBlockingAction = {
--NO_ENDTURN_BLOCKING_TYPE, ENDTURN_BLOCKING_POLICY, ENDTURN_BLOCKING_RESEARCH, ENDTURN_BLOCKING_PRODUCTION, ENDTURN_BLOCKING_UNITS, ENDTURN_BLOCKING_DIPLO_VOTE, ENDTURN_BLOCKING_MINOR_QUEST, ENDTURN_BLOCKING_FREE_TECH, ENDTURN_BLOCKING_STACKED_UNITS, ENDTURN_BLOCKING_UNIT_NEEDS_ORDERS, ENDTURN_BLOCKING_UNIT_PROMOTION, ENDTURN_BLOCKING_CITY_RANGE_ATTACK, ENDTURN_BLOCKING_FREE_POLICY, ENDTURN_BLOCKING_FREE_ITEMS, ENDTURN_BLOCKING_FOUND_PANTHEON, ENDTURN_BLOCKING_FOUND_RELIGION, ENDTURN_BLOCKING_ENHANCE_RELIGION, ENDTURN_BLOCKING_STEAL_TECH, ENDTURN_BLOCKING_MAYA_LONG_COUNT, ENDTURN_BLOCKING_FAITH_GREAT_PERSON, ENDTURN_BLOCKING_ADD_REFORMATION_BELIEF, ENDTURN_BLOCKING_LEAGUE_CALL_FOR_PROPOSALS, ENDTURN_BLOCKING_CHOOSE_ARCHAEOLOGY, ENDTURN_BLOCKING_LEAGUE_CALL_FOR_VOTES, ENDTURN_BLOCKING_CHOOSE_IDEOLOGY,
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_UNITS or -1] = GotoFirstReadyUnit,
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_UNIT_NEEDS_ORDERS or -1] = GotoFirstReadyUnit,
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_STACKED_UNITS or -1] = function( player )
		for unit in player:Units() do
			if not unit:CanHold( unit:GetPlot() ) then
				return GotoUnit( unit, ToLower"TXT_KEY_MOVE_STACKED_UNIT" )
			end
		end
	end,
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_UNIT_PROMOTION or -1] = function( player )
		for unit in player:Units() do
			if unit:IsPromotionReady() then
				return GotoUnit( unit, L"TXT_KEY_NOTIFICATION_SUMMARY_UNIT_CAN_GET_PROMOTION" )
			end
		end
	end,
	[EndTurnBlockingTypes.ENDTURN_BLOCKING_CITY_RANGE_ATTACK or -1] = function()
		local city = UI.GetHeadSelectedCity()
		if city then
			GotoPlot( city:Plot(), L("TXT_KEY_NOTIFICATION_SUMMARY_CITY_CAN_SHOOT", city:GetName()) ) --(GetNotificationStr()) )
		end
	end,
}tEndTurnBlockingAction[-1] = nil

local function SetEndTurnWaiting()
	-- If the active player has sent the AllComplete message, disable the button
	if _bNetworkMultiPlayer and Network.HasSentNetTurnAllComplete() then
		Controls.EndTurnButton:SetDisabled( true )
	end

	local iActivePlayer = GetActivePlayer()
	local activeTeam = Teams[GetActiveTeam()]

	local pleaseWait = ""
	local playersWaiting = _bNetworkMultiPlayer and Network.HasSentNetTurnComplete() and 1 or 0
	for i = 0, MAX_MAJOR_CIVS-1 do
		local otherPlayer = Players[ i ]
		if otherPlayer and i ~= iActivePlayer and otherPlayer:IsHuman() and not otherPlayer:HasReceivedNetTurnComplete() then
			pleaseWait = pleaseWait .. "[NEWLINE]" .. otherPlayer:GetName() .. " (" .. L(activeTeam and activeTeam:IsHasMet(otherPlayer:GetTeam()) and otherPlayer:GetCivilizationShortDescriptionKey() or "TXT_KEY_POP_VOTE_RESULTS_UNMET_PLAYER") .. ")"
			playersWaiting = playersWaiting + 1
		end
	end

	if playersWaiting == 0 then
		Controls.EndTurnText:LocalizeAndSetText( "TXT_KEY_PLEASE_WAIT" )
		Controls.EndTurnButton:LocalizeAndSetToolTip( "TXT_KEY_PLEASE_WAIT_TT" )
	else
		Controls.EndTurnText:LocalizeAndSetText( "TXT_KEY_WAITING_FOR_PLAYERS" )
		Controls.EndTurnButton:SetToolTipString( L"TXT_KEY_WAITING_FOR_PLAYERS_TT" .. pleaseWait )
	end

	return SetEndTurnFlashing( FLASHING_END_TURN )
end

local function OnEndTurnDirty()
	local player = Players[ GetActivePlayer() ]
	if player and player:IsTurnActive() and not ( _bNetworkMultiPlayer and Network.HasSentNetTurnComplete() or Game.IsProcessingMessages() ) then
		local sEndTurnMessage, sButtonToolTip, eFlashingState
		local bButtonDisabled = false
		local f = tEndTurnState[ player:GetEndTurnBlockingType() ]
		if f then
			eFlashingState, sEndTurnMessage, sButtonToolTip = f( player )
		elseif UI.WaitingForRemotePlayers() then
			sEndTurnMessage = "TXT_KEY_WAITING_FOR_PLAYERS"
			sButtonToolTip = "TXT_KEY_WAITING_FOR_PLAYERS_TT"
			bButtonDisabled = true
			eFlashingState = NO_FLASHING
		else
			sEndTurnMessage = "TXT_KEY_NEXT_TURN"
			sButtonToolTip = "TXT_KEY_NEXT_TURN_TT"
			eFlashingState = FLASHING_END_TURN
		end
		Controls.EndTurnButton:SetDisabled( bButtonDisabled )
		Controls.EndTurnText:LocalizeAndSetText( sEndTurnMessage )
		Controls.EndTurnButton:LocalizeAndSetToolTip( sButtonToolTip )
		return SetEndTurnFlashing( eFlashingState )
	else
		return SetEndTurnWaiting()
	end
end
Events.SerialEventEndTurnDirty.Add( OnEndTurnDirty )
Events.RemotePlayerTurnEnd.Add( OnEndTurnDirty ) -- The "Waiting For Players" tooltip might need to be updated.
Events.ActivePlayerTurnEnd.Add( SetEndTurnWaiting )
Events.EndTurnBlockingChanged.Add( function( ePrevEndTurnBlockingType, eNewEndTurnBlockingType )
	local player = Players[GetActivePlayer()]
	if player and player:IsTurnActive() then
		local f = tEndTurnBlockingAction[ eNewEndTurnBlockingType ]
		if f then
			f( player )
		end
	end
end)

local function ReselectUnit( iPlayer, unitID )
	Events.UnitSelectionChanged.RemoveAll()
	Events.SerialEventUnitFlagSelected( iPlayer, unitID )
end

local function OnEndTurnClicked( isEndTurn, isRemove )
	local iActivePlayer = GetActivePlayer()
	local pActivePlayer = Players[ iActivePlayer ]
--	local force = isEndTurn and ( UI.ShiftKeyDown() or UI.AltKeyDown() or UI.CtrlKeyDown() )
	if pActivePlayer and not pActivePlayer:IsTurnActive() then
		return print("Player's turn not active")
	elseif Game.IsProcessingMessages() then
		return print("The game is busy processing messages")
	elseif _bNetworkMultiPlayer and Network.HasSentNetTurnComplete() then
		if Network.SendTurnUnready() then
			return OnEndTurnDirty()
		end
	else
		local iEndTurnBlockingNotificationIndex = pActivePlayer:GetEndTurnBlockingNotificationIndex()
		if iEndTurnBlockingNotificationIndex ~= -1 then
			if isRemove then
				return UI.RemoveNotification( iEndTurnBlockingNotificationIndex ) -- won't remove if forbidden !
			else
				return ActivateNotification( iEndTurnBlockingNotificationIndex )
			end
		else
			local f = tEndTurnBlockingAction[ pActivePlayer:GetEndTurnBlockingType() ]
			if f then
--				print( "Cannot end turn due to blocking action", pActivePlayer:GetEndTurnBlockingType() )
				return f( pActivePlayer, true )
			elseif not UI.CanEndTurn() then
				print( "UI thinks that we can't end turn, but the notification system disagrees", pActivePlayer:GetEndTurnBlockingType() )
			end
		end
		if isEndTurn then
			if _bWorkerFocus then
				for unit in pActivePlayer:Units() do
					if unit:IsWork() and unit:CanMove() then
						local iBuild = unit:GetBuildType()
						local rBuild = GameInfo.Builds[ iBuild ]
						local plot = unit:GetPlot()
						if plot and rBuild and not rBuild.RouteType and plot:GetOwner() == iActivePlayer and plot:GetBuildTurnsLeft( iBuild, iActivePlayer, 0, 0 ) == 0 and unit:CanStartMission( GameInfoTypes.MISSION_BUILD, iBuild, -1 ) then
--						unit:CanStartMission( eMission, iData1, iData2, pPlot = NULL, bTestVisible = false )--!!! not used by Firaxis UI
--						Game.CanHandleAction( actionID )
							local city = plot:GetWorkingCity()
							local rImprovement = GameInfo.Improvements[ rBuild.ImprovementType or -1 ]
--print( rImprovement, rImprovement and rImprovement.Type, rImprovement and rImprovement.PromptWhenComplete )
							if city and not city:IsPuppet() and not (rImprovement and rImprovement.PromptWhenComplete) then
								for _, action in pairs( GameInfoActions ) do
									if action.MissionData == iBuild and action.SubType == ACTIONSUBTYPE_BUILD then
										Events.UnitSelectionChanged.Add( ReselectUnit )
										GotoUnit( unit, rBuild._Name )
--										Game.HandleAction( actionID )
--										Game.SelectionListGameNetMessage( eMessage, eCommand|eMission = -1, idata1|x = -1, idata2|y = -1, iFlags = 0, bAlt = false, bShift = false )
										return Game.SelectionListGameNetMessage( GameMessageTypes.GAMEMESSAGE_PUSH_MISSION, GameInfoTypes.MISSION_BUILD, iBuild )
									end
								end
							end
						end
					end
				end
			end
			print( "Player ending turn:", Game.GetGameTurn(), "Lua memory in use:", ToNumber( collectgarbage("count") * 1024, "#,###,###,###" ) )
			collectgarbage("collect")
			return Game.DoControl( GameInfoTypes.CONTROL_ENDTURN )
		end
	end
end

Controls.EndTurnButton:RegisterCallback( Mouse.eLClick, function() OnEndTurnClicked( true ) end )
Controls.EndTurnButton:RegisterCallback( Mouse.eRClick, function() OnEndTurnClicked( false, true ) end )

-- Key Down Processing
do
	local diploChatPanel = LookUpControl( "/InGame/WorldView/DiploCorner/ChatPanel" )
	if diploChatPanel then
		_iChatPanelHeight = diploChatPanel:GetSizeY()
	end
	local VK_RETURN = Keys.VK_RETURN
	local KeyDown = KeyEvents.KeyDown
	local ChatEntry = LookUpControl( "/InGame/WorldView/DiploCorner/ChatEntry" )
	ContextPtr:SetInputHandler( function( uiMsg, wParam )
		if uiMsg == KeyDown and wParam == VK_RETURN then
			if not (_bChatOpen and ChatEntry and #ChatEntry:GetText()>0) then
				OnEndTurnClicked( true )
			end
			return true
		end
	end)
end
OnEndTurnDirty()

--==========================================================
-- Utility Functions
--==========================================================

local function SortStack( a, b )
	if a and b then
		for i = 3, 1, -1 do
			if a[i] ~= b[i] then
				return a[i] > b[i]
			end
		end
	end
end

local function SortMajorStack( control1, control2 )
	return SortStack( _tMajorControlTable[ control1:GetVoid1() ], _tMajorControlTable[ control2:GetVoid1() ] )
end

local function SortMinorStack( control1, control2 )
	return SortStack( _tMinorControlTable[ control1:GetVoid1() ], _tMinorControlTable[ control2:GetVoid1() ] )
end

local isQuestKillCamp
if _bCiv5BNW then
	function isQuestKillCamp( minorPlayer )
		return minorPlayer:IsMinorCivDisplayedQuestForPlayer( _iActivePlayer, MINOR_CIV_QUEST_KILL_CAMP )
	end
elseif _bCiv5GK then
	function isQuestKillCamp( minorPlayer )
		return minorPlayer:IsMinorCivActiveQuestForPlayer( _iActivePlayer, MINOR_CIV_QUEST_KILL_CAMP )
	end
else
	function isQuestKillCamp( minorPlayer )
		return minorPlayer:GetActiveQuestForPlayer( _iActivePlayer ) == MINOR_CIV_QUEST_KILL_CAMP
	end
end

--==========================================================
-- Civilization Ribbon Tooltips
-- function names must match XML instance control ID
--==========================================================
local g_civListInstanceToolTips = {
	Button = 1,
	Quests = 1,
	Ally = 1,
	Pledge1 = 1,
	Pledge2 = 1,
	Spy = 1,
	DeclarationOfFriendship = 1,
	ResearchAgreement = 1,
	DefenseAgreement = 1,
	TheirBordersClosed = 1,
	OurBordersClosed = 1,
	TheirBordersOpen = 1,
	OurBordersOpen = 1,
	ActivePlayer = 1,
	War = 1,
	Score = 1,
	Gold = 1,
	TheirTradeItems = 1,
	OurTradeItems = 1,
	Host = 1,
	Connection = 1,
	Diplomacy = 1,
}

--==========================================================
-- Civilization Ribbon
-- Mouse Click Handlers
-- Table names must match  XML instance control ID
--==========================================================
local g_civListInstanceCallBacks = {
	Button = {
		[Mouse.eLClick] = function( iPlayer )
			local player = iPlayer and Players[iPlayer]
			if player and iPlayer ~= _iLeader and ( not _iLeaderMode or UI.GetLeaderHeadRootUp() ) then
				local eTeam = player:GetTeam()
				-- player
				if iPlayer == _iActivePlayer then
					if not _iLeaderMode then
						Events.SerialEventGameMessagePopup{ Type = ButtonPopupTypes.BUTTONPOPUP_ADVISOR_COUNSEL, Data1 = 1 }
					end
				-- war declaration
				elseif _bCiv5BNW and UI.CtrlKeyDown() and _pActiveTeam:CanChangeWarPeace( eTeam ) then
					if _pActiveTeam:IsAtWar( eTeam ) then
					-- Asking for Peace (currently at war) - bring up the trade screen
						Game.DoFromUIDiploEvent( FROM_UI_DIPLO_EVENT_HUMAN_NEGOTIATE_PEACE, iPlayer, 0, 0 )
					elseif _pActiveTeam:CanDeclareWar( eTeam ) then
					-- Declaring War - bring up the BNW popup
						UI.AddPopup{ Type = ButtonPopupTypes.BUTTONPOPUP_DECLAREWARMOVE, Data1 = eTeam, Option1 = true }
					end
				-- human player
				elseif player:IsHuman() then
					Events.OpenPlayerDealScreenEvent( iPlayer )

				-- city state
				elseif player:IsMinorCiv() then
					Events.SerialEventGameMessagePopup{ Type = ButtonPopupTypes.BUTTONPOPUP_CITY_STATE_DIPLO, Data1 = iPlayer }

				-- AI player
				elseif not player:IsBarbarian() then
					UI.SetRepeatActionPlayer( iPlayer )
					UI.ChangeStartDiploRepeatCount( 1 )
					player:DoBeginDiploWithHuman()
				end
				if _iLeaderMode then
					_tScratchDeal:ClearItems()
					UIManager:DequeuePopup( _tLeaderPopups[ _iLeaderMode ] )
					UI.SetLeaderHeadRootUp( false )
					UI.RequestLeaveLeader()
				end
			end
		end,

		[Mouse.eRClick] = function( iPlayer )
			local player = Players[ iPlayer ]
			if player then
				if player:IsMinorCiv() then
					local city = not _iLeaderMode and player:GetCapitalCity()
					return GotoPlot( city and city:Plot(), city:GetName() )
				else
					Events.SearchForPediaEntry( player:GetCivilizationShortDescription() )
				end
			end
		end,
--		[Mouse.eMouseEnter] = nil,
--		[Mouse.eMouseExit] = nil,
	},--/Button

	Spy = {
		[Mouse.eLClick] = function()
			Events.SerialEventGameMessagePopup{ Type = ButtonPopupTypes.BUTTONPOPUP_ESPIONAGE_OVERVIEW }
		end,
	},--/Spy

	Quests = {
		[Mouse.eLClick] = function( minorPlayerID )
			local minorPlayer = not _iLeaderMode and Players[ minorPlayerID ]
			return GotoPlot( minorPlayer and isQuestKillCamp( minorPlayer ) and
								GetPlot( minorPlayer:GetQuestData1( _iActivePlayer, MINOR_CIV_QUEST_KILL_CAMP ),
										minorPlayer:GetQuestData2( _iActivePlayer, MINOR_CIV_QUEST_KILL_CAMP ) ),
								L( "TXT_KEY_NOTIFICATION_SUMMARY_QUEST_KILL_CAMP", minorPlayer:GetCivilizationShortDescriptionKey() ) )
		end,
	},--/Quests

	Connection = {
		[Mouse.eLClick] = function( iPlayer )
			local player = Players[iPlayer]
			if player
				and Matchmaking.IsHost()
				and iPlayer ~= _iActivePlayer
				and (Network.IsPlayerConnected(iPlayer) or (player:IsHuman() and not player:IsObserver()))
			then
				UIManager:PushModal( Controls.ConfirmKick, true )
				LuaEvents.SetKickPlayer( iPlayer, player:GetName() )
			end
		end,
	},--/Connection
}--g_civListInstanceCallBacks

--==========================================================
-- Civilization Ribbon Update
--==========================================================
local function UpdateCivList()

	local iActivePlayer = GetActivePlayer()
	local pActivePlayer = Players[ iActivePlayer ]
	local eActiveTeam = Game.GetActiveTeam()
	local activeTeam = Teams[ eActiveTeam ]
	local deal = _tScratchDeal
	-- Find the Spies
	if pActivePlayer and activeTeam and deal then
		local spies = {}
		if _bCiv5GK then
			for _, spy in ipairs( pActivePlayer:GetEspionageSpies() ) do
				local plot = GetPlot( spy.CityX, spy.CityY )
				if plot then
					local city = plot:GetPlotCity()
					if city then
						spies[ city:GetOwner() ] = true
					end
				end
			end
		end
		-- Update the Majors
		local Resources = GameInfo.Resources
		local luxuries = { ResourceUsage = RESOURCEUSAGE_LUXURY }
		local strategics = { ResourceUsage = RESOURCEUSAGE_STRATEGIC }

		for iPlayer, instance in pairs( _tMajorControlTable ) do

			local player = Players[ iPlayer ]
			local eTeam = player:GetTeam()
			local team = Teams[ eTeam ]

			-- have we met ?

			if player:IsAlive() and activeTeam:IsHasMet( eTeam ) then
				if team:GetNumMembers() > 1 then
					instance.TeamIcon:SetText( "[ICON_TEAM_" .. team:GetID() + 1 .. "]" )
					instance.TeamIcon:SetHide( false )
					instance.CivIconBG:SetHide( true )
				else
					instance.TeamIcon:SetHide( true )
					instance.CivIconBG:SetHide( false )
				end

				-- Setup status flags

				local isAtWar = team:IsAtWar( eActiveTeam )
				local isDoF = player:IsDoF( iActivePlayer )
				local isActivePlayer = iPlayer == iActivePlayer
				local isOurBorderOpen = activeTeam:IsAllowsOpenBordersToTeam( eTeam )
				local isTheirBorderOpen = team:IsAllowsOpenBordersToTeam( eActiveTeam )

				if _bNetworkMultiPlayer or _bHotSeatGame then
					if _bNetworkMultiPlayer then
						if Matchmaking.GetHostID() == iPlayer then
							instance.Connection:SetTextureOffsetVal(4,68)
						elseif Network.IsPlayerHotJoining(iPlayer) then
							instance.Connection:SetTextureOffsetVal(4,36)
						elseif player:IsConnected() then
							instance.Connection:SetTextureOffsetVal(4,4)
						else
							instance.Connection:SetTextureOffsetVal(4,100)
						end
					end
					if UI.ProposedDealExists( iPlayer, iActivePlayer ) then
						--They proposed something to us
						instance.Diplomacy:SetHide(false)
						instance.Diplomacy:SetAlpha( 1.0 )
					elseif UI.ProposedDealExists( iActivePlayer, iPlayer ) then
						-- We proposed something to them
						instance.Diplomacy:SetHide(false)
						instance.Diplomacy:SetAlpha( 0.5 )
					else
						instance.Diplomacy:SetHide(true)
					end
				end
				instance.War:SetHide( not isAtWar )
				instance.ActivePlayer:SetHide( not isActivePlayer )
				instance.ResearchAgreement:SetHide( not team:IsHasResearchAgreement( eActiveTeam ) )
				instance.DefenseAgreement:SetHide( not team:IsDefensivePact( eActiveTeam ) )
				instance.DeclarationOfFriendship:SetHide( not isDoF )
				instance.TheirBordersClosed:SetHide( isActivePlayer or isAtWar or isTheirBorderOpen )
				instance.OurBordersClosed:SetHide( isActivePlayer or isAtWar or isOurBorderOpen )
				instance.TheirBordersOpen:SetHide( isActivePlayer or not isTheirBorderOpen )
				instance.OurBordersOpen:SetHide( isActivePlayer or not isOurBorderOpen )

				local color
				if isAtWar then
					color = _tColorWar
				elseif player:IsDenouncingPlayer( iActivePlayer ) then
					color = _tColorDenounce
				elseif player:IsHuman() or team:IsHuman() then
					color = _tColorHuman
				else
					color = _tColorMajorCivApproach[ pActivePlayer:GetApproachTowardsUsGuess( iPlayer ) ]
				end
				instance.Button:SetColor( color )

				-- Set Score
				instance.Score:SetText( player:GetScore() )

				local theirTradeItems = {}
				local ourTradeItems = {}

				if isActivePlayer then
					-- Resources we can trade
--[[ too much stuff
--					ourTradeItems[1] = tostring( not _iLeaderMode or UI.GetLeaderHeadRootUp() )
					for resource in Resources() do
						for iPlayer = 0, MAX_MAJOR_CIVS-1 do
							local player = Players[iPlayer]
							if player
								and player:IsAlive()
								and activeTeam:IsHasMet( player:GetTeam() )
								and not activeTeam:IsAtWar( player:GetTeam() )
								and deal:IsPossibleToTradeItem( iActivePlayer, iPlayer, TradeableItems.TRADE_ITEM_RESOURCES, resource.ID, 1 )
							then
								insert( ourTradeItems, resource.IconString )
								break
							end
						end
					end
--]]

				elseif isAtWar then
					instance.Gold:SetText( "[COLOR_RED]" .. L"TXT_KEY_DIPLO_MAJOR_CIV_DIPLO_STATE_WAR" .. "[/COLOR]" )
				else
					-- Gold available
					local gold = 0
					local goldRate = player:CalculateGoldRate()
					if deal:IsPossibleToTradeItem( iPlayer, iActivePlayer, TradeableItems.TRADE_ITEM_GOLD, 1 ) then -- includes DoF check
						gold = player:GetGold()
						instance.Gold:SetText( "[COLOR_YELLOW]" .. gold .. "[/COLOR]" )	--[ICON_GOLD]
					else
						instance.Gold:SetText()
						if not deal:IsPossibleToTradeItem( iPlayer, iActivePlayer, TradeableItems.TRADE_ITEM_GOLD_PER_TURN, 1 ) then
							goldRate = 0
						end
					end
					local minKeepLuxuries = 1
					-- Reasonable trade is not possible if hostile
					if player:GetMajorCivApproach( iActivePlayer ) ~= MajorCivApproachTypes.MAJOR_CIV_APPROACH_HOSTILE then --MAJOR_CIV_APPROACH_DECEPTIVE then
						-- Luxuries available from them
						for resource in Resources( luxuries ) do
							if player:GetNumResourceAvailable( resource.ID, true ) > 1 -- single resources (including imports) are too expensive (3x)
								and deal:IsPossibleToTradeItem( iPlayer, iActivePlayer, TradeableItems.TRADE_ITEM_RESOURCES, resource.ID, 1 )
							then
								insert( theirTradeItems, resource.IconString )
								minKeepLuxuries = 0	-- if they have luxes to trade, we can trade even our last one
							end
						end
						local dealDuration = Game.GetDealDuration()
						if goldRate > 0 then
							gold = dealDuration * goldRate + gold
						end
						local happyWithoutLux = minKeepLuxuries == 0 or pActivePlayer:GetExcessHappiness() > 4 + pActivePlayer:GetNumCities() -- approximation... should take actual happy value + scan city growth
						-- Luxuries available from us, if they can pay for it or trade for another lux
						local isLux = gold >= dealDuration * 5 or minKeepLuxuries == 0
						if isLux then
							for resource in Resources( luxuries ) do
								-- IsPossibleToTradeItem includes check on min quantity, banned luxes and obsolete strategics
								if pActivePlayer:GetNumResourceAvailable( resource.ID, true ) > 1 and deal:IsPossibleToTradeItem( iActivePlayer, iPlayer, TradeableItems.TRADE_ITEM_RESOURCES, resource.ID, 1 ) then
									insert( ourTradeItems, resource.IconString )
								end
							end
						end
						-- Strategics available from us, if they can pay at least 1GPT for it
						if gold >= dealDuration then
							for resource in Resources( strategics ) do
								-- IsPossibleToTradeItem includes check on min quantity, banned luxes (nope: and obsolete strategics)
								if deal:IsPossibleToTradeItem( iActivePlayer, iPlayer, TradeableItems.TRADE_ITEM_RESOURCES, resource.ID, 1 )
										and player:GetNumResourceAvailable( resource.ID, true ) <= player:GetNumCities() -- game limit on AI trading
										and player:GetCurrentEra() < ( GameInfoTypes[ resource.AIStopTradingEra ] or huge ) -- not obsolete
								then
									insert( ourTradeItems, resource.IconString )
								end
							end
						end
						if isLux then
							for resource in Resources( luxuries ) do
								-- IsPossibleToTradeItem includes check on min quantity, banned luxes
								if happyWithoutLux and pActivePlayer:GetNumResourceAvailable( resource.ID, true ) == 1 and deal:IsPossibleToTradeItem( iActivePlayer, iPlayer, TradeableItems.TRADE_ITEM_RESOURCES, resource.ID, 1 ) then
									insert( ourTradeItems, resource.IconString )
								end
							end
						end
					end
				end
				instance.TheirTradeItems:SetText( concat( theirTradeItems ) )
				if #ourTradeItems < 4 then
					instance.OurTradeItems:SetText( concat( ourTradeItems ) )
				else
					instance.OurTradeItems:SetText( concat( ourTradeItems, nil, 1, 3 ).."..." ) --"[ICON_PLUS]"
				end

				-- disable the button if we have a pending deal with this player
				instance.Button:SetDisabled( iPlayer == UI.HasMadeProposal( iActivePlayer ) )

				instance.Button:SetHide( false )
				instance[3] = team:GetScore()
				instance[2] = player:GetScore()
			else
				instance.Button:SetHide( true )
			end
		end
		Controls.MajorStack:SortChildren( SortMajorStack )

		-- Show the CityStates we know

		local capital = pActivePlayer:GetCapitalCity()
		for minorPlayerID, instance in pairs( _tMinorControlTable ) do

			local minorPlayer = Players[ minorPlayerID ]

			if minorPlayer
				and minorPlayer:IsAlive()
				and activeTeam:IsHasMet( minorPlayer:GetTeam() )
			then
				instance.Button:SetHide( false )

				-- Update Background
				UpdateCityStateStatusIconBG( iActivePlayer, minorPlayerID, instance.Portrait )

				-- Update Allies
				local allyID = minorPlayer:GetAlly()
				local ally = Players[ allyID ]

				if ally then
					CivIconHookup( activeTeam:IsHasMet( ally:GetTeam() ) and allyID, 32, instance.AllyIcon, instance.AllyBG, instance.AllyShadow )
					instance.Ally:SetHide(false)
				else
					instance.Ally:SetHide(true)
				end

				-- Update Spies
				instance.Spy:SetHide( not spies[ minorPlayerID ] )

				-- Update Quests
				instance.Quests:SetText( GetActiveQuestText( iActivePlayer, minorPlayerID ) )

				-- Update Pledge
				if _bCiv5GK then
					local pledge = pActivePlayer:IsProtectingMinor( minorPlayerID )
					local free = minorPlayer:CanMajorWithdrawProtection( iActivePlayer )
					instance.Pledge1:SetHide( not pledge or free )
					instance.Pledge2:SetHide( not(pledge and free) )
				end
				-- Update War
				instance.War:SetHide( not activeTeam:IsAtWar( minorPlayer:GetTeam() ) )

				instance[3] = minorPlayer:GetMinorCivFriendshipWithMajor( iActivePlayer )
				local minorCapital = minorPlayer:GetCapitalCity()
				instance[2] = -(capital and minorCapital and PlotDistance( capital:GetX(), capital:GetY(), minorCapital:GetX(), minorCapital:GetY() ) or huge )
			else
				instance.Button:SetHide( true )
			end
		end
		Controls.MinorStack:SortChildren( SortMinorStack )
	end
	return ProcessStackSizes()
end

--==========================================================
-- 'Active' (local human) player has changed
--==========================================================
local function OnSetActivePlayer( ... )	--iActivePlayer, prevActivePlayerID )
--print( "OnSetActivePlayer", ... )
	-- update globals
	_iActivePlayer = GetActivePlayer()
	_pActivePlayer = Players[ _iActivePlayer ]
	_iActiveTeam = Game.GetActiveTeam()
	_pActiveTeam = Teams[ _iActiveTeam ]

	-- Remove all the UI notifications. The new player will rebroadcast any persistent ones from their last turn
	for Id in pairs( _tActiveNotifications ) do
		RemoveNotificationID( Id )
	end
	UI.RebroadcastNotifications()
	HookupNewNotifications()

	-- update the civ list
	return UpdateCivList()
end

--==========================================================
-- Civ List Init
--==========================================================
local CivilizationToolTipCallback = LuaEvents.CivilizationToolTips.Call
for iPlayer = 0, MAX_CIV_PLAYERS-1 do

	local player = Players[ iPlayer ]
	if player and player:IsEverAlive() then
--print( "Setting up civilization ribbon player ID", iPlayer )
		local instance = { -iPlayer, 0, 0, 0 }

		if player:IsMinorCiv() then

			-- Create instance
			ContextPtr:BuildInstanceForControl( "CityStateInstance", instance, Controls.MinorStack )
			_tMinorControlTable[iPlayer] = instance

			-- Setup icons
			instance.StatusIcon:SetTexture((GameInfo.MinorCivTraits[(GameInfo.MinorCivilizations[player:GetMinorCivType()]or{}).MinorCivTrait]or{}).TraitIcon)
			instance.StatusIcon:SetColor( PrimaryColors[iPlayer] )
		else

			-- Create instance
			ContextPtr:BuildInstanceForControl( "LeaderButtonInstance", instance, Controls.MajorStack )
			_tMajorControlTable[iPlayer] = instance

			-- Setup icons
			local leader = GameInfo.Leaders[player:GetLeaderType()]or{}
			IconHookup( leader.PortraitIndex, 64, leader.IconAtlas, instance.Portrait )
			CivIconHookup( iPlayer, 32, instance.CivIcon, instance.CivIconBG, instance.CivIconShadow )
			instance.Connection:SetHide( not _bNetworkMultiPlayer )
			instance.Diplomacy:SetHide( not _bNetworkMultiPlayer and not _bHotSeatGame )
		end

		local control
		-- Setup Tootips
		for name in pairs( g_civListInstanceToolTips ) do
			control = instance[name]
			if control then
				control:SetToolTipCallback( function( control )
					control:SetToolTipCallback( function( control ) return CivilizationToolTipCallback( control, iPlayer ) end )
					control:SetToolTipType( "EUI_CivilizationTooltip" )
				end)
			end
		end
		-- Setup Callbacks
		for name, eventCallbacks in pairs( g_civListInstanceCallBacks ) do
			control = instance[name]
			if control then
				for event, callback in pairs( eventCallbacks ) do
					control:SetVoid1( iPlayer )
					control:RegisterCallback( event, callback )
				end
			end
		end
	end
end

local function OnChatToggle( isChatOpen )
	_bChatOpen = isChatOpen
	_iCivPanelOffsetY = _iDiploButtonsHeight + (isChatOpen and _iChatPanelHeight or 0)
	_iMaxTotalStackHeight = _iScreenHeight - Controls.OuterStack:GetOffsetY() - _iCivPanelOffsetY
	if not _iLeaderMode then
		Controls.CivPanelContainer:SetOffsetY( _iCivPanelOffsetY )
		ProcessStackSizes( true )
	end
end

local function OnOptionsChanged()
	_bWorkerFocus = UserInterfaceSettings.WorkerFocus ~= 0
	_bCivilizationRibbon = UserInterfaceSettings.CivilizationRibbon ~= 0
	Controls.CivPanel:SetHide( not _bCivilizationRibbon )
	Controls.DarkBorders:SetHide( not _bCivilizationRibbon )
	return UpdateCivList()
end

local diploButtons = {}
local predefined = {
	[L"TXT_KEY_ADVISOR_COUNSEL"] = "",-- "DC45_AdvisorCounsel.dds",
	[L"TXT_KEY_ADVISOR_SCREEN_TECH_TREE_DISPLAY"] = "",-- "DC45_TechTree.dds",
	[L"TXT_KEY_DIPLOMACY_OVERVIEW"] = "",--"DC45_DiplomacyOverview.dds",
	[L"TXT_KEY_MILITARY_OVERVIEW"] = "DC45_MilitaryOverview.dds",--{ "MainUnitButton.dds", "MainUnitButtonHL.dds" },--
	[L"TXT_KEY_ECONOMIC_OVERVIEW"] = "",-- "DC45_EconomicOverview.dds",
	[L"TXT_KEY_VP_TT"] = "DC45_VictoryProgress.dds",
	[L"TXT_KEY_DEMOGRAPHICS"] = "DC45_InfoAddict.dds", --"DC45_Demographics.dds",
	[L"TXT_KEY_POP_NOTIFICATION_LOG"] = "DC45_NotificationLog.dds",
	[L"TXT_KEY_TRADE_ROUTE_OVERVIEW"] = "",-- "DC45_TradeRouteOverview.dds",
	[L"TXT_KEY_EO_TITLE"] = "",--"DC45_EspionageOverview.dds",
	[L"TXT_KEY_RELIGION_OVERVIEW"] = "",--"DC45_ReligionOverview.dds",
	[L"TXT_KEY_LEAGUE_OVERVIEW"] = "DC45_WorldCongress.dds",
	[L"TXT_KEY_INFOADDICT_MAIN_TITLE"] = "DC45_InfoAddict.dds",
}

do
	local diploButtonStack = LookUpControl( "/InGame/WorldView/DiploCorner/DiploCornerStack" )
	if diploButtonStack then
		local alertButton
		LuaEvents.AdditionalInformationDropdownGatherEntries.Add( function( diploButtonEntries )
			local instance
			local n = 1
			local c = LookUpControl( "/InGame/WorldView/DiploCorner/CultureOverviewButton" )
			if c then
				c:SetHide( not _bCiv5BNW or Game.IsOption("GAMEOPTION_NO_CULTURE_OVERVIEW_UI") )
			end

			local DiploCorner = LookUpControl( "/InGame/WorldView/DiploCorner" )
			if DiploCorner then
				for _, v in ipairs( diploButtonEntries ) do
					local texture = v.art or predefined[ v.text ]
					if not texture or #texture > 0 then
						instance = diploButtons[n]
						if instance then
							instance.Button:SetHide( false )
						else
							instance={}
							DiploCorner:BuildInstanceForControl( "DiploCornerButton", instance, diploButtonStack )
							diploButtons[n] = instance
						end
						n = n+1
						if texture then
							instance.Button:SetTexture( texture )
							if texture == "DC45_NotificationLog.dds" then
								alertButton = instance.Button
								_sAlertMessageTitle = v.text
								_sAlertMessages = _sAlertMessageTitle
							end
						end
						instance.Button:SetText( not texture and v.text:sub(1,3) )
						instance.Button:RegisterCallback( Mouse.eLClick, v.call )
						instance.Button:SetToolTipString( v.text )
					end
				end
				for i = n, #diploButtons do
					diploButtons[i].Button:SetHide( true )
				end
				diploButtonStack:SortChildren(
				function(a,b)
					return (a:GetToolTipString() or "") > (b:GetToolTipString() or "")
				end)
			else
				print("Error: could not find DiploCorner lua context, probably a mod conflict")
			end
			_iDiploButtonsHeight = 28 + diploButtonStack:GetSizeY()
		end)
		LuaEvents.RequestRefreshAdditionalInformationDropdownEntries()
		if alertButton and alertButton.SetToolTipString then
			Events.GameplayAlertMessage.Add(
			function( messageText )
				if _bAlertMessages then
					_sAlertMessages = _sAlertMessages .."[NEWLINE]".. messageText
					alertButton:SetToolTipString( _sAlertMessages )
				else
					_bAlertMessages = true
				end
			end)
		end
	else
		print("Error: could not find DiploCorner button stack, probably a mod conflict")
	end
end

OnChatToggle( _bNetworkMultiPlayer )
OnOptionsChanged()
OnSetActivePlayer()
Events.GameOptionsChanged.Add( OnOptionsChanged )
Events.GameplaySetActivePlayer.Add( OnSetActivePlayer )
LuaEvents.ChatShow.Add( OnChatToggle )
Events.SerialEventGameDataDirty.Add( UpdateCivList )
Events.SerialEventScoreDirty.Add( UpdateCivList )
Events.SerialEventCityInfoDirty.Add( UpdateCivList )
Events.SerialEventImprovementCreated.Add( UpdateCivList )	-- required to update trades when a resource gets hooked up
Events.WarStateChanged.Add( UpdateCivList )			-- update when war is declared
Events.MultiplayerGamePlayerDisconnected.Add( UpdateCivList )
Events.MultiplayerGamePlayerUpdated.Add( UpdateCivList )
Events.MultiplayerHotJoinStarted.Add(
function()
	Controls.HotJoinNotice:SetHide(false)
	return UpdateCivList()
end )
Events.MultiplayerHotJoinCompleted.Add(
function()
	Controls.HotJoinNotice:SetHide(true)
	return UpdateCivList()
end )
local function HighlightAndUpdateCivList( iPlayer, isActive )
	local instance = _tMajorControlTable[ iPlayer ] or _tMinorControlTable[ iPlayer ]
	if instance then
		instance.Active:SetHide( not isActive )
	end
	return UpdateCivList()
end
Events.RemotePlayerTurnStart.Add( function() return HighlightAndUpdateCivList( _iActivePlayer, true ) end)
Events.RemotePlayerTurnEnd.Add( function() return HighlightAndUpdateCivList( _iActivePlayer, false ) end)

Events.AIProcessingStartedForPlayer.Add( function( iPlayer )
--print("AIProcessingStartedForPlayer", iPlayer )
	return HighlightAndUpdateCivList( iPlayer, true )
end)
Events.AIProcessingEndedForPlayer.Add( function( iPlayer )
--print("AIProcessingEndedForPlayer", iPlayer )
	if iPlayer == 63 then
		HookupNewNotifications()
	elseif iPlayer == _iActivePlayer then
--print("RemoveNewNotifications")
		_sAlertMessages = _sAlertMessageTitle
		_bAlertMessages = true
		GameEvents.SetPopulation.RemoveAll()
		GameEvents.CityBoughtPlot.RemoveAll()
	end
	return HighlightAndUpdateCivList( iPlayer, false )
end)

Events.LeavingLeaderViewMode.Add(
function()
--print("LeavingLeaderViewMode event in leader mode", _iLeaderMode )
	if _iLeaderMode then
		_iLeaderMode = false
		_iLeader = false
		Controls.CivPanel:ChangeParent( Controls.CivPanelContainer )
	end
	return UpdateCivList()
end)
Events.AILeaderMessage.Add(
function( iPlayer ) --, diploUIStateID, leaderMessage, animationAction, data1 )
--local d = "?"; for k,v in pairs( DiploUIStateTypes ) do if v == diploUIStateID then d = k break end end
--print("AILeaderMessage event", Players[iPlayer]:GetCivilizationShortDescription(), diploUIStateID, d, "during my turn", _pActivePlayer:IsTurnActive(), "IsGameCoreBusy", IsGameCoreBusy() )
	_iLeader = iPlayer
	for i=1, #_tLeaderPopups do
		if not _tLeaderPopups[i]:IsHidden() then
			if i ~= _iLeaderMode then
				_iLeaderMode = i
				Controls.CivPanel:ChangeParent( _tLeaderPopups[i] )
--print("enter leader mode", _tLeaderPopups[i]:GetID() )
			end
			return UpdateCivList()
		end
	end
end)
LuaEvents.EUILeaderHeadRoot.Add(
function()
	if not _iLeaderMode or _iLeaderMode>1 then
		_iLeaderMode = 1
		Controls.CivPanel:ChangeParent( _tLeaderPopups[1] )
	end
--print("enter leader mode", 1 )
end)
--==========================================================
-- On shutdown, we need to get our children back,
-- or they will get duplicted on future hotload
-- and we'll assert clearing the registered button handler
--==========================================================
ContextPtr:SetShutdown( function()
	Controls.CivPanel:ChangeParent( ContextPtr )
	Controls.DarkBordersContainer:ChangeParent( ContextPtr )
end)
Controls.DarkBordersContainer:ChangeParent( LookUpControl( "/Ingame/WorldViewControls" ) )
end)
