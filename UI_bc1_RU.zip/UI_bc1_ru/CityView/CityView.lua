--==========================================================
-- City View
-- Re-written by bc1 using Notepad++
-- code is common using switches
-- compatible with Gazebo's City-State Diplomacy Mod (CSD) for Brave New World v21
-- compatible with JFD's Piety & Prestige for Brave New World
-- compatible with GameInfo.Yields() iterator broken by Communitas
--==========================================================

Events.SequenceGameInitComplete.Add(function()

local _bCiv5 = InStrategicView ~= nil
local _bCivBE = not _bCiv5
local _bCiv5vanilla = _bCiv5 and not Game.GetReligionName
local _bCiv5BNW = _bCiv5 and Game.GetActiveLeague ~= nil

include "UserInterfaceSettings"
local UserInterfaceSettings = UserInterfaceSettings

include "GameInfoCache" -- warning! booleans are true, not 1, and use iterator ONLY with table field conditions, NOT string SQL query
local GameInfo = GameInfoCache

include "IconHookup"
local IconHookup = IconHookup
local CivIconHookup = CivIconHookup
local ColorCulture = Color( 1, 0, 1, 1 )

include "InstanceStackManager"
local InstanceStackManager = InstanceStackManager

include "ShowProgress"
local ShowProgress = ShowProgress

include "CityUtilities"
local CityPlots = CityPlots
local GetCityHappiness = GetCityHappiness
local GetCityUnhappiness = GetCityUnhappiness
local UpdateCityInstance = UpdateCityInstance

if _bCiv5BNW then
	include "GreatPeopleIcons"
end
local GreatPeopleIcons = GreatPeopleIcons

if _bCivBE then
	include "IntrigueHelper"
end

--==========================================================
-- Minor lua optimizations
--==========================================================

local ipairs = ipairs
local ceil = math.ceil
local floor = math.floor
local max = math.max
local min = math.min
local sqrt = math.sqrt
local pairs = pairs
local tonumber = tonumber
local tostring = tostring
local unpack = unpack
local concat = table.concat
local insert = table.insert
local sort = table.sort

local ButtonPopupTypes = ButtonPopupTypes
local CityAIFocusTypes = CityAIFocusTypes
local CityUpdateTypes = CityUpdateTypes
local ContextPtr = ContextPtr
local Controls = Controls
local Events = Events
local EventsClearHexHighlightStyle = Events.ClearHexHighlightStyle.Call
local EventsRequestYieldDisplay = Events.RequestYieldDisplay.Call
local EventsSerialEventHexHighlight = Events.SerialEventHexHighlight.Call
local Game = Game
local DEFAULT_SPECIALIST = GameDefines.DEFAULT_SPECIALIST
local UNHAPPINESS_PER_POPULATION = GameDefines.UNHAPPINESS_PER_POPULATION
local FOOD_CONSUMPTION_PER_POPULATION = GameDefines.FOOD_CONSUMPTION_PER_POPULATION
local MAX_CITY_HIT_POINTS = GameDefines.MAX_CITY_HIT_POINTS
local GameInfoTypes = GameInfoTypes
local GameMessageTypes = GameMessageTypes
local GetHeadSelectedCity = UI.GetHeadSelectedCity
local GetUnitPortraitIcon = UI.GetUnitPortraitIcon
local HexToWorld = HexToWorld
local KeyEvents = KeyEvents
local Keys = Keys
local L = Locale.ConvertTextKey
local Locale = Locale
local LuaEvents = LuaEvents
local NOTIFICATION_PRODUCTION = NotificationTypes.NOTIFICATION_PRODUCTION
local NUM_YIELD_TYPES_M1 = YieldTypes.NUM_YIELD_TYPES-1
local Network = Network
local ORDER_CONSTRUCT = OrderTypes.ORDER_CONSTRUCT
local ORDER_CREATE = OrderTypes.ORDER_CREATE
local ORDER_MAINTAIN = OrderTypes.ORDER_MAINTAIN
local ORDER_TRAIN = OrderTypes.ORDER_TRAIN
local OptionsManager = OptionsManager
local Players = Players
local PopupPriority = PopupPriority
local TaskTypes = TaskTypes
local ToHexFromGrid = ToHexFromGrid
local UI = UI
local YIELD_CULTURE = YieldTypes.YIELD_CULTURE
local YIELD_FAITH = YieldTypes.YIELD_FAITH
local YIELD_FOOD = YieldTypes.YIELD_FOOD
local YIELD_GOLD = _bCiv5 and YieldTypes.YIELD_GOLD or YieldTypes.YIELD_ENERGY
local YIELD_SCIENCE = YieldTypes.YIELD_SCIENCE
local YieldDisplayTypesAREA = YieldDisplayTypes.AREA
local eLClick = Mouse.eLClick
local eMouseEnter = Mouse.eMouseEnter
local eRClick = Mouse.eRClick

--==========================================================
-- Globals
--==========================================================

local _sCurrencyIcon = _bCiv5 and "[ICON_GOLD]" or "[ICON_ENERGY]"
local _sMaintenanceCurrency = _bCiv5 and "GoldMaintenance" or "EnergyMaintenance"
local _bScienceEnabled = not Game.IsOption(GameOptionTypes.GAMEOPTION_NO_SCIENCE)
--local _bPoliciesEnabled = not Game.IsOption(GameOptionTypes.GAMEOPTION_NO_POLICIES)
local _bHappinessEnabled = not Game.IsOption(GameOptionTypes.GAMEOPTION_NO_HAPPINESS)
local _bReligionEnabled = not Game.IsOption(GameOptionTypes.GAMEOPTION_NO_RELIGION)

local _bAdvisor = true

local _iActivePlayer = Game.GetActivePlayer()
local _pActivePlayer = Players[ _iActivePlayer ]
local _tFinishedItems = {}

local _bWorkerHeadingOpen = OptionsManager.IsNoCitizenWarning()

local _tWorldPositionOffset = { x = 0, y = 0, z = 30 }
local _tWorldPositionOffset2 = { x = 0, y = 35, z = 0 }
local _iPortraitSize = Controls.PQportrait:GetSizeX()
local _iScreenWidth, _iScreenHeight = UIManager.GetScreenSizeVal()

local _PlotButtonIM	= InstanceStackManager( "PlotButtonInstance", "PlotButtonAnchor", Controls.PlotButtonContainer )
local _BuyPlotButtonIM	= InstanceStackManager( "BuyPlotButtonInstance", "BuyPlotButtonAnchor", Controls.PlotButtonContainer )
local _GreatWorksIM	= InstanceStackManager( "Work", "Button", false )
local _SpecialistsIM	= InstanceStackManager( "Slot", "Button", false )
local _CitiesIM = InstanceStackManager( "CityInstance", "Button", Controls.CityStack )

local _ProdQueueIM, _SpecialBuildingsIM, _GreatWorkIM, _WondersIM, _BuildingsIM, _GreatPeopleIM, _SlackerIM, _CityInfoIM, _UnitSelectIM, _BuildingSelectIM, _WonderSelectIM, _ProcessSelectIM, _FocusSelectIM,
		_iQueuedItem, _bBuyPlotMode, _pPreviousCity, _bButtonPopupChooseProduction, _bScreenAutoClose, _bResetCityPlotPurchase, _bNextCityProduction
local _bDebugMode = Game.IsDebugMode()

local _tCitySpecialists = {}
local _CityInstances = {}

local _bViewOnly = true

local _tSlotTextures = {
	SPECIALIST_CITIZEN = "CitizenUnemployed.dds",
	SPECIALIST_SCIENTIST = "CitizenScientist.dds",
	SPECIALIST_MERCHANT = "CitizenMerchant.dds",
	SPECIALIST_ARTIST = "CitizenArtist.dds",
	SPECIALIST_MUSICIAN = "CitizenArtist.dds",
	SPECIALIST_WRITER = "CitizenArtist.dds",
	SPECIALIST_ENGINEER = "CitizenEngineer.dds",
	SPECIALIST_CIVIL_SERVANT = "CitizenCivilServant.dds",	-- Compatibility with Gazebo's City-State Diplomacy Mod (CSD) for Brave New World
	SPECIALIST_JFD_MONK = "CitizenMonk.dds", -- Compatibility with JFD's Piety & Prestige for Brave New World
	SPECIALIST_PMMM_ENTERTAINER = "PMMMEntertainmentSpecialist.dds", --Compatibility with Vicevirtuoso's Madoka Magica: Wish for the World for Brave New World
}
for row in GameInfo.Specialists() do
	if row.SlotTexture then
		_tSlotTextures[ row.Type ] = row.SlotTexture
	end
end

local _sSlackerTexture = _bCivBE and "UnemployedIndicator.dds" or _tSlotTextures[ (GameInfo.Specialists[DEFAULT_SPECIALIST] or {}).Type ]

local _tGameInfo = {
	[ORDER_TRAIN] = GameInfo.Units,
	[ORDER_CONSTRUCT] = GameInfo.Buildings,
	[ORDER_CREATE] = GameInfo.Projects,
	[ORDER_MAINTAIN] = GameInfo.Processes,
}
local _tAvisorRecommended = {
	[ORDER_TRAIN] = Game.IsUnitRecommended,
	[ORDER_CONSTRUCT] = Game.IsBuildingRecommended,
	[ORDER_CREATE] = Game.IsProjectRecommended,
}
local _tAdvisors = {
	[AdvisorTypes.ADVISOR_ECONOMIC] = "EconomicRecommendation",
	[AdvisorTypes.ADVISOR_MILITARY] = "MilitaryRecommendation",
	[AdvisorTypes.ADVISOR_SCIENCE] = "ScienceRecommendation",
	[AdvisorTypes.ADVISOR_FOREIGN] = "ForeignRecommendation",
}

local function GetSelectedCity()
	return ( not Game.IsNetworkMultiPlayer() or _pActivePlayer:IsTurnActive() ) and GetHeadSelectedCity()
end

local function GetSelectedModifiableCity()
	return (not _bViewOnly or _bDebugMode) and GetSelectedCity()
end

----------------
-- Citizen Focus
local _tCityFocusButtons = { Controls.AvoidGrowthButton, Controls.ResetButton, Controls.BoxOSlackers, Controls.EditButton, Controls.CityFocusPullDown }
local InitCityFocusPullDown
do
	local instance = {}
	local pulldown = Controls.CityFocusPullDown
	local button = pulldown:GetButton()
	local _tCityFocusText = {
		[ CityAIFocusTypes.NO_CITY_AI_FOCUS_TYPE or -9 ] = "TXT_KEY_CITYVIEW_FOCUS_BALANCED",
		[ CityAIFocusTypes.CITY_AI_FOCUS_TYPE_FOOD or -9 ] = "TXT_KEY_CITYVIEW_FOCUS_FOOD",
		[ CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PRODUCTION or -9 ] = "TXT_KEY_CITYVIEW_FOCUS_PROD",
		[ CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GOLD or CityAIFocusTypes.CITY_AI_FOCUS_TYPE_ENERGY or -9 ] = "TXT_KEY_CITYVIEW_FOCUS_GOLD",
		[ CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GREAT_PEOPLE or -9 ] = "TXT_KEY_CITYVIEW_FOCUS_GREAT_PERSON",
		[ CityAIFocusTypes.CITY_AI_FOCUS_TYPE_SCIENCE or -9 ] = "TXT_KEY_CITYVIEW_FOCUS_RESEARCH",
		[ CityAIFocusTypes.CITY_AI_FOCUS_TYPE_CULTURE or -9 ] = "TXT_KEY_CITYVIEW_FOCUS_CULTURE",
--		[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PROD_GROWTH or -9] = "[ICON_PRODUCTION][ICON_FOOD]",
--		[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GOLD_GROWTH or -9] = "[ICON_GOLD][ICON_FOOD]",
		[ CityAIFocusTypes.CITY_AI_FOCUS_TYPE_FAITH or -9 ] = "TXT_KEY_CITYVIEW_FOCUS_FAITH",
		[-9] = nil}
	for iFocus, s in pairs( _tCityFocusText ) do
		pulldown:BuildEntry( "InstanceOne", instance )
		instance.Button:LocalizeAndSetText( s.."_TEXT" )
		instance.Button:LocalizeAndSetToolTip( s.."_TT" )
		instance.Button:SetVoid1( iFocus )
	end
	pulldown:CalculateInternals()
	InitCityFocusPullDown = function( city )
		local s = _tCityFocusText[ city:GetFocusType() ] or "TXT_KEY_CITYVIEW_FOCUS_BALANCED"
		button:LocalizeAndSetText( s.."_TEXT" )
		button:LocalizeAndSetToolTip( s.."_TT" )
	end
	pulldown:RegisterSelectionCallback( function( iFocus )
		local city = GetSelectedModifiableCity()
		if city then
			Network.SendSetCityAIFocus( city:GetID(), iFocus )
			return Network.SendUpdateCityCitizens( city:GetID() )
		end
	end)
end

local function HexRadius( a )
	return ( sqrt( 1 + 4*a/3 ) - 1 ) / 2
end

local function SetupCallbacks( controls, toolTips, tootTipType, callBacks )
	local control
	-- Setup Tootips
	for name, callback in pairs( toolTips ) do
		control = controls[name]
		if control then
			control:SetToolTipCallback( callback )
			control:SetToolTipType( tootTipType )
		end
	end
	-- Setup Callbacks
	for name, eventCallbacks in pairs( callBacks ) do
		control = controls[name]
		if control then
			for event, callback in pairs( eventCallbacks ) do
				control:RegisterCallback( event, callback )
			end
		end
	end
end


Controls.FaithBox:SetHide( _bCivBE or _bCiv5vanilla )
Controls.TourismBox:SetHide( not _bCiv5BNW )
Controls.CityInfoStack:CalculateSize()

local function ResizeLeftStacks()
	local iQueuePanelHeight = min( 190, Controls.QueueStack:IsHidden() and 0 or Controls.QueueStack:GetSizeY() )	-- 190 = 5 x 38=instance height
	Controls.QueueSlider2:SetSizeY( iQueuePanelHeight )
	Controls.QueueScrollPanel:SetSizeY( iQueuePanelHeight )
	Controls.QueueScrollPanel:CalculateInternalSize()
	Controls.TopLeftStacks:CalculateSize()
	local iTopLeftStackHeight = Controls.TopLeftStacks:GetSizeY()
	Controls.TopLeftBackground:SetSizeY( iTopLeftStackHeight + 85 )
	Controls.TopLeftBackground:ReprocessAnchoring()
	local iTrimOffset = 282
	if Controls.SelectionBackground:IsHidden() then
		iTrimOffset = 0
	else
		Controls.SelectionStacks:CalculateSize()
		local iSelectionPanelHeight = min( Controls.SelectionStacks:GetSizeY(), max( _iScreenHeight - 85 - iTopLeftStackHeight, 160 ) )
		Controls.SelectionBackground:SetSizeY( iSelectionPanelHeight + 85 )
		Controls.SelectionScrollPanel:SetSizeY( iSelectionPanelHeight )
		Controls.SelectionScrollPanel:CalculateInternalSize()
		Controls.SelectionBackground:ReprocessAnchoring()
	end
	return Controls.CityTrimLeft:SetOffsetX( iTrimOffset )
end

local function ResizeRightStack()
	Controls.BoxOSlackers:SetHide( Controls.SlackerStack:IsHidden() )
	Controls.BoxOSlackers:SetSizeY( Controls.SlackerStack:GetSizeY() )
	Controls.WorkerManagementBox:CalculateSize()
	Controls.WorkerManagementBox:ReprocessAnchoring()
	Controls.RightStack:CalculateSize()
	local iRightStackHeight = Controls.RightStack:GetSizeY() + 85
	local iRightPanelHeight = _iScreenHeight + 48
	local iTrimOffset = 295
	if iRightPanelHeight > iRightStackHeight then
		iRightPanelHeight = iRightStackHeight
		iTrimOffset = 0
	end
	Controls.BuildingListBackground:SetSizeY( iRightPanelHeight )
	Controls.RightScrollPanel:SetSizeY( min( _iScreenHeight - 38, iRightStackHeight ) )
	Controls.RightScrollPanel:CalculateInternalSize()
	Controls.RightScrollPanel:ReprocessAnchoring()
	return Controls.CityTrimRight:SetOffsetX( iTrimOffset )
end

local cityIsCanPurchase
if _bCiv5vanilla then
	function cityIsCanPurchase( city, bTestPurchaseCost, bTestTrainable, iUnit, iBuilding, iProject, iYield )
		if iYield == YIELD_GOLD then
			return city:IsCanPurchase( not bTestPurchaseCost, iUnit, iBuilding, iProject )
							-- bOnlyTestVisible
		else
			return false
		end
	end
else
	function cityIsCanPurchase( city, ... )
		return city:IsCanPurchase( ... )
	end
end

--==========================================================
-- Clear out the UI so that when a player changes
-- the next update doesn't show the previous player's
-- values for a frame
--==========================================================
local function ClearCityUIInfo()
	Controls.TopLeftBackground:SetHide(true)
	Controls.ProductionPortraitButton:SetHide(true)
	Controls.SelectionBackground:SetHide(true)
	Controls.BuildingListBackground:SetHide(true)
end

--==========================================================
-- Selling Buildings
--==========================================================
local function SellBuilding( iBuilding )

	local city = GetSelectedModifiableCity()
	local building = GameInfo.Buildings[ iBuilding ]
	-- Can this building be sold?
	if building and city then
		if _bDebugMode then
			city:SetNumRealBuilding( iBuilding, 0 )
			Network.SendUpdateCityCitizens( city:GetID() )
			Network.ForceResync()
		elseif city:IsBuildingSellable( iBuilding ) then
			Controls.YesButton:SetVoids( city:GetID(), iBuilding )
			Controls.SellBuildingTitle:SetText( building._Name:upper() )
			Controls.SellBuildingText:LocalizeAndSetText( "TXT_KEY_SELL_BUILDING_INFO", city:GetSellBuildingRefund(iBuilding), building[_sMaintenanceCurrency] or 0 )
			Controls.SellBuildingImage:SetHide( not IconHookup( building.PortraitIndex, 256, building.IconAtlas, Controls.SellBuildingImage ) )
			Controls.SellBuildingStack:CalculateSize()
			Controls.SellBuildingFrame:DoAutoSize()
--todo energy
			return Controls.SellBuildingConfirm:SetHide( false )
		end
	end
end

local function CancelBuildingSale()
	Controls.SellBuildingConfirm:SetHide(true)
	return Controls.YesButton:SetVoids( -1, -1 )
end

local function CleanupCityScreen()
	-- clear any rogue leftover tooltip
	_bButtonPopupChooseProduction = false
	Controls.RightScrollPanel:SetScrollValue(0)
	return CancelBuildingSale()
end

local function GotoCity( iPlayer, iCity )
	local player = Players[ iPlayer ]
	local city = player:GetCityByID( iCity )
	if city then
		CleanupCityScreen()
		UI.SelectCity( city )
		return UI.LookAtSelectionPlot()
	end
end

local function GotoNextCity()
	if not _bViewOnly then
		CleanupCityScreen()
		return Game.DoControl( GameInfoTypes.CONTROL_NEXTCITY )
	end
end

local function GotoPrevCity()
	if not _bViewOnly then
		CleanupCityScreen()
		return Game.DoControl( GameInfoTypes.CONTROL_PREVCITY )
	end
end

local function ExitCityScreen()
--print("request exit city screen")

	return Events.SerialEventExitCityScreen()
end

--==========================================================
-- Key Down Processing
--==========================================================
do
	local VK_RETURN = Keys.VK_RETURN
	local VK_ESCAPE = Keys.VK_ESCAPE
	local VK_LEFT  = Keys.VK_LEFT
	local VK_RIGHT = Keys.VK_RIGHT
	local KeyDown = KeyEvents.KeyDown
	ContextPtr:SetInputHandler( function ( uiMsg, wParam )
		if uiMsg == KeyDown then
			if wParam == VK_ESCAPE or wParam == VK_RETURN then
				if Controls.SellBuildingConfirm:IsHidden() then
					ExitCityScreen()
				else
					CancelBuildingSale()
				end
				return true
			elseif wParam == VK_LEFT then
				GotoPrevCity()
				return true
			elseif wParam == VK_RIGHT then
				GotoNextCity()
				return true
			end
		end
	end)
end

--==========================================================
-- Pedia
--==========================================================
local SearchForPediaEntry = Events.SearchForPediaEntry.Call
local function Pedia( row )
	return row and SearchForPediaEntry( row._Name )
end
	
local function UnitClassPedia( iUnitClass )
	return Pedia( GameInfo.UnitClasses[ iUnitClass ] )
end

local function BuildingPedia( iBuilding )
	return Pedia( GameInfo.Buildings[ iBuilding ] )
end

local function SpecialistPedia( iBuilding )
	return Pedia( GameInfo.Specialists[ GameInfoTypes[(GameInfo.Buildings[iBuilding]or{}).SpecialistType] or DEFAULT_SPECIALIST ] )
end

local function SelectionPedia( iOrder, iRow )
	return Pedia( (_tGameInfo[ iOrder ]or{})[ iRow ] )
end

local function ProductionPedia( iQueuedItem )
	local city = GetHeadSelectedCity()
	if city and iQueuedItem then
		return SelectionPedia( city:GetOrderFromQueue( iQueuedItem ) )
	end
end

--==========================================================
-- Tooltips
--==========================================================

local GreatPeopleIcon = GreatPeopleIcons and function (k)
	return GreatPeopleIcons[k] 
end or function()
	return "[ICON_GREAT_PEOPLE]"
end

local function GetSpecialistYields( city, rSpecialist )
	local yieldTips = {}
	if city and rSpecialist then
		local iSpecialistYield, iSpecialistYieldModifier, rYield
		local iSpecialist = rSpecialist.ID
		local player = Players[ city:GetOwner() ]
		-- Culture
		local iCultureFromSpecialist = city:GetCultureFromSpecialist( iSpecialist )
		local iSpecialistCultureModifier = city:GetCultureRateModifier() + ( player and ( player:GetCultureCityModifier() + ( city:GetNumWorldWonders() > 0 and player:GetCultureWonderMultiplier() or 0 ) or 0 ) )
		-- Yield
		for iYield = 0, NUM_YIELD_TYPES_M1 do
			rYield = GameInfo.Yields[iYield]
			if rYield then
				iSpecialistYield = city:GetSpecialistYield( iSpecialist, iYield )
				iSpecialistYieldModifier = city:GetBaseYieldRateModifier( iYield )
				if iYield == YIELD_CULTURE then
					iSpecialistYield = iSpecialistYield + iCultureFromSpecialist
					iSpecialistYieldModifier = iSpecialistYieldModifier + iSpecialistCultureModifier
					iCultureFromSpecialist = 0
				end
				if iSpecialistYield ~= 0 then
					insert( yieldTips, iSpecialistYield * iSpecialistYieldModifier / 100 .. rYield.IconString )
				end
			end
		end
		if iCultureFromSpecialist ~= 0 then
			insert( yieldTips, iCultureFromSpecialist .. "[ICON_CULTURE]" )
		end
		if _bCiv5 and (rSpecialist.GreatPeopleRateChange or 0) ~= 0 then
			insert( yieldTips, rSpecialist.GreatPeopleRateChange .. GreatPeopleIcon( rSpecialist.Type ) )
		end
	end
	return concat( yieldTips, " " )
end

local ShowItemToolTipAndPicture = LuaEvents.ShowItemToolTipAndPicture.Call
local BuildingToolTip = LuaEvents.CityViewBuildingToolTip.Call
local CityOrderItemTooltip = LuaEvents.CityOrderItemTooltip.Call
-- CityViewSpecialistToolTip
local function SpecialistTooltip( control )
	local iBuilding = control:GetVoid1()
	local building = GameInfo.Buildings[ iBuilding ]
	local sSpecialistType = building and building.SpecialistType
	local iSpecialist = sSpecialistType and GameInfoTypes[sSpecialistType] or DEFAULT_SPECIALIST
	local rSpecialist = GameInfo.Specialists[ iSpecialist ]
	local tip = rSpecialist._Name .. " " .. GetSpecialistYields( GetHeadSelectedCity(), rSpecialist )
	local tSlot = building and _tCitySpecialists[iBuilding]
	if tSlot and not tSlot[control:GetVoid2()] then
		tip = L"TXT_KEY_CITYVIEW_EMPTY_SLOT".."[NEWLINE]("..tip..")"
	end
	return ShowItemToolTipAndPicture( tip, rSpecialist.PortraitIndex, rSpecialist.IconAtlas )
end

local function ProductionToolTip( control )
	local city = GetHeadSelectedCity()
	local iQueuedItem = control:GetVoid1()
	if city and not ( Controls.QueueSlider1:IsTrackingLeftMouseButton() or Controls.QueueSlider2:IsTrackingLeftMouseButton() ) then
		return CityOrderItemTooltip( city, false, false, city:GetOrderFromQueue( iQueuedItem ) )
	end
end

--==========================================================
-- Specialist Managemeent
--==========================================================

local function OnSlackersSelected( iBuilding, iSlot )
	local city = GetSelectedModifiableCity()
	if city then
		for _=1, iSlot<=0 and city:GetSpecialistCount( DEFAULT_SPECIALIST ) or 1 do
			Network.SendDoTask( city:GetID(), TaskTypes.TASK_REMOVE_SLACKER, 0, -1, false )
		end
		return Network.SendUpdateCityCitizens( city:GetID() )
	end
end

local function ToggleSpecialist( iBuilding, iSlot )
	local city = iBuilding and iSlot and GetSelectedModifiableCity()
	if city then
		local iCity = city:GetID()
		-- If Specialists are automated then you can't change things with them
		if _bCiv5 and not city:IsNoAutoAssignSpecialists() then
--			Game.SelectedCitiesGameNetMessage(GameMessageTypes.GAMEMESSAGE_DO_TASK, TaskTypes.TASK_NO_AUTO_ASSIGN_SPECIALISTS, -1, -1, true)
			Network.SendDoTask( iCity, TaskTypes.TASK_NO_AUTO_ASSIGN_SPECIALISTS, -1, -1, true )
			Controls.NoAutoSpecialistCheckbox:SetCheck(true)
			local b = Controls.NoAutoSpecialistCheckbox2
			if b then
				b:SetCheck(true)
			end
		end

		local iSpecialist = GameInfoTypes[(GameInfo.Buildings[ iBuilding ] or {}).SpecialistType] or -1
		local tBuildingSpecialists = _tCitySpecialists[iBuilding]
		if tBuildingSpecialists[iSlot] then
			if city:GetNumSpecialistsInBuilding(iBuilding) > 0 then
				tBuildingSpecialists[iSlot] = false
				tBuildingSpecialists.n = tBuildingSpecialists.n - 1
--				Game.SelectedCitiesGameNetMessage( GameMessageTypes.GAMEMESSAGE_DO_TASK, TaskTypes.TASK_REMOVE_SPECIALIST, iSpecialist, iBuilding )
				Network.SendDoTask( iCity, TaskTypes.TASK_REMOVE_SPECIALIST, iSpecialist, iBuilding )
			end
		elseif city:IsCanAddSpecialistToBuilding(iBuilding) then
			tBuildingSpecialists[iSlot] = true
			tBuildingSpecialists.n = tBuildingSpecialists.n + 1
--			Game.SelectedCitiesGameNetMessage( GameMessageTypes.GAMEMESSAGE_DO_TASK, TaskTypes.TASK_ADD_SPECIALIST, iSpecialist, iBuilding )
			Network.SendDoTask( iCity, TaskTypes.TASK_ADD_SPECIALIST, iSpecialist, iBuilding )
		end
		return Network.SendUpdateCityCitizens( iCity )
	end
end

--==========================================================
-- Great Work Managemeent
--==========================================================

local function GreatWorkPopup( iGreatWork )
	local row = GameInfo.GreatWorks[ Game.GetGreatWorkType( iGreatWork or -1 ) or -1 ]

	if row and row.GreatWorkClassType ~= "GREAT_WORK_ARTIFACT" then
		return Events.SerialEventGameMessagePopup{
			Type = ButtonPopupTypes.BUTTONPOPUP_GREAT_WORK_COMPLETED_ACTIVE_PLAYER,
			Data1 = iGreatWork,
			Priority = PopupPriority.Current
			}
	end
end

local function YourCulturePopup( iGreatWork )
	return Events.SerialEventGameMessagePopup{
		Type = ButtonPopupTypes.BUTTONPOPUP_CULTURE_OVERVIEW,
		Data1 = 1,
		Data2 = 1,
		}
end

local function ThemingTooltip( iBuildingClass, _, control )
	control:SetToolTipString( GetHeadSelectedCity():GetThemingTooltip( iBuildingClass ) )
end

local function GreatWorkTooltip( iGreatWork, iGreatWorkSlot, slot )
	if iGreatWork >= 0 then
		return slot:SetToolTipString( Game.GetGreatWorkTooltip( iGreatWork, GetHeadSelectedCity():GetOwner() ) )
	else
		return slot:LocalizeAndSetToolTip( tostring(( GameInfo.GreatWorkSlots[ iGreatWorkSlot ] or {}).EmptyToolTipText) )
	end
end

--==========================================================
-- Great Person Meters
--==========================================================
local function UpdateGreatPersonMeters( city, player, iPlayer )
	_GreatPeopleIM:ResetInstances()
	for rSpecialist in GameInfo.Specialists() do

		local sGreatPeopleUnitClass = rSpecialist.GreatPeopleUnitClass	-- nil / UNITCLASS_ARTIST / UNITCLASS_SCIENTIST / UNITCLASS_MERCHANT / UNITCLASS_ENGINEER ...
		local rUnitClass = GameInfo.UnitClasses[ sGreatPeopleUnitClass or -1 ]
		if rUnitClass then
			local gpThreshold = city:GetSpecialistUpgradeThreshold(rUnitClass.ID)
			local gpProgress = city:GetSpecialistGreatPersonProgressTimes100(rSpecialist.ID) / 100
			local gpChange = rSpecialist.GreatPeopleRateChange * city:GetSpecialistCount( rSpecialist.ID )
			for row in GameInfo.Buildings{SpecialistType = rSpecialist.Type} do
				if city:IsHasBuilding(row.ID) then
					gpChange = gpChange + row.GreatPeopleRateChange
				end
			end

			local gpChangePlayerMod = player:GetGreatPeopleRateModifier()
			local gpChangeCityMod = city:GetGreatPeopleRateModifier()
			local gpChangePolicyMod = 0
			local gpChangeWorldCongressMod = 0
			local gpChangeGoldenAgeMod = 0
			local isGoldenAge = player:GetGoldenAgeTurns() > 0

			if _bCiv5BNW then
				-- Generic GP mods

				gpChangePolicyMod = player:GetPolicyGreatPeopleRateModifier()

				local worldCongress = (Game.GetNumActiveLeagues() > 0) and Game.GetActiveLeague()
				local sGreatPeopleUnitClass = rSpecialist.GreatPeopleUnitClass
				-- GP mods by type
				if sGreatPeopleUnitClass == "UNITCLASS_WRITER" then
					gpChangePlayerMod = gpChangePlayerMod + player:GetGreatWriterRateModifier()
					gpChangePolicyMod = gpChangePolicyMod + player:GetPolicyGreatWriterRateModifier()
					if worldCongress then
						gpChangeWorldCongressMod = gpChangeWorldCongressMod + worldCongress:GetArtsyGreatPersonRateModifier()
					end
					if isGoldenAge and player:GetGoldenAgeGreatWriterRateModifier() > 0 then
						gpChangeGoldenAgeMod = gpChangeGoldenAgeMod + player:GetGoldenAgeGreatWriterRateModifier()
					end
				elseif sGreatPeopleUnitClass == "UNITCLASS_ARTIST" then
					gpChangePlayerMod = gpChangePlayerMod + player:GetGreatArtistRateModifier()
					gpChangePolicyMod = gpChangePolicyMod + player:GetPolicyGreatArtistRateModifier()
					if worldCongress then
						gpChangeWorldCongressMod = gpChangeWorldCongressMod + worldCongress:GetArtsyGreatPersonRateModifier()
					end
					if isGoldenAge and player:GetGoldenAgeGreatArtistRateModifier() > 0 then
						gpChangeGoldenAgeMod = gpChangeGoldenAgeMod + player:GetGoldenAgeGreatArtistRateModifier()
					end
				elseif sGreatPeopleUnitClass == "UNITCLASS_MUSICIAN" then
					gpChangePlayerMod = gpChangePlayerMod + player:GetGreatMusicianRateModifier()
					gpChangePolicyMod = gpChangePolicyMod + player:GetPolicyGreatMusicianRateModifier()
					if worldCongress then
						gpChangeWorldCongressMod = gpChangeWorldCongressMod + worldCongress:GetArtsyGreatPersonRateModifier()
					end
					if isGoldenAge and player:GetGoldenAgeGreatMusicianRateModifier() > 0 then
						gpChangeGoldenAgeMod = gpChangeGoldenAgeMod + player:GetGoldenAgeGreatMusicianRateModifier()
					end
				elseif sGreatPeopleUnitClass == "UNITCLASS_SCIENTIST" then
					gpChangePlayerMod = gpChangePlayerMod + player:GetGreatScientistRateModifier()
					gpChangePolicyMod = gpChangePolicyMod + player:GetPolicyGreatScientistRateModifier()
					if worldCongress then
						gpChangeWorldCongressMod = gpChangeWorldCongressMod + worldCongress:GetScienceyGreatPersonRateModifier()
					end
				elseif sGreatPeopleUnitClass == "UNITCLASS_MERCHANT" then
					gpChangePlayerMod = gpChangePlayerMod + player:GetGreatMerchantRateModifier()
					gpChangePolicyMod = gpChangePolicyMod + player:GetPolicyGreatMerchantRateModifier()
					if worldCongress then
						gpChangeWorldCongressMod = gpChangeWorldCongressMod + worldCongress:GetScienceyGreatPersonRateModifier()
					end
				elseif sGreatPeopleUnitClass == "UNITCLASS_ENGINEER" then
					gpChangePlayerMod = gpChangePlayerMod + player:GetGreatEngineerRateModifier()
					gpChangePolicyMod = gpChangePolicyMod + player:GetPolicyGreatEngineerRateModifier()
					if worldCongress then
						gpChangeWorldCongressMod = gpChangeWorldCongressMod + worldCongress:GetScienceyGreatPersonRateModifier()
					end
				-- Compatibility with Gazebo's City-State Diplomacy Mod (CSD) for Brave New World
				elseif player.GetGreatDiplomatRateModifier and sGreatPeopleUnitClass == "UNITCLASS_GREAT_DIPLOMAT" then
					gpChangePlayerMod = gpChangePlayerMod + player:GetGreatDiplomatRateModifier()
				end

				-- Player mod actually includes policy mod and World Congress mod, so separate them for tooltip
				gpChangePlayerMod = gpChangePlayerMod - gpChangePolicyMod - gpChangeWorldCongressMod

			elseif sGreatPeopleUnitClass == "UNITCLASS_SCIENTIST" then

				gpChangePlayerMod = gpChangePlayerMod + player:GetTraitGreatScientistRateModifier()

			end

			local gpChangeMod = gpChangePlayerMod + gpChangePolicyMod + gpChangeWorldCongressMod + gpChangeCityMod + gpChangeGoldenAgeMod
			gpChange = (gpChangeMod / 100 + 1) * gpChange

			if gpProgress > 0 or gpChange > 0 then
				local instance = _GreatPeopleIM:GetInstance()
				instance.GPMeter:SetPercents( gpProgress / gpThreshold, (gpProgress + gpChange) / gpThreshold )
				local labelText = rUnitClass._Name
				local icon = GreatPeopleIcon(sGreatPeopleUnitClass)
				local tips = { "[COLOR_YIELD_FOOD]" .. Locale.ToUpper( labelText ) .. "[ENDCOLOR]" .. " " .. gpProgress .. icon .." / " .. gpThreshold .. icon }
--					insert( tips, L( "TXT_KEY_PROGRESS_TOWARDS", "[COLOR_YIELD_FOOD]" .. Locale.ToUpper( labelText ) .. "[ENDCOLOR]" ) )
				if gpChange > 0 then
					local gpTurns = ceil( (gpThreshold - gpProgress) / gpChange )
					insert( tips, "[COLOR_YIELD_FOOD]" .. Locale.ToUpper( L( "TXT_KEY_STR_TURNS", gpTurns ) ) .. "[ENDCOLOR]  "
								 .. gpChange .. icon .. " " .. L"TXT_KEY_GOLD_PERTURN_HEADING4_TITLE" )
					labelText = labelText .. ": " .. Locale.ToLower( L( "TXT_KEY_STR_TURNS", gpTurns ) )
				end
				instance.GreatPersonLabel:SetText( icon .. labelText )
				if _bCiv5vanilla then
					if gpChangeMod ~= 0 then
						insert( tips, "[ICON_BULLET] "..gpChangeMod..icon )
					end
				else
					if gpChangePlayerMod ~= 0 then
						insert( tips, L( "TXT_KEY_PLAYER_GP_MOD", gpChangePlayerMod ) )
					end
					if gpChangePolicyMod ~= 0 then
						insert( tips, L( "TXT_KEY_POLICY_GP_MOD", gpChangePolicyMod ) )
					end
					if gpChangeCityMod ~= 0 then
						insert( tips, L( "TXT_KEY_CITY_GP_MOD", gpChangeCityMod ) )
					end
					if gpChangeGoldenAgeMod ~= 0 then
						insert( tips, L( "TXT_KEY_GOLDENAGE_GP_MOD", gpChangeGoldenAgeMod ) )
					end
					if gpChangeWorldCongressMod < 0 then
						insert( tips, L( "TXT_KEY_WORLD_CONGRESS_NEGATIVE_GP_MOD", gpChangeWorldCongressMod ) )
					elseif gpChangeWorldCongressMod > 0 then
						insert( tips, L( "TXT_KEY_WORLD_CONGRESS_POSITIVE_GP_MOD", gpChangeWorldCongressMod ) )
					end
				end
				instance.GPBox:SetToolTipString( concat( tips, "[NEWLINE]") )
				instance.GPBox:SetVoid1( rUnitClass.ID )
				instance.GPBox:RegisterCallback( eRClick, UnitClassPedia )

				local portraitOffset, portraitAtlas = GetUnitPortraitIcon( GameInfoTypes[ rUnitClass.DefaultUnit ], iPlayer )
				instance.GPImage:SetHide(not IconHookup( portraitOffset, 64, portraitAtlas, instance.GPImage ) )
			end
		end
	end
	_GreatPeopleIM.Commit()
end

--==========================================================
-- City Buildings List
--==========================================================

local function sortBuildings(a,b)
	if a and b then
		if a[4] ~= b[4] then
			return a[4] < b[4]
		elseif a[3] ~= b[3] then
			return a[3] > b[3]
		end
		return a[2] < b[2]
	end
end

local function UpdateCityBuidings( city, bNotResisting, iPlayer, player )
	local tGreatWorkBuildings = {}
	local tSpecialistBuildings = {}
	local tWonders = {}
	local tOtherBuildings = {}
	local bNoWondersWithSpecialistInThisCity = true

	for building in GameInfo.Buildings() do
		local iBuilding = building.ID
		if city:IsHasBuilding(iBuilding) then
			local buildingClass = GameInfo.BuildingClasses[ building.BuildingClass ]
			local tBuildings
			local iGreatWorkCount = _bCiv5BNW and building.GreatWorkCount or 0
			local areSpecialistsAllowedByBuilding = city:GetNumSpecialistsAllowedByBuilding(iBuilding) > 0

			if buildingClass 
				and ( buildingClass.MaxGlobalInstances > 0
					or buildingClass.MaxTeamInstances > 0
					or ( buildingClass.MaxPlayerInstances == 1 and not areSpecialistsAllowedByBuilding ) )
			then
				tBuildings = tWonders
				if areSpecialistsAllowedByBuilding then
					bNoWondersWithSpecialistInThisCity = false
				end
			elseif areSpecialistsAllowedByBuilding then
				tBuildings = tSpecialistBuildings
			elseif iGreatWorkCount > 0 then
				tBuildings = tGreatWorkBuildings
			elseif iGreatWorkCount == 0 then		-- compatibility with Firaxis code exploit for invisibility
				tBuildings = tOtherBuildings
			end
			if tBuildings then
				insert( tBuildings, { building, building._Name, iGreatWorkCount, areSpecialistsAllowedByBuilding and GameInfoTypes[building.SpecialistType] or 999 } )
			end
		end
	end
	local strMaintenanceTT = L( "TXT_KEY_BUILDING_MAINTENANCE_TT", city:GetTotalBaseBuildingMaintenance() )
	Controls.SpecialBuildingsHeader:SetToolTipString(strMaintenanceTT)
	Controls.BuildingsHeader:SetToolTipString(strMaintenanceTT)
	Controls.GreatWorkHeader:SetToolTipString(strMaintenanceTT)
	Controls.SpecialistControlBox:SetHide( #tSpecialistBuildings < 1 )
	Controls.SpecialistControlBox2:SetHide( bNoWondersWithSpecialistInThisCity )
	_GreatWorksIM:ResetInstances()
	_SpecialistsIM:ResetInstances()
	local rHandicap = GameInfo.HandicapInfos[ player:GetHandicapType() ] or {}
	local iSpecialistHappiness = player:IsHalfSpecialistUnhappiness() and ( UNHAPPINESS_PER_POPULATION * ( (city:IsCapital() and player:GetCapitalUnhappinessMod() or 0)+100 ) * ( player:GetUnhappinessMod() + 100 ) * ( player:GetTraitPopUnhappinessMod() + 100 ) * ( rHandicap.PopulationUnhappinessMod or 100 ) / 2e8 ) or 0
	local function SetupBuildingList( tBuildings, buildingIM )
		buildingIM:ResetInstances()
		sort( tBuildings, sortBuildings )
		-- Get the active perk types for civ BE
		local cityOwnerPerks = _bCivBE and player:GetAllActivePlayerPerkTypes()
		local building, iBuilding, iBuildingClass, sBuildingName, iGreatWorkCount, iGreatWork, slotStack, slot, new, instance, buildingButton, sellButton, textButton

		for i = 1, #tBuildings do

			building, sBuildingName, iGreatWorkCount = unpack(tBuildings[i])
			iBuilding = building.ID
			iBuildingClass = GameInfoTypes[ building.BuildingClass ] or -1
			instance, new = buildingIM:GetInstance()
			slotStack = instance.SlotStack
			buildingButton = instance.Button
			sellButton = instance.SellButton
			textButton = instance.TextButton
			textButton:SetHide( true )

			if new then
				buildingButton:RegisterCallback( eRClick, BuildingPedia )
				buildingButton:SetToolTipCallback( BuildingToolTip )
				sellButton:RegisterCallback( eLClick, SellBuilding )
				textButton:RegisterCallback( eLClick, YourCulturePopup )
				textButton:RegisterCallback( eMouseEnter, ThemingTooltip )
			end
			buildingButton:SetVoid1( iBuilding )

			-- Can we sell this building?
			if _bDebugMode then
				sellButton:LocalizeAndSetText "TXT_KEY_DELETE_BUTTON"
				sellButton:SetHide( city:GetNumFreeBuilding( iBuilding ) > 0 )
				sellButton:SetVoid1( iBuilding )
			elseif not _bViewOnly and city:IsBuildingSellable( iBuilding ) then
				sellButton:SetText( city:GetSellBuildingRefund( iBuilding ) .. _sCurrencyIcon )
				sellButton:SetHide( false )
				sellButton:SetVoid1( iBuilding )
			else
				sellButton:SetHide( true )
			end


	--!!!BE portrait size is bigger

			instance.Portrait:SetHide( not IconHookup( building.PortraitIndex, 64, building.IconAtlas, instance.Portrait ) )

			-------------------
			-- Great Work Slots
			if iGreatWorkCount > 0 then
				local row = GameInfo.GreatWorkSlots[ building.GreatWorkSlotType or -1 ]
				if row then
					if city:IsThemingBonusPossible( iBuildingClass ) then
						textButton:SetText( " +" .. city:GetThemingBonus( iBuildingClass ) )
						textButton:SetVoid1( iBuildingClass )
						textButton:SetHide( false )
					end

					for i = 0, iGreatWorkCount - 1 do
						slot, new = _GreatWorksIM:GetInstance( slotStack )
						slot = slot.Button
						if new then
							slot:RegisterCallback( eLClick, YourCulturePopup )
							slot:RegisterCallback( eMouseEnter, GreatWorkTooltip )
						end
						iGreatWork = city:GetBuildingGreatWork( iBuildingClass, i )
						slot:SetVoids( iGreatWork, row.ID )
						if iGreatWork >= 0 then
							slot:SetTexture( row.FilledIcon )
							slot:RegisterCallback( eRClick, GreatWorkPopup )
						else
							slot:SetTexture( row.EmptyIcon )
							slot:ClearCallback( eRClick )
						end
					end
				end
			end

			-------------------
			-- Specialist Slots
			local iSpecialistsInBuilding = city:GetNumSpecialistsInBuilding( iBuilding )
			local tBuildingSpecialists = _tCitySpecialists[iBuilding] or {}
			if tBuildingSpecialists.n ~= iSpecialistsInBuilding then
				tBuildingSpecialists = { n = iSpecialistsInBuilding }
				for i = 1, iSpecialistsInBuilding do
					tBuildingSpecialists[i] = true
				end
				_tCitySpecialists[iBuilding] = tBuildingSpecialists
			end
			local sSpecialistType = building.SpecialistType
			local rSpecialist = GameInfo.Specialists[sSpecialistType]
			if rSpecialist then
				for iSlot = 1, city:GetNumSpecialistsAllowedByBuilding( iBuilding ) do
					slot, new = _SpecialistsIM:GetInstance( slotStack )
					slot = slot.Button
					if new then
						slot:RegisterCallback( eRClick, SpecialistPedia )
						slot:SetToolTipCallback( SpecialistTooltip )
					end
					if _bCiv5 then
						slot:SetTexture( tBuildingSpecialists[ iSlot ] and _tSlotTextures[ sSpecialistType ] or "CitizenEmpty.dds" )
					else
						-- todo (does not look right)
						IconHookup( rSpecialist.PortraitIndex, 45, rSpecialist.IconAtlas, slot )
						slot:SetHide( not tBuildingSpecialists[ iSlot ] )
					end
					slot:SetVoids( iBuilding, iSlot )
					if _bViewOnly then
						slot:ClearCallback( eLClick )
					else
						slot:RegisterCallback( eLClick, ToggleSpecialist )
					end
				end -- Specialist Slots
			end

			-- Building stats/bonuses
			local iMaintenanceCost = tonumber(building[_sMaintenanceCurrency]) or 0
			local iDefenseChange = tonumber(building.Defense) or 0
			local iHitPointChange = tonumber(building.ExtraCityHitPoints) or 0
			local iBuildingCultureRate = (_bCiv5vanilla and tonumber(building.Culture) or 0) + (rSpecialist and city:GetCultureFromSpecialist( rSpecialist.ID ) or 0) * iSpecialistsInBuilding
			local iBuildingCultureModifier = tonumber(building.CultureRateModifier) or 0
			local iCityCultureRateModifier = player:GetCultureCityModifier() + city:GetCultureRateModifier() + (city:GetNumWorldWonders() > 0 and player and player:GetCultureWonderMultiplier() or 0)
			local iCityCultureRate
			local iCityPopulation = city:GetPopulation()
			local tips = {}
			local thisBuildingAndYieldTypes = { BuildingType = building.Type }
			if _bCiv5 then
				iCityCultureRate = city:GetBaseJONSCulturePerTurn()
				-- Happiness
				local happinessChange = (tonumber(building.Happiness) or 0)
							+ (tonumber(building.UnmoddedHappiness) or 0)
							+ player:GetExtraBuildingHappinessFromPolicies( iBuilding )
							+ (player.GetPlayerBuildingClassHappiness and player:GetPlayerBuildingClassHappiness( iBuildingClass ) or 0)
							+ (city.GetReligionBuildingClassHappiness and city:GetReligionBuildingClassHappiness( iBuildingClass ) or 0)
--							+ iSpecialistHappiness * iSpecialistsInBuilding
				if happinessChange ~=0 then
					insert( tips, happinessChange .. "[ICON_HAPPINESS_1]" )
				end
			else -- _bCivBE
				iCityCultureRate = city:GetBaseCulturePerTurn()
				-- Health
				local iHealthChange = (tonumber(building.Health) or 0) + (tonumber(building.UnmoddedHealth) or 0) + player:GetExtraBuildingHealthFromPolicies( iBuilding )
				local iHealthModifier = tonumber(building.HealthModifier) or 0
				-- Effect of player perks
				for _, perkID in ipairs(cityOwnerPerks) do
					iHealthChange = iHealthChange + Game.GetPlayerPerkBuildingClassPercentHealthChange( perkID, iBuildingClass )
					iHealthModifier = iHealthModifier + Game.GetPlayerPerkBuildingClassPercentHealthChange( perkID, iBuildingClass )
					iDefenseChange = iDefenseChange + Game.GetPlayerPerkBuildingClassCityStrengthChange( perkID, iBuildingClass )
					iHitPointChange = iHitPointChange + Game.GetPlayerPerkBuildingClassCityHPChange( perkID, iBuildingClass )
					iMaintenanceCost = iMaintenanceCost + Game.GetPlayerPerkBuildingClassEnergyMaintenanceChange( perkID, iBuildingClass )
				end
				if iHealthChange ~=0 then
					insert( tips, iHealthChange .. "[ICON_HEALTH_1]" )
				end
	--			if iHealthModifier~=0 then insert( tips, L( "TXT_KEY_STAT_POSITIVE_YIELD_MOD", "[ICON_HEALTH_1]", iHealthModifier ) ) end
			end
			local iBuildingYieldRate, iBuildingYieldPerPop, iBuildingYieldModifier, iCityYieldRate, iCityYieldRateModifier, bProducing, rYield
			for iYield = 0, NUM_YIELD_TYPES_M1 do
				rYield = GameInfo.Yields[iYield]
				if rYield then
					bProducing = bNotResisting
					thisBuildingAndYieldTypes.YieldType = rYield.Type or -1
					-- Yield changes from the building
					iBuildingYieldRate = Game.GetBuildingYieldChange( iBuilding, iYield )
								+ (not _bCiv5vanilla and player:GetPlayerBuildingClassYieldChange( iBuildingClass, iYield )
									+ city:GetReligionBuildingClassYieldChange( iBuildingClass, iYield ) or 0)
								+ (_bCiv5BNW and city:GetLeagueBuildingClassYieldChange( iBuildingClass, iYield ) or 0)
					-- Yield modifiers from the building
					iBuildingYieldModifier = Game.GetBuildingYieldModifier( iBuilding, iYield )
								+ player:GetPolicyBuildingClassYieldModifier( iBuildingClass, iYield )
					-- Effect of player perks
					if _bCivBE then
						for _, perkID in ipairs(cityOwnerPerks) do
							iBuildingYieldRate = iBuildingYieldRate + Game.GetPlayerPerkBuildingClassFlatYieldChange( perkID, iBuildingClass, iYield )
							iBuildingYieldModifier = iBuildingYieldModifier + Game.GetPlayerPerkBuildingClassPercentYieldChange( perkID, iBuildingClass, iYield )
						end
					end
					-- Specialists yield
					if rSpecialist then
						iBuildingYieldRate = iBuildingYieldRate + iSpecialistsInBuilding * city:GetSpecialistYield( rSpecialist.ID, iYield )
					end
					iCityYieldRateModifier = city:GetBaseYieldRateModifier( iYield )
					iCityYieldRate = city:GetYieldPerPopTimes100( iYield ) * iCityPopulation / 100 + city:GetBaseYieldRate( iYield )
					-- Special culture case
					if iYield == YIELD_CULTURE then
						iBuildingYieldRate = iBuildingYieldRate + iBuildingCultureRate
						iBuildingYieldModifier = iBuildingYieldModifier + iBuildingCultureModifier
						iCityYieldRateModifier = iCityYieldRateModifier + iCityCultureRateModifier
						iCityYieldRate = iCityYieldRate + iCityCultureRate
						iBuildingCultureRate = 0
						iBuildingCultureModifier = 0
					elseif iYield == YIELD_FOOD then
						local foodPerPop = FOOD_CONSUMPTION_PER_POPULATION
						local foodConsumed = city:FoodConsumption()
						iBuildingYieldRate = iBuildingYieldRate + (foodConsumed < foodPerPop * iCityPopulation and foodPerPop * iSpecialistsInBuilding / 2 or 0)
						iBuildingYieldModifier = iBuildingYieldModifier + (tonumber(building.FoodKept) or 0)
						iCityYieldRate = city:FoodDifferenceTimes100() / 100 -- iCityYieldRate - foodConsumed
						iCityYieldRateModifier = iCityYieldRateModifier + city:GetMaxFoodKeptPercent()
						bProducing = true
					end
					-- Population yield
					iBuildingYieldPerPop = 0
					for row in GameInfo.Building_YieldChangesPerPop( thisBuildingAndYieldTypes ) do
						iBuildingYieldPerPop = iBuildingYieldPerPop + (row.Yield or 0)
					end
					iBuildingYieldRate = iBuildingYieldRate + iBuildingYieldPerPop * iCityPopulation / 100

					iBuildingYieldRate = iBuildingYieldRate * iCityYieldRateModifier + ( iCityYieldRate - iBuildingYieldRate ) * iBuildingYieldModifier
					if bProducing and iBuildingYieldRate ~= 0 then
						insert( tips, iBuildingYieldRate / 100 .. rYield.IconString )
					end
				end
			end

			-- Culture leftovers
			iBuildingCultureRate = iBuildingCultureRate * (100+iCityCultureRateModifier) + ( iCityCultureRate - iBuildingCultureRate ) * iBuildingCultureModifier
			if bNotResisting and iBuildingCultureRate ~=0 then
				insert( tips, iBuildingCultureRate / 100 .. "[ICON_CULTURE]" )
			end

	-- TODO TOURISM
			if _bCiv5BNW then
				local tourism = ( ( (building.FaithCost or 0) > 0
						and building.UnlockedByBelief
						and building.Cost == -1
						and city and city:GetFaithBuildingTourism()
						) or 0 )
	--			local enhancedYieldTechID = GameInfoTypes[ building.EnhancedYieldTech ]
				tourism = tourism + (tonumber(building.TechEnhancedTourism) or 0)
				if tourism ~= 0 then
					insert( tips, tourism.."[ICON_TOURISM]" )
				end
			end

			if _bCiv5 and building.IsReligious then
				sBuildingName = L( "TXT_KEY_RELIGIOUS_BUILDING", sBuildingName, Players[city:GetOwner()]:GetStateReligionKey() )
			end
			if city:GetNumFreeBuilding( iBuilding ) > 0 then
				sBuildingName = sBuildingName .. " (" .. L"TXT_KEY_FREE" .. ")"
			elseif iMaintenanceCost ~=0 then
				insert( tips, -iMaintenanceCost .. _sCurrencyIcon )
			end
			instance.Name:SetText( sBuildingName )

			if iDefenseChange ~=0 then
				insert( tips, iDefenseChange / 100 .. "[ICON_STRENGTH]" )
			end
			if iHitPointChange ~= 0 then
				insert( tips, L( "TXT_KEY_PEDIA_DEFENSE_HITPOINTS", iHitPointChange ) )
			end

			instance.Label:ChangeParent( instance.Stack )
			instance.Label:SetText( concat( tips, " ") )
			slotStack:CalculateSize()
			if slotStack:GetSizeX() + instance.Label:GetSizeX() < 254 then
				instance.Label:ChangeParent( slotStack )
			end
			instance.Stack:CalculateSize()
	--		slotStack:ReprocessAnchoring()
	--		instance.Stack:ReprocessAnchoring()
			buildingButton:SetSizeY( max(64, instance.Stack:GetSizeY() + 16) )
		end
		return buildingIM.Commit()
	end
	SetupBuildingList( tSpecialistBuildings, _SpecialBuildingsIM )
	SetupBuildingList( tWonders, _WondersIM )
	SetupBuildingList( tGreatWorkBuildings, _GreatWorkIM )
	SetupBuildingList( tOtherBuildings, _BuildingsIM )
	Controls.BuildingListBackground:SetHide( false )
	ResizeRightStack()
end

--==========================================================
-- Production Selection List Management
--==========================================================

local function SelectionPurchase( iOrder, iRow, iYield, sSoundKey )
	local city = GetSelectedCity()
	if city then
		local iPlayer = city:GetOwner()
		if iPlayer == _iActivePlayer then
			local iCity = city:GetID()
			local bPurchase
			if iOrder == ORDER_TRAIN then
				if cityIsCanPurchase( city, true, true, iRow, -1, -1, iYield ) then
					Game.CityPurchaseUnit( city, iRow, iYield )
					bPurchase = true
				end
			elseif iOrder == ORDER_CONSTRUCT then
				if cityIsCanPurchase( city, true, true, -1, iRow, -1, iYield ) then
					Game.CityPurchaseBuilding( city, iRow, iYield )
					Network.SendUpdateCityCitizens( iCity )
					bPurchase = true
				end
			elseif iOrder == ORDER_CREATE then
				if cityIsCanPurchase( city, true, true, -1, -1, iRow, iYield ) then
					Game.CityPurchaseProject( city, iRow, iYield )
					bPurchase = true
				end
			end
			if bPurchase then
				Events.SpecificCityInfoDirty( iPlayer, iCity, CityUpdateTypes.CITY_UPDATE_TYPE_BANNER )
				Events.SpecificCityInfoDirty( iPlayer, iCity, CityUpdateTypes.CITY_UPDATE_TYPE_PRODUCTION )
				if sSoundKey then
					Events.AudioPlay2DSound( sSoundKey )
				end
			end
		end
	end
end

local function AddSelectionItem( city, row,
				tSelectionList,
				iOrder,
				cityCanProduce,
				iUnit, iBuilding, iProject,
				cityGetTurnsLeft,
				cityGetNeeded,
				cityGetCurrent,
				cityGetGoldCost,
				cityGetFaithCost )

	local iRow = row.ID
	local sName = row._Name or "nil"
	if _bDebugMode and iOrder == ORDER_CONSTRUCT then
		if not city:IsHasBuilding( iRow ) then
			return insert( tSelectionList, { row = row, iOrder = iOrder, sName = sName, bProduceable = true } )
		end
	else
		local bProduceableNow = not _bViewOnly and cityCanProduce( city, iRow, 0, 1 )	-- 0 = /continue, 1 = testvisible, nil = /ignore cost
		local bGoldBuyable, iGoldCost, bFaithBuyable, iFaithCost
		if iUnit then
			if _bCivBE then
				local bestUpgradeInfo = GameInfo.UnitUpgrades[ _pActivePlayer:GetBestUnitUpgrade(iUnit) ]
				sName = bestUpgradeInfo and bestUpgradeInfo._Name or sName
			end
			if cityGetGoldCost then
				bGoldBuyable = cityIsCanPurchase( city, true, true, iUnit, iBuilding, iProject, YIELD_GOLD )
				iGoldCost = cityIsCanPurchase( city, false, false, iUnit, iBuilding, iProject, YIELD_GOLD )
						and cityGetGoldCost( city, iRow )
			end
			if cityGetFaithCost then
				bFaithBuyable = cityIsCanPurchase( city, true, true, iUnit, iBuilding, iProject, YIELD_FAITH )
				iFaithCost = cityIsCanPurchase( city, false, false, iUnit, iBuilding, iProject, YIELD_FAITH )
						and cityGetFaithCost( city, iRow, true )
			end
		end
		if bProduceableNow or iGoldCost or iFaithCost then
			return insert( tSelectionList, { row = row, iOrder = iOrder, sName = sName, bGoldBuyable = bGoldBuyable, iGoldCost = iGoldCost, bFaithBuyable = bFaithBuyable, iFaithCost = iFaithCost,
												bProduceable = not _bViewOnly and cityCanProduce( city, iRow ), -- nil = /continue, nil = /testvisible, nil = /ignore cost
												iProductionCost = cityGetNeeded and cityGetNeeded( city, iRow ),
												iProduced = cityGetCurrent and cityGetCurrent( city, iRow ),
												iTurnsLeft = bProduceableNow and ( cityGetTurnsLeft and cityGetTurnsLeft( city, iRow ) or -1 ) } )
		end
	end
end

local function SortSelectionList(a,b)
	return a.sName < b.sName
end

local g_SelectionListCallBacks = {
	Button = {
		[eLClick] = function( iOrder, iRow )
			local city = GetSelectedModifiableCity()
			if city then
				local iCity = city:GetID()
				if _bDebugMode and iOrder == ORDER_CONSTRUCT then
					city:SetNumRealBuilding(iRow, 1)
					Network.SendUpdateCityCitizens( iCity )
					Network.ForceResync()
				else
					local iPlayer = city:GetOwner()
					if iPlayer == _iActivePlayer and not city:IsPuppet() then
						Game.CityPushOrder( city, iOrder, iRow, UI.AltKeyDown(), UI.ShiftKeyDown(), not UI.CtrlKeyDown() ) -- repeatBuild, replaceQueue, bottomOfQueue
						Events.SpecificCityInfoDirty( iPlayer, iCity, CityUpdateTypes.CITY_UPDATE_TYPE_BANNER )
						Events.SpecificCityInfoDirty( iPlayer, iCity, CityUpdateTypes.CITY_UPDATE_TYPE_PRODUCTION )
						if _bButtonPopupChooseProduction then
							-- is there another city without production order ?
							if _bNextCityProduction then
								for c in _pActivePlayer:Cities() do
									if c ~= city and not c:IsPuppet() and c:GetOrderQueueLength() < 1 then
										UI.SelectCity( c )
										return UI.LookAtSelectionPlot()
									end
								end
							end
							if _bScreenAutoClose then
								return ExitCityScreen()
							end
						end
					end
				end
			end
		end,
		[eRClick] = SelectionPedia,
	},
	GoldButton = {
		[eLClick] = function( iOrder, iRow )
			return SelectionPurchase( iOrder, iRow, YIELD_GOLD, "AS2D_INTERFACE_CITY_SCREEN_PURCHASE" )
		end,
	},
	FaithButton = {
		[eLClick] = function( iOrder, iRow )
			return SelectionPurchase( iOrder, iRow, YIELD_FAITH, "AS2D_INTERFACE_FAITH_PURCHASE" )
		end,
	},
}
local g_SelectionListTooltips = {
	Button = function( control )
		return CityOrderItemTooltip( GetHeadSelectedCity(), true, false, control:GetVoid1(), control:GetVoid2() )
	end,
	GoldButton = function( control )
		return CityOrderItemTooltip( GetHeadSelectedCity(), control:IsDisabled(), YIELD_GOLD, control:GetVoid1(), control:GetVoid2() )
	end,
	FaithButton = function( control )
		return CityOrderItemTooltip( GetHeadSelectedCity(), control:IsDisabled(), YIELD_FAITH, control:GetVoid1(), control:GetVoid2() )
	end,
}

local function SetupSelectionList( selectionIM, itemList, iGold, iFaith, iPlayer, getUnitPortraitIcon )
	sort( itemList, SortSelectionList )
	selectionIM:ResetInstances()
	for _, item in ipairs(itemList) do
		local row = item.row
		local iOrder = item.iOrder
		local bProduceable = item.bProduceable
		local iProductionCost = item.iProductionCost
		local iProduced = iProductionCost and item.iProduced
		local iTurnsLeft = item.iTurnsLeft
		local bGoldBuyable = item.bGoldBuyable
		local iGoldCost = item.iGoldCost
		local bFaithBuyable = item.bFaithBuyable
		local iFaithCost = item.iFaithCost
		local iRow = row.ID
		local bAvisorRecommended = _bAdvisor and _tAvisorRecommended[ iOrder ]

		local instance, new = selectionIM:GetInstance()
		if new then
			SetupCallbacks( instance, g_SelectionListTooltips, "EUI_ItemTooltip", g_SelectionListCallBacks )
		end
		instance.DisabledProduction:SetHide( bProduceable or not(bGoldBuyable or bFaithBuyable) )
		instance.Disabled:SetHide( bProduceable or bGoldBuyable or bFaithBuyable )
		instance.ProductionMeter:SetPercent( iProduced and iProduced / iProductionCost or 0 )
		instance.ProductionMeter:SetToolTipString( (iProduced or 0)>0 and L( "TXT_KEY_PROGRESS_TOWARDS", item.sName ) ..": "..iProduced.." / "..iProductionCost.." [ICON_PRODUCTION]" or nil )
		if getUnitPortraitIcon then
			local iconIndex, iconAtlas = getUnitPortraitIcon( iRow, iPlayer )
			IconHookup( iconIndex, 45, iconAtlas, instance.Portrait )
		else
			IconHookup( row.PortraitIndex, 45, row.IconAtlas, instance.Portrait )
		end
		instance.Name:SetText( item.sName )
		if not iTurnsLeft then
		elseif iTurnsLeft > -1 and iTurnsLeft <= 999 then
			instance.Turns:LocalizeAndSetText( "TXT_KEY_STR_TURNS", iTurnsLeft )
		else
			instance.Turns:LocalizeAndSetText( "TXT_KEY_PRODUCTION_HELP_INFINITE_TURNS" )
		end
		instance.Turns:SetHide( not iTurnsLeft )
		instance.Button:SetVoids( iOrder, iRow )

		local control = instance.GoldButton
		control:SetHide( not iGoldCost )
		if iGoldCost then
			control:SetDisabled( not bGoldBuyable )
			control:SetAlpha( bGoldBuyable and 1 or 0.5 )
			control:SetVoids( iOrder, iRow )
			control:SetText( (iGold>=iGoldCost and iGoldCost or "[COLOR_WARNING_TEXT]".. iGoldCost.."[ENDCOLOR]") .. _sCurrencyIcon )
		end
		control = instance.FaithButton
		control:SetHide( not iFaithCost )
		if iFaithCost then
			control:SetDisabled( not bFaithBuyable )
			control:SetAlpha( bFaithBuyable and 1 or 0.5 )
			control:SetVoids( iOrder, iRow )
			control:SetText( (iFaith>=iFaithCost and iFaithCost or "[COLOR_WARNING_TEXT]"..iFaithCost.."[ENDCOLOR]") .. "[ICON_PEACE]" )
		end

		for iAdvisor, advisorName in pairs(_tAdvisors) do
			control = instance[ advisorName ]
			if control then
				control:SetHide( not (bAvisorRecommended and bAvisorRecommended( iRow, iAdvisor )) )
			end
		end
	end
	return selectionIM.Commit()
end

--==========================================================
-- Production Queue Managemeent
--==========================================================
local function RemoveQueueItem( iQueuedItem )
	local city = GetSelectedModifiableCity()
	if city then
		local iOrderQueueLength = city:GetOrderQueueLength()
		if city:GetOwner() == _iActivePlayer and iOrderQueueLength > iQueuedItem then
			Game.SelectedCitiesGameNetMessage( GameMessageTypes.GAMEMESSAGE_POP_ORDER, iQueuedItem )
			if iOrderQueueLength < 2 then
				local sTooltip = L( "TXT_KEY_NOTIFICATION_NEW_CONSTRUCTION", city:GetName() )
				_pActivePlayer:AddNotification( NOTIFICATION_PRODUCTION, sTooltip, sTooltip, city:GetX(), city:GetY(), -1, -1 )
			end
		end
	end
end

local function SwapQueueItem( iQueuedItem )
	if _iQueuedItem and ( Controls.QueueSlider1:IsTrackingLeftMouseButton() or Controls.QueueSlider2:IsTrackingLeftMouseButton() ) then
		local a = _iQueuedItem
		local b = iQueuedItem
		if a>b then a, b = b, a end
		for i=a, b-1 do
			Game.SelectedCitiesGameNetMessage( GameMessageTypes.GAMEMESSAGE_SWAP_ORDER, i )
		end
		for i=b-2, a, -1 do
			Game.SelectedCitiesGameNetMessage( GameMessageTypes.GAMEMESSAGE_SWAP_ORDER, i )
		end
	end
	_iQueuedItem = iQueuedItem
end

Controls.AutomateProduction:RegisterCheckHandler( function( bChecked )
	local city = GetSelectedModifiableCity()
	if city then
--		Game.SelectedCitiesGameNetMessage( GameMessageTypes.GAMEMESSAGE_DO_TASK, TaskTypes.TASK_SET_AUTOMATED_PRODUCTION, -1, -1, bChecked, false )
		local iCity = city:GetID()
		Network.SendDoTask( iCity, TaskTypes.TASK_SET_AUTOMATED_PRODUCTION, -1, -1, bChecked, true, true, true ) -- UI.CtrlKeyDown() 3 x true = clear production queue
		return Network.SendUpdateCityCitizens( iCity )
	end
end)

--==========================================================
-- Update City Production Queue
--==========================================================

local function UpdateCityProductionQueue( city, iCity, iPlayer, iGold, iFaith, bActivePlayerCity, bVeniceException )
--print( "UpdateCityProductionQueue1", city:GetName(), iCity, iPlayer, bActivePlayerCity, bVeniceException )
	local bProductionAutomated = city:IsProductionAutomated() or not city:IsHuman()
	Controls.AutomateProduction:SetCheck( bProductionAutomated )
	Controls.AutomateProduction:SetDisabled( _bViewOnly or not city:IsHuman() )

	local iQueueLength = city:GetOrderQueueLength()
	local bEmptyQueue = iQueueLength < 1
	local bMaintain = false

	local tQueueItems = {}
	local row, bHide, getItemProductionTurnsLeft, portraitSize, instance, new

--print( "UpdateCityProductionQueue2", iQueueLength )

	_ProdQueueIM:ResetInstances()
	for iQueuedItem = 0, bEmptyQueue and 0 or iQueueLength-1 do

		local _, t, portraitOffset, portraitAtlas, iOrder, iRow, bRepeat, bReallyRepeat, bIcon
		if bEmptyQueue then
			t = bActivePlayerCity and _tFinishedItems[ iCity ]
			if t then
				iOrder = t[1]
				iRow = t[2]
			end
		else
			iOrder, iRow, _, bRepeat = city:GetOrderFromQueue( iQueuedItem )
			tQueueItems[ iOrder / 64 + iRow ] = true
		end
--print( "UpdateCityProductionQueue3", iOrder, iRow, bRepeat, bEmptyQueue )
		if iOrder == ORDER_TRAIN then
			row = GameInfo.Units[iRow]
			getItemProductionTurnsLeft = city.GetUnitProductionTurnsLeft
			if row then portraitOffset, portraitAtlas = GetUnitPortraitIcon( iRow, iPlayer ) end
			bReallyRepeat = bRepeat
		elseif iOrder == ORDER_CONSTRUCT then
			row = GameInfo.Buildings[iRow]
			getItemProductionTurnsLeft = city.GetBuildingProductionTurnsLeft
		elseif iOrder == ORDER_CREATE then
			row = GameInfo.Projects[iRow]
			getItemProductionTurnsLeft = city.GetProjectProductionTurnsLeft
		elseif iOrder == ORDER_MAINTAIN then
			row = GameInfo.Processes[iRow]
			bMaintain = true
			bReallyRepeat = true
		else
			row = nil
		end

		if iQueuedItem == 0 then
			instance = Controls
			portraitSize = _iPortraitSize
			bHide = not row
		else
			portraitSize = 45
			instance, new = _ProdQueueIM:GetInstance()
			if new then
				instance.PQbox:SetToolTipCallback( ProductionToolTip )
				instance.PQbox:RegisterCallback( eMouseEnter, SwapQueueItem )
				instance.PQbox:RegisterCallback( eRClick, ProductionPedia )
				instance.PQremove:RegisterCallback( eLClick, RemoveQueueItem )
			end
			instance.PQdisabled:SetHide( not bMaintain )
		end

		if row then
			bIcon = IconHookup( portraitOffset or row.PortraitIndex, portraitSize, portraitAtlas or row.IconAtlas, instance.PQportrait )
			instance.PQname:SetText( row._Name )
			if bMaintain or bEmptyQueue then
			elseif getItemProductionTurnsLeft then
				instance.PQturns:LocalizeAndSetText( "TXT_KEY_PRODUCTION_HELP_NUM_TURNS", getItemProductionTurnsLeft( city,  iRow, iQueuedItem ) )
			else
				instance.PQturns:LocalizeAndSetText( "TXT_KEY_PRODUCTION_HELP_INFINITE_TURNS" )
			end
		else
			instance.PQname:LocalizeAndSetText( "TXT_KEY_PRODUCTION_NO_PRODUCTION" )
		end

		instance.PQbox:SetVoid1( iQueuedItem )
		instance.PQturns:SetHide( bMaintain or bEmptyQueue or not bIcon )
		instance.PQportrait:SetHide( not bIcon )
		instance.PQremove:SetHide( bEmptyQueue or _bViewOnly )
		instance.PQremove:SetVoid1( iQueuedItem )

		if bReallyRepeat then
			bMaintain = true
			instance.PQrank:SetText( "[ICON_TURNS_REMAINING]" )
		else
			instance.PQrank:SetText( not bMaintain and iQueueLength > 1 and (iQueuedItem+1).."." )
		end
	end
	_ProdQueueIM.Commit()

	local iCurrentProductionPerTurnTimes100 = city:GetCurrentProductionDifferenceTimes100( false, false )	-- bIgnoreFood, bOverflow
	local bGeneratingProduction = ( iCurrentProductionPerTurnTimes100 > 0 ) and not ( city.IsProductionProcess and city:IsProductionProcess() )
	Controls.ProductionFinished:SetHide( not bEmptyQueue or not row )
	Controls.ProdPerTurnLabel:LocalizeAndSetText( "TXT_KEY_CITYVIEW_PERTURN_TEXT", iCurrentProductionPerTurnTimes100 / 100 )
	-- Progress info for meter
	ShowProgress( _iPortraitSize, Controls.PQlossMeter, Controls.PQprogressMeter, Controls.PQline1, Controls.PQlabel1, Controls.PQline2, Controls.PQlabel2,
		not bEmptyQueue and bGeneratingProduction and city:GetProductionTurnsLeft(),
		city:GetProductionNeeded() * 100,
		city:GetProductionTimes100() + city:GetCurrentProductionDifferenceTimes100( false, true ) - iCurrentProductionPerTurnTimes100,	-- /bIgnoreFood, bOverflow
		iCurrentProductionPerTurnTimes100 )
	Controls.ProductionPortraitButton:SetHide( bHide )

	-------------------------------------------
	-- Update Selection List
	-------------------------------------------

	local isSelectionList = ( not _bViewOnly and not bProductionAutomated or bVeniceException ) or _bDebugMode
	if isSelectionList then
		local unitSelectList = {}
		local buildingSelectList = {}
		local wonderSelectList = {}
		local processSelectList = {}

		if _bAdvisor then
			Game.SetAdvisorRecommenderCity( city )
		end
		-- Buildings & Wonders
		local iOrder = ORDER_CONSTRUCT
		local code = iOrder / 64
		for row in GameInfo.Buildings() do
			local buildingClass = GameInfo.BuildingClasses[row.BuildingClass]
			local isWonder = buildingClass and (buildingClass.MaxGlobalInstances > 0 or buildingClass.MaxPlayerInstances == 1 or buildingClass.MaxTeamInstances > 0)
			if not tQueueItems[ code + row.ID ] then
				AddSelectionItem( city, row,
						isWonder and wonderSelectList or buildingSelectList,
						iOrder,
						city.CanConstruct,
						-1, row.ID, -1,
						city.GetBuildingProductionTurnsLeft,
						city.GetBuildingProductionNeeded,
						city.GetBuildingProduction,
						city.GetBuildingPurchaseCost,
						city.GetBuildingFaithPurchaseCost )
			end
		end

		-- Units
		iOrder = ORDER_TRAIN
		for row in GameInfo.Units() do
			AddSelectionItem( city, row,
						unitSelectList,
						iOrder,
						city.CanTrain,
						row.ID, -1, -1,
						city.GetUnitProductionTurnsLeft,
						city.GetUnitProductionNeeded,
						city.GetUnitProduction,
						city.GetUnitPurchaseCost,
						city.GetUnitFaithPurchaseCost )
		end
		-- Projects
		iOrder = ORDER_CREATE
		code = iOrder / 64
		for row in GameInfo.Projects() do
			if not tQueueItems[ code + row.ID ] then
				AddSelectionItem( city, row,
						wonderSelectList,
						iOrder,
						city.CanCreate,
						-1, -1, row.ID,
						city.GetProjectProductionTurnsLeft,
						city.GetProjectProductionNeeded,
						city.GetProjectProduction,
						city.GetProjectPurchaseCost,
						city.GetProjectFaithPurchaseCost )	-- nil
			end
		end
		-- Processes
		iOrder = ORDER_MAINTAIN
		code = iOrder / 64
		for row in GameInfo.Processes() do
			if not tQueueItems[ code + row.ID ] then
				AddSelectionItem( city, row,
						processSelectList,
						iOrder,
						city.CanMaintain )
			end
		end

		SetupSelectionList( _UnitSelectIM, unitSelectList, iGold, iFaith, iPlayer, GetUnitPortraitIcon )
		SetupSelectionList( _BuildingSelectIM, buildingSelectList, iGold, iFaith )
		SetupSelectionList( _WonderSelectIM, wonderSelectList, iGold, iFaith )
		SetupSelectionList( _ProcessSelectIM, processSelectList, iGold, iFaith )

	end
--print( "UpdateCityProductionQueue9" )
	Controls.SelectionBackground:SetHide( not isSelectionList )
	Controls.TopLeftBackground:SetHide( false )
	return ResizeLeftStacks()
end

--==========================================================
-- City Hex Clicking & Mousing
--==========================================================

local function PlotButtonClicked( plotIndex )
	local city = GetSelectedModifiableCity()
	local plot = city and city:GetCityIndexPlot( plotIndex )
	if plot then
		-- calling this with the city center (0 in the third param) causes it to reset all forced tiles
		Network.SendDoTask( city:GetID(), TaskTypes.TASK_CHANGE_WORKING_PLOT, plotIndex, -1, false )
		if city ~= plot:GetWorkingCity() then
			return Network.SendUpdateCityCitizens( city:GetID() )
		end
	end
end

local function BuyPlotAnchorButtonClicked( plotIndex )
	local city = GetSelectedModifiableCity()
	if city then
		local plot = city:GetCityIndexPlot( plotIndex )
		local plotX = plot:GetX()
		local plotY = plot:GetY()
		Network.SendCityBuyPlot( city:GetID(), plotX, plotY )
		Network.SendUpdateCityCitizens( city:GetID() )
		UI.UpdateCityScreen()
		Events.AudioPlay2DSound("AS2D_INTERFACE_BUY_TILE")
	end
	return true
end

--==========================================================
-- Update City Hexes
--==========================================================

local function UpdateCityWorkingHexes( city, bViewOnly )
--print( "UpdateCityWorkingHexes1", city, bViewOnly )

	bViewOnly = bViewOnly or _bViewOnly
	_PlotButtonIM:ResetInstances()
	_BuyPlotButtonIM:ResetInstances()

	-- Show plots that will be acquired by culture
	EventsClearHexHighlightStyle( "HexContour" )
	local tBuyablePlotList = {city:GetBuyablePlotList()}
	for i = 1, #tBuyablePlotList do
		local plot = tBuyablePlotList[i]
		EventsSerialEventHexHighlight( ToHexFromGrid{ x=plot:GetX(), y=plot:GetY() }, true, ColorCulture, "HexContour" )
		tBuyablePlotList[ plot ] = true
	end

	local iCityPlots = city:GetNumCityPlots() - 1

	-- display worked plots buttons
	local iPlayer = city:GetOwner()
	if _bWorkerHeadingOpen then
		for cityPlotIndex = 0, iCityPlots do
			local plot = city:GetCityIndexPlot( cityPlotIndex )

			if plot and plot:GetOwner() == iPlayer then

				local hexPos = ToHexFromGrid{ x=plot:GetX(), y=plot:GetY() }
				local worldPos = HexToWorld( hexPos )
				local iIcon, tipKey, text
				if city:IsWorkingPlot( plot ) then

					-- The city itself
					if cityPlotIndex == 0 then
						iIcon = 11
						tipKey = "TXT_KEY_CITYVIEW_CITY_CENTER"

					-- Forced worked plot
					elseif city:IsForcedWorkingPlot( plot ) then
						iIcon = 10
						tipKey = "TXT_KEY_CITYVIEW_FORCED_WORK_TILE"

					-- AI-picked worked plot
					else
						iIcon = 0
						tipKey = "TXT_KEY_CITYVIEW_GUVNA_WORK_TILE"
					end
				else
					local workingCity = plot:GetWorkingCity()
					-- Assigned to another one of our cities
					if city ~= workingCity then
						iIcon = 12

						-- Other city forced worked plot
						if workingCity:IsForcedWorkingPlot( plot ) then
							text="[ICON_LOCKED]"
							tipKey = "{TXT_KEY_CITYVIEW_FORCED_WORK_TILE} {TXT_KEY_CITYVIEW_NUTHA_CITY_TILE}"

						-- Other city AI-picked worked plot
						elseif workingCity:IsWorkingPlot( plot ) then
							text="[ICON_CITIZEN]"
							tipKey = "TXT_KEY_CITYVIEW_NUTHA_CITY_TILE"

						-- Other city unworked plot
						else
							tipKey = "TXT_KEY_CITYVIEW_UNWORKED_CITY_TILE"
						end

					-- Unworked plot
					elseif city:CanWork( plot ) then
						iIcon = 9
						tipKey = "TXT_KEY_CITYVIEW_UNWORKED_CITY_TILE"

					-- Enemy unit standing here
					elseif plot:IsVisibleEnemyUnit( iPlayer ) then
						iIcon = 13
						tipKey = "TXT_KEY_CITYVIEW_ENEMY_UNIT_CITY_TILE"

					-- Blockaded water plot
					elseif plot:IsWater() and city:IsPlotBlockaded( plot ) then
						iIcon = 13
						tipKey = "TXT_KEY_CITYVIEW_BLOCKADED_CITY_TILE"

					end
				end
				if iIcon then
					local instance = _PlotButtonIM:GetInstance()
					instance.PlotButtonAnchor:SetWorldPositionVal( worldPos.x + _tWorldPositionOffset.x, worldPos.y + _tWorldPositionOffset.y, worldPos.z + _tWorldPositionOffset.z ) --todo: improve code
					local button = instance.PlotButtonImage
					IconHookup( iIcon, 45, "CITIZEN_ATLAS", button )
					button:SetText( text )
					button:LocalizeAndSetToolTip( tipKey )
					if iIcon == 13 or bViewOnly then
						button:ClearCallback( eLClick )
					else
						button:SetVoid1( cityPlotIndex )
						button:RegisterCallback( eLClick, PlotButtonClicked )
					end
				end
			end
		end --loop
	end

	-- display buy plot buttons
	if  not bViewOnly and _bBuyPlotMode then
		local iGold = _pActivePlayer:GetGold()
		for cityPlotIndex = 0, iCityPlots do
			local plot = city:GetCityIndexPlot( cityPlotIndex )
			if plot then
				local x = plot:GetX()
				local y = plot:GetY()
				local hexPos = ToHexFromGrid{ x=x, y=y }
				local worldPos = HexToWorld( hexPos )
				if city:CanBuyPlotAt( x, y, true ) then
					local instance = _BuyPlotButtonIM:GetInstance()
					local button = instance.BuyPlotAnchoredButton
					instance.BuyPlotButtonAnchor:SetWorldPositionVal( worldPos.x + _tWorldPositionOffset2.x, worldPos.y + _tWorldPositionOffset2.y, worldPos.z + _tWorldPositionOffset2.z ) --todo: improve code
					local iBuyPlotCost = city:GetBuyPlotCost( x, y )
					local tip, txt, alpha
					local bCanBuyPlot = city:CanBuyPlotAt( x, y, false )
					if bCanBuyPlot then
						tip = L( "TXT_KEY_CITYVIEW_CLAIM_NEW_LAND", iBuyPlotCost )
						txt = iBuyPlotCost
						alpha = 1
						button:SetVoid1( cityPlotIndex )
						button:RegisterCallback( eLClick, BuyPlotAnchorButtonClicked )
					else
						tip = L( "TXT_KEY_CITYVIEW_NEED_MONEY_BUY_TILE", iBuyPlotCost-iGold )
						txt = "[COLOR_WARNING_TEXT]".. iBuyPlotCost .."[ENDCOLOR]"
						alpha = 0.5
					end
					button:SetDisabled( not bCanBuyPlot )
					instance.BuyPlotButtonAnchor:SetAlpha( alpha )
--todo
					button:SetToolTipString( tip )
					instance.BuyPlotAnchoredButtonLabel:SetText( txt )
				end
			end
		end --loop
	end
--print( "UpdateCityWorkingHexes9" )
end

local function UpdateWorkingHexes()
	local city = GetHeadSelectedCity()
	if city then
		return UpdateCityWorkingHexes( city )
	end
end

--==========================================================
-- Update City View
--==========================================================

local function UpdateCityView()
--print( "UpdateCityView1" )

	local city = GetHeadSelectedCity()

	if city and UI.IsCityScreenUp() then

		if _tCitySpecialists.city ~= city then
			_tCitySpecialists = { city = city }
		end
		local iCity = city:GetID()
		local iPlayer = city:GetOwner()
		local player = Players[iPlayer]
		local iTeam = city:GetTeam()
		local bActivePlayerCity = iPlayer == Game.GetActivePlayer()
		local bNotResisting = not city:IsResistance()
		local isCityCaptureViewingMode = UI.IsPopupTypeOpen(ButtonPopupTypes.BUTTONPOPUP_CITY_CAPTURED)
		_bViewOnly = city:IsPuppet() or not bActivePlayerCity or isCityCaptureViewingMode
		_bDebugMode = Game.IsDebugMode()

--print( "UpdateCityView2", city:GetName() )

		-------------------------------------------
		-- City Info
		-------------------------------------------

		-- Happiness
		Controls.Happiness:LocalizeAndSetText( "TXT_KEY_CITYVIEW_PERTURN_TEXT", GetCityHappiness( player, city ) )
--[[
		-- if _bHappinessEnabled then
		local iCityHappiness = GetCityHappiness( player, city ) - GetCityUnhappiness( player, city )
		local tLuxuries = {}
		for plot in CityPlots( city ) do
			-- Happiness from terrain
			local feature = GameInfo.Features[ plot:GetFeatureType() ]
			if feature then
				iCityHappiness = iCityHappiness + floor( ( tonumber(feature.InBorderHappiness) or 0 ) * ( 100 + player:GetNaturalWonderYieldModifier() ) / 100 )
			end
			-- Happiness from luxuries
			local resourceID = plot:GetResourceType( iTeam )
			local resource =  not tLuxuries[ resourceID ] and player:GetNumResourceAvailable( resourceID, true ) > 0 and GameInfo.Resources[ resourceID ]
			if resource then
				tLuxuries[ resourceID ] = 1
				local iHappinessFromLuxury = player:GetHappinessFromLuxury( resourceID ) or tonumber(resource.Happiness) or 0
				if iHappinessFromLuxury > 0 and ( plot:IsCity() or not plot:IsImprovementPillaged() and plot:IsResourceConnectedByImprovement( plot:GetRevealedImprovementType( iTeam ) ) ) then
					iCityHappiness = iCityHappiness + iHappinessFromLuxury
				end
			end
		end
		if iCityHappiness < 0 then
			Controls.HappinessIcon:SetText( "[ICON_HAPPINESS_3]" )
			Controls.HappinessLabel:LocalizeAndSetText( "TXT_KEY_UNHAPPINESS" )
			Controls.Happiness:LocalizeAndSetText( "TXT_KEY_CITYVIEW_PERTURN_TEXT_NEGATIVE", iCityHappiness )
		else
			Controls.HappinessIcon:SetText( "[ICON_HAPPINESS_1]" )
			Controls.HappinessLabel:LocalizeAndSetText( "TXT_KEY_TOPIC_HAPPINESS" )
			Controls.Happiness:LocalizeAndSetText( "TXT_KEY_CITYVIEW_PERTURN_TEXT", iCityHappiness )
		end
--]]
		-- Gold
		Controls.GoldPerTurnLabel:LocalizeAndSetText( "TXT_KEY_CITYVIEW_PERTURN_TEXT", city:GetYieldRateTimes100( YIELD_GOLD ) / 100 )

		-- Science
		if _bScienceEnabled then
			Controls.SciencePerTurnLabel:LocalizeAndSetText( "TXT_KEY_CITYVIEW_PERTURN_TEXT", city:GetYieldRateTimes100(YIELD_SCIENCE) / 100 )
		else
			Controls.SciencePerTurnLabel:LocalizeAndSetText( "TXT_KEY_CITYVIEW_OFF" )
		end

		-- Religion
		if not _bCiv5vanilla then
			if _bReligionEnabled then
				Controls.FaithPerTurnLabel:LocalizeAndSetText( "TXT_KEY_CITYVIEW_PERTURN_TEXT", city:GetFaithPerTurn() )
			else
				Controls.FaithPerTurnLabel:LocalizeAndSetText( "TXT_KEY_CITYVIEW_OFF" )
			end
		end

		-- Culture
		local iCulturePerTurn, iCultureStored, iCultureThreshold
		if _bCiv5 then
--todo BE
			Controls.CityIsOccupied:SetHide( not city:IsOccupied() or city:IsNoOccupiedUnhappiness() )

			-- Auto Specialist checkbox
			local isNoAutoAssignSpecialists = city:IsNoAutoAssignSpecialists()
			Controls.NoAutoSpecialistCheckbox:SetCheck( isNoAutoAssignSpecialists )
			Controls.NoAutoSpecialistCheckbox:SetDisabled( _bViewOnly )

			-- Tourism
			if _bCiv5BNW then
				Controls.TourismPerTurnLabel:LocalizeAndSetText( "TXT_KEY_CITYVIEW_PERTURN_TEXT", city:GetBaseTourism() )
				Controls.NoAutoSpecialistCheckbox2:SetCheck( isNoAutoAssignSpecialists )
				Controls.NoAutoSpecialistCheckbox2:SetDisabled( _bViewOnly )
			end
			UpdateGreatPersonMeters( city, player, iPlayer )

			-- thanks for Firaxis Cleverness !
			iCulturePerTurn = city:GetJONSCulturePerTurn()
			iCultureStored = city:GetJONSCultureStored()
			iCultureThreshold = city:GetJONSCultureThreshold()
		else
			iCulturePerTurn = city:GetCulturePerTurn()
			iCultureStored = city:GetCultureStored()
			iCultureThreshold = city:GetCultureThreshold()
		end
		Controls.CulturePerTurnLabel:LocalizeAndSetText( "TXT_KEY_CITYVIEW_PERTURN_TEXT", iCulturePerTurn )
		Controls.CultureTimeTillGrowthLabel:SetText( iCulturePerTurn > 0 and max( ceil( (iCultureThreshold - iCultureStored) / iCulturePerTurn), 1 ) or nil )
		Controls.CultureMeter:SetPercents( iCultureStored / iCultureThreshold, (iCultureStored+iCulturePerTurn) / iCultureThreshold )

		local bCapital = city:IsCapital()

		Controls.CityIsConnected:SetHide( bCapital or city:IsBlockaded() or not player:IsCapitalConnectedToCity(city) or iTeam ~= Game.GetActiveTeam() )

		Controls.CityIsBlockaded:SetHide( not city:IsBlockaded() )

		local cityName = Locale.ToUpper( city:GetName() )
		if bCapital then
			cityName = "[ICON_CAPITAL]" .. cityName
		end
		if city:IsRazing() then
			Controls.CityIsRazing:SetHide(false)
			Controls.CityIsRazing:LocalizeAndSetToolTip( "TXT_KEY_CITY_BURNING", city:GetRazingTurns() )
			cityName = cityName .. " (" .. L"TXT_KEY_BURNING" .. ")"
		else
			Controls.CityIsRazing:SetHide(true)
		end
		Controls.CityNameTitleBarLabel:SetText( cityName )

		Controls.CityIsPuppet:SetHide( not city:IsPuppet() )

		Controls.CityIsResistance:SetHide( bNotResisting )
		if not bNotResisting then
			Controls.CityIsResistance:LocalizeAndSetToolTip( "TXT_KEY_CITY_RESISTANCE", city:GetResistanceTurns() )
		end

		Controls.Defense:SetText( floor( city:GetStrengthValue() / 100 ) )

 		CivIconHookup( iPlayer, 64, Controls.CivIcon, Controls.CivIconBG, Controls.CivIconShadow, false, true )

		-------------------------------------------
		-- City Damage
		-------------------------------------------

		local cityDamage = city:GetDamage()
		if cityDamage > 0 then
			local cityHealthPercent = 1 - cityDamage / ( not _bCiv5vanilla and city:GetMaxHitPoints() or MAX_CITY_HIT_POINTS )

			Controls.HealthMeter:SetPercent( cityHealthPercent )
			if cityHealthPercent > 0.66 then
				Controls.HealthMeter:SetTexture("CityNamePanelHealthBarGreen.dds")
			elseif cityHealthPercent > 0.33 then
				Controls.HealthMeter:SetTexture("CityNamePanelHealthBarYellow.dds")
			else
				Controls.HealthMeter:SetTexture("CityNamePanelHealthBarRed.dds")
			end
			Controls.HealthFrame:SetHide( false )
		else
			Controls.HealthFrame:SetHide( true )
		end

		-------------------------------------------
		-- Resource Demanded
		-------------------------------------------
		if city:GetResourceDemanded(true) ~= -1 then
			local resourceInfo = GameInfo.Resources[ city:GetResourceDemanded() ]
			local weLoveTheKingDayCounter = city:GetWeLoveTheKingDayCounter()
			if weLoveTheKingDayCounter > 0 then
				Controls.ResourceDemandedString:LocalizeAndSetText( "TXT_KEY_CITYVIEW_WLTKD_COUNTER", weLoveTheKingDayCounter )
				Controls.ResourceDemandedBox:LocalizeAndSetToolTip( "TXT_KEY_CITYVIEW_RESOURCE_FULFILLED_TT" )
			else
				Controls.ResourceDemandedString:LocalizeAndSetText( "TXT_KEY_CITYVIEW_RESOURCE_DEMANDED", (resourceInfo.IconString or"") .. " " .. resourceInfo._Name )
				Controls.ResourceDemandedBox:LocalizeAndSetToolTip( "TXT_KEY_CITYVIEW_RESOURCE_DEMANDED_TT" )
			end

			Controls.ResourceDemandedBox:SetSizeX(Controls.ResourceDemandedString:GetSizeX() + 10)
			Controls.ResourceDemandedBox:SetHide(false)
		else
			Controls.ResourceDemandedBox:SetHide(true)
		end

		Controls.IconsStack:CalculateSize()
		Controls.IconsStack:ReprocessAnchoring()

		Controls.NotificationStack:CalculateSize()
		Controls.NotificationStack:ReprocessAnchoring()

		-------------------------------------------
		-- Citizen Focus & Slackers
		-------------------------------------------

		Controls.AvoidGrowthButton:SetCheck( city:IsForcedAvoidGrowth() )

		local slackerCount = city:GetSpecialistCount( DEFAULT_SPECIALIST )

		InitCityFocusPullDown( city )

		local doHide = city:GetNumForcedWorkingPlots() < 1 and slackerCount < 1
		Controls.ResetButton:SetHide( doHide )
		Controls.ResetFooter:SetHide( doHide )

		_SlackerIM:ResetInstances()
		for i = 1, slackerCount do
			local instance = _SlackerIM:GetInstance()
			local slot = instance.Button
			slot:SetVoids( -1, i )
			slot:SetToolTipCallback( SpecialistTooltip )
			slot:SetTexture( _sSlackerTexture )
			if _bViewOnly then
				slot:ClearCallback( eLClick )
			else
				slot:RegisterCallback( eLClick, OnSlackersSelected )
			end
			slot:RegisterCallback( eRClick, SpecialistPedia )
		end
		_SlackerIM.Commit()

		-------------------------------------------
		-- City Growth Meter
		-------------------------------------------

		local iPopulation = city:GetPopulation()
		Controls.CityPopulationLabel:SetText( iPopulation )
		Controls.CityPopulationLabelSuffix:LocalizeAndSetText( "TXT_KEY_CITYVIEW_CITIZENS_TEXT", iPopulation )
--		Controls.PeopleMeter:SetPercent( city:GetFood() / city:GrowthThreshold() )

		local iFoodTimes100 = city:GetFoodTimes100()
		local iFoodDifferenceTimes100 = city:FoodDifferenceTimes100()
		local iFoodTurnsLeft = city:GetFoodTurnsLeft()
		local iconIndex = 0
		local sColor = "Green_Black"
		if iFoodDifferenceTimes100 < 0 then
			iFoodTurnsLeft = floor( iFoodTimes100 / -iFoodDifferenceTimes100 ) + 1
			iconIndex = 5
			sColor = "Red_Black"
		end
		IconHookup( iconIndex, _iPortraitSize, "CITIZEN_ATLAS", Controls.PopPortrait )
		ShowProgress( _iPortraitSize, Controls.PopLossMeter, Controls.PopProgressMeter, Controls.PopLine1, Controls.PopLabel1, Controls.PopLine2, Controls.PopLabel2,
			iFoodTurnsLeft,
			city:GrowthThreshold() * 100,
			iFoodTimes100,
			iFoodDifferenceTimes100 )
		Controls.PopLabel1:SetColorByName( sColor )
		Controls.PopLabel2:SetColorByName( sColor )
--		Controls.CityGrowthLabel:SetText( city:GetYieldModifierTooltip( YIELD_FOOD ) )
		Controls.FoodPerTurnLabel:LocalizeAndSetText( iFoodDifferenceTimes100 >= 0 and "TXT_KEY_CITYVIEW_PERTURN_TEXT" or "TXT_KEY_CITYVIEW_PERTURN_TEXT_NEGATIVE", iFoodDifferenceTimes100 / 100 )

		-------------------------------------------
		-- Raze / Unraze / Annex City Buttons
		-------------------------------------------

		local sToolTip, sLabel, iTask
		if bActivePlayerCity then

			if city:IsRazing() then

				-- We can unraze this city
				iTask = TaskTypes.TASK_UNRAZE
				sLabel = L"TXT_KEY_CITYVIEW_UNRAZE_BUTTON_TEXT"
				sToolTip = L"TXT_KEY_CITYVIEW_UNRAZE_BUTTON_TT"

			elseif city:IsPuppet() and not(_bCiv5BNW and player:MayNotAnnex()) then

				-- We can annex this city
				iTask = TaskTypes.TASK_ANNEX_PUPPET
				sLabel = L"TXT_KEY_POPUP_ANNEX_CITY"
-- todo
				if _bCiv5 then
					sToolTip = L( "TXT_KEY_POPUP_CITY_CAPTURE_INFO_ANNEX", player:GetUnhappinessForecast(city) - player:GetUnhappiness() )
				end
			elseif not _bViewOnly and player:CanRaze( city, true ) then
				sLabel = L"TXT_KEY_CITYVIEW_RAZE_BUTTON_TEXT"

				if player:CanRaze( city, false ) then

					-- We can actually raze this city
					iTask = TaskTypes.TASK_RAZE
					sToolTip = L"TXT_KEY_CITYVIEW_RAZE_BUTTON_TT"
				else
					-- We COULD raze this city if it weren't a capital
					sToolTip = L"TXT_KEY_CITYVIEW_RAZE_BUTTON_DISABLED_BECAUSE_CAPITAL_TT"
				end
			end
		end
		local CityTaskButton = Controls.CityTaskButton
		CityTaskButton:SetText( sLabel )
		CityTaskButton:SetVoids( iCity, iTask or -1 )
		CityTaskButton:SetToolTipString( sToolTip )
		CityTaskButton:SetDisabled( not iTask )
		CityTaskButton:SetHide( not sLabel )
--Controls.ReturnToMapButton:SetToolTipString( concat( {"_bViewOnly:", tostring(_bViewOnly), "Can raze:", tostring(player:CanRaze( city, true )), "Can actually raze:", tostring(player:CanRaze( city, false )), "iTask:", tostring(iTask) }, " " ) )

		-------------------------------------------
		-- Disable Buttons as Appropriate
		-------------------------------------------

		local b = _bViewOnly or not city:CanBuyAnyPlot()
		Controls.BuyPlotButton:SetDisabled( b )
		if _bBuyPlotMode and not b then
			Controls.BuyPlotAnim:Play()
		else
			Controls.BuyPlotAnim:SetToBeginning()
		end

		local bIsLock = _bViewOnly or (player:GetNumCities() <= 1)
		Controls.PrevCityButton:SetDisabled( bIsLock )
		Controls.NextCityButton:SetDisabled( bIsLock )
		for _, control in pairs( _tCityFocusButtons ) do
			control:SetDisabled( _bViewOnly )
		end

		-------------------------------------------
		-- Panels
		-------------------------------------------

		UpdateCityBuidings( city, bNotResisting, iPlayer, player )
		UpdateCityProductionQueue( city, iCity, iPlayer, player:GetGold(), player.GetFaith and player:GetFaith() or 0, bActivePlayerCity, not isCityCaptureViewingMode and _bCiv5BNW and player:MayNotAnnex() and city:IsPuppet() )
		UpdateCityWorkingHexes( city )
		EventsRequestYieldDisplay( YieldDisplayTypesAREA, HexRadius( city:GetNumCityPlots() - 1 ), city:GetX(), city:GetY() )

--print( "UpdateCityView9" )
		local instance = _CityInstances[ iCity ]
		if instance then
			return UpdateCityInstance( city, instance )
		end
	end
end

local function UpdateOptionsAndCityView()
	_bAdvisor = UserInterfaceSettings.CityAdvisor ~= 0
	_bScreenAutoClose = UserInterfaceSettings.CityScreenAutoClose ~= 0
	_bNextCityProduction = UserInterfaceSettings.NextCityProduction ~= 0
	_bResetCityPlotPurchase = UserInterfaceSettings.ResetCityPlotPurchase ~= 0
	_FocusSelectIM.Collapse( not OptionsManager.IsNoCitizenWarning() )
	_bDebugMode = Game.IsDebugMode()
	return UpdateCityView()
end

_SpecialBuildingsIM	= InstanceStackManager( "BuildingInstance", "Button", Controls.SpecialBuildingsStack, Controls.SpecialBuildingsHeader, ResizeRightStack )
_GreatWorkIM		= InstanceStackManager( "BuildingInstance", "Button", Controls.GreatWorkStack, Controls.GreatWorkHeader, ResizeRightStack )
_WondersIM			= InstanceStackManager( "BuildingInstance", "Button", Controls.WondersStack, Controls.WondersHeader, ResizeRightStack )
_BuildingsIM		= InstanceStackManager( "BuildingInstance", "Button", Controls.BuildingsStack, Controls.BuildingsHeader, ResizeRightStack )
_GreatPeopleIM		= InstanceStackManager( "GPInstance", "GPBox", Controls.GPStack, Controls.GPHeader, ResizeRightStack )
_SlackerIM			= InstanceStackManager( "Slot", "Button", Controls.SlackerStack, Controls.SlackerHeader, ResizeRightStack )
_CityInfoIM			= InstanceStackManager( "ProductionInstance", "PQbox", Controls.CityInfoStack, Controls.CityInfoHeader, ResizeLeftStacks, true ) -- dummy IM to manage header :D
_ProdQueueIM		= InstanceStackManager( "ProductionInstance", "PQbox", Controls.QueueStack, Controls.QueueHeader, ResizeLeftStacks, true )
_UnitSelectIM		= InstanceStackManager( "SelectionInstance", "Button", Controls.UnitButtonStack, Controls.UnitButton, ResizeLeftStacks )
_BuildingSelectIM	= InstanceStackManager( "SelectionInstance", "Button", Controls.BuildingButtonStack, Controls.BuildingsButton, ResizeLeftStacks )
_WonderSelectIM		= InstanceStackManager( "SelectionInstance", "Button", Controls.WonderButtonStack, Controls.WondersButton, ResizeLeftStacks )
_ProcessSelectIM	= InstanceStackManager( "SelectionInstance", "Button", Controls.OtherButtonStack, Controls.OtherButton, ResizeLeftStacks )
_FocusSelectIM		= InstanceStackManager( "", "", Controls.WorkerManagementBox, Controls.WorkerHeader, function(collapsed) _bWorkerHeadingOpen = not collapsed ResizeRightStack() UpdateWorkingHexes() end, true, not _bWorkerHeadingOpen )

--------------
-- Rename City
local function RenameCity()
	local city = GetSelectedModifiableCity()
	if city then
		return Events.SerialEventGameMessagePopup{
				Type = ButtonPopupTypes.BUTTONPOPUP_RENAME_CITY,
				Data1 = city:GetID(),
				Data2 = -1,
				Data3 = -1,
				Option1 = false,
				Option2 = false
				}
	end
end

local NoAutoSpecialistCheckbox = { [eLClick] = function()
	local city = GetSelectedModifiableCity()
	if city then
--		Game.SelectedCitiesGameNetMessage(GameMessageTypes.GAMEMESSAGE_DO_TASK, TaskTypes.TASK_NO_AUTO_ASSIGN_SPECIALISTS, -1, -1, not city:IsNoAutoAssignSpecialists() )
		Network.SendDoTask( city:GetID(), TaskTypes.TASK_NO_AUTO_ASSIGN_SPECIALISTS, -1, -1, not city:IsNoAutoAssignSpecialists(), false )
	end
end }

--==========================================================
-- Register Events
--==========================================================
SetupCallbacks( Controls, 
{
	HappinessBox = LuaEvents.CityViewToolTips.Call,
	ProdBox = LuaEvents.CityViewToolTips.Call,
	FoodBox = LuaEvents.CityViewToolTips.Call,
	GoldBox = LuaEvents.CityViewToolTips.Call,
	ScienceBox = LuaEvents.CityViewToolTips.Call,
	CultureBox = LuaEvents.CityViewToolTips.Call,
	CulturePlot = LuaEvents.CityViewToolTips.Call,
	FaithBox = LuaEvents.CityViewToolTips.Call,
	TourismBox = LuaEvents.CityViewToolTips.Call,
	ProductionPortraitButton = LuaEvents.CityViewToolTips.Call,
	PopulationPortraitButton = LuaEvents.CityViewToolTips.Call,
	PQbox = ProductionToolTip,
},
"EUI_ItemTooltip",
{
	AvoidGrowthButton = {
		[eLClick] = function()
			local city = GetSelectedModifiableCity()
			if city then
				Network.SendSetCityAvoidGrowth( city:GetID(), not city:IsForcedAvoidGrowth() )
				return Network.SendUpdateCityCitizens( city:GetID() )
			end
		end,
	},
	CityTaskButton = {
		[eLClick] = function( iCity, iTask, button )
			local city = GetSelectedCity()
			if city and city:GetID() == iCity then
				return Events.SerialEventGameMessagePopup{
					Type = ButtonPopupTypes.BUTTONPOPUP_CONFIRM_CITY_TASK,
					Data1 = iCity,
					Data2 = iTask,
					Text = button:GetToolTipString()
					}
			end
		end,
	},
	YesButton = {
		[eLClick] = function( iCity, iBuilding )
			Controls.SellBuildingConfirm:SetHide( true )
			if iCity and iBuilding and iBuilding > 0 and GetSelectedModifiableCity() then
				Network.SendSellBuilding( iCity, iBuilding )
				Network.SendUpdateCityCitizens( iCity )
			end
			return Controls.YesButton:SetVoids( -1, -1 )
		end,
	},
	NoButton = { [eLClick] = CancelBuildingSale },
	NextCityButton = { [eLClick] = GotoNextCity },
	PrevCityButton = { [eLClick] = GotoPrevCity },
	ReturnToMapButton = { [eLClick] = ExitCityScreen },
	ProductionPortraitButton = { [eRClick] = ProductionPedia },
	BoxOSlackers = { [eLClick] = OnSlackersSelected },
	ResetButton = { [eLClick] = PlotButtonClicked },
	NoAutoSpecialistCheckbox = NoAutoSpecialistCheckbox,
	NoAutoSpecialistCheckbox2 = NoAutoSpecialistCheckbox,
	EditButton = { [eLClick] = RenameCity },
	TitlePanel = { [eRClick] = RenameCity },
	PQbox = { [eMouseEnter] = SwapQueueItem, [eRClick] = ProductionPedia },
	PQremove = { [eLClick] = RemoveQueueItem },
})

--Controls.ResetButton:SetVoid1( 0 )	-- calling with 0 = city center causes reset of all forced tiles
--Controls.BoxOSlackers:SetVoids(-1,-1)
--Controls.ProductionPortraitButton:SetVoid1( 0 )

Controls.BuyPlotButton:RegisterCallback( eLClick, function()
	_bBuyPlotMode = not _bBuyPlotMode
	return UpdateCityView()
end)

Events.GameOptionsChanged.Add( UpdateOptionsAndCityView )
UpdateOptionsAndCityView()

Events.SerialEventCityCreated.Add( function( hexPos, iPlayer, iCity ) --, cultureType, eraType, continent, populationSize, size, fowState )
	if iPlayer == _iActivePlayer then
--print( "SerialEventCityCreated1", hexPos.x, hexPos.y, iPlayer, iCity )
		local player = Players[ iPlayer ]
		local city = player and player:GetCityByID( iCity )
		if city and not ( city:IsPuppet() or city:IsResistance() ) then
			local a = tonumber(UserInterfaceSettings.DefaultCityFocus)
			if a and a>=0 and a<=CityAIFocusTypes.NUM_CITY_AI_FOCUS_TYPES then
				Network.SendSetCityAIFocus( iCity, a ) --CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PRODUCTION
			end
			Network.SendUpdateCityCitizens( iCity ) -- reassign citizens
			UI.DoSelectCityAtPlot( city:Plot() ) -- open city screen
		end
--print( "SerialEventCityCreated2", GetHeadSelectedCity(), UI.IsCityScreenUp() )
	end
end)

LuaEvents.ShowWorkingHexes.Add( function( control, city )
--print( "LuaEvents.ShowWorkingHexes.Call", control, city and city:GetName() )
	if control and city then
		Controls.PlotButtonContainer:ChangeParent( control )
		return UpdateCityWorkingHexes( city, true )
	else
		Controls.PlotButtonContainer:ChangeParent( Controls.CityButtons )
		return EventsClearHexHighlightStyle( "HexContour" )
	end
end)

--==========================================================
-- Enter City Screen
--==========================================================

Controls.CityScrollPanel:SetSizeX( _iScreenWidth - 600 )

Events.SerialEventEnterCityScreen.Add( function()
--print("enter city screen", GetHeadSelectedCity())
	Controls.PlotButtonContainer:ChangeParent( Controls.CityButtons )
	LuaEvents.TryQueueTutorial("CITY_SCREEN", true)
	Events.SerialEventCityScreenDirty.Add( UpdateCityView )
	Events.SerialEventCityInfoDirty.Add( UpdateCityView )
	Events.SerialEventCityHexHighlightDirty.Add( UpdateWorkingHexes )
	_iQueuedItem = nil
	_pPreviousCity = nil
	if _bResetCityPlotPurchase then
		_bBuyPlotMode = false
	end
	Controls.RightScrollPanel:SetScrollValue(0)
	_CitiesIM:ResetInstances()
	_CityInstances = {}
	UpdateCityView()
	local city = UI.GetHeadSelectedCity()
	local iPlayer = city and city:GetOwner()
	local player = Players[ iPlayer ]
	if player and player:GetTeam() == Game.GetActiveTeam() then --todo observer & spy
		for city in player:Cities() do
			local instance, new = _CitiesIM:GetInstance()
			UpdateCityInstance( city, instance )
			local iCity = city:GetID()
			instance.Button:SetVoids( iPlayer, iCity )
			_CityInstances[ iCity ] = instance
			if new then
				instance.Button:RegisterCallback( eLClick, GotoCity )
			end
		end
--		Controls.CityStack:ReprocessAnchoring()
		Controls.CityScrollPanel:CalculateInternalSize()
		Controls.CityScrollPanel:ReprocessAnchoring()
	end
--TODO other scroll panels
end)

--==========================================================
-- Exit City Screen
--==========================================================

Events.SerialEventExitCityScreen.Add( function()
--print("exit city screen")
	if UI.IsCityScreenUp() then
		Events.SerialEventCityScreenDirty.RemoveAll()
		Events.SerialEventCityInfoDirty.RemoveAll()
		Events.SerialEventCityHexHighlightDirty.RemoveAll()
		local city = UI.GetHeadSelectedCity()
		local plot = city and city:Plot()

		EventsClearHexHighlightStyle( "HexContour" )

		-- We may get here after a player change, clear the UI if this is not the active player's city
		if not city or city:GetOwner() ~= _iActivePlayer then
			ClearCityUIInfo()
		end
		-- required for game engine to display proper hex shading
		UI.ClearSelectedCities()
		LuaEvents.TryDismissTutorial("CITY_SCREEN")
		-- Try and re-select the last unit selected
		if not UI.GetHeadSelectedUnit() and UI.GetLastSelectedUnit() then
			UI.SelectUnit( UI.GetLastSelectedUnit() )
		end
		if plot then
			UI.LookAt( plot, 2 ) -- 1 = CAMERALOOKAT_CITY_ZOOM_IN, 2 = CAMERALOOKAT_NORMAL (see CvEnums.h)
		else
			UI.LookAtSelectionPlot()
		end
		_bViewOnly = true
		return CleanupCityScreen()
	end
end)

--==========================================================
-- Change Strategic View State
--==========================================================

if _bCiv5 then
	local NormalWorldPositionOffset = _tWorldPositionOffset
	local NormalWorldPositionOffset2 = _tWorldPositionOffset2
	local StrategicViewWorldPositionOffset = { x = 0, y = 20, z = 0 }
	Events.StrategicViewStateChanged.Add( function( bStrategicView )
		if bStrategicView then
			_tWorldPositionOffset = StrategicViewWorldPositionOffset
			_tWorldPositionOffset2 = StrategicViewWorldPositionOffset
		else
			_tWorldPositionOffset = NormalWorldPositionOffset
			_tWorldPositionOffset2 = NormalWorldPositionOffset2
		end
		_pPreviousCity = false
		return UpdateCityView()
	end)
end

--==========================================================
-- 'Active' (local human) player has changed
--==========================================================

Events.GameplaySetActivePlayer.Add( function( activePlayerID )--, previousActivePlayerID )
	_iActivePlayer = activePlayerID
	_pActivePlayer = Players[ _iActivePlayer ]
	_tFinishedItems = {}
	ClearCityUIInfo()
	if UI.IsCityScreenUp() then
		return ExitCityScreen()
	end
end)

Events.ActivePlayerTurnEnd.Add( function()
	_tFinishedItems = {}
end)

AddSerialEventGameMessagePopup( function( popupInfo )
	if popupInfo.Type == ButtonPopupTypes.BUTTONPOPUP_CHOOSEPRODUCTION then
		Events.SerialEventGameMessagePopupProcessed.CallImmediate(ButtonPopupTypes.BUTTONPOPUP_CHOOSEPRODUCTION, 0)
		Events.SerialEventGameMessagePopupShown( popupInfo )

		local iCity = popupInfo.Data1		-- city id
		local iOrder = popupInfo.Data2		-- finished order id
		local iRow = popupInfo.Data3		-- finished row id
		local city = iCity and _pActivePlayer:GetCityByID( iCity )

		if city then
			if iOrder >= 0 and iRow >= 0 then
				_tFinishedItems[ iCity ] = { iOrder, iRow }
			end
			_bButtonPopupChooseProduction = true
			return UI.DoSelectCityAtPlot( city:Plot() )	-- open city screen
		end
	end
end, ButtonPopupTypes.BUTTONPOPUP_CHOOSEPRODUCTION )

local function FinishedItem( iOrder, iPlayer, iCity , iItem )--, bGold, bFaithOrCulture )
	if iPlayer == _iActivePlayer then
		_tFinishedItems[ iCity ] = { iOrder, iItem }
	end
end
-- !!! GameEvents is bugged and must go through pcall !!!
GameEvents.CityTrained.Add( function( ... ) return pcall( function( iPlayer, iCity, iUnit, ... )
	if iPlayer == _iActivePlayer then
		local player = Players[ iPlayer ]
		local unit = player and player:GetUnitByID( iUnit )
		if unit then
			return FinishedItem( ORDER_TRAIN, iPlayer, iCity, unit:GetUnitType(), ... )
		end
	end
end, ... ) end )
GameEvents.CityConstructed.Add( function( ... ) return pcall( FinishedItem, ORDER_CONSTRUCT, ... ) end )
GameEvents.CityCreated.Add( function( ... ) return pcall( FinishedItem, ORDER_CREATE, ... ) end )

ContextPtr:SetShutdown( function()
	Controls.PlotButtonContainer:ChangeParent( ContextPtr )
end)
end)
--==========================================================
-- Support for Modded Add-in UI's
--==========================================================
do
	g_uiAddins = {}
	local Modding = Modding
	local uiAddins = g_uiAddins
	for addin in Modding.GetActivatedModEntryPoints("CityViewUIAddin") do
		local addinFile = Modding.GetEvaluatedFilePath(addin.ModID, addin.Version, addin.File)
		if addinFile then
			print( "Loading MOD CityViewUIAddin\n", Modding.GetModProperty(addin.ModID, addin.Version, "Name"), addin.File )
			table.insert( uiAddins, ContextPtr:LoadNewContext( addinFile.EvaluatedPath:match("(.*)%..*") ) )
		end
	end
end
