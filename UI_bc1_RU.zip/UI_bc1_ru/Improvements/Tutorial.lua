if Game.IsGameMultiPlayer() or Game.IsHotSeat() or Game.IsOption("GAMEOPTION_NO_TUTORIAL") then
	print("No Tutorials Allowed")
else
	-- An extremely hacky way to determine which tutorial is to be run
	local g_TutorialID = GameDefines.TUTORIAL or -1
	local g_Tutorial = ({ "Tutorial_1_MovementAndExploration", "Tutorial_2_FoundCities", "Tutorial_3_ImprovingCities", "Tutorial_4_CombatAndConquest", "Tutorial_5_Diplomacy" })[ g_TutorialID ]
	local g_IsTutorialEngineEnabled

	local function LoadTutorialChoice( init )
		if g_Tutorial or Game.GetTutorialLevel() >= 0 or Game.IsStaticTutorialActive() then
			if not g_IsTutorialEngineEnabled then
				include("TutorialChecks")
				if g_Tutorial then
					include( g_Tutorial )
				elseif g_TutorialID == 0 then
					Game.SetStaticTutorialActive(true)
					include("Tutorial_MainGame")
				else
					include("Tutorial_MainGame")
				end
				include("TutorialEngine")
				if init ~= 12345 then
					InitializeTutorialSystem()
				end
				print("Tutorials Enabled")
				g_IsTutorialEngineEnabled = true
			end
		elseif g_IsTutorialEngineEnabled then
			Events.HexFOWStateChanged.RemoveAll()
			Events.NaturalWonderRevealed.RemoveAll()
			Events.SerialEventImprovementCreated.RemoveAll()
			Events.RunCombatSim.RemoveAll()
			Events.EndCombatSim.RemoveAll()
			Events.LocalMachineAppUpdate.RemoveAll()
			Events.SerialEventGameMessagePopup.RemoveAll()
			Events.SerialEventGameMessagePopupShown.RemoveAll()
			Events.SerialEventGameMessagePopupProcessed.RemoveAll()
			Events.NotificationAdded.RemoveAll()
			Events.NotificationRemoved.RemoveAll()
			Events.AdvisorDisplayHide.RemoveAll()
			Events.SequenceGameInitComplete.RemoveAll()
			Events.SerialEventImprovementDestroyed.RemoveAll()
			Events.SerialEventCityCreated.RemoveAll()
			Events.SerialEventImprovementIconCreated.RemoveAll()
			Events.SerialEventRoadCreated.RemoveAll()
			Events.SerialEventCityCaptured.RemoveAll()
			LuaEvents.TryQueueTutorial.RemoveAll()
			LuaEvents.TryDismissTutorial.RemoveAll()
			g_IsTutorialEngineEnabled = false
			print("Tutorials Disabled")
		elseif init == 12345 then
			print("No Tutorials Required")
		end
	end

	Events.GameOptionsChanged.Add( LoadTutorialChoice )
	LoadTutorialChoice( 12345 )

end