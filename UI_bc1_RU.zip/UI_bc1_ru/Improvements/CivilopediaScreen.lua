-------------------------------------------------
-- Civilopedia screen
-------------------------------------------------

print"Loading EUI Civilopedia Script"

include "GameInfoCache" -- warning! booleans are true, not 1, and use iterator ONLY with table field conditions, NOT string SQL query
local GameInfo = GameInfoCache

include( "InstanceStackManager" )
local InstanceStackManager = InstanceStackManager

include( "IconHookup" )
local IconLookup = IconLookup
local IconHookup = IconHookup
local nullOffset = nullOffset

local ipairs = ipairs
local math = math
local pairs = pairs
--local print = print
local string = string
local table = table
local tostring = tostring
local tonumber = tonumber
local insert = table.insert
local sort = table.sort
local concat = table.concat
--local remove = table.remove

local Game = Game
local Controls = Controls
local UIManager = UIManager
local eLClick = Mouse.eLClick
local _HasTextKey = Locale.HasTextKey
local L = Locale.ConvertTextKey
local ToLower = Locale.ToLower
local Compare = Locale.Compare
local DataBaseQuery = DB.Query
local YieldTypes = YieldTypes
local GameDefines = GameDefines
local Players = Players
local Teams = Teams
local Events = Events
local KeyDown = KeyEvents.KeyDown
local VK_ESCAPE = Keys.VK_ESCAPE
--local VK_RETURN = Keys.VK_RETURN
local BulkShowUI = SystemUpdateUIType.BulkShowUI
local BulkHideUI = SystemUpdateUIType.BulkHideUI
local ContextPtr = ContextPtr
local PopupPriority = PopupPriority

local ToolTipControls = {}
TTManager:GetTypeControlTable( "TypeRoundImage", ToolTipControls )

-- defines for the various categories of topics
local eCategoryHomePage = 1
local eCategoryGameConcepts = 2
local eCategoryTechnologies = 3
local eCategoryUnits = 4
local eCategoryPromotions = 5
local eCategoryBuildings = 6
local eCategoryWonders = 7
local eCategoryPolicies = 8
local eCategoryGreatPeople = 9
local eCategoryCivilizations = 10
local eCategoryCityStates = 11
local eCategoryTerrains = 12
local eCategoryResources = 13
local eCategoryImprovements = 14
local eCategoryReligions = 15
local eCategoryLeagueProjects = 16
local eCategoryProjects = 17
local eCategoryFeatures = 18
local eCategoryFakeFeatures = 19
local eCategoryRoutes = 20
local eCategoryLeaders = 21
local eCategorySpecialists = 22
local eCategoryBeliefs = 23
local eCategoryResolutions = 24
local eCategoryProcesses = 25

local _bCiv5BNW = ContentManager.IsActive("6DA07636-4123-4018-B643-6575B4EC336B", ContentType.GAMEPLAY) or nil
local _bCiv5notVanilla = _bCiv5BNW or ContentManager.IsActive("0E3751A1-F840-4e1b-9706-519BF484E59D", ContentType.GAMEPLAY) or nil
local _bCiv5Vanilla = not _bCiv5notVanilla or nil
local _bReligionActive = _bCiv5notVanilla and not (Game and Game.IsOption(GameOptionTypes.GAMEOPTION_NO_RELIGION)) or nil

local _tGroupedCategories = {
	[ eCategoryProjects ] = eCategoryWonders,
	[ eCategoryProcesses ] = eCategoryWonders,
	[ eCategoryFeatures ] = eCategoryTerrains,
	[ eCategoryFakeFeatures ] = eCategoryTerrains,
	[ eCategoryRoutes ] = eCategoryImprovements,
	[ eCategoryLeaders ] = eCategoryCivilizations,
	[ eCategorySpecialists ] = eCategoryGreatPeople,
	[ eCategoryBeliefs ] = eCategoryReligions,
	[ eCategoryResolutions ] = eCategoryLeagueProjects,
}

local _ButtonStack, _ButtonStackInstance, _tSection, _tSections, _tCategories, _iSelectedCategory
local _iArticlesHistory = 0
local _tArticlesHistory = {}
local _tArticlesByNameKey = {}
local _tArticlesByNameLowerCase = {}
local _tArticlesBySection = {}
local _tBoxSizes = { 208, 440, 640 }
local _tStacks = { Controls.NarrowStack, Controls.WideStack, Controls.SuperWideStack }
local _iButtonCount = 0
local _iButtonSize = 64
local _iButtonStackWidth = 100

-- These projects were more of an implementation detail and not explicit projects
-- that the user can build.  So to avoid confusion, we shall ignore them from the pedia.
local _tProjectsToIgnore = {
	PROJECT_SS_COCKPIT = true,
	PROJECT_SS_STASIS_CHAMBER = true,
	PROJECT_SS_ENGINE = true,
	PROJECT_SS_BOOSTER = true
}

local _tTrophyIcons = {
	"[ICON_TROPHY_BRONZE]",
	"[ICON_TROPHY_SILVER]",
	"[ICON_TROPHY_GOLD]",
}

-- the instance managers
local _SearchResultIM = InstanceStackManager( "ListItemInstance", "ListItemButton", Controls.SearchResultsStack )
local _ListItemIM = InstanceStackManager( "ListItemInstance", "ListItemButton", Controls.ListOfArticles )
local _ListHeadingIM = InstanceStackManager( "ListHeadingInstance", "ListHeadingButton", Controls.ListOfArticles )
local _GreatWorksIM = InstanceStackManager( "GreatWorksInstance", "GreatWorksButton" )
local _ButtonIM = InstanceStackManager( "ButtonInstance", "Button" )
local _TextIM = InstanceStackManager( "TextInstance", "Text" )
local _ButtonBoxIM = InstanceStackManager( "ButtonBoxInstance", "Frame" )
local _TextBoxIM = InstanceStackManager( "TextBoxInstance", "Frame" )

-- adjust the various parts to fit the screen size
local _, _iScreenSizeY = UIManager:GetScreenSizeVal() -- Controls.BackDrop:GetSize()
Controls.ScrollPanel:SetSizeY( _iScreenSizeY - 126 )
Controls.ScrollPanel:GetScrollBar():SetSizeY( _iScreenSizeY - 162 )
Controls.LeftScrollPanel:SetSizeY( _iScreenSizeY - 126 )
Controls.LeftScrollPanel:GetScrollBar():SetSizeY( _iScreenSizeY - 162 )

local function TipHandler( control )
	local tCategory = _tCategories[ control:GetVoid1() ]
	local info = tCategory and tCategory.Info
	local row = info and info[ control:GetVoid2() ]
	local index = row and (row.PortraitIndex or row.IconIndex)
	if index and row.IconAtlas then
		local offset, texture = IconLookup( index, 256, row.IconAtlas )
		if offset and texture then
			ToolTipControls.ToolTipText:SetText( row._Name )
			ToolTipControls.ToolTipGrid:DoAutoSize()
			ToolTipControls.ToolTipImage:SetTexture( texture )
			ToolTipControls.ToolTipImage:SetTextureOffset( offset )
			return ToolTipControls.ToolTipFrame:SetHide( false )
		end
	end
	ToolTipControls.ToolTipFrame:SetHide( true )
end

--------------------------------------------------------------------------------------------------------
-- a few handy-dandy helper functions
--------------------------------------------------------------------------------------------------------

local function signed( i )
	i = tonumber( i )
	if i then
		if i > 0 then
			return "+"..i
		else
			return i
		end
	else
		return "?"
	end
end

local function NZ( i )
	return (tonumber(i) or 0) ~= 0
end

local function HasTextKey( key )
	return _HasTextKey( tostring(key) )
end

local function LL( ... )
	if HasTextKey(...) then
		return L( ... )
	end
end

local function insertIf( t, v )
	if v then
		return insert( t, v )
	end
end

local function insertIfLocalized( t, ... )
	if HasTextKey(...) then
		return insert( t, L( ... ) )
	end
end

local function ShowInPedia( row )
	return row and row.ShowInPedia ~= false and row.ShowInPedia ~= 0
end

local function ResizeEtc()
	Controls.ListOfArticles:CalculateSize()
	Controls.WideStack:CalculateSize()
	Controls.NarrowStack:CalculateSize()

	Controls.WideStack:ReprocessAnchoring()
	Controls.NarrowStack:ReprocessAnchoring()
	Controls.ListOfArticles:ReprocessAnchoring()
	
	local n = Controls.NarrowStack:GetSizeY()
	local w = Controls.WideStack:GetSizeY()
	Controls.SuperWideStack:SetOffsetY( (n>w and n or w)+50 )
	w = n>0 and -40 or -140
	Controls.TitleID:SetOffsetX( w )
	Controls.SuperWideStack:CalculateSize()
	Controls.SuperWideStack:ReprocessAnchoring()

	Controls.ScrollPanel:CalculateInternalSize()
	Controls.LeftScrollPanel:CalculateInternalSize()

	Controls.SearchEditBox:TakeFocus()
	Controls.SearchGrid:SetHide( true )
end

local function AddTextBox( title, text, i, b )
	if text and tostring(text) > "" then
		i = i or 1
		local instance = _TextBoxIM:GetInstance( _tStacks[ i ] )
		i = _tBoxSizes[ i ]
		instance.Title:SetTruncateWidth( i )
		instance.Text:SetWrapWidth( i-20 )
		instance.Title:LocalizeAndSetText( title or "" )
		instance.Text:SetFontByName( b and "TwCenMT18" or "TwCenMT20" )
		instance.Text:SetText( text )
		local h = instance.Text:GetSizeY()
		instance.InnerFrame:SetSizeVal( i, h + 34 )
		instance.Frame:SetSizeVal( i-4, h + 30 )
	end
end

local function SetPortrait( portraitAtlas, portraitIndex )
	if portraitAtlas then
		if portraitIndex then
			if IconHookup( portraitIndex, 256, portraitAtlas, Controls.Portrait ) then
				Controls.PortraitFrame:SetHide( false )
				return true
			end
		elseif portraitAtlas then
			Controls.Portrait:SetTexture( portraitAtlas )
			Controls.Portrait:SetTextureOffsetVal( 0,0 )
			Controls.PortraitFrame:SetHide( false )
			return true
		end
	end
end

local function ClearArticle()
	Controls.PortraitFrame:SetHide( true )
	Controls.SearchGrid:SetHide( true )
	Controls.SearchButton:SetHide( false )
	Controls.ScrollPanel:SetScrollValue( 0 )
	Controls.Portrait:UnloadTexture()
	_GreatWorksIM:ResetInstances()
	_ButtonIM:ResetInstances()
	_TextIM:ResetInstances()
	_ButtonBoxIM:ResetInstances()
	_TextBoxIM:ResetInstances()
end

local function AddListItem( s, callback, void1, void2 )
	local instance = _ListItemIM:GetInstance()
	if instance then
		instance.ListItemLabel:SetText( s )
		instance.ListItemButton:SetVoids( void1, void2 )
		instance.ListItemButton:RegisterCallback( eLClick, callback )
		instance.ListItemButton:SetToolTipCallback( TipHandler )
	end
end

local SelectArticleHistorized -- function defined later

local function SelectCategoryHeading( iCategory, iHeading )
	_ListHeadingIM:ResetInstances()
	_ListItemIM:ResetInstances()
	-- put in a home page item
	local tSections = _tArticlesBySection[ iCategory ]
	if tSections then
		if tSections.HomePage then
			AddListItem( tSections.HomePage, SelectArticleHistorized, iCategory, -1 )
		end
		for iSection, tSection in ipairs( tSections ) do
			local isOpen = true
			-- show section header
			if tSection.HeadingName then
				isOpen = not tSection.HeadingClosed
				if iSection == iHeading then
					tSection.HeadingClosed = isOpen
					isOpen = not isOpen
				end
				local instance = _ListHeadingIM:GetInstance()
				if instance then
					instance.ListHeadingLabel:SetText( ( isOpen and "[ICON_MINUS] " or "[ICON_PLUS] " ) .. tSection.HeadingName )
					instance.ListHeadingButton:SetVoids( iCategory, iSection )
					instance.ListHeadingButton:RegisterCallback( eLClick, SelectCategoryHeading )
				end
			end
			-- show names of articles in section
			if isOpen then
				for _, tArticle in ipairs(tSection) do
					AddListItem( tArticle.EntryName, SelectArticleHistorized, tArticle.CategoryID, tArticle.EntryID )
				end
			end
		end
	end
	return ResizeEtc()
end

local function SelectArticle( iCategory, iRow, bHistorize )
	local tCategory = _tCategories[ iCategory ]
	if tCategory then
		iCategory = _tGroupedCategories[ iCategory ] or iCategory
		if _iSelectedCategory ~= iCategory then
			_iSelectedCategory = iCategory
			-- set up tab & label
			Controls.SelectedCategoryTab:SetOffsetX( 47 * (iCategory - 1) )
			Controls.SelectedCategoryTab:SetTexture( _tCategories[ iCategory ].Texture )
			Controls.CategoryLabel:LocalizeAndSetText( "TXT_KEY_PEDIA_CATEGORY_"..iCategory.."_LABEL" )
			-- populate the list of entries
			SelectCategoryHeading( iCategory )
		end
		if bHistorize then
			local tArticle = tCategory[ iRow or -1 ]
			if tArticle then
				if _iArticlesHistory == 0 or tArticle ~= _tArticlesHistory[ _iArticlesHistory ] then
					_iArticlesHistory = _iArticlesHistory + 1
					_tArticlesHistory[_iArticlesHistory] = tArticle
					for i = _iArticlesHistory + 1, #_tArticlesHistory do
						_tArticlesHistory[i] = nil
					end
				end
			end
		end
		ClearArticle()
		local row = tCategory.Info and tCategory.Info[ iRow ]
		if row then
			Controls.ArticleID:SetText( row._Name )
			local i = tCategory.DisplayArticle and 2 or 3
			local j = i
			if SetPortrait( row.IconAtlas, row.PortraitIndex or row.IconIndex ) then
				i = 2
			end
			if HasTextKey( row.Help ) then
				AddTextBox( "TXT_KEY_PEDIA_GAME_INFO_LABEL", L(row.Help), i )
				i = j
			end
			if tCategory.DisplayArticle then
				tCategory.DisplayArticle( row, iRow )
			end
			if row.Help ~= row.Strategy and HasTextKey( row.Strategy ) then
				AddTextBox( "TXT_KEY_PEDIA_STRATEGY_LABEL", L(row.Strategy), i )
				i = j
			end
			if HasTextKey( row.Quote ) then
				AddTextBox( "TXT_KEY_PEDIA_QUOTE_LABEL", L(row.Quote), i, 1 )
				i = j
			end
			if HasTextKey( row.Civilopedia ) then
				AddTextBox( "TXT_KEY_PEDIA_HISTORICAL_LABEL", L(row.Civilopedia), i, 1 )
			end
		else
			tCategory = _tCategories[ iCategory ] or tCategory
			if tCategory.DisplayHomePage then
				tCategory.DisplayHomePage()
			end
		end
	end
	return ResizeEtc()
end

function SelectArticleHistorized( iCategory, iRow )
	return SelectArticle( iCategory, iRow, true )
end

local function ConfigureButton( image, button, iCategory, sTipKey, iRow, textureOffset, sTexture )
	image:SetTexture( sTexture or "blank.dds" )
	image:SetTextureOffset( textureOffset or nullOffset )
	if iCategory and iRow then
		button:SetVoids( iCategory, iRow )
		button:RegisterCallback( eLClick, SelectArticleHistorized )
		button:SetToolTipCallback( TipHandler )
		button:SetToolTipType( "TypeRoundImage" )
	else
		if button.ClearCallback then
			button:ClearCallback( eLClick )
		end
		button:SetToolTipType()
		if sTipKey then
			button:LocalizeAndSetToolTip( sTipKey )
		else
			button:SetToolTipString()
		end
	end
	_iButtonCount = _iButtonCount + 1
end

local function AddTextToButtonStack( s )
	local instance = s and s>"" and _TextIM:GetInstance( _ButtonStack )
	if instance then
		instance.Text:SetText( s )
		instance.Text:SetWrapWidth( _iButtonStackWidth )
		_iButtonCount = _iButtonCount + 1
	end
end	

local function AddSmallButton( row, iCategory, iRow )
	local instance = row and _ButtonIM:GetInstance( _ButtonStack )
	if instance then
		return ConfigureButton( instance.Image, instance.Button, iCategory, row._Name, iRow or row.ID, IconLookup( row.PortraitIndex or row.IconIndex, _iButtonSize, row.IconAtlas ) )
	end
end

local function AddSmallButtonInPedia( ... )
	if ShowInPedia((...)) then
		return AddSmallButton( ... )
	end
end

local function AddBuildingButtonInPedia( row )
	if ShowInPedia(row) then
		local class = GameInfo.BuildingClasses[ row.BuildingClass ]
		return AddSmallButton( row, class and ( class.MaxGlobalInstances > 0 or (class.MaxPlayerInstances == 1 and row.SpecialistCount == 0) or class.MaxTeamInstances > 0 ) and eCategoryWonders or eCategoryBuildings )
	end
end

local function AddBuildingClassButton( row, sCivType )
	if row then
		local r = sCivType and GameInfo.Civilization_BuildingClassOverrides{ CivilizationType = sCivType, BuildingClassType = row.Type }()
		return AddBuildingButtonInPedia( GameInfo.Buildings[ r and r.BuildingType or row.DefaultBuilding ] )
	end
end

local function InitButtonStack( i )
	i = i or 1
	_ButtonStackInstance = _ButtonBoxIM:GetInstance( _tStacks[ i ] )
	_ButtonStack = _ButtonStackInstance.Stack
	i = _tBoxSizes[ i ]
	_ButtonStackInstance.Label:SetTruncateWidth( i )
	_ButtonStackInstance.InnerFrame:SetSizeX( i )
	_ButtonStackInstance.Frame:SetSizeX( i-4 )
	_ButtonStack:SetWrapWidth( i )
	_iButtonStackWidth = i-20
	_iButtonCount = 0
end

local function CommitButtonStack( s )
	if _ButtonStack:GetNumChildren() > 0 then
		_ButtonStack:CalculateSize()
		_ButtonStack:ReprocessAnchoring()
		local h = _ButtonStack:GetSizeY()
		_ButtonStackInstance.InnerFrame:SetSizeY( h + 4 )
		_ButtonStackInstance.Frame:SetSizeY( h )
		_ButtonStackInstance.Label:LocalizeAndSetText( s )
	else
		_ButtonBoxIM:ReleaseInstance( _ButtonStackInstance )
	end
end

local function AddButtonsBox( addButton, iCategory, s, rows, i )
	InitButtonStack( i )
	for row in rows do
		addButton( row, iCategory )
	end
	return CommitButtonStack( s )
end

local function AddLinkedButtonsBox( addButton, iCategory, info, link, s, rows, i )
	InitButtonStack( i )
	for row in rows do
		addButton( info[ row[link] ], iCategory )
	end
	return CommitButtonStack( s )
end

local function AddSingleButton( iCategory, s, row, i )
	if row then
		InitButtonStack( i )
		AddSmallButton( row, iCategory )
		return CommitButtonStack( s )
	end
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
local function AddWorkerActions( rows, link )
	InitButtonStack()
	for row in rows do
		if link then
			row = GameInfo.Builds[ row[ link ] ]
		end
		if ShowInPedia( row ) then
			local iRow, iCategory
			if row.ImprovementType then
				iCategory = eCategoryImprovements
				iRow = GameInfo.Improvements[ row.ImprovementType ].ID
			elseif row.RouteType then
				iCategory = eCategoryRoutes
				iRow = GameInfo.Routes[ row.RouteType ].ID
			else
				local row = GameInfo.BuildFeatures{ BuildType = row.Type }()
				row = row and GameInfo.Features[ row.FeatureType ]
				iRow = row and row.ID
				iCategory = iRow and eCategoryFeatures
			end
			AddSmallButton( row, iCategory, iRow )
		end
	end
	return CommitButtonStack "TXT_KEY_PEDIA_WORKER_ACTION_LABEL"
end

local function AddTech( s, key )
	return AddSingleButton( eCategoryTechnologies, s, GameInfo.Technologies[ key ] )
end

local function AddResources( ... )
	return AddLinkedButtonsBox( AddSmallButton, eCategoryResources, GameInfo.Resources, "ResourceType", ... )
end

local function AddPrereqTechs( ... )
	return AddLinkedButtonsBox( AddSmallButton, eCategoryTechnologies, GameInfo.Technologies, "PrereqTech", "TXT_KEY_PEDIA_PREREQ_TECH_LABEL", ... )
end

local function AddCivilizations( ... )
	return AddLinkedButtonsBox( AddSmallButton, eCategoryCivilizations, GameInfo.Civilizations, "CivilizationType", "TXT_KEY_PEDIA_CIVILIZATIONS_LABEL", ... )
end

local function AddSameClass( rows, iCategory, iRow )
	InitButtonStack()
	for row in rows do
		if ShowInPedia(row) and iRow ~= row.ID then
			AddSmallButton( row, iCategory )
		end
	end
	return CommitButtonStack "TXT_KEY_PEDIA_REPLACES_LABEL"
end

local function DoDisplayHomePage( pageLabel, quoteText, helpText, portraitAtlas, portraitIndex, iconQuery )
	ClearArticle()
	Controls.ArticleID:LocalizeAndSetText( pageLabel )

	-- Update some circle logo
	local row = iconQuery and DataBaseQuery( iconQuery )()
	if row then
		portraitIndex = row.PortraitIndex
		portraitAtlas = row.IconAtlas
	end
	SetPortrait( portraitAtlas, portraitIndex )

	--Welcome and insert 1st manual paragraph
	AddTextBox( "TXT_KEY_PEDIA_QUOTE_LABEL", LL(quoteText), 2 )

	--How to use the Pedia
	return AddTextBox( pageLabel, LL(helpText), 3 )
end

local function DisplayBuildingOrWonderArticle( rBuilding, iBuilding )
	local tBuildingType = { BuildingType = rBuilding.Type }

	-- civilization unique
	AddCivilizations( GameInfo.Civilization_BuildingClassOverrides( tBuildingType ) )

	-- Cost
	local iCost = Game and Players[Game.GetActivePlayer()]:GetBuildingProductionNeeded( iBuilding ) or tonumber(rBuilding.Cost) or 0
	local iFaithCost = _bReligionActive and tonumber(rBuilding.FaithCost) or 0
	local iCostPerPlayer = 0
	if _bCiv5BNW then
		for tLeagueProject in GameInfo.LeagueProjects() do
			for iTier = 1, 3, 1 do
				local tLeagueTier = tLeagueProject["RewardTier" .. iTier]
				local tReward = tLeagueTier  and GameInfo.LeagueProjectRewards[ tLeagueTier ]
				local rewardBuildingInfo = tReward and tReward.Building and GameInfo.Buildings[tReward.Building]
				if rewardBuildingInfo and rewardBuildingInfo.ID == iBuilding then
					local league = Game and Game.GetNumActiveLeagues() > 0 and Game.GetActiveLeague()
					iCostPerPlayer = league and league:GetProjectCostPerPlayer(tLeagueProject.ID) / 100 or tLeagueProject.CostPerPlayer or 0
				end
			end
		end
	end
	local s
	if iCostPerPlayer > 0 then
		s = L( "TXT_KEY_LEAGUE_PROJECT_COST_PER_PLAYER", iCostPerPlayer )
	elseif iCost > 1 and iFaithCost > 0 then
		s = L( "TXT_KEY_PEDIA_A_OR_B", iCost .. " [ICON_PRODUCTION]", iFaithCost .. " [ICON_PEACE]" )
	elseif iCost > 0 then
		s = iCost .. " [ICON_PRODUCTION]"
	elseif iFaithCost > 0 then
		s = iFaithCost .. " [ICON_PEACE]"
	else
		s = L"TXT_KEY_FREE"
	end
	AddTextBox( "TXT_KEY_PEDIA_COST_LABEL", s )

	-- Maintenance
	local i = tonumber(rBuilding.GoldMaintenance) or 0
	if i > 0 then
		AddTextBox( "TXT_KEY_PEDIA_MAINT_LABEL", signed(-i).." [ICON_GOLD]" )
	end

	-- Happiness
	i = tonumber(rBuilding.Happiness) or 0
	if i > 0 then
		AddTextBox( "TXT_KEY_PEDIA_HAPPINESS_LABEL", signed(i).." [ICON_HAPPINESS_1]" )
	end

	-- Unmodded Happiness
	i = tonumber(rBuilding.UnmoddedHappiness) or 0
	if i > 0 then
		AddTextBox( "TXT_KEY_PEDIA_HAPPINESS_LABEL", signed(i).." [ICON_HAPPINESS_1]" )
	end

	-- Use Game to calculate Yield Changes and modifiers.
	local GetBuildingYieldChange = Game
	and function( yieldType )
		return Game.GetBuildingYieldChange( iBuilding, YieldTypes[ yieldType ] )
	end
	or function( yieldType )
		local yieldModifier = 0
		for row in GameInfo.Building_YieldChanges{ BuildingType = rBuilding.Type, YieldType = yieldType } do
			yieldModifier = yieldModifier + row.Yield
		end
		return yieldModifier
	end

	local GetBuildingYieldModifier = Game
	and function( yieldType )
		return Game.GetBuildingYieldModifier( iBuilding, YieldTypes[ yieldType ] )
	end
	or function( yieldType )
		local yieldModifier = 0
		for row in GameInfo.Building_YieldModifiers{ BuildingType = rBuilding.Type, YieldType = yieldType } do
			yieldModifier = yieldModifier + row.Yield
		end
		return yieldModifier
	end

	-- Culture
	i = _bCiv5notVanilla and GetBuildingYieldChange( "YIELD_CULTURE" ) or tonumber(rBuilding.Culture) or 0
	if i > 0 then
		AddTextBox( "TXT_KEY_PEDIA_CULTURE_LABEL", signed(i).." [ICON_CULTURE]" )
	end

	-- Faith
	i = _bReligionActive and GetBuildingYieldChange( "YIELD_FAITH" ) or 0
	if i > 0 then
		AddTextBox( "TXT_KEY_PEDIA_FAITH_LABEL", signed(i).." [ICON_PEACE]" )
	end

	-- Defense
	local t = {}
	i = tonumber(rBuilding.Defense) or 0
	insertIf( t, i > 0 and signed(i / 100).."[ICON_STRENGTH]" )
	i = _bCiv5notVanilla and tonumber(rBuilding.ExtraCityHitPoints) or 0
	insertIfLocalized( t, i > 0 and "TXT_KEY_PEDIA_DEFENSE_HITPOINTS", i )
	if #t > 0 then
		AddTextBox( "TXT_KEY_PEDIA_DEFENSE_LABEL", concat( t, "  " ) )
	end
	-- Food
	t = {}
	i = GetBuildingYieldChange( "YIELD_FOOD" )
	insertIf( t, i > 0 and "+"..i.." [ICON_FOOD]" )
	i = GetBuildingYieldModifier( "YIELD_FOOD" )
	insertIf( t, i > 0 and "+"..i.."% [ICON_FOOD]" )
	if #t > 0 then
		AddTextBox( "TXT_KEY_PEDIA_FOOD_LABEL", concat( t, "  " ) )
	end
	-- Gold
	t = {}
	i = GetBuildingYieldChange( "YIELD_GOLD" )
	insertIf( t, i > 0 and "+"..i.." [ICON_GOLD]" )
	i = GetBuildingYieldModifier( "YIELD_GOLD" )
	insertIf( t, i > 0 and "+"..i.."% [ICON_GOLD]" )
	if #t > 0 then
		AddTextBox( "TXT_KEY_PEDIA_GOLD_LABEL", concat( t, "  " ) )
	end
	-- Science
	t = {}
	i = GetBuildingYieldChange( "YIELD_SCIENCE" )
	insertIf( t, i ~= 0 and signed(i).." [ICON_RESEARCH]" )
	i = GetBuildingYieldModifier( "YIELD_SCIENCE" )
	insertIf( t, i ~= 0 and signed(i).."% [ICON_RESEARCH]" )
	if #t > 0 then
		AddTextBox( "TXT_KEY_PEDIA_SCIENCE_LABEL", concat( t, "  " ) )
	end
	-- Production
	t = {}
	i = GetBuildingYieldChange( "YIELD_PRODUCTION" )
	insertIf( t, i ~= 0 and signed(i).." [ICON_PRODUCTION]" )
	i = GetBuildingYieldModifier( "YIELD_PRODUCTION" )
	insertIf( t, i ~= 0 and signed(i).."% [ICON_PRODUCTION]" )
	if #t > 0 then
		AddTextBox( "TXT_KEY_PEDIA_PRODUCTION_LABEL", concat( t, "  " ) )
	end

	-- required tech
	AddTech( "TXT_KEY_PEDIA_PREREQ_TECH_LABEL", rBuilding.PrereqTech )
	AddTech( "TXT_KEY_PEDIA_OBSOLETE_TECH_LABEL", rBuilding.ObsoleteTech )

	-- required local resources
	AddResources( "TXT_KEY_PEDIA_LOCAL_RESRC_LABEL", GameInfo.Building_LocalResourceAnds( tBuildingType ) )

	-- required resources
	AddResources( "TXT_KEY_PEDIA_REQ_RESRC_LABEL", GameInfo.Building_ResourceQuantityRequirements( tBuildingType ) )

	-- required buildings
	AddLinkedButtonsBox( AddBuildingClassButton, nil, GameInfo.BuildingClasses, "BuildingClassType", "TXT_KEY_PEDIA_REQ_BLDG_LABEL", GameInfo.Building_ClassesNeededInCity( tBuildingType ) )

	-- similar buildings
	AddSameClass( GameInfo.Buildings{ BuildingClass = rBuilding.BuildingClass }, eCategoryBuildings, rBuilding.ID )

	-- what buildings does this building enable ?
	AddLinkedButtonsBox( AddBuildingButtonInPedia, nil, GameInfo.Buildings, "BuildingType", "TXT_KEY_PEDIA_BLDG_UNLOCK_LABEL", GameInfo.Building_ClassesNeededInCity{ BuildingClassType = rBuilding.BuildingClass } )

	-- Great People
	local sSpecialistType = rBuilding.SpecialistType
	i = sSpecialistType and tonumber( rBuilding.GreatPeopleRateChange ) or 0
	if i > 0 then
		AddTextBox( GameInfo.Specialists[sSpecialistType].GreatPeopleTitle, i.." [ICON_GREAT_PEOPLE]" )
	end

	-- specialists
	if rBuilding.SpecialistCount > 0 and rBuilding.SpecialistType then
		local row = GameInfo.Specialists[rBuilding.SpecialistType]
		if row then
			InitButtonStack()
			for _ = 1, rBuilding.SpecialistCount do
				AddSmallButton( row, eCategorySpecialists )
			end
			CommitButtonStack "TXT_KEY_PEDIA_SPEC_LABEL"
		end
	end

	-- great works
	if _bCiv5BNW then
		s = LL( rBuilding.ThemingBonusHelp )
		InitButtonStack( s and 2 )
		local greatWorkSlot = GameInfo.GreatWorkSlots[rBuilding.GreatWorkSlotType]
		for _ = 1, greatWorkSlot and rBuilding.GreatWorkCount or 0 do
			local instance = _GreatWorksIM:GetInstance( _ButtonStack )
			ConfigureButton( instance.GreatWorksImage, instance.GreatWorksButton, nil, greatWorkSlot.EmptyToolTipText, 0, nullOffset, greatWorkSlot.EmptyIcon )
		end
		AddTextToButtonStack( s )
		CommitButtonStack "TXT_KEY_PEDIA_GREAT_WORKS_LABEL"
	end
end

local function DisplayFeatureArticle( rFeature )

	local tFeatureType = { FeatureType = rFeature.Type }

	-- City Yield
	local sYield = ""
	for row in GameInfo.Feature_YieldChanges( tFeatureType ) do
		sYield = sYield..signed(row.Yield).." "..GameInfo.Yields[row.YieldType].IconString.." "
	end

	-- culture hack for vanilla
	if _bCiv5Vanilla and rFeature.Culture ~= 0 then
		sYield = sYield..signed(rFeature.Culture).."[ICON_CULTURE] "
	end

	-- add happiness since it is a quasi-yield
	if (rFeature.InBorderHappiness or 0) ~= 0 then
		sYield = sYield..signed(rFeature.InBorderHappiness).."[ICON_HAPPINESS_1]"
	end
	if sYield > "" then
		AddTextBox( "TXT_KEY_PEDIA_YIELD_LABEL", sYield )
	end

	-- Movement
	local iMoveCost = tonumber(rFeature.Movement) or 0
	if iMoveCost ~=0 or rFeature.Impassable then
		AddTextBox( "TXT_KEY_PEDIA_MOVECOST_LABEL", rFeature.Impassable and L"TXT_KEY_PEDIA_IMPASSABLE" or signed(iMoveCost).." [ICON_MOVES]" )
	end

	-- Combat Modifier
	local iCombatModifier = tonumber(rFeature.Defense) or 0
	if iCombatModifier ~=0 then
		AddTextBox( "TXT_KEY_PEDIA_COMBATMOD_LABEL", signed(iCombatModifier).."%" )
	end

	-- Terrains on which this feature can exist
	AddLinkedButtonsBox( AddSmallButton, eCategoryTerrains, GameInfo.Terrains, "TerrainType", "TXT_KEY_PEDIA_TERRAINS_LABEL", GameInfo.Feature_TerrainBooleans( tFeatureType ), 2 )

	-- Resources that can exist on this feature
	AddResources( "TXT_KEY_PEDIA_RESOURCESFOUND_LABEL", GameInfo.Resource_FeatureBooleans( tFeatureType ), 2 )
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

_tCategories = {
[ eCategoryHomePage ] = {
	Texture = "CivilopediaTopButtonsHome.dds",
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_HOME_PAGE_LABEL", "TXT_KEY_PEDIA_HOME_PAGE_BLURB_TEXT", "TXT_KEY_PEDIA_HOME_PAGE_HELP_TEXT", "TERRAIN_ATLAS", 20 )
	end,
},
[ eCategoryGameConcepts ] = {
	Texture = "CivilopediaTopButtonsGameplay.dds",
	Info = GameInfo.Concepts,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_GAME_CONCEPT_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_GCONCEPTS", "TXT_KEY_PEDIA_GAME_CONCEPT_HELP_TEXT", "TECH_ATLAS_1", 47 )
	end,
	DisplayArticle = function( thisConcept )
		Controls.ArticleID:LocalizeAndSetText( thisConcept.Description )
		AddTextBox( "", LL(thisConcept.Summary), 3 ) --TXT_KEY_PEDIA_SUMMARY_LABEL
		AddTextBox( "TXT_KEY_PEDIA_EXTENDED_LABEL", LL(thisConcept.Extended), 3 )
		AddTextBox( "TXT_KEY_PEDIA_DNOTES_LABEL", LL(thisConcept.DesignNotes), 3 )
	end,
},
[ eCategoryTechnologies ] = {
	Texture = "CivilopediaTopButtonsTechnology.dds",
	Info = GameInfo.Technologies,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_TECH_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_TECHS", "TXT_KEY_PEDIA_TECHNOLOGIES_HELP_TEXT", "TECH_ATLAS_1", 48, "SELECT PortraitIndex, IconAtlas from Technologies ORDER By Random() LIMIT 1" )
	end,
	DisplayArticle = function( rTech, iTech )
		-- Cost
		local iCost = Game and Teams[Players[Game.GetActivePlayer()]:GetTeam()]:GetTeamTechs():GetResearchCost(iTech) or rTech.Cost or 0
		AddTextBox( "TXT_KEY_PEDIA_COST_LABEL", iCost > 0 and iCost.." [ICON_RESEARCH]" or L"TXT_KEY_FREE" )

		local sTechType = rTech.Type
		local tTechType = { TechType = sTechType }
		local tPrereqTech = { PrereqTech = sTechType }
		local tTechPrereq = { TechPrereq = sTechType }
		local tTechReveal = { TechReveal = sTechType }

		-- prereq techs
		AddPrereqTechs( GameInfo.Technology_PrereqTechs( tTechType ) )

		-- leads to techs
		AddLinkedButtonsBox( AddSmallButton, eCategoryTechnologies, GameInfo.Technologies, "TechType", "TXT_KEY_PEDIA_LEADS_TO_TECH_LABEL", GameInfo.Technology_PrereqTechs( tPrereqTech ) )

		-- unlocked units
		AddButtonsBox( AddSmallButtonInPedia, eCategoryUnits, "TXT_KEY_PEDIA_UNIT_UNLOCK_LABEL", GameInfo.Units( tPrereqTech ) )

		-- unlocked buildings
		AddButtonsBox( AddBuildingButtonInPedia, nil, "TXT_KEY_PEDIA_BLDG_UNLOCK_LABEL", GameInfo.Buildings( tPrereqTech ) )

		-- unlocked projects & processes 
		InitButtonStack()
		for row in GameInfo.Projects( tTechPrereq ) do
			if not _tProjectsToIgnore[row.Type] then
				AddSmallButton( row, eCategoryProjects )
			end
		end
		for row in GameInfo.Processes( tTechPrereq ) do
			AddSmallButton( row, eCategoryProcesses )
		end
		CommitButtonStack "TXT_KEY_PEDIA_PROJ_UNLOCK_LABEL"

		-- worker actions unlocked
		AddWorkerActions( GameInfo.Builds( tPrereqTech ) )

		-- revealed resources
		AddButtonsBox( AddSmallButton, eCategoryResources, "TXT_KEY_PEDIA_RESRC_RVL_LABEL", GameInfo.Resources( tTechReveal ) )

		-- special abilities
		local t = {}
		for row in GameInfo.Route_TechMovementChanges( tTechType ) do
			insert( t, L( "TXT_KEY_CIVILOPEDIA_SPECIALABILITIES_MOVEMENT", GameInfo.Routes[row.RouteType].Description) )
		end
		for row in GameInfo.Improvement_TechYieldChanges( tTechType ) do
			insert( t, L("TXT_KEY_CIVILOPEDIA_SPECIALABILITIES_YIELDCHANGES", GameInfo.Improvements[row.ImprovementType].Description, GameInfo.Yields[row.YieldType].Description, row.Yield) )
		end
		for row in GameInfo.Improvement_TechNoFreshWaterYieldChanges( tTechType ) do
			insert( t, L("TXT_KEY_CIVILOPEDIA_SPECIALABILITIES_NOFRESHWATERYIELDCHANGES", GameInfo.Improvements[row.ImprovementType].Description, GameInfo.Yields[row.YieldType].Description, row.Yield ) )
		end
		for row in GameInfo.Improvement_TechFreshWaterYieldChanges( tTechType ) do
			insert( t, L("TXT_KEY_CIVILOPEDIA_SPECIALABILITIES_FRESHWATERYIELDCHANGES", GameInfo.Improvements[row.ImprovementType].Description, GameInfo.Yields[row.YieldType].Description, row.Yield ) )
		end
		insertIfLocalized( t, NZ(rTech.EmbarkedMoveChange) and "TXT_KEY_ABLTY_FAST_EMBARK_STRING" )
		insertIfLocalized( t, rTech.AllowsEmbarking and "TXT_KEY_ALLOWS_EMBARKING" )
		insertIfLocalized( t, rTech.AllowsDefensiveEmbarking and "TXT_KEY_ABLTY_DEFENSIVE_EMBARK_STRING" )
		insertIfLocalized( t, rTech.EmbarkedAllWaterPassage and "TXT_KEY_ABLTY_OCEAN_EMBARK_STRING" )
		insertIfLocalized( t, rTech.AllowEmbassyTradingAllowed and "TXT_KEY_ABLTY_ALLOW_EMBASSY_STRING" )
		insertIfLocalized( t, rTech.OpenBordersTradingAllowed and "TXT_KEY_ABLTY_OPEN_BORDER_STRING" )
		insertIfLocalized( t, rTech.DefensivePactTradingAllowed and "TXT_KEY_ABLTY_D_PACT_STRING" )
		insertIfLocalized( t, rTech.ResearchAgreementTradingAllowed and "TXT_KEY_ABLTY_R_PACT_STRING" )
		insertIfLocalized( t, rTech.TradeAgreementTradingAllowed and "TXT_KEY_ABLTY_T_PACT_STRING" )
		insertIfLocalized( t, rTech.BridgeBuilding and "TXT_KEY_ABLTY_BRIDGE_STRING" )
		insertIfLocalized( t, rTech.MapVisible and "TXT_KEY_REVEALS_ENTIRE_MAP" )
		insertIfLocalized( t, NZ(rTech.UnitFortificationModifier) and "TXT_KEY_UNIT_FORTIFICATION_MOD", rTech.UnitFortificationModifier )
		insertIfLocalized( t, NZ(rTech.UnitBaseHealModifier) and "TXT_KEY_UNIT_BASE_HEAL_MOD", rTech.UnitBaseHealModifier )
		insertIfLocalized( t, NZ(rTech.InternationalTradeRoutesChange) and "TXT_KEY_ADDITIONAL_INTERNATIONAL_TRADE_ROUTE" )
		insertIfLocalized( t, NZ(rTech.InfluenceSpreadModifier) and "TXT_KEY_DOUBLE_TOURISM" )
		insertIfLocalized( t, rTech.AllowsWorldCongress and "TXT_KEY_ALLOWS_WORLD_CONGRESS" )
		insertIfLocalized( t, NZ(rTech.ExtraVotesPerDiplomat) and "TXT_KEY_EXTRA_VOTES_FROM_DIPLOMATS", rTech.ExtraVotesPerDiplomat )
		insertIfLocalized( t, rTech.TriggersArchaeologicalSites and "TXT_KEY_EUI_TRIGGERS_ARCHAEOLOGICAL_SITES" )
		insertIfLocalized( t, NZ(rTech.WorkerSpeedModifier), "TXT_KEY_EUI_BUILDING_WORKERSPEEDMODIFIER" )
		insertIfLocalized( t, NZ(rTech.FirstFreeTechs), "TXT_KEY_EUI_FIRST_FREE_TECHS" )
		insertIfLocalized( t, rTech.EndsGame and "TXT_KEY_EUI_ENDS_GAME" )
		insertIfLocalized( t, rTech.ExtraWaterSeeFrom and "TXT_KEY_EUI_EXTRA_WATER_SEE_FROM" )
		insertIfLocalized( t, rTech.WaterWork and "TXT_KEY_EUI_WATER_WORK" )

		insertIfLocalized( t, rTech.ScenarioTechButton == 1 and "TXT_KEY_SCENARIO_TECH_BUTTON_1" )
		insertIfLocalized( t, rTech.ScenarioTechButton == 2 and "TXT_KEY_SCENARIO_TECH_BUTTON_2" )
		insertIfLocalized( t, rTech.ScenarioTechButton == 3 and "TXT_KEY_SCENARIO_TECH_BUTTON_3" )
		insertIfLocalized( t, rTech.ScenarioTechButton == 4 and "TXT_KEY_SCENARIO_TECH_BUTTON_4" )

		for row in GameInfo.Technology_TradeRouteDomainExtraRange( tTechType ) do
			if row.TechType == sTechType and NZ(row.Range) then
				if row.DomainType == "DOMAIN_LAND" then
					insert( t, L"TXT_KEY_EXTENDS_LAND_TRADE_ROUTE_RANGE" )
				elseif row.DomainType == "DOMAIN_SEA" then
					insert( t, L"TXT_KEY_EXTENDS_SEA_TRADE_ROUTE_RANGE" )
				end
			end
		end
		for row in GameInfo.Technology_FreePromotions( tTechType ) do
			local promotion = GameInfo.UnitPromotions[ row.PromotionType ]
			if promotion then
				insert( t, L( "TXT_KEY_FREE_PROMOTION_FROM_TECH", promotion._Name, promotion.Help ) )
			end
		end
		AddTextBox( "TXT_KEY_PEDIA_ABILITIES_LABEL", concat( t, "[NEWLINE]" ), 2 )
	end,
},
[ eCategoryUnits ] = {
	Texture = "CivilopediaTopButtonsUnit.dds",
	Info = GameInfo.Units,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_UNITS_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_UNITS", "TXT_KEY_PEDIA_UNITS_HELP_TEXT", "UNIT_ATLAS_1", 26, "SELECT PortraitIndex, IconAtlas from Units WHERE Special IS NULL OR PrereqTech IS NOT NULL ORDER By Random() LIMIT 1" )
	end,
	DisplayArticle = function( rUnit, iUnit )

		local tUnitType = { UnitType = rUnit.Type }
		local bDefensive = false

		-- free promotions
		local t = {}
		for row in GameInfo.Unit_FreePromotions( tUnitType ) do
			t[ row.PromotionType ] = true
			row = GameInfo.UnitPromotions[ row.PromotionType ]
			if row and row.OnlyDefensive then
				bDefensive = true
			end
		end

		-- Civilization unique
		AddCivilizations( GameInfo.Civilization_UnitClassOverrides( tUnitType ) )

		-- Prereq tech
		AddTech( "TXT_KEY_PEDIA_PREREQ_TECH_LABEL", rUnit.PrereqTech )

		-- required resources
		AddResources( "TXT_KEY_PEDIA_REQ_RESRC_LABEL", GameInfo.Unit_ResourceQuantityRequirements( tUnitType ) )

		-- Cost
		local iCost = Game and Players[Game.GetActivePlayer()]:GetUnitProductionNeeded( iUnit ) or tonumber(rUnit.Cost) or 0
		local iFaithCost = _bReligionActive and Game and Game.GetFaithCost(iUnit) or tonumber(rUnit.FaithCost) or 0
		local s, i
		if iCost > 1 and iFaithCost > 0 then
			s = L( "TXT_KEY_PEDIA_A_OR_B", tostring(iCost) .. " [ICON_PRODUCTION]", iFaithCost.." [ICON_PEACE]" )
		elseif iFaithCost > 0 then
			s = iFaithCost.." [ICON_PEACE]"
		elseif iCost > 0 then
			s = iCost.." [ICON_PRODUCTION]"
		elseif rUnit.Type ~= "UNIT_SETTLER" then
			s = L"TXT_KEY_FREE"
		end
		AddTextBox( "TXT_KEY_PEDIA_COST_LABEL", s )

		-- Combat Type
		local r = GameInfo.UnitCombatInfos[rUnit.CombatClass]
		if r then
			AddTextBox( "TXT_KEY_PEDIA_COMBATTYPE_LABEL", LL(r.Description) )
		end

		if rUnit.Domain == "DOMAIN_AIR" then
			-- Combat
			i = tonumber(rUnit.RangedCombat) or 0
			if i > 0 then
				AddTextBox( "TXT_KEY_PEDIA_COMBAT_LABEL", i.."[ICON_STRENGTH]" )
			end
			-- Range
			i = tonumber(rUnit.Range) or 0
			if i > 0 then
				AddTextBox( "TXT_KEY_PEDIA_RANGE_LABEL", "[ICON_RANGE_STRENGTH] " .. i )
			end
			-- Rebase
			i = i * (GameDefines.AIR_UNIT_REBASE_RANGE_MULTIPLIER or 0) / 100
			if i > 0 then
				AddTextBox( "{TXT_KEY_AIRPOWER_REBASE_HEADING3_TITLE}:", "[ICON_RANGE_STRENGTH] " .. i )
			end
		else
			-- Movement
			i = tonumber(rUnit.Moves) or 0
			if i > 0 then
				AddTextBox( "TXT_KEY_PEDIA_MOVEMENT_LABEL", i.." [ICON_MOVES]" )
			end
			-- Ranged Combat
			i = tonumber(rUnit.RangedCombat) or 0
			if i > 0 then
				AddTextBox( "TXT_KEY_PEDIA_RANGEDCOMBAT_LABEL", i.." [ICON_RANGE_STRENGTH] "..(tonumber(rUnit.Range) or 0) )
			end
			-- Combat
			i = tonumber(rUnit.Combat) or 0
			if i > 0 then
				AddTextBox( bDefensive and "TXT_KEY_PEDIA_DEFENSE_LABEL" or "TXT_KEY_PEDIA_COMBAT_LABEL", i.."[ICON_STRENGTH]" )
			end
		end

		-- What units can be upgraded to this unit ?
		AddLinkedButtonsBox( AddSmallButtonInPedia, eCategoryUnits, GameInfo.Units, "UnitType", "TXT_KEY_GOLD_UPGRADE_UNITS_HEADING3_TITLE", GameInfo.Unit_ClassUpgrades{ UnitClassType = rUnit.Class } )

		-- similar units
		AddSameClass( GameInfo.Units{ Class = rUnit.Class }, eCategoryUnits, rUnit.ID )

		-- obsolete tech
		AddTech( "TXT_KEY_PEDIA_OBSOLETE_TECH_LABEL", rUnit.ObsoleteTech )

		-- what units can this unit upgrade to ?
		if Game then
			AddSingleButton( eCategoryUnits, "TXT_KEY_COMMAND_UPGRADE", GameInfo.Units[ Game.GetUnitUpgradesTo( iUnit ) ] )
		else
			AddLinkedButtonsBox( AddSmallButtonInPedia, eCategoryUnits, GameInfo.Units, "UnitClassType", "TXT_KEY_COMMAND_UPGRADE", GameInfo.Unit_ClassUpgrades( tUnitType ) )
		end

		-- worker commands
		AddWorkerActions( GameInfo.Unit_Builds( tUnitType ), "BuildType" )

		-- what promotions can this unit have ?
		InitButtonStack( 2 )
		local promotions = {}
		if rUnit.CombatClass then
			for row in GameInfo.UnitPromotions_UnitCombats{ UnitCombatType = rUnit.CombatClass } do
				promotions[ row.PromotionType ] = true
			end
		end
		for row in GameInfo.UnitPromotions() do
			if t[row.Type] then
				insertIf( t, LL(row.Help or row.Description) )
			elseif promotions[row.Type] and (row.CannotBeChosen or 0)==0 then
				AddSmallButton( row, eCategoryPromotions )
			end
		end
		AddTextBox( "TXT_KEY_PEDIA_ABILITIES_LABEL", concat( t, "[NEWLINE]" ), 2 )
		_ButtonStackInstance.Frame:ChangeParent( Controls.WideStack )
		CommitButtonStack "{TXT_KEY_COMBAT_EXPERIENCEPOINTS_HEADING2_TITLE}:"
	end,
},
[ eCategoryPromotions ] = {
	Texture = "CivilopediaTopButtonsPromotions.dds",
	Info = GameInfo.UnitPromotions,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_PROMOTIONS_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_PROMOTIONS", "TXT_KEY_PEDIA_PROMOTIONS_HELP_TEXT", "PROMOTION_ATLAS", 16, "SELECT PortraitIndex, IconAtlas from UnitPromotions ORDER By Random() LIMIT 1" )
	end,
	DisplayArticle = function( rPromotion )
		local sPromotionType = rPromotion.Type
		local tPromotionType = { PromotionType = sPromotionType }
		-- required promotions
		InitButtonStack()
		for i = 0, 9 do
			local key = rPromotion[ i==0 and "PromotionPrereq" or "PromotionPrereqOr"..i ]
			local row = key and GameInfo.UnitPromotions[ key ]
			if row then
				AddSmallButton( row, eCategoryPromotions )
			end
		end
		for row in GameInfo.UnitPromotions_PostCombatRandomPromotion{ NewPromotion = sPromotionType } do
			AddSmallButton( GameInfo.UnitPromotions[ row.PromotionType ], eCategoryPromotions )
		end
		CommitButtonStack "TXT_KEY_PEDIA_REQ_PROMOTIONS_LABEL"

		-- leads to other promotions
		InitButtonStack( 2 )
		for row in GameInfo.UnitPromotions() do
			for i = 0, 9 do
				if row[ i==0 and "PromotionPrereq" or "PromotionPrereqOr"..i ]==sPromotionType then
					AddSmallButton( row, eCategoryPromotions )
				end
			end
		end
		for row in GameInfo.UnitPromotions_PostCombatRandomPromotion( tPromotionType ) do
			AddSmallButton( GameInfo.UnitPromotions[ row.NewPromotion ], eCategoryPromotions )
		end
		CommitButtonStack "{TXT_KEY_PEDIA_CATEGORY_5_LABEL} {TXT_KEY_PEDIA_PROJ_UNLOCK_LABEL}"

		-- What units have this ability ?
		InitButtonStack( 2 )
		for row in GameInfo.Unit_FreePromotions( tPromotionType ) do
			AddSmallButtonInPedia( GameInfo.Units[ row.UnitType ], eCategoryUnits )
		end
		CommitButtonStack "TXT_KEY_PEDIA_ABILITIES_LABEL"

		-- What units can be promoted ?
		InitButtonStack( 2 )
		for row in GameInfo.UnitPromotions_CivilianUnitType( tPromotionType ) do
			AddSmallButton( GameInfo.Units[ row.UnitType ], eCategoryUnits )
		end
		for row in GameInfo.UnitPromotions_UnitCombats( tPromotionType ) do
			for row in GameInfo.Units{ CombatClass = row.UnitCombatType } do
				AddSmallButtonInPedia( row, eCategoryUnits )
			end
		end
		CommitButtonStack "{TXT_KEY_COMBAT_EXPERIENCEPOINTS_HEADING2_TITLE}:"

	end,
},
[ eCategoryBuildings ] = {
	Texture = "CivilopediaTopButtonsBuildings.dds",
	Info = GameInfo.Buildings,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_BUILDINGS_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_BUILDINGS", "TXT_KEY_PEDIA_BUILDINGS_HELP_TEXT", "BW_ATLAS_1", 24, "SELECT PortraitIndex, IconAtlas from Buildings WHERE WonderSplashImage IS NULL ORDER By Random() LIMIT 1" )
	end,
	DisplayArticle = DisplayBuildingOrWonderArticle,
},
[ eCategoryWonders ] = {
	Texture = "CivilopediaTopButtonsWonders.dds",
	Info = GameInfo.Buildings,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_WONDERS_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_WONDERS", "TXT_KEY_PEDIA_WONDERS_HELP_TEXT", "BW_ATLAS_2", 2, "SELECT PortraitIndex, IconAtlas from Buildings WHERE WonderSplashImage IS NOT NULL ORDER By Random() LIMIT 1" )
	end,
	DisplayArticle = DisplayBuildingOrWonderArticle,
},
[ eCategoryPolicies ] = {
	Texture = "CivilopediaTopButtonsSocialPolicy.dds",
	Info = GameInfo.Policies,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_POLICIES_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_POLICIES", "TXT_KEY_PEDIA_SOCIAL_POL_HELP_TEXT", "POLICY_ATLAS", 25, "SELECT PortraitIndex, IconAtlas from Policies WHERE IconAtlas IS NOT NULL ORDER By Random() LIMIT 1" )
	end,
	DisplayArticle = function( rPolicy )
		-- policy branch
		if rPolicy.PolicyBranchType then
			local row = GameInfo.PolicyBranchTypes[rPolicy.PolicyBranchType]
			if row then
				AddTextBox( "TXT_KEY_PEDIA_POLICYBRANCH_LABEL", LL(row.Description) )
				-- prereq era
				row = GameInfo.Eras[row.EraPrereq]
				if row then
					AddTextBox( "TXT_KEY_PEDIA_PREREQ_ERA_LABEL", LL(row.Description) )
				end
			end
		end

		-- prereq policies
		AddLinkedButtonsBox( AddSmallButton, eCategoryPolicies, GameInfo.Policies, "PrereqPolicy", "TXT_KEY_PEDIA_PREREQ_POLICY_LABEL", GameInfo.Policy_PrereqPolicies{ PolicyType = rPolicy.Type } )

		if (tonumber(rPolicy.Level)or 0)~=0 then
			AddTextBox( "{TXT_KEY_PEDIA_TENET_LEVEL}:", LL("TXT_KEY_POLICYSCREEN_L"..rPolicy.Level.."_TENET") )
		end

	end,
},
[ eCategoryGreatPeople ] = {
	Texture = "CivilopediaTopButtonsGreatPersons.dds",
	Info = GameInfo.Units,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_PEOPLE_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_PEOPLE", "TXT_KEY_PEDIA_SPEC_HELP_TEXT", "UNIT_ATLAS_2", 47, "SELECT PortraitIndex, IconAtlas from Units WHERE Special IS NOT NULL AND PrereqTech IS NULL ORDER By Random() LIMIT 1" )
	end,
},
[ eCategoryCivilizations ] = {
	Texture = "CivilopediaTopButtonsCivsCityStates.dds",
	Info = GameInfo.Civilizations,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_CIVILIZATIONS_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_CIVS", "TXT_KEY_PEDIA_CIVS_HELP_TEXT", "LEADER_ATLAS", 7, "SELECT l.PortraitIndex, l.IconAtlas from Leaders l INNER JOIN Civilization_Leaders cl ON cl.LeaderheadType = l.Type INNER JOIN Civilizations c ON cl.CivilizationType = c.Type WHERE l.Type <> 'LEADER_BARBARIAN' ORDER By Random() LIMIT 1" )
	end,
	DisplayArticle = function( rCiv )
		local tCivilizationType = { CivilizationType = rCiv.Type }
		if not rCiv.Playable then
			AddTextBox( "", "Not playable" ) --todo XML
		end

		-- Leaders
		AddLinkedButtonsBox( AddSmallButton, eCategoryLeaders, GameInfo.Leaders, "LeaderheadType", "TXT_KEY_PEDIA_LEADERS_LABEL", GameInfo.Civilization_Leaders( tCivilizationType ) )

		-- Unique buildings
		AddLinkedButtonsBox( AddSmallButtonInPedia, eCategoryUnits, GameInfo.Units, "UnitType", "TXT_KEY_PEDIA_UNIQUEUNIT_LABEL", GameInfo.Civilization_UnitClassOverrides( tCivilizationType ), 2 )

		-- Unique units
		AddLinkedButtonsBox( AddBuildingButtonInPedia, nil, GameInfo.Buildings, "BuildingType", "TXT_KEY_PEDIA_UNIQUEBLDG_LABEL", GameInfo.Civilization_BuildingClassOverrides( tCivilizationType ), 2 )

		-- Unique improvements
		AddButtonsBox( AddSmallButton, eCategoryImprovements, "TXT_KEY_PEDIA_UNIQUEIMPRV_LABEL", GameInfo.Improvements( tCivilizationType ), 2 )

		-- Free technologies
		AddLinkedButtonsBox( AddSmallButton, eCategoryTechnologies, GameInfo.Technologies, "TechType", "Free technologies", GameInfo.Civilization_FreeTechs( tCivilizationType ), 2 )
		AddLinkedButtonsBox( AddSmallButton, eCategoryTechnologies, GameInfo.Technologies, "TechType", "Disabled technologies", GameInfo.Civilization_DisableTechs( tCivilizationType ), 2 )

		-- Free buildings
		AddLinkedButtonsBox( AddBuildingClassButton, rCiv.Type, GameInfo.BuildingClasses, "BuildingClassType", "Free buildings", GameInfo.Civilization_FreeBuildingClasses( tCivilizationType ), 2 )

		-- Special abilities & factoid
		local sTag = rCiv.CivilopediaTag
		if sTag then
			local headerString = sTag .. "_HEADING_"
			local bodyString = sTag .. "_TEXT_"
			for i=1, 9 do
				AddTextBox( headerString..i, LL(bodyString..i), 3, 1 )
			end
			AddTextBox( sTag.."_FACTOID_HEADING", LL(sTag .. "_FACTOID_TEXT"), 3, 1 )
		end
	end,
},
[ eCategoryCityStates ] = {
	Texture = "CivilopediaTopButtonsCities.dds",
	Info = GameInfo.MinorCivilizations,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_CITY_STATES_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_CITYSTATES", "TXT_KEY_PEDIA_CSTATES_HELP_TEXT", "UNIT_ATLAS_2", 44 )
	end,
	xDisplayArticle = function( rCiv )
		SetPortrait( "UNIT_ATLAS_2", 44 )
		local row = rCiv.MinorCivTrait and GameInfo.MinorCivTraits[ rCiv.MinorCivTrait ]
		if row then
			AddTextBox( "", LL(row.Description) )
		end
	end,
},
[ eCategoryTerrains ] = {
	Texture = "CivilopediaTopButtonsTerrian.dds",
	Info = GameInfo.Terrains,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_TERRAIN_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_TERRAIN", nil, "TERRAIN_ATLAS", 9, "SELECT PortraitIndex, IconAtlas from Terrains ORDER By Random() LIMIT 1" )
		AddTextBox( "TXT_KEY_PEDIA_TERRAIN_LABEL", L"TXT_KEY_PEDIA_TERRAIN_HELP_TEXT", 3 )
		AddTextBox( "TXT_KEY_PEDIA_TERRAIN_FEATURES_LABEL", L"TXT_KEY_PEDIA_TERRAIN_FEATURES_HELP_TEXT", 3 )
	end,
	DisplayArticle = function( rTerrain )

		local tTerrainType = { TerrainType = rTerrain.Type }

		-- City Yield
		local sYield = ""
		for row in GameInfo.Terrain_Yields( tTerrainType ) do
			sYield = sYield..signed(row.Yield).." "..GameInfo.Yields[row.YieldType].IconString.." "
		end
		-- special case hackery for hills
		if rTerrain.Type == "TERRAIN_HILL" then
			-- Terrain_HillsYieldChanges
			sYield = "+2 [ICON_PRODUCTION]" --todo XML
		end

		AddTextBox( "TXT_KEY_PEDIA_YIELD_LABEL", sYield > "" and sYield or L"TXT_KEY_PEDIA_NO_YIELD" )

		-- Movement
		local iMoveCost = tonumber(rTerrain.Movement) or 0
		-- special case hackery for hills
		if rTerrain.Type == "TERRAIN_HILL" then
			iMoveCost = iMoveCost + GameDefines.HILLS_EXTRA_MOVEMENT
		end
		AddTextBox( "TXT_KEY_PEDIA_MOVECOST_LABEL", rTerrain.Type == "TERRAIN_MOUNTAIN" and L"TXT_KEY_PEDIA_IMPASSABLE" or iMoveCost.." [ICON_MOVES]" )


		-- Combat Modifier
		local iCombatModifier = 0
		if rTerrain.Type == "TERRAIN_HILL" or rTerrain.Type == "TERRAIN_MOUNTAIN" then
			iCombatModifier = GameDefines.HILLS_EXTRA_DEFENSE
		elseif not rTerrain.Water then
			iCombatModifier = GameDefines.FLAT_LAND_EXTRA_DEFENSE
		end
		if iCombatModifier ~= 0 then
			AddTextBox( "TXT_KEY_PEDIA_COMBATMOD_LABEL", signed(iCombatModifier).."%" )
		end
		-- Features that can exist on this terrain
		AddLinkedButtonsBox( AddSmallButton, eCategoryFeatures, GameInfo.Features, "FeatureType", "TXT_KEY_PEDIA_FEATURES_LABEL", GameInfo.Feature_TerrainBooleans( tTerrainType ), 2 )

		-- Resources that can exist on this terrain
		InitButtonStack( 2 )
		for row in GameInfo.Resource_TerrainBooleans( tTerrainType ) do
			AddSmallButton( GameInfo.Resources[ row.ResourceType ], eCategoryResources )
		end
		-- special case hackery for hills
		if rTerrain.Type == "TERRAIN_HILL" then
			for row in GameInfo.Resources() do
				if row.Hills then
					AddSmallButton( row, eCategoryResources )
				end
			end
		end
		CommitButtonStack "TXT_KEY_PEDIA_RESOURCESFOUND_LABEL"
	end,
},
[ eCategoryResources ] = {
	HomePage = L"TXT_KEY_PEDIA_IMPROVEMENTS_PAGE_LABEL",
	Texture = "CivilopediaTopButtonsResourcesImprovements.dds",
	Info = GameInfo.Resources,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_RESOURCES_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_RESOURCES", "TXT_KEY_PEDIA_RESOURCES_HELP_TEXT", "RESOURCE_ATLAS", 6, "SELECT PortraitIndex, IconAtlas from Resources ORDER By Random() LIMIT 1" )
	end,
	DisplayArticle = function( rResource )

		local tRessourceType = { ResourceType = rResource.Type }

		-- tech visibility
		if rResource.TechReveal then
			AddTech( "TXT_KEY_PEDIA_REVEAL_TECH_LABEL", rResource.TechReveal )
		end

		-- City Yield
		local sYield = ""
		for row in GameInfo.Resource_YieldChanges( tRessourceType ) do
			sYield = sYield..signed(row.Yield)..GameInfo.Yields[row.YieldType].IconString.." "
		end

		AddTextBox( "TXT_KEY_PEDIA_YIELD_LABEL", sYield > "" and sYield or L"TXT_KEY_PEDIA_NO_YIELD" )

		-- found on
		InitButtonStack()
		for row in GameInfo.Resource_FeatureBooleans( tRessourceType ) do
			AddSmallButton( GameInfo.Features[ row.FeatureType ], eCategoryFeatures )
		end

		local isAlreadyShowingHills = false
		for row in GameInfo.Resource_TerrainBooleans( tRessourceType ) do
			row = GameInfo.Terrains[row.TerrainType]
			if row then
				if row.TerrainType == "TERRAIN_HILL" then
					isAlreadyShowingHills = true
				end
				AddSmallButton( row, eCategoryTerrains )
			end
		end
		-- hackery for hills
		if rResource and not isAlreadyShowingHills and rResource.Hills then
			AddSmallButton( GameInfo.Terrains.TERRAIN_HILL, eCategoryTerrains )
		end
		CommitButtonStack "TXT_KEY_PEDIA_TERRAINS_LABEL"

		-- improvement
		AddLinkedButtonsBox( AddSmallButton, eCategoryImprovements, GameInfo.Improvements, "ImprovementType", "TXT_KEY_PEDIA_IMPROVEMENTS_LABEL", GameInfo.Improvement_ResourceTypes( tRessourceType ) )
	end,
},
[ eCategoryImprovements ] = {
	HomePage = L"TXT_KEY_PEDIA_IMPROVEMENTS_PAGE_LABEL",
	Texture = "CivilopediaTopButtonsImprovements.dds",
	Info = GameInfo.Improvements,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_IMPROVEMENTS_PAGE_LABEL", "TXT_KEY_PEDIA_QUOTE_BLOCK_IMPROVEMENTS", "TXT_KEY_PEDIA_IMPROVEMENT_HELP_TEXT", "BW_ATLAS_1", 1, "SELECT PortraitIndex, IconAtlas from Improvements ORDER By Random() LIMIT 1" )
	end,
	DisplayArticle = function( rImprovement )

		local tImprovementType = { ImprovementType = rImprovement.Type }

		if rImprovement.CivilizationType then
--			AddCivilizations( GameInfo.Improvements{ Type = rImprovement.Type } )
			AddSingleButton( eCategoryCivilizations, "TXT_KEY_PEDIA_CIVILIZATIONS_LABEL", GameInfo.Civilizations[ rImprovement.CivilizationType ] )
		end

		-- tech visibility
		AddPrereqTechs( GameInfo.Builds( tImprovementType ) )

		-- City Yield
		local sYield = ""
		for row in GameInfo.Improvement_Yields( tImprovementType ) do
			sYield = sYield..signed(row.Yield)..GameInfo.Yields[row.YieldType].IconString.." "
		end

		-- culture hack for vanilla
		if _bCiv5Vanilla and NZ(rImprovement.Culture) then
			sYield = sYield..signed(rImprovement.Culture).."[ICON_CULTURE]"
		end
		AddTextBox( "TXT_KEY_PEDIA_YIELD_LABEL", sYield > "" and sYield or L"TXT_KEY_PEDIA_NO_YIELD" )

		-- add in mountain adjacency yield
		sYield = ""
		for row in GameInfo.Improvement_AdjacentMountainYieldChanges( tImprovementType ) do
			sYield = sYield..signed(row.Yield)..GameInfo.Yields[row.YieldType].IconString.." "
		end
		if sYield > "" then
			AddTextBox( "TXT_KEY_PEDIA_MOUNTAINADJYIELD_LABEL", sYield )
		end

		-- found on
		InitButtonStack()
		for row in GameInfo.Improvement_ValidFeatures( tImprovementType ) do
			AddSmallButton( GameInfo.Features[row.FeatureType], eCategoryFeatures )
		end
		for row in GameInfo.Improvement_ValidTerrains( tImprovementType ) do
			AddSmallButton( GameInfo.Terrains[row.TerrainType], eCategoryTerrains )
		end
		-- hackery for hills
		--if rImprovement and rImprovement.HillsMakesValid then
				--AddSmallButton( GameInfo.Terrains.TERRAIN_HILL, eCategoryTerrains )
			--end
		--end
		CommitButtonStack "TXT_KEY_PEDIA_FOUNDON_LABEL"

		AddResources( "TXT_KEY_PEDIA_IMPROVES_RESRC_LABEL", GameInfo.Improvement_ResourceTypes( tImprovementType ) )
	end,
},
[ eCategoryReligions ] = _bCiv5notVanilla and {
	Texture = "CivilopediaTopButtonsReligion.dds",
	Info = GameInfo.Religions,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_BELIEFS_PAGE_LABEL", "TXT_KEY_PEDIA_BELIEFS_HOMEPAGE_BLURB", nil, "Religion256.dds" )
		AddTextBox( "TXT_KEY_PEDIA_BELIEFS_HOMEPAGE_LABEL1", LL"TXT_KEY_PEDIA_BELIEFS_HOMEPAGE_TEXT1", 3 )
	end,
},
[ eCategoryLeagueProjects ] = _bCiv5BNW and {
	Texture = "CivilopediaTopButtonsWorldCongress.dds",
	Info = GameInfo.LeagueProjects,
	DisplayHomePage = function()
		DoDisplayHomePage( "TXT_KEY_PEDIA_WORLD_CONGRESS_PAGE_LABEL", "TXT_KEY_PEDIA_WORLD_CONGRESS_HOMEPAGE_BLURB", nil, "WorldCongressPortrait256_EXP2.dds" )
		AddTextBox( "TXT_KEY_PEDIA_WORLD_CONGRESS_HOMEPAGE_LABEL1", LL"TXT_KEY_PEDIA_WORLD_CONGRESS_HOMEPAGE_TEXT1", 3 )
	end,
	DisplayArticle = function( thisLeagueProject, iRow )
		-- Cost
		local league = Game and Game.GetNumActiveLeagues() > 0 and Game.GetActiveLeague()
		local iCost = league and league:GetProjectCostPerPlayer( iRow ) / 100 or tonumber(thisLeagueProject.CostPerPlayer) or 0
		if iCost > 0 then
			AddTextBox( "TXT_KEY_PEDIA_COST_LABEL", L("TXT_KEY_LEAGUE_PROJECT_COST_PER_PLAYER", iCost) )
		end

		-- rewards
		local rewards = {}
		for i = 3, 1, -1 do
			local reward = thisLeagueProject["RewardTier" .. i]
			reward = reward and GameInfo.LeagueProjectRewards[ reward ]
			if reward then
				insert( rewards, L( "TXT_KEY_PEDIA_LEAGUE_PROJECT_REWARD", _tTrophyIcons[i], reward.Description or "", reward.Help or "" ) )
			end
		end
		AddTextBox( "TXT_KEY_PEDIA_SUMMARY_LABEL", concat( rewards, "[NEWLINE][NEWLINE]"), 2 )
	end,
},
[ eCategoryProjects ] = {
	Info = GameInfo.Projects,
	DisplayArticle = function( rProject )
		-- Cost
		local iCost = Game and Players[Game.GetActivePlayer()]:GetProjectProductionNeeded( rProject.ID ) or tonumber(rProject.Cost) or 0
		AddTextBox( "TXT_KEY_PEDIA_PRODUCTION_LABEL", iCost > 0 and iCost.." [ICON_PRODUCTION]" or L"TXT_KEY_FREE" )
		-- prereq techs
		AddTech( "TXT_KEY_PEDIA_PREREQ_TECH_LABEL", rProject.PrereqTech )
		-- required buildings
		AddButtonsBox( AddBuildingClassButton, nil, "TXT_KEY_PEDIA_REQ_BLDG_LABEL", GameInfo.Building_ClassesNeededInCity{ BuildingType = rProject.Type } )
	end,
},
[ eCategoryFeatures ] = {
	Info = GameInfo.Features,
	DisplayArticle = DisplayFeatureArticle,
},
[ eCategoryFakeFeatures ] = {
	Info = GameInfo.FakeFeatures,
	DisplayArticle = DisplayFeatureArticle,
},
[ eCategoryRoutes ] = {
	Info = GameInfo.Routes,
	DisplayArticle = function( row )
		AddPrereqTechs( GameInfo.Builds{ RouteType = row.Type } )
	end,
},
[ eCategoryLeaders ] = {
	Info = GameInfo.Leaders,
	DisplayArticle = function( rLeader )
		-- add the civ icons
		AddCivilizations( GameInfo.Civilization_Leaders{ LeaderheadType = rLeader.Type } )

		-- list of traits "TXT_KEY_PEDIA_TRAITS_LABEL"
		for row in GameInfo.Leader_Traits{ LeaderType = rLeader.Type } do
			row = GameInfo.Traits[ row.TraitType ]
			if row then
				AddTextBox( row.ShortDescription, LL(row.Description), 2 )
			end
		end

		local sTag = rLeader.CivilopediaTag
		if sTag then
			Controls.ArticleID:LocalizeAndSetText( sTag.."_NAME" )
			-- add titles etc.
			local titlesString = sTag .. "_TITLES_"
			local titles = {}
			for i=1, 9 do
				insertIf( titles, LL(titlesString .. i) )
			end
			if #titles > 0 then
				AddTextBox( "TXT_KEY_PEDIA_TITLES_LABEL", concat( titles, "[NEWLINE]" ), 2 )
			end
			AddTextBox( "TXT_KEY_PEDIA_LIVED_LABEL", LL(sTag.."_LIVED"), 2 )
		end

		-- add the free form text
		if sTag then
			local headerString = sTag .. "_HEADING_"
			local bodyString = sTag .. "_TEXT_"
			for i=1, 9 do
				AddTextBox( headerString .. i, LL(bodyString .. i), 3, 1 )
			end
			bodyString = sTag .. "_FACT_"
			for i=1, 9 do
				AddTextBox( "TXT_KEY_PEDIA_FACTOID", LL(bodyString .. i), 3, 1 )
			end
		end
	end,
},
[ eCategorySpecialists ] = {
	Info = GameInfo.Specialists,
},
[ eCategoryBeliefs ] = _bCiv5notVanilla and {
	Info = GameInfo.Beliefs,
	DisplayArticle = function( row )
		AddTextBox( "", LL(row.Description), 3 )
	end,
},
[ eCategoryResolutions ] = _bCiv5BNW and {
	Info = GameInfo.Resolutions,
	DisplayArticle = function()
		return SetPortrait( "WorldCongressPortrait256_EXP2.dds" )
	end,
},
[ eCategoryProcesses ] = {
	Info = GameInfo.Processes,
},
}

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

local function CreateCategory( iCategory, s )
	_tSections = { HomePage = s }
	_tArticlesBySection[ iCategory ] = _tSections
end

local function CreateSection( s, bClosed )
	_tSection = { HeadingName = s, HeadingClosed = bClosed }
end

local function InsertSection( SortFunction )
	if #_tSection > 0 then
		if SortFunction then
			sort( _tSection, SortFunction )
		end
		insert( _tSections, _tSection )
	end
end

-- sort method for sorting alphabetically.
local function Alphabetically( a, b )
	return Compare(a and a.EntryName or"", b and b.EntryName or"") == -1
end

local function CreateArticle( iCategory, iEntry, s )
	local tArticle={
		EntryName = s,
		EntryID = iEntry,
		CategoryID = iCategory,
	}
	_tCategories[ iCategory ][ iEntry ] = tArticle
	_tArticlesByNameLowerCase[ ToLower(s) ] = tArticle
	return tArticle
end


local function InsertArticle( iCategory, row )
	local tArticle = CreateArticle( iCategory, row.ID, row._Name )
	_tArticlesByNameKey[ row.ShortDescription or row.Description or "" ] = tArticle
	insert( _tSection, tArticle )
	return tArticle
end

-------------------------------------------------------------------------------
CreateCategory( eCategoryHomePage ) -- no home page
CreateSection() -- no header
CreateArticle( eCategoryHomePage, -1, L"TXT_KEY_PEDIA_HOME_PAGE_LABEL" )

for iCategory =1, 99 do
	local button = Controls[ "CategoryButton"..iCategory ]
	if button then
		if _tCategories[ iCategory ] then
			button:RegisterCallback( eLClick, SelectArticleHistorized )
			button:SetVoids( iCategory, -1 )
			insert( _tSection, CreateArticle( iCategory, -1, L("TXT_KEY_PEDIA_CATEGORY_" .. iCategory .. "_LABEL") ) )
		else
			button:SetHide( true )
		end
	else
		break
	end
end
InsertSection() -- no sort

-------------------------------------------------------------------------------
CreateCategory( eCategoryGameConcepts, L"TXT_KEY_PEDIA_GAME_CONCEPT_PAGE_LABEL" )

for i, k in ipairs{ "HEADER_CITIES", "HEADER_COMBAT", "HEADER_TERRAIN", "HEADER_RESOURCES", "HEADER_IMPROVEMENTS", "HEADER_CITYGROWTH", "HEADER_TECHNOLOGY", "HEADER_CULTURE", "HEADER_DIPLOMACY", "HEADER_HAPPINESS", "HEADER_FOW", "HEADER_POLICIES", "HEADER_GOLD", "HEADER_ADVISORS", "HEADER_PEOPLE", "HEADER_CITYSTATE", "HEADER_MOVEMENT", "HEADER_AIRCOMBAT", "HEADER_RUBARB", "HEADER_UNITS", "HEADER_VICTORY", "HEADER_ESPIONAGE", "HEADER_RELIGION", "HEADER_TRADE", "HEADER_WORLDCONGRESS" } do
	CreateSection( L("TXT_KEY_GAME_CONCEPT_SECTION_"..i), true )
	for thisConcept in GameInfo.Concepts{ CivilopediaHeaderType = k } do
		local tArticle = InsertArticle( eCategoryGameConcepts, thisConcept )
		tArticle.InsertBefore = thisConcept.InsertBefore
		tArticle.InsertAfter = thisConcept.InsertAfter
		tArticle.Type = thisConcept.Type
	end
	InsertSection() -- no sort
end
--[[

-- In order to maintain the original order as best as possible,
-- we assign "InsertBefore" values to all items that lack any insert.
for _, conceptList in ipairs(_tSections) do
	for i = #conceptList, 1, -1 do
		local concept = conceptList[i]
		if(concept.InsertBefore == nil and concept.InsertAfter == nil) then
			for ii = i - 1, 1, -1 do
				local previousConcept = conceptList[ii]
				if(previousConcept.InsertBefore == nil and previousConcept.InsertAfter == nil) then
					concept.InsertAfter = previousConcept.Type
					break
				end
			end
		end
	end
end

-- sort the articles by their dependencies.
function DependencySort(tArticles)

	-- index articles by Topic
	local tArticlesByType= {}
	local tDependencies = {}

	for _,tArticle in pairs(tArticles) do
		tArticlesByType[tArticle.Type] = tArticle
		tDependencies[tArticle] = {}
	end
	local t
	for tArticle, tDependency in ipairs(tArticles) do
		t = tArticlesByType[tArticle.InsertBefore]
		if t then
			tDependency[t] = true
		end
		t = tArticlesByType[tArticle.InsertAfter]
			tDependency[t] = true
		end
	end

	local tArticlesBySection = {}

	local articleCount = #tArticles
	while(#tArticlesBySection < articleCount) do

		-- Attempt to find a node with 0 dependencies
		local tArticle
		for i,a in ipairs(tArticles) do
			if(tDependencies[a] ~= nil and table.count(tDependencies[a]) == 0) then
				tArticle = a
				break
			end
		end

		if(tArticle == nil) then
			print("Failed to sort articles topologically!! There are dependency cycles.")
			return nil
		else

			-- Insert Node
			insert( tArticlesBySection, tArticle )

			-- Remove node
			tDependencies[tArticle] = nil
			for a,d in pairs(tDependencies) do
				d[tArticle] = nil
			end
		end
	end

	return tArticlesBySection
end

for i,tSection in ipairs(_tSections) do
	local oldList = tSection
	local newList = DependencySort(tSection)

	if(newList == nil) then
		newList = oldList
	else
		newList.headingOpen = false
	end

	_tSections[i] = newList
end

--]]

-------------------------------------------------------------------------------
CreateCategory( eCategoryTechnologies, L"TXT_KEY_PEDIA_TECH_PAGE_LABEL" )

for row in GameInfo.Eras() do
	CreateSection( row._Name )
	for tech in GameInfo.Technologies{ Era = row.Type } do
		InsertArticle( eCategoryTechnologies, tech )
	end
	InsertSection( Alphabetically )
end

-------------------------------------------------------------------------------
CreateCategory( eCategoryUnits, L"TXT_KEY_PEDIA_UNITS_PAGE_LABEL" )

-- Add units which cost faith to a "Faith" section first.
if _bReligionActive then
	CreateSection( L"TXT_KEY_PEDIA_RELIGIOUS" )
	for unit in GameInfo.Units{ Cost = -1 } do
		if ShowInPedia( unit ) and not unit.RequiresFaithPurchaseEnabled and (tonumber(unit.FaithCost) or 0) > 0 then
			InsertArticle( eCategoryUnits, unit )
		end
	end
	InsertSection( Alphabetically )
end

-- Categorize units by era, placing those without tech requirements in the Ancient Era for lack of a better place
local bFirstEra = true
for row in GameInfo.Eras() do
	CreateSection( row._Name )
	for unit in GameInfo.Units() do
		if ShowInPedia( unit ) and ( unit.RequiresFaithPurchaseEnabled or (tonumber(unit.FaithCost) or 0) == 0 or unit.Cost >= 0 ) then
			local tech = GameInfo.Technologies[ unit.PrereqTech ]
			if tech and tech.Era == row.Type or bFirstEra and not unit.PrereqTech and not unit.Special then
				InsertArticle( eCategoryUnits, unit )
			end
		end
	end
	InsertSection( Alphabetically )
	bFirstEra = false
end

-------------------------------------------------------------------------------
CreateCategory( eCategoryPromotions, L"TXT_KEY_PEDIA_PROMOTIONS_PAGE_LABEL" )

for i, pediaType in ipairs{ "PEDIA_MELEE", "PEDIA_RANGED", "PEDIA_NAVAL", "PEDIA_HEAL", "PEDIA_SCOUTING", "PEDIA_AIR", "PEDIA_SHARED", "PEDIA_ATTRIBUTES" } do
	CreateSection( L("TXT_KEY_PROMOTIONS_SECTION_"..i) )
	for rPromotion in GameInfo.UnitPromotions{ PediaType = pediaType } do
		InsertArticle( eCategoryPromotions, rPromotion )
	end
	InsertSection( Alphabetically )
end

-------------------------------------------------------------------------------
CreateCategory( eCategoryBuildings, L"TXT_KEY_PEDIA_BUILDINGS_PAGE_LABEL" )

--Add Faith Buildings first
if _bReligionActive then
	CreateSection( L"TXT_KEY_PEDIA_RELIGIOUS" )
	for building in GameInfo.Buildings{ Cost = -1 } do
		local class = GameInfo.BuildingClasses[ building.BuildingClass ]
		if class and ShowInPedia(building) and (building.FaithCost or 0) > 0 and class.MaxGlobalInstances < 0 and (class.MaxPlayerInstances ~= 1 or building.SpecialistCount > 0) and class.MaxTeamInstances < 0 then
			InsertArticle( eCategoryBuildings, building )
		end
	end
	InsertSection( Alphabetically )
end

-- Categorize buildings by era, placing those without tech requirements in the Ancient Era for lack of a better place
bFirstEra = true
for row in GameInfo.Eras() do
	CreateSection( row._Name )
	for building in GameInfo.Buildings() do
		local tech = GameInfo.Technologies[ building.PrereqTech ]
		if tech and tech.Era == row.Type or bFirstEra and not tech then
			local class = GameInfo.BuildingClasses[ building.BuildingClass ]
			if class and ShowInPedia(building) and ((building.FaithCost or 0) == 0 or building.Cost >= 0) and class.MaxGlobalInstances < 0 and (class.MaxPlayerInstances ~= 1 or building.SpecialistCount > 0) and class.MaxTeamInstances < 0 then
				InsertArticle( eCategoryBuildings, building )
			end
		end
	end
	InsertSection( Alphabetically )
	bFirstEra = false
end

-------------------------------------------------------------------------------
CreateCategory( eCategoryWonders, L"TXT_KEY_PEDIA_WONDERS_PAGE_LABEL" )

-- Wonders
CreateSection( L"TXT_KEY_WONDER_SECTION_1" )
for building in GameInfo.Buildings() do
	-- exclude wonders etc.
	local class = GameInfo.BuildingClasses[building.BuildingClass]
	if class and ShowInPedia(building) and class.MaxGlobalInstances > 0  then
		InsertArticle( eCategoryWonders, building )
	end
end
InsertSection( Alphabetically )

-- National Wonders
CreateSection( L"TXT_KEY_WONDER_SECTION_2" )
for building in GameInfo.Buildings() do
	local class = GameInfo.BuildingClasses[building.BuildingClass]
	if class and ShowInPedia(building) and class.MaxPlayerInstances == 1 and building.SpecialistCount == 0 then
		InsertArticle( eCategoryWonders, building )
	end
end
InsertSection( Alphabetically )

-- Projects
CreateSection( L"TXT_KEY_WONDER_SECTION_3" )
for row in GameInfo.Projects() do
	if ShowInPedia(row) and not _tProjectsToIgnore[row.Type] then
		InsertArticle( eCategoryProjects, row )
	end
end

-- Processes
for row in GameInfo.Processes() do
	if GameInfo.Process_ProductionYields{ ProcessType = row.Type }() then
		InsertArticle( eCategoryProcesses, row )
	end
end

InsertSection( Alphabetically )

-------------------------------------------------------------------------------
CreateCategory( eCategoryPolicies, L"TXT_KEY_PEDIA_POLICIES_PAGE_LABEL" )

for row in GameInfo.PolicyBranchTypes() do

	CreateSection( row._Name )
	-- for each policy in this branch
	for policy in GameInfo.Policies{ PolicyBranchType = row.Type } do
		InsertArticle( eCategoryPolicies, policy )
	end

	-- put in free policies that belong to this branch on top
	local freePolicy = row.FreePolicy and GameInfo.Policies[row.FreePolicy]
	if freePolicy then
		InsertArticle( eCategoryPolicies, freePolicy )
	end
	InsertSection( Alphabetically )
end

-------------------------------------------------------------------------------
CreateCategory( eCategoryGreatPeople, L"TXT_KEY_PEDIA_PEOPLE_PAGE_LABEL" )

-- first Specialists
CreateSection( L"TXT_KEY_PEOPLE_SECTION_1" )
for person in GameInfo.Specialists() do
	InsertArticle( eCategorySpecialists, person )
end
InsertSection( Alphabetically )

-- next Great People
CreateSection( L"TXT_KEY_PEOPLE_SECTION_2" )
for unit in GameInfo.Units() do
	if ShowInPedia(unit) and not unit.PrereqTech and unit.Special then
		InsertArticle( eCategoryGreatPeople, unit )
	end
end
InsertSection( Alphabetically )

-------------------------------------------------------------------------------
CreateCategory( eCategoryCivilizations, L"TXT_KEY_PEDIA_CIVILIZATIONS_PAGE_LABEL" )

-- first Civilizations
CreateSection( L"TXT_KEY_CIVILIZATIONS_SECTION_1" )
for row in GameInfo.Civilizations() do
	if row.Type ~= "CIVILIZATION_MINOR" and row.Type ~= "CIVILIZATION_BARBARIAN" then
		InsertArticle( eCategoryCivilizations, row )
	end
end
InsertSection( Alphabetically )

-- next Leaders
CreateSection( L"TXT_KEY_CIVILIZATIONS_SECTION_2" )
for row in GameInfo.Civilizations() do
	if row.Type ~= "CIVILIZATION_MINOR" and row.Type ~= "CIVILIZATION_BARBARIAN" then
		row = GameInfo.Civilization_Leaders{ CivilizationType = row.Type }()
		row = row and GameInfo.Leaders[ row.LeaderheadType ]
		if row then
			InsertArticle( eCategoryLeaders, row )
		end
	end
end
InsertSection( Alphabetically )

-------------------------------------------------------------------------------
CreateCategory( eCategoryCityStates, L"TXT_KEY_PEDIA_CITY_STATES_PAGE_LABEL" )

for row in GameInfo.MinorCivTraits() do
	CreateSection( row._Name )
	-- for each city state that has this trait
	for cityState in GameInfo.MinorCivilizations{ MinorCivTrait = row.Type } do
		InsertArticle( eCategoryCityStates, cityState )
	end
	InsertSection( Alphabetically )
end

-------------------------------------------------------------------------------
CreateCategory( eCategoryTerrains, L"TXT_KEY_PEDIA_TERRAIN_PAGE_LABEL" )

CreateSection( L"TXT_KEY_TERRAIN_SECTION_1" )
for row in GameInfo.Terrains() do
	InsertArticle( eCategoryTerrains, row )
end
InsertSection( Alphabetically )

CreateSection( L"TXT_KEY_TERRAIN_SECTION_2" )
for row in GameInfo.Features() do
	InsertArticle( eCategoryFeatures, row )
end
for row in GameInfo.FakeFeatures() do
	InsertArticle( eCategoryFakeFeatures, row )
end
InsertSection( Alphabetically )

-------------------------------------------------------------------------------
CreateCategory( eCategoryResources, L"TXT_KEY_PEDIA_RESOURCES_PAGE_LABEL" )

for i = 0, 2 do
	-- for each type of resource
	CreateSection( L("TXT_KEY_RESOURCES_SECTION_"..i) )
	for row in GameInfo.Resources{ ResourceUsage = i } do
		InsertArticle( eCategoryResources, row )
	end
	InsertSection( Alphabetically )
end

-------------------------------------------------------------------------------
CreateCategory( eCategoryImprovements, L"TXT_KEY_PEDIA_IMPROVEMENTS_PAGE_LABEL" )
CreateSection() -- no header
for row in GameInfo.Improvements() do
	if not row.GraphicalOnly then
		InsertArticle( eCategoryImprovements, row )
	end
end
for row in GameInfo.Routes() do
	InsertArticle( eCategoryRoutes, row )
end
InsertSection( Alphabetically )

-------------------------------------------------------------------------------
if _bCiv5notVanilla then
	CreateCategory( eCategoryReligions, L"TXT_KEY_PEDIA_BELIEFS_PAGE_LABEL" )

	CreateSection( L"TXT_KEY_PEDIA_BELIEFS_CATEGORY_1" )
	for religion in GameInfo.Religions() do
		if religion.Type ~= "RELIGION_PANTHEON" then
			InsertArticle( eCategoryReligions, religion )
		end
	end
	InsertSection( Alphabetically )

	for i, key in ipairs{ "Pantheon", "Founder", "Follower", "Enhancer", _bCiv5BNW and "Reformation" } do
		CreateSection( L("TXT_KEY_PEDIA_BELIEFS_CATEGORY_"..i+1) )
		for belief in GameInfo.Beliefs() do
			if (belief[key] or 0)~=0 then
				InsertArticle( eCategoryBeliefs, belief )
			end
		end
		InsertSection( Alphabetically )
	end
end

-------------------------------------------------------------------------------
if _bCiv5BNW then
	CreateCategory( eCategoryLeagueProjects, L"TXT_KEY_PEDIA_WORLD_CONGRESS_PAGE_LABEL" )

	CreateSection( L"TXT_KEY_PEDIA_WORLD_CONGRESS_CATEGORY_1" )
	for resolution in GameInfo.Resolutions() do
		InsertArticle( eCategoryResolutions, resolution )
	end
	InsertSection( Alphabetically )

	CreateSection( L"TXT_KEY_PEDIA_WORLD_CONGRESS_CATEGORY_2" )
	for leagueProject in GameInfo.LeagueProjects() do
		InsertArticle( eCategoryLeagueProjects, leagueProject )
	end
	InsertSection( Alphabetically )
end

SelectArticleHistorized( eCategoryHomePage )

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

local function GotoArticle( tArticle, bHistorize )
	if tArticle then
		SelectArticle( tArticle.CategoryID, tArticle.EntryID, bHistorize )
	end
end

function OnClose()
	Controls.Portrait:UnloadTexture()
	UIManager:DequeuePopup( ContextPtr )
end
Controls.CloseButton:RegisterCallback( eLClick, OnClose )

Controls.BackButton:RegisterCallback( eLClick, function()
	if _iArticlesHistory > 1 then
		_iArticlesHistory = _iArticlesHistory - 1
		GotoArticle( _tArticlesHistory[ _iArticlesHistory ] )
	end
end)

Controls.ForwardButton:RegisterCallback( eLClick, function()
	if _iArticlesHistory < #_tArticlesHistory then
		_iArticlesHistory = _iArticlesHistory + 1
		GotoArticle( _tArticlesHistory[ _iArticlesHistory ] )
	end
end)

local function OnSearchButtonClicked()
	local searchString = Controls.SearchEditBox:GetText()
	local y=0
	if searchString and searchString:match"[]%c\"<>|/\\*?[]" == nil and searchString:gsub("%s", ""):len() > 2 then
		UIManager:SetUICursor( 1 )
		local lowerCaseSearchString = ToLower(searchString)
		local instance, new
		local tArticles = {}
		for k, tArticle in pairs(_tArticlesByNameLowerCase) do
			if string.find( k, lowerCaseSearchString ) then
				insert( tArticles, tArticle )
			end
		end
		sort( tArticles, Alphabetically )
		_SearchResultIM:ResetInstances()
		for _, tArticle in ipairs(tArticles) do
			instance, new = _SearchResultIM:GetInstance()
			if new then
				instance.ListItemButton:RegisterCallback( eLClick, SelectArticleHistorized )
				instance.ListItemButton:SetToolTipCallback( TipHandler )
			end
			instance.ListItemButton:SetText( tArticle.EntryName )
			instance.ListItemButton:SetVoids( tArticle.CategoryID, tArticle.EntryID )
		end
		Controls.SearchResultsStack:CalculateSize()
		y = Controls.SearchResultsStack:GetSizeY()
		if y>0 then
			Controls.SearchScrollPanel:SetSizeY( math.min( y, _iScreenSizeY-400 ) )
			Controls.SearchScrollPanel:CalculateInternalSize()
			Controls.SearchGrid:DoAutoSize()
		end
		UIManager:SetUICursor( 0 )
	end
	Controls.SearchGrid:SetHide( y<=0 )
end
Controls.SearchEditBox:RegisterCallback( OnSearchButtonClicked )
Controls.SearchButton:RegisterCallback( eLClick, OnSearchButtonClicked )

Events.SearchForPediaEntry.Add( function( searchString )
	UIManager:SetUICursor( 1 )
	if ContextPtr:IsHidden() then
		UIManager:QueuePopup( ContextPtr, PopupPriority.eUtmost )
	end
	local tArticle = _tArticlesByNameKey[ searchString ]
	searchString = ToLower( ( tostring(searchString or ""):gsub("[]%c\"<>|/\\*?[]", "") ) )
	tArticle = tArticle or _tArticlesByNameLowerCase[ searchString ]
	if tArticle then
		GotoArticle( tArticle, true )
	else
		Controls.SearchEditBox:SetText( searchString )
		SelectArticleHistorized( eCategoryHomePage )
		OnSearchButtonClicked()
	end
	UIManager:SetUICursor( 0 )
end)

Events.GoToPediaHomePage.Add( function( iHomePage )
	UIManager:SetUICursor( 1 )
	UIManager:QueuePopup( ContextPtr, PopupPriority.Civilopedia )
	SelectArticleHistorized( iHomePage )
	UIManager:SetUICursor( 0 )
end)

ContextPtr:SetInputHandler( function( uiMsg, wParam )
	if uiMsg == KeyDown then
		if wParam == VK_ESCAPE then
			if Controls.SearchGrid:IsHidden() then
				OnClose()
			else
--				Controls.SearchEditBox:TakeFocus()
				Controls.SearchGrid:SetHide( true )
			end
			return true
		end
	end
end)

ContextPtr:SetShowHideHandler( function( isHide )
	if isHide then
		Controls.Portrait:UnloadTexture()
		Events.SystemUpdateUI.CallImmediate( BulkShowUI )
		Events.GameplaySetActivePlayer.Remove( OnClose )
		Events.MultiplayerGameLobbyInvite.Remove( OnClose )
		Events.MultiplayerGameServerInvite.Remove( OnClose )
	else
		Events.SystemUpdateUI.CallImmediate( BulkHideUI )
		if _tCategories then
			local tArticle = _tArticlesHistory[ _iArticlesHistory ]
			if tArticle then
				GotoArticle( tArticle )
			else
				_iSelectedCategory = nil
				SelectArticleHistorized( eCategoryHomePage )
			end
		else
			local cursor = UIManager:SetUICursor( 1 )
			print"Reload"
			ContextPtr:Reload()
			UIManager:SetUICursor( cursor )
		end
		Events.GameplaySetActivePlayer.Add( OnClose )
		Events.MultiplayerGameLobbyInvite.Add( OnClose )
		Events.MultiplayerGameServerInvite.Add( OnClose )
	end
end)

if not Game then
	local function RequireRefresh()
		-- assumes ContextPtr is hidden while this happens
		print"RequireRefresh"
		_tCategories = nil
	end
	Events.AfterModsDeactivate.Add( RequireRefresh )
	Events.AfterModsActivate.Add( RequireRefresh )
end
