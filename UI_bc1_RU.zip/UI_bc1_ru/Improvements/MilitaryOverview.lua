-------------------------------------------------
-- Military
-------------------------------------------------

include "GameInfoCache" -- warning! booleans are true, not 1, and use iterator ONLY with table field conditions, NOT string SQL query
local GameInfo = GameInfoCache

include "IconHookup"
local CivIconHookup = CivIconHookup

include "InstanceStackManager"
local m_MilitaryIM = InstanceStackManager( "UnitInstance", "Root", Controls.MilitaryStack )
local m_CivilianIM = InstanceStackManager( "UnitInstance", "Root", Controls.CivilianStack )

include "UnitUtilities"
local GetUnitBuildProgress = GetUnitBuildProgress

local m_SortTable = {}
local m_SortModes = { "name", "status", "movement", "moves", "strength", "ranged" }
local m_SortMode = m_SortModes[1]
local m_SortReverse = false

local m_PopupInfo = nil

local move_denominator = GameDefines.MOVE_DENOMINATOR

-------------------------------------------------
-- On Popup
-------------------------------------------------
AddSerialEventGameMessagePopup( function( popupInfo )
	if popupInfo.Type == ButtonPopupTypes.BUTTONPOPUP_MILITARY_OVERVIEW then
		m_PopupInfo = popupInfo

		if m_PopupInfo.Data1 == 1 then
			if ContextPtr:IsHidden() then
				UIManager:QueuePopup( ContextPtr, PopupPriority.InGameUtmost )
			else
				OnClose()
			end
		else
			UIManager:QueuePopup( ContextPtr, PopupPriority.MilitaryOverview )
		end
	end
end, ButtonPopupTypes.BUTTONPOPUP_MILITARY_OVERVIEW )

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function OnClose()
	UIManager:DequeuePopup( ContextPtr )
end
Controls.CloseButton:RegisterCallback( Mouse.eLClick, OnClose)


-- Key Down Processing
do
	local VK_RETURN = Keys.VK_RETURN
	local VK_ESCAPE = Keys.VK_ESCAPE
	local KeyDown = KeyEvents.KeyDown
	ContextPtr:SetInputHandler( function( uiMsg, wParam )
		if uiMsg == KeyDown then
			if wParam == VK_ESCAPE or wParam == VK_RETURN then
				OnClose()
			end
			return true
		end
	end)
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function UnitClicked(unitID)
	local selectedUnit = UI:GetHeadSelectedUnit()
	if selectedUnit and selectedUnit:GetID() == unitID then
		UI.LookAtSelectionPlot(0)
	else
		Events.SerialEventUnitFlagSelected( Game:GetActivePlayer(), unitID )
	end
end


-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function UpdateScreen()

	local playerID = Game.GetActivePlayer()
	local player = Players[ playerID ]

	--------------------------------------------------------
	-- Great General Progress
	local fThreshold = player:GreatGeneralThreshold()
	local fProgress	= player:GetCombatExperience()
	Controls.GPMeter:SetPercent( fProgress / fThreshold )
	Controls.GPBox:LocalizeAndSetToolTip( "TXT_KEY_MO_GENERAL_TT", fProgress, fThreshold )

	--------------------------------------------------------
	-- Great Admiral Progress
	if player.GreatAdmiralThreshold then
		local fThreshold = player:GreatAdmiralThreshold()
		local fProgress = player:GetNavalCombatExperience()
		Controls.GAMeter:SetPercent( fProgress / fThreshold )
		Controls.GABox:LocalizeAndSetToolTip( "TXT_KEY_MO_ADMIRAL_TT", fProgress, fThreshold )
	end
	--------------------------------------------------------
	-- Supply Details
	Controls.HandicapSupplyValue:SetText( player:GetNumUnitsSuppliedByHandicap() )
	Controls.CitiesSupplyValue:SetText(  player:GetNumUnitsSuppliedByCities() )
	Controls.PopulationSupplyValue:SetText( player:GetNumUnitsSuppliedByPopulation() )
	Controls.SupplyCapValue:SetText( 	player:GetNumUnitsSupplied() )
	Controls.SupplyUseValue:SetText( 	player:GetNumUnits() )

	local iSupplyDeficit = player:GetNumUnitsOutOfSupply()
	local bInDeficit = (iSupplyDeficit ~= 0 )

	if not bInDeficit then
		Controls.SupplyRemainingValue:SetText( player:GetNumUnitsSupplied() - player:GetNumUnits() )
	else
		Controls.SupplyDeficitValue:SetText( iSupplyDeficit )
		Controls.SupplyDeficitPenaltyValue:SetText( player:GetUnitProductionMaintenanceMod() .. "%" )
	end

	Controls.SupplyRemaining:SetHide( bInDeficit )
	Controls.SupplyDeficit:SetHide( not bInDeficit )
	Controls.DeficitPenalty:SetHide( not bInDeficit )


	--------------------------------------------------------
	-- Unit List
	BuildUnitList()
end


--------------------------------------------------------
--------------------------------------------------------
function BuildUnitList()

	m_SortTable = {}

	local playerID = Game.GetActivePlayer()
	local player = Players[ playerID ]

	local isMilitary = false
	local isCivilian = false

	local selectedUnit = UI:GetHeadSelectedUnit()
	local selectedUnitID = selectedUnit and selectedUnit:GetID() or -1

	m_MilitaryIM:ResetInstances()
	m_CivilianIM:ResetInstances()

	for unit in player:Units() do
		local instance
		local unitID = unit:GetID()

		if unit:GetUnitCombatType() ~= -1 or unit:CanNuke() then
			instance = m_MilitaryIM:GetInstance()
			isMilitary = true
		else
			instance = m_CivilianIM:GetInstance()
			isCivilian = true
		end

		local sortEntry = {}
		m_SortTable[ tostring( instance.Root ) ] = sortEntry

		instance.Button:RegisterCallback( Mouse.eLClick, UnitClicked )
		instance.Button:SetVoid1( unit:GetID() )

		local unitName = unit:GetName()
		sortEntry.name = unitName
		instance.UnitName:SetText( unitName )

		if unit:MovesLeft() > 0 then
			instance.Button:SetAlpha( 1.0 )
		else
			instance.Button:SetAlpha( 0.6 )
		end

		instance.SelectionFrame:SetHide( selectedUnitID ~= unitID )

		sortEntry.hasPromotion = unit:CanPromote()
		instance.PromotionIndicator:SetHide( not sortEntry.hasPromotion )

		---------------------------------------------------------
		-- Status field
		local buildType = unit:GetBuildType()
		local activityType = unit:GetActivityType()
		local status
		if unit:IsEmbarked() then
			status = "TXT_KEY_UNIT_STATUS_EMBARKED"

		elseif unit:IsGarrisoned() then
			status = "TXT_KEY_MISSION_GARRISON"

		elseif unit:IsAutomated() then
			if unit:IsWork() then
				status = "TXT_KEY_ACTION_AUTOMATE_BUILD"
			else
				status = "TXT_KEY_ACTION_AUTOMATE_EXPLORE"
			end

		elseif activityType == ActivityTypes.ACTIVITY_HEAL then
			status = "TXT_KEY_MISSION_HEAL"

		elseif activityType == ActivityTypes.ACTIVITY_SENTRY then
			status = "TXT_KEY_MISSION_ALERT"

		elseif unit:GetFortifyTurns() > 0 then
			status = "TXT_KEY_UNIT_STATUS_FORTIFIED"

		elseif activityType == ActivityTypes.ACTIVITY_SLEEP then
			status = "TXT_KEY_MISSION_SLEEP"

		elseif buildType ~= -1 then -- this is a worker who is actively building something
			local thisBuild = GameInfo.Builds[buildType]
			local status = Locale.ConvertTextKey(thisBuild.Description)
			local iTurnsLeft = GetUnitBuildProgress( unit, unit:GetPlot(), buildType )
			if iTurnsLeft < 4000 and iTurnsLeft > 0 then
				status = status.." ("..tostring(iTurnsLeft)..")"
			end
		end
		sortEntry.status = status or ""
		instance.Status:SetHide( not status )
		instance.Status:LocalizeAndSetText( status or "" )

		local moves_left = unit:MovesLeft() / move_denominator
		local max_moves = unit:MaxMoves() / move_denominator

		if moves_left >= max_moves then
			instance.MovementPip:SetTextureOffsetVal( 0, 0 )
		elseif moves_left <= 0 then
			instance.MovementPip:SetTextureOffsetVal( 0, 96 )
		else
			instance.MovementPip:SetTextureOffsetVal( 0, 32 )
		end

		sortEntry.movement = moves_left
		sortEntry.moves = max_moves
		instance.Movement:SetText( (" %.3g / %g [ICON_MOVES]"):format( moves_left, max_moves ) )

		local strength = unit:GetBaseCombatStrength()
		sortEntry.strength = strength
		instance.Strength:SetText( strength == 0 and "-" or strength )

		local ranged = unit:GetBaseRangedCombatStrength()
		sortEntry.ranged = ranged
		instance.RangedAttack:SetText( ranged == 0 and "-" or ranged )

		sortEntry.unit = unit
	end

	Controls.CivilianSeperator:SetHide( not(isMilitary and isCivilian) )

	Controls.MilitaryStack:SortChildren( SortFunction )
	Controls.CivilianStack:SortChildren( SortFunction )

	Controls.MilitaryStack:CalculateSize()
	Controls.CivilianStack:CalculateSize()

	Controls.MainStack:CalculateSize()
	Controls.ScrollPanel:CalculateInternalSize()

	Controls.ScrollPanel:ReprocessAnchoring()
end


-------------------------------------------------
-------------------------------------------------
-- assumes that SortChildren is a stable sort
function SortFunction( a, b )
	if m_SortReverse then
		a,b = b,a
	end
	local entryA = m_SortTable[ tostring( a ) ]
	local entryB = m_SortTable[ tostring( b ) ]

	if entryA and entryB then
		local valueA = entryA[m_SortMode]
		local valueB = entryB[m_SortMode]
		return valueA and valueB and valueA < valueB
	end
end

-------------------------------------------------
-------------------------------------------------
function OnSort( sortID )
	local sortMode = m_SortModes[ sortID ] or m_SortModes[ 1 ]
	if m_SortMode == sortMode then
		m_SortReverse = not m_SortReverse
	else
		m_SortReverse = false
	end
	m_SortMode = sortMode
	Controls.MilitaryStack:SortChildren( SortFunction )
	Controls.CivilianStack:SortChildren( SortFunction )
end
Controls.SortName:RegisterCallback( Mouse.eLClick, OnSort )
Controls.SortStatus:RegisterCallback( Mouse.eLClick, OnSort )
Controls.SortMovement:RegisterCallback( Mouse.eLClick, OnSort )
Controls.SortMoves:RegisterCallback( Mouse.eLClick, OnSort )
Controls.SortStrength:RegisterCallback( Mouse.eLClick, OnSort )
Controls.SortRanged:RegisterCallback( Mouse.eLClick, OnSort )
Controls.SortName:SetVoid1( 1 )
Controls.SortStatus:SetVoid1( 2 )
Controls.SortMovement:SetVoid1( 3 )
Controls.SortMoves:SetVoid1( 4 )
Controls.SortStrength:SetVoid1( 5 )
Controls.SortRanged:SetVoid1( 6 )


-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
local isHidden = ContextPtr:IsHidden()
ContextPtr:SetShowHideHandler(
function( isHide, isInit )
	if not isInit and isHidden ~= isHide then
		isHidden = isHide
		if not isHide then
			UI.incTurnTimerSemaphore()
			-- Set player icon at top of screen
			CivIconHookup( 0, 64, Controls.Icon, Controls.CivIconBG, Controls.CivIconShadow, false, true )
			UpdateScreen()
			Events.SerialEventGameMessagePopupShown(m_PopupInfo)
		else
			UI.decTurnTimerSemaphore()
			Events.SerialEventGameMessagePopupProcessed.CallImmediate(ButtonPopupTypes.BUTTONPOPUP_MILITARY_OVERVIEW, 0)
		end
	end
end)

----------------------------------------------------------------
-- 'Active' (local human) player has changed
----------------------------------------------------------------
Events.GameplaySetActivePlayer.Add(OnClose)
