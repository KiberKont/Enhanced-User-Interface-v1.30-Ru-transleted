-- Written by bc1 using Notepad++
-- !!! assumes prior include of "GameInfoCache" and "IconHookup"

local GameInfo = GameInfoCache
local IconHookup = IconHookup
local Color = Color

local ceil = math.ceil
local max = math.max
local min = math.min
local floor = math.floor
local tonumber = tonumber

local GetUnitPortraitIcon = UI.GetUnitPortraitIcon
local Players = Players
local GetWorldNumCitiesUnhappinessPercent = Game.GetWorldNumCitiesUnhappinessPercent

local MAX_CITY_HIT_POINTS = tonumber(GameDefines.MAX_CITY_HIT_POINTS) or 200
local ORDER_TRAIN = OrderTypes.ORDER_TRAIN
local ORDER_CONSTRUCT = OrderTypes.ORDER_CONSTRUCT
local ORDER_CREATE = OrderTypes.ORDER_CREATE
local ORDER_MAINTAIN = OrderTypes.ORDER_MAINTAIN
local DEFAULT_SPECIALIST = tonumber(GameDefines.DEFAULT_SPECIALIST) or 0
local UNHAPPINESS_PER_POPULATION = tonumber(GameDefines.UNHAPPINESS_PER_POPULATION) or 1
local UNHAPPINESS_PER_CITY = tonumber(GameDefines.UNHAPPINESS_PER_CITY) or 3
local _iHappinessPerTradeRouteFactor = Game.GetReligionName and 100 or 1
local _iNum_SpecialistsM1 = #GameInfo.Specialists - 1
local _iMaximumAcquirePlotArea = (GameDefines.MAXIMUM_ACQUIRE_PLOT_DISTANCE+1) * GameDefines.MAXIMUM_ACQUIRE_PLOT_DISTANCE * 3
local _tCityFocusIcons = {
--[CityAIFocusTypes.NO_CITY_AI_FOCUS_TYPE or -9] = "",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_FOOD or -9] = "[ICON_FOOD]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PRODUCTION or -9] = "[ICON_PRODUCTION]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GOLD or -9] = "[ICON_GOLD]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_SCIENCE or -9] = "[ICON_RESEARCH]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_CULTURE or -9] = "[ICON_CULTURE]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GREAT_PEOPLE or -9] = "[ICON_GREAT_PEOPLE]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_FAITH or -9] = "[ICON_PEACE]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PROD_GROWTH or -9] = "[ICON_PRODUCTION][ICON_FOOD]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GOLD_GROWTH or -9] = "[ICON_GOLD][ICON_FOOD]",
[-9] = nil }
-- Hardcoded values in BNW DLL CvCultureClasses.cpp
local _tPublicOpinionUnhappiness = {
	[PublicOpinionTypes.PUBLIC_OPINION_DISSIDENTS or -9 ] = { 1, 10 },
	[PublicOpinionTypes.PUBLIC_OPINION_CIVIL_RESISTANCE or -9 ] = { 2, 5 },
	[PublicOpinionTypes.PUBLIC_OPINION_REVOLUTIONARY_WAVE or -9 ] = { 4, 3 },
	[-9] = nil }

--==========================================================
if Map.GetPlot(0,0).GetCityPurchaseID then
	CityPlots = function( city, i )
		if not i then i = 0 end
		local iCity = city:GetID()
		local iPlayer = city:GetOwner()
		return function()
			while i <= _iMaximumAcquirePlotArea do
				local plot = city:GetCityIndexPlot( i )
				i = i+1
				if plot	and plot:GetOwner() == iPlayer and plot:GetCityPurchaseID() == iCity then
					return plot
				end
			end
		end
	end
else
	CityPlots = function( city, i )
		if not i then i = 0 end
		return function()
			while i <= _iMaximumAcquirePlotArea do
				local plot = city:GetCityIndexPlot( i )
				i = i+1
				if plot	and plot:GetWorkingCity() == city then
					return plot
				end
			end
		end
	end
end

--==========================================================
function GetCityHappiness( player, city )
	return ( city.GetLocalHappiness and city:GetLocalHappiness() or 0 )
			-- Free Happiness per City
			+ player:GetExtraHappinessPerCity()
			-- City Buildings
			+ city:GetHappiness()
			-- Connected to Capital
			+ ( not city:IsCapital() and player:IsCapitalConnectedToCity(city) and ( player:GetHappinessPerTradeRoute() / _iHappinessPerTradeRouteFactor ) or 0 )
			-- Garrisoned Unit
			+ ( city:GetGarrisonedUnit() and player:GetHappinessPerGarrisonedUnit() or 0 )
end

--==========================================================
function GetCityUnhappiness( player, city )
	local iPopulation = city:GetPopulation()
	local iPublicOpinionUnhappiness = 0
	if player.GetPublicOpinionType then
		local t = _tPublicOpinionUnhappiness[ player:GetPublicOpinionType() ]
		if t then
			if player:GetNumCities() * t[1] < floor( player:GetTotalPopulation() / t[2] ) then
				iPublicOpinionUnhappiness = floor( iPopulation * 100 / t[2] ) / 100
			else
				iPublicOpinionUnhappiness = t[1]
			end
		end
	end
	if city:IsOccupied() and city:IsNoOccupiedUnhappiness() then
		-- In this case the DLL is bugged, have to do the actual compute
		-- Unhappiness bonus from Specialists
		if player:IsHalfSpecialistUnhappiness() then
			for iSpecialist = 0, _iNum_SpecialistsM1 do
				if iSpecialist ~= DEFAULT_SPECIALIST then
					iPopulation = iPopulation - city:GetSpecialistCount( iSpecialist ) * .5
				end
			end
		end
		local rHandicap = GameInfo.HandicapInfos[ player:GetHandicapType() ] or {}
		return floor(
		-- Population unhappiness
							UNHAPPINESS_PER_POPULATION
							* floor(iPopulation)
							* ( city:IsCapital() and ( 100 + player:GetCapitalUnhappinessMod() ) or 100 )
							* ( 100 + player:GetUnhappinessMod() )
							* ( 100 + player:GetTraitPopUnhappinessMod() )
							* ( tonumber(rHandicap.PopulationUnhappinessMod) or 100 )
							/ 1e6
		-- City count unhappiness
							+ UNHAPPINESS_PER_CITY
							* ( 100 + player:GetCityCountUnhappinessMod() + player:GetTraitCityUnhappinessMod() )
							* ( tonumber(rHandicap.NumCitiesUnhappinessMod) or 100 )
							* GetWorldNumCitiesUnhappinessPercent()
							/1e4
					) / 100 + iPublicOpinionUnhappiness, iPublicOpinionUnhappiness
	else
		-- Otherwise the DLL is OK
		return player:GetUnhappinessFromCityForUI( city ) / 100 + iPublicOpinionUnhappiness, iPublicOpinionUnhappiness
	end
end

--==========================================================
function UpdateCityInstance( city, instance )
	if city and instance then
		local bNotPuppet = not city:IsPuppet()
		local bRazing = city:IsRazing()
		local bResistance = city:IsResistance()
		local bCapital = city:IsCapital()
		local iPlayer = city:GetOwner()
		local player = Players[ iPlayer ]

		local row, portraitOffset, portraitAtlas, buildPercent
		local turnsRemaining = city:GetProductionTurnsLeft()
		local productionNeeded = city:GetProductionNeeded()
		local storedProduction = city:GetProduction() + city:GetOverflowProduction() + city:GetFeatureProduction()
		local iOrder, iItem = city:GetOrderFromQueue()
		if iOrder == ORDER_TRAIN then
			row = GameInfo.Units[ iItem ]
			if row then portraitOffset, portraitAtlas = GetUnitPortraitIcon( iItem, iPlayer ) end
		elseif iOrder == ORDER_CONSTRUCT then
			row = GameInfo.Buildings[ iItem ]
		elseif iOrder == ORDER_CREATE then
			row = GameInfo.Projects[ iItem ]
		elseif iOrder == ORDER_MAINTAIN then
			row = GameInfo.Processes[ iItem ]
			turnsRemaining = nil
			productionNeeded = 0
		end
		if row then
			row = IconHookup( portraitOffset or row.PortraitIndex, 64, portraitAtlas or row.IconAtlas, instance.CityProduction ) --instance.CityProduction:GetSizeX()
			if productionNeeded > 0 then
				buildPercent = 1 - max( 0, storedProduction/productionNeeded )
			end
			instance.BuildMeter:SetPercents( 0, buildPercent or 0 )
		end
		instance.CityProduction:SetHide( not row )
		instance.BuildGrowth:SetString( row and not bResistance and not bRazing and turnsRemaining )
		instance.CityPopulation:SetString( city:GetPopulation() )
		local foodPerTurnTimes100 = city:FoodDifferenceTimes100()
		if bRazing or foodPerTurnTimes100 < 0 then
			instance.CityGrowth:SetString( "[COLOR_RED]" .. (bRazing and 1 or min( floor( ( city:GetFoodTimes100() ) / -foodPerTurnTimes100 ) + 1, 99 ) ) .. "[ENDCOLOR]" )
		elseif city:IsForcedAvoidGrowth() then
			instance.CityGrowth:SetString( "[ICON_LOCKED]" )
		elseif city:IsFoodProduction() or foodPerTurnTimes100 == 0 then
			instance.CityGrowth:SetString()
		else
			instance.CityGrowth:SetString( min( city:GetFoodTurnsLeft(), 99 ) )
		end

		instance.CityIsCapital:SetHide( not bCapital )
		instance.CityIsPuppet:SetHide( bNotPuppet )
		instance.CityFocus:SetText( not bRazing and bNotPuppet and _tCityFocusIcons[city:GetFocusType()] )
		instance.CityQuests:SetText( city:GetWeLoveTheKingDayCounter() > 0 and "[ICON_HAPPINESS_1]" or (GameInfo.Resources[city:GetResourceDemanded()] or {}).IconString )
		instance.CityIsRazing:SetHide( not bRazing )
		instance.CityIsResistance:SetHide( not bResistance )
		instance.CityResistanceTurns:SetText( bRazing and city:GetRazingTurns() or bResistance and city:GetResistanceTurns() )
		instance.CityIsConnected:SetHide( bCapital or player and not player:IsCapitalConnectedToCity( city ) )
		instance.CityIsBlockaded:SetHide( not city:IsBlockaded() )
		instance.CityIsOccupied:SetHide( not city:IsOccupied() or city:IsNoOccupiedUnhappiness() )
		instance.CityName:SetString( city:GetName() )
		local religion = city.GetReligiousMajority and GameInfo.Religions[city:GetReligiousMajority()]
		instance.CityReligion:SetString( religion and religion.IconString )
		local culturePerTurn = city:GetJONSCulturePerTurn()
		instance.BorderGrowth:SetString( culturePerTurn > 0 and ceil( (city:GetJONSCultureThreshold() - city:GetJONSCultureStored()) / culturePerTurn ) )

		local percent = 1 - city:GetDamage() / ( city.GetMaxHitPoints and city:GetMaxHitPoints() or MAX_CITY_HIT_POINTS )
		instance.Button:SetColor( Color( 1, percent, percent, 1 ) )
	end
end
