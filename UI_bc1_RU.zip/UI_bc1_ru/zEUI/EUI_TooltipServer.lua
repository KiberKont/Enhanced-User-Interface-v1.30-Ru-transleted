--==========================================================
-- Written by bc1 using Notepad++
-- Include for EUI context
--==========================================================

local print = print
print( "Loading EUI tooltip server..." )

local UserInterfaceSettings = UserInterfaceSettings -- global defined by EUI_Context
local GameInfo = GameInfoCache -- warning! booleans are true, not 1, and use iterator ONLY with table field conditions, NOT string SQL query

local _bCiv5 = InStrategicView ~= nil
local _bCivBE = not _bCiv5
local _bCiv5notVanilla = Game.GetReligionName ~= nil
local _bCiv5BNW = _bCiv5 and Game.GetActiveLeague ~= nil
local _bCiv5BNWorBE = _bCiv5BNW or _bCivBE
local _bNewWorldDeluxeScenario = Modding.GetActivatedModVersion"34fb6c19-10dd-4b65-b143-fd00b2c0826f" ~= nil

if _bCiv5BNW then
	include "GreatPeopleIcons"
end
local GreatPeopleIcons = GreatPeopleIcons

include "InstanceStackManager"

include "IconHookup"
local IconHookup = IconHookup
local CivIconHookup = CivIconHookup

include "ScanGP"
local ScanGP = ScanGP

include "UnitUtilities"
local ShortUnitTip = ShortUnitTip
local GetUnitBuildProgress = GetUnitBuildProgress
local GetUnitHealProgress = GetUnitHealProgress

include "CityUtilities"
local CityPlots = CityPlots
local GetCityHappiness = GetCityHappiness
--local GetCityUnhappiness = GetCityUnhappiness

include "ScratchDeal"
local ScratchDeal = ScratchDeal
local PopScratchDeal = PopScratchDeal
local PushScratchDeal = PushScratchDeal

include "CityStateStatusHelper"
local GetAllyToolTip = GetAllyToolTip
local GetActiveQuestToolTip = GetActiveQuestToolTip
local GetCityStateStatusToolTip = GetCityStateStatusToolTip

include "InfoTooltipInclude"
local GetHelpTextForUnit = GetHelpTextForUnit
local GetHelpTextForBuilding = GetHelpTextForBuilding
local GetHelpTextForProject = GetHelpTextForProject
local GetHelpTextForProcess = GetHelpTextForProcess
local GetHelpTextForImprovement = GetHelpTextForImprovement
local GetFoodTooltip = GetFoodTooltip
local GetGoldTooltip = _bCiv5 and GetGoldTooltip or GetEnergyTooltip
local GetScienceTooltip = GetScienceTooltip
local GetProductionTooltip = GetProductionTooltip
local GetCultureTooltip = GetCultureTooltip
local GetFaithTooltip = GetFaithTooltip
local GetReligionTooltip = GetReligionTooltip
local GetTourismTooltip = GetTourismTooltip
local GetMoodInfo = GetMoodInfo
local GetHelpTextForPlayerPerk = GetHelpTextForPlayerPerk -- BE only
local GetHelpTextForAffinity = GetHelpTextForAffinity -- BE only

include "TechHelpInclude"
local GetHelpTextForTech = GetHelpTextForTech

include "ShowProgress"
local ShowProgressToolTip = ShowProgressToolTip

--==========================================================
-- Minor lua optimizations
--==========================================================

local ipairs = ipairs
local pairs = pairs
local tostring = tostring
local tonumber = tonumber
local ceil = math.ceil
local floor = math.floor
local min = math.min
local max = math.max
local modf = math.modf
local insert = table.insert
local concat = table.concat
local format = string.format

local PreGame = PreGame
local Game = Game
local GetActivePlayer = Game.GetActivePlayer
local GetActiveTeam = Game.GetActiveTeam
local GetResourceUsageType = Game.GetResourceUsageType
local GameOptionTypes = GameOptionTypes
local GameInfoActions = GameInfoActions
local GameInfoTypes = GameInfoTypes
local GetPlot = Map.GetPlot
local PlotDirection = Map.PlotDirection
local L = Locale.ConvertTextKey
local ToUpper = Locale.ToUpper
local HasTextKey = Locale.HasTextKey
local Matchmaking = Matchmaking
local Network = Network
local OptionsManager = OptionsManager
local Players = Players
local Teams = Teams
local GetHeadSelectedCity = UI.GetHeadSelectedCity
local GetHeadSelectedUnit = UI.GetHeadSelectedUnit
local GetUnitPortraitIcon = UI.GetUnitPortraitIcon
local GetMousePos = UIManager.GetMousePos
local TradeableItems = TradeableItems
local FAITH_PURCHASE_UNIT = FaithPurchaseTypes.FAITH_PURCHASE_UNIT
local FAITH_PURCHASE_BUILDING = FaithPurchaseTypes.FAITH_PURCHASE_BUILDING

local RESOURCEUSAGE_STRATEGIC = ResourceUsageTypes.RESOURCEUSAGE_STRATEGIC
local RESOURCEUSAGE_LUXURY = ResourceUsageTypes.RESOURCEUSAGE_LUXURY
local RESOURCEUSAGE_BONUS = ResourceUsageTypes.RESOURCEUSAGE_BONUS
local TRADE_ITEM_RESOURCES = TradeableItems.TRADE_ITEM_RESOURCES
local ACTIONSUBTYPE_BUILD = ActionSubTypes.ACTIONSUBTYPE_BUILD
local ACTIONSUBTYPE_PROMOTION = ActionSubTypes.ACTIONSUBTYPE_PROMOTION
local RELIGION_PANTHEON = ReligionTypes and ReligionTypes.RELIGION_PANTHEON
local MAX_CIV_PLAYERS_M1 = GameDefines.MAX_CIV_PLAYERS - 1
local MAX_MAJOR_CIVS = GameDefines.MAX_MAJOR_CIVS
local MINOR_CIV_QUEST_CONNECT_RESOURCE = MinorCivQuestTypes.MINOR_CIV_QUEST_CONNECT_RESOURCE
local MOVE_DENOMINATOR = tonumber(GameDefines.MOVE_DENOMINATOR) or 60
--[[
local DEFAULT_SPECIALIST = tonumber(GameDefines.DEFAULT_SPECIALIST) or 0
local UNHAPPINESS_PER_POPULATION = tonumber(GameDefines.UNHAPPINESS_PER_POPULATION) or 1
local UNHAPPINESS_PER_CITY = tonumber(GameDefines.UNHAPPINESS_PER_CITY) or 3
local UNHAPPINESS_PER_OCCUPIED_POPULATION = tonumber(GameDefines.UNHAPPINESS_PER_OCCUPIED_POPULATION) or 1.34
local UNHAPPINESS_PER_CAPTURED_CITY = tonumber(GameDefines.UNHAPPINESS_PER_CAPTURED_CITY) or 5
local _iNum_SpecialistsM1 = #GameInfo.Specialists - 1
--]]

local DOMAIN_LAND = DomainTypes.DOMAIN_LAND
local DOMAIN_SEA = DomainTypes.DOMAIN_SEA
local DOMAIN_AIR = DomainTypes.DOMAIN_AIR

local ORDER_TRAIN = OrderTypes.ORDER_TRAIN
local ORDER_CONSTRUCT = OrderTypes.ORDER_CONSTRUCT
local ORDER_CREATE = OrderTypes.ORDER_CREATE
local ORDER_MAINTAIN = OrderTypes.ORDER_MAINTAIN

local YIELD_GOLD = _bCiv5 and YieldTypes.YIELD_GOLD or YieldTypes.YIELD_ENERGY
local YIELD_FAITH = YieldTypes.YIELD_FAITH
local NUM_YIELD_TYPES_M1 = YieldTypes.NUM_YIELD_TYPES - 1

local ICON_GOLD = _bCiv5 and "[ICON_GOLD]" or "[ICON_ENERGY]"
local GOLD = _bCiv5 and "GOLD" or "ENERGY"
local HAPPINESS = _bCiv5 and "HAPPINESS" or "HEALTH"
local _sScienceTextColor = _bCiv5 and "[COLOR:33:190:247:255]" or "[COLOR_MENU_BLUE]"
local _iRelationshipDuration = (GameInfo.GameSpeeds[ PreGame.GetGameSpeed() ]or {}).RelationshipDuration or GameDefines.DOF_EXPIRATION_TIME or 50
local _iHappinessPerTradeRouteFactor = Game.GetReligionName and 100 or 1 -- stupid Firaxis API change

local _cItemTooltip = {}
TTManager:GetTypeControlTable( "EUI_ItemTooltip", _cItemTooltip )

local _cUnitTooltip = {}
TTManager:GetTypeControlTable( "EUI_UnitTooltip", _cUnitTooltip )

local _cUnitActionTooltip = {}
TTManager:GetTypeControlTable( "EUI_UnitAction", _cUnitActionTooltip )

local _cCivilizationTooltip = {}
TTManager:GetTypeControlTable( "EUI_CivilizationTooltip", _cCivilizationTooltip )

local _cCityProductionTooltip = {}
TTManager:GetTypeControlTable( "EUI_CityProductionTooltip", _cCityProductionTooltip )

local _cCityGrowthTooltip = {}
TTManager:GetTypeControlTable( "EUI_CityGrowthTooltip", _cCityGrowthTooltip )

local _cTechProgressToolTip = {}
TTManager:GetTypeControlTable( "EUI_ScienceProgressTooltip", _cTechProgressToolTip )

local _cUnitTooltipTimer = Controls.UnitTooltipTimer

local _bShowCityStateLeaderIcon, _bShowUnitIcon, _bShowToolTipIcon, _bBasicHelp, _bScienceEnabled, _bReligionEnabled, _bHappinessEnabled, _bPoliciesEnabled, _bHealthEnabled, _bEspionageDisabled, _bAlwaysWar, _bOneCityChallenge

do
	_cUnitTooltipTimer:RegisterAnimCallback( function()
		local controls = _cUnitTooltip
		controls.PortraitFrame:SetHide( not _bShowUnitIcon )
		controls.Details:SetHide( false )
		controls.IconStack:SetWrapWidth( 32 )
		controls.IconStack:CalculateSize()
		controls.PromotionText:SetHide( false )
		controls.Grid:ReprocessAnchoring()
		controls.Grid:DoAutoSize()
	end)

	local GetTooltip2Seconds = OptionsManager.GetTooltip2Seconds
	local function UpdateOptions()
		_bScienceEnabled = not Game.IsOption(GameOptionTypes.GAMEOPTION_NO_SCIENCE)
		_bPoliciesEnabled = not Game.IsOption(GameOptionTypes.GAMEOPTION_NO_POLICIES)
		_bHappinessEnabled = _bCiv5 and not Game.IsOption(GameOptionTypes.GAMEOPTION_NO_HAPPINESS)
		_bReligionEnabled = _bCiv5notVanilla and not Game.IsOption(GameOptionTypes.GAMEOPTION_NO_RELIGION)
		_bHealthEnabled = not _bCiv5 and not Game.IsOption(GameOptionTypes.GAMEOPTION_NO_HEALTH)
		_bEspionageDisabled = Game.IsOption(GameOptionTypes.GAMEOPTION_NO_ESPIONAGE)
		_bAlwaysWar = Game.IsOption( GameOptionTypes.GAMEOPTION_ALWAYS_WAR )
		_bOneCityChallenge = Game.IsOption(GameOptionTypes.GAMEOPTION_ONE_CITY_CHALLENGE)
		_bBasicHelp = _bCivBE or not OptionsManager.IsNoBasicHelp()
		_cUnitTooltipTimer:SetToBeginning()
		_cUnitTooltipTimer:SetPauseTime( GetTooltip2Seconds() / 100 )
		_bShowCityStateLeaderIcon = UserInterfaceSettings.CityStateLeaders ~= 0
		_bShowUnitIcon = UserInterfaceSettings.ShowUnitMouseOverIcon ~= 0
		_cUnitTooltip.PortraitFrame:SetHide( true )
		_cUnitTooltip.UnitPortrait:UnloadTexture()
		_bShowToolTipIcon = UserInterfaceSettings.ShowToolTipIcon ~= 0
		_cItemTooltip.PortraitFrame:SetHide( true )
		_cItemTooltip.Portrait:UnloadTexture()
	end
	Events.GameOptionsChanged.Add( UpdateOptions )
	UpdateOptions()
end

local _PromotionIconIM = InstanceStackManager( "PromotionIcon", "Image", _cUnitTooltip.IconStack )

local _tYieldStrings = {
	[YieldTypes.YIELD_FOOD or -9] = "TXT_KEY_BUILD_FOOD_STRING",
	[YieldTypes.YIELD_PRODUCTION or -9] = "TXT_KEY_BUILD_PRODUCTION_STRING",
	[YieldTypes.YIELD_GOLD or -9] = "TXT_KEY_BUILD_GOLD_STRING",
	[YieldTypes.YIELD_SCIENCE or -9] = "TXT_KEY_BUILD_SCIENCE_STRING",
	[YieldTypes.YIELD_CULTURE or -9] = "TXT_KEY_BUILD_CULTURE_STRING",
	[YIELD_FAITH or -9] = "TXT_KEY_BUILD_FAITH_STRING",
	[-9] = nil
}

local _tInfoSource = {
	[ ActionSubTypes.ACTIONSUBTYPE_PROMOTION or -9 ] = GameInfo.UnitPromotions,
	[ ActionSubTypes.ACTIONSUBTYPE_INTERFACEMODE or -9 ] = GameInfo.InterfaceModes,
	[ ActionSubTypes.ACTIONSUBTYPE_MISSION or -9 ] = GameInfo.Missions,
	[ ActionSubTypes.ACTIONSUBTYPE_COMMAND or -9 ] = GameInfo.Commands,
	[ ActionSubTypes.ACTIONSUBTYPE_AUTOMATE or -9 ] = GameInfo.Automates,
	[ ActionSubTypes.ACTIONSUBTYPE_BUILD or -9 ] = GameInfo.Builds,
	[ ActionSubTypes.ACTIONSUBTYPE_CONTROL or -9 ] = GameInfo.Controls,
	[-9] = nil
}

local _tCityFocusTooltips = {
	[CityAIFocusTypes.NO_CITY_AI_FOCUS_TYPE or -9] = L"TXT_KEY_CITYVIEW_FOCUS_BALANCED_TEXT",
	[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_FOOD or -9] = L"TXT_KEY_CITYVIEW_FOCUS_FOOD_TEXT",
	[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PRODUCTION or -9] = L"TXT_KEY_CITYVIEW_FOCUS_PROD_TEXT",
	[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GOLD or -9] = L"TXT_KEY_CITYVIEW_FOCUS_GOLD_TEXT",
	[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_SCIENCE or -9] = L"TXT_KEY_CITYVIEW_FOCUS_RESEARCH_TEXT",
	[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_CULTURE or -9] = L"TXT_KEY_CITYVIEW_FOCUS_CULTURE_TEXT",
	[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GREAT_PEOPLE or -9] = L"TXT_KEY_CITYVIEW_FOCUS_GREAT_PERSON_TEXT",
	[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_FAITH or -9] = L"TXT_KEY_CITYVIEW_FOCUS_FAITH_TEXT",
	[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PROD_GROWTH or -9] = "[ICON_PRODUCTION][ICON_FOOD]",
	[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GOLD_GROWTH or -9] = ICON_GOLD .."[ICON_FOOD]",
	[-9] = nil
}

local _tActivityMissions = {
	--[ActivityTypes.ACTIVITY_AWAKE or -9] = nil,
	[ActivityTypes.ACTIVITY_HOLD or -9] = false, --GameInfo.Missions.MISSION_SKIP, -- only when moves left > 0
	--[ActivityTypes.ACTIVITY_SLEEP or -9] = GameInfo.Missions.MISSION_SLEEP, -- can be sleep or fortify
	[ActivityTypes.ACTIVITY_HEAL or -9] = GameInfo.Missions.MISSION_HEAL,
	[ActivityTypes.ACTIVITY_SENTRY or -9] = GameInfo.Missions.MISSION_ALERT,
	[ActivityTypes.ACTIVITY_INTERCEPT or -9] = GameInfo.Missions.MISSION_AIRPATROL,
	--[ActivityTypes.ACTIVITY_MISSION or -9] = GameInfo.Missions.MISSION_MOVE_TO,
	[-9] = nil
}

local function LL( s, ... )
	if s and s~= "" then
		return ( L( s, ... ):gsub( "%[NEWLINE%]%[NEWLINE%]", "[NEWLINE]" ) )
	end
end

local function insertLocalizedIfNonZero( t, s, ... )
	if (... or 0) ~= 0 then
		return insert( t, L( s, ... ) )
	end
end

local function insertLocalizedBulletIfNonZero( t, s, ... )
	if (... or 0) ~= 0 then
		return insert( t, "[ICON_BULLET]" .. L( s, ... ) )
	end
end

local function GetItemPortraitIcon( GameInfoItems, itemID )
	local item = GameInfoItems and GameInfoItems[itemID]
	if item then
		return item.PortraitIndex or item.IconIndex, item.IconAtlas
	end
end

--[[
local function CallZeroIfNil( f, ... )
	if f then
		return f( ... )
	else
		return 0
	end
end

local function UnitColor( s )
	return "[COLOR_UNIT_TEXT]"..s.."[ENDCOLOR]"
end

local function BuildingColor( s )
	return "[COLOR_YIELD_FOOD]"..s.."[ENDCOLOR]"
end

local function PolicyColor( s )
	return "[COLOR_MAGENTA]"..s.."[ENDCOLOR]"
end

local function TechColor( s )
	return "[COLOR_CYAN]"..s.."[ENDCOLOR]"
end

local function ReligionColor( s )
	return "[COLOR_WHITE]"..s.."[ENDCOLOR]"
end
local function ColorizeSigned( x )
	if x > 0 then
		return "[COLOR_POSITIVE_TEXT]+" .. x .. "[ENDCOLOR]"
	elseif x < 0 then
		return "[COLOR_WARNING_TEXT]" .. x .. "[ENDCOLOR]"
	else
		return "0"
	end
end
--]]
local function Colorize( x )
	if x > 0 then
		return "[COLOR_POSITIVE_TEXT]" .. x .. "[ENDCOLOR]"
	elseif x < 0 then
		return "[COLOR_WARNING_TEXT]" .. x .. "[ENDCOLOR]"
	else
		return "0"
	end
end

local function ColorizeAbs( x )
	if x > 0 then
		return "[COLOR_POSITIVE_TEXT]" .. x .. "[ENDCOLOR]"
	elseif x < 0 then
		return "[COLOR_WARNING_TEXT]" .. -x .. "[ENDCOLOR]"
	else
		return "0"
	end
end

local function TooltipSelect( tooltipTable, control, ... )
	local tooltip = tooltipTable[ control:GetID() ]
	if tooltip then
		return tooltip( ... )
	end
end

local function ShowToolTipAndPicture( controls, tip, index, altlas )
	controls.Text:SetText( tip )
	if _bShowToolTipIcon then
		controls.PortraitFrame:SetHide( not ( altlas and IconHookup( index, 256, altlas, controls.Portrait ) ) )
		controls.PortraitFrame:SetAnchor( GetMousePos() > 300 and "L,C" or "R,C" )
	end
	controls.Grid:DoAutoSize()
	controls.Grid:SetHide( not tip )
end
local function ShowItemToolTipAndPicture( ... )
	return ShowToolTipAndPicture( _cItemTooltip, ... )
end
LuaEvents.ShowItemToolTipAndPicture.Add( ShowItemToolTipAndPicture )

local function ShowTextToolTip( ... )
	return ShowItemToolTipAndPicture( ... and concat( {...}, "[NEWLINE]----------------[NEWLINE]" ) )
end

--==========================================================
-- Resource Tooltip
--==========================================================

local function ShowResourceToolTip( resourceID, tips )
	local resource = GameInfo.Resources[ resourceID ]
	if resource then
		local activePlayerID = GetActivePlayer()
		local activeTeamID = GetActiveTeam()
		local activePlayer = Players[activePlayerID]
		local activeTeam = Teams[activeTeamID]
		local activeCivilizationID = activePlayer:GetCivilizationType()
		local activeCivilization = GameInfo.Civilizations[ activeCivilizationID ]
		local activeTeamTechs = activeTeam:GetTeamTechs()

		local resourceID = resource.ID
		local nResourceUsed = activePlayer:GetNumResourceUsed( resourceID )
		local nResourceAvailable = activePlayer:GetNumResourceAvailable( resourceID, true )	-- same as (total - used)
		local nResourceExport = activePlayer:GetResourceExport( resourceID )
		local nResourceImport = activePlayer:GetResourceImport( resourceID ) + activePlayer:GetResourceFromMinors( resourceID )
		local nResourceLocal = activePlayer:GetNumResourceTotal( resourceID, false ) + nResourceExport

--	if resourceID and GetResourceUsageType(resourceID) == RESOURCEUSAGE_STRATEGIC then

		insert( tips, ColorizeAbs( nResourceAvailable ) .. tostring( resource.IconString ) .. " " .. ToUpper( tostring( resource._Name ) ) )
		insert( tips, "----------------" )

		----------------------------
		-- Local Resources in Cities
		----------------------------
		insert( tips, L( "[NEWLINE]{1} {TXT_KEY_EO_LOCAL_RESOURCES}", Colorize( nResourceLocal ) ) )

		-- Resources from city terrain
		for city in activePlayer:Cities() do
			local nConnectedResource = 0
			local nUnconnectedResource = 0
			for plot in CityPlots( city ) do
				local nResource = plot:GetNumResource()
				if nResource > 0  and resourceID == plot:GetResourceType( activeTeamID ) then
					if plot:IsCity() or (not plot:IsImprovementPillaged() and plot:IsResourceConnectedByImprovement( plot:GetImprovementType() )) then
						nConnectedResource = nConnectedResource + nResource
					else
						nUnconnectedResource = nUnconnectedResource + nResource
					end
				end
			end
			local tip = ""
			if nConnectedResource > 0 then
				tip = " " .. ColorizeAbs( nConnectedResource ) .. tostring( resource.IconString )
			end
			if nUnconnectedResource > 0 then
				tip = tip .. " " .. ColorizeAbs( -nUnconnectedResource ) .. tostring( resource.IconString )
			end
			if #tip > 0 then
				insert( tips, "[ICON_BULLET]" .. city:GetName() .. tip )
			end
		end
		local tipIndex = #tips
		if _bCiv5notVanilla then
			-- Resources from buildings
			for row in GameInfo.Building_ResourceQuantity{ ResourceType = resource.Type } do
				local building = GameInfo.Buildings[ row.BuildingType ]
				local nResource = row.Quantity
				if building and nResource and nResource > 0 then
					local buildingID = building.ID
					-- count how many such buildings player has
					local nExisting = activePlayer:CountNumBuildings( buildingID )
					-- count how many such units player is building
					local nBuilds = 0
					for city in activePlayer:Cities() do
						if city:GetProductionBuilding() == buildingID then
							nBuilds = nBuilds + 1
						end
					end
					-- can player build this building someday ?
					local canBuildSomeday
					-- check whether this Unit has been blocked out by the civ XML
					local buildingOverride = GameInfo.Civilization_BuildingClassOverrides{ CivilizationType = activeCivilization.Type, BuildingClassType = building.BuildingClass }()
					if buildingOverride then
						canBuildSomeday = buildingOverride.BuildingType == building.Type
					else
						canBuildSomeday = (GameInfo.BuildingClasses[ building.BuildingClass ] or {}).DefaultBuilding == building.Type
					end
					if canBuildSomeday and
						-- no espionage buildings for a non-espionage game
						( ( _bEspionageDisabled and building.IsEspionage )
						-- is building obsolete by tech?
						or ( building.ObsoleteTech and activeTeamTechs:HasTech( GameInfoTypes[building.ObsoleteTech] ) ) )
					then
						canBuildSomeday = false
					end
					if canBuildSomeday or nExisting > 0 or nBuilds > 0 then
						local totalResource = (nExisting + nBuilds) * nResource
						local tip = "[COLOR_YIELD_FOOD]" .. tostring( building._Name ) .. "[ENDCOLOR]"
						if canBuildSomeday then
							local tech = GameInfo.Technologies[ building.PrereqTech ]
							if tech and not activeTeamTechs:HasTech( tech.ID ) then
								tip = tip .. " [COLOR_CYAN]" .. tostring( tech._Name ) .. "[ENDCOLOR]"
							end
							local policyBranch = GameInfo.PolicyBranchTypes[ building.PolicyBranchType ]
							if policyBranch and not activePlayer:GetPolicyBranchChosen( policyBranch.ID ) then
								tip = tip .. " [COLOR_MAGENTA]" .. tostring( policyBranch._Name ) .. "[ENDCOLOR]"
							end
						end
						if totalResource > 0 then
							tipIndex = tipIndex+1
							insert( tips, tipIndex, "[ICON_BULLET]" .. totalResource .. tostring( resource.IconString ) .. " = " ..  nExisting .. " (+" .. nBuilds .. ") " .. tip )
						else
							insert( tips, "[ICON_BULLET] (" .. nResource .. "/" .. tip .. ")" )
						end
					end
				end
			end
		end
		----------------------------
		-- Import & Export Breakdown
		----------------------------

		-- Get specified resource traded with the active player

		local itemType, duration, finalTurn, data1, data2, data3, flag1, fromPlayerID
		local gameTurn = Game.GetGameTurn()-1
		local Exports = {}
		local Imports = {}
		for playerID = 0, MAX_MAJOR_CIVS-1 do
			Exports[ playerID ] = {}
			Imports[ playerID ] = {}
		end
		PushScratchDeal()
		for i = 0, UI.GetNumCurrentDeals( activePlayerID ) - 1 do
			UI.LoadCurrentDeal( activePlayerID, i )
			local otherPlayerID = ScratchDeal:GetOtherPlayer( activePlayerID )
			ScratchDeal:ResetIterator()
			repeat
				if _bCiv5BNWorBE then
					itemType, duration, finalTurn, data1, data2, data3, flag1, fromPlayerID = ScratchDeal:GetNextItem()
				else
					itemType, duration, finalTurn, data1, data2, fromPlayerID = ScratchDeal:GetNextItem()
				end
				-- data1 is resourceID, data2 is quantity

				if itemType == TRADE_ITEM_RESOURCES and data1 == resourceID and data2 then
					if fromPlayerID == activePlayerID then
						Exports[otherPlayerID][finalTurn] = (Exports[otherPlayerID][finalTurn] or 0) + data2
					else
						Imports[fromPlayerID][finalTurn] = (Imports[fromPlayerID][finalTurn] or 0) + data2
					end
				end
			until not itemType
		end
		PopScratchDeal()

		----------------------------
		-- Resource Imports
		----------------------------
		if nResourceImport > 0 then
			insert( tips, L( "[NEWLINE]{1} {TXT_KEY_RESOURCES_IMPORTED}", Colorize(nResourceImport) ) )
			for playerID, row in pairs( Imports ) do
				local tip = ""
				for turn, quantity in pairs( row ) do
					if quantity > 0 then
						tip = tip .. " " .. quantity .. tostring( resource.IconString ) .. "(" .. turn - gameTurn .. ")"
					end
				end
				if #tip > 0 then
					insert( tips, "[ICON_BULLET]" .. Players[ playerID ]:GetCivilizationShortDescription() .. tip )
				end
			end
			for minorID = MAX_MAJOR_CIVS, MAX_CIV_PLAYERS_M1 do
				local minor = Players[ minorID ]
				if minor and minor:IsAlive() and minor:GetAlly() == activePlayerID then
					local quantity = minor:GetResourceExport(resourceID)
					if quantity > 0 then
						insert( tips, "[ICON_BULLET]" .. minor:GetCivilizationShortDescription() .. " " .. quantity .. tostring( resource.IconString ) )
					end
				end
			end
		end
		----------------------------
		-- Resource Exports
		----------------------------
		if nResourceExport > 0 then
			insert( tips, L( "[NEWLINE]{1} {TXT_KEY_RESOURCES_EXPORTED}", Colorize(-nResourceExport) ) )
			for playerID, row in pairs( Exports ) do
				local tip = ""
				for turn, quantity in pairs( row ) do
					if quantity > 0 then
						tip = tip .. " " .. quantity .. tostring( resource.IconString ) .. "(" .. turn - gameTurn .. ")"
					end
				end
				if #tip > 0 then
					insert( tips, "[ICON_BULLET]" .. Players[ playerID ]:GetCivilizationShortDescription() .. tip )
				end
			end
		end

		----------------------------
		-- Resource Usage Breakdown
		----------------------------
		insert( tips, L( "[NEWLINE]{1} {TXT_KEY_PEDIA_REQ_RESRC_LABEL}", Colorize(-nResourceUsed) ) ) -- TXT_KEY_CITYVIEW_RESOURCE_DEMANDED
		tipIndex = #tips
		for unit in GameInfo.Units() do
			local unitID = unit.ID
			local nResource = Game.GetNumResourceRequiredForUnit( unitID, resourceID )
			if nResource > 0 then
				-- count how many such units player has
				local nExisting = 0
				for unit in activePlayer:Units() do
					if unit:GetUnitType() == unitID then
						nExisting = nExisting + 1
					end
				end
				-- count how many such units player is building
				local nBuilds = 0
				for city in activePlayer:Cities() do
					for i=0, city:GetOrderQueueLength()-1 do
						local queuedOrderType, queuedItemType = city:GetOrderFromQueue( i )
						if queuedOrderType == ORDER_TRAIN and queuedItemType == unitID then
							nBuilds = nBuilds + 1
						end
					end
				end
				-- can player build this unit someday ?
				local canBuildSomeday = true
				if _bCiv5BNWorBE then
					-- does player trait prohibits training this unit ?
					local leader = GameInfo.Leaders[ activePlayer:GetLeaderType() ]
					for leaderTrait in GameInfo.Leader_Traits{ LeaderType = leader.Type } do
						if GameInfo.Trait_NoTrain{ UnitClassType = unit.Class, TraitType = leaderTrait.TraitType }() then
							canBuildSomeday = false
							break
						end
					end
				end
				if canBuildSomeday then
					-- check whether this Unit has been blocked out by the civ XML unit override
					local unitOverride = GameInfo.Civilization_UnitClassOverrides{ CivilizationType = activeCivilization.Type, UnitClassType = unit.Class }()
					if unitOverride then
						canBuildSomeday = unitOverride.UnitType == unit.Type
					else
						canBuildSomeday = GameInfo.UnitClasses[ unit.Class ].DefaultUnit == unit.Type
					end
				end
				canBuildSomeday = canBuildSomeday and not (
					-- one City Challenge?
					( _bOneCityChallenge and (unit.Found or unit.FoundAbroad) )
					-- Faith Requirements?
					or ( _bReligionEnabled and (unit.FoundReligion or unit.SpreadReligion or unit.RemoveHeresy) )
					-- obsolete by tech?
					or ( unit.ObsoleteTech and activeTeamTechs:HasTech( GameInfoTypes[unit.ObsoleteTech] ) )
				)
				if canBuildSomeday or nExisting > 0 or nBuilds > 0 then
					local totalResource = (nExisting + nBuilds) * nResource
					local tip = "[COLOR_YELLOW]" .. tostring( unit._Name ) .. "[ENDCOLOR]"
					if canBuildSomeday then
						-- Tech requirements
						local tech = GameInfo.Technologies[ unit.PrereqTech ]
						if tech and not activeTeamTechs:HasTech( tech.ID ) then
							tip = format( "%s [COLOR_CYAN]%s[ENDCOLOR]", tip, tostring( tech._Name ) )
						end
						-- Policy Requirement
						local policy = _bCiv5BNW and GameInfo.Policies[ unit.PolicyType ]
						if policy and not activePlayer:HasPolicy( policy.ID ) then
							tip = format( "%s [COLOR_MAGENTA]%s[ENDCOLOR]", tip, tostring( policy._Name ) )
						end
						if _bCivBE then
							-- Affinity Level Requirements
							for affinityPrereq in GameInfo.Unit_AffinityPrereqs{ UnitType = unit.Type } do
								local affinityInfo = ( tonumber( affinityPrereq.Level) or 0 ) > 0 and GameInfo.Affinity_Types[ affinityPrereq.AffinityType ]
								if affinityInfo and activePlayer:GetAffinityLevel( affinityInfo.ID ) < affinityPrereq.Level then
									tip = format("%s [%s]%i%s%s[ENDCOLOR]", tip, tostring( affinityInfo.ColorType ), tostring( affinityPrereq.Level ), tostring( affinityInfo.IconString ), tostring( affinityInfo._Name ) )
								end
							end
						end
					end
					if totalResource > 0 then
						tipIndex = tipIndex+1
						insert( tips, tipIndex, "[ICON_BULLET]" .. totalResource .. tostring( resource.IconString ) .. " = " ..  nExisting .. " (+" .. nBuilds .. ") " .. tip )
					else
						insert( tips, "[ICON_BULLET] (" .. nResource .. "/" .. tip .. ")" )
					end
				end
			end
		end
		for building in GameInfo.Buildings() do
			local buildingID = building.ID
			local nResource = Game.GetNumResourceRequiredForBuilding( buildingID, resourceID )
			if nResource > 0 then
				-- count how many such buildings player has
				local nExisting = activePlayer:CountNumBuildings( buildingID )
				-- count how many such units player is building
				local nBuilds = 0
				for city in activePlayer:Cities() do
					for i=0, city:GetOrderQueueLength()-1 do
						local queuedOrderType, queuedItemType = city:GetOrderFromQueue( i )
						if queuedOrderType == ORDER_CONSTRUCT and queuedItemType == buildingID then
							nBuilds = nBuilds + 1
						end
					end
				end
				-- can player build this building someday ?
				local canBuildSomeday
				-- check whether this Unit has been blocked out by the civ XML
				local buildingOverride = GameInfo.Civilization_BuildingClassOverrides{ CivilizationType = activeCivilization.Type, BuildingClassType = building.BuildingClass }()
				if buildingOverride then
					canBuildSomeday = buildingOverride.BuildingType == building.Type
				else
					canBuildSomeday = (GameInfo.BuildingClasses[ building.BuildingClass ] or {}).DefaultBuilding == building.Type
				end
				canBuildSomeday = canBuildSomeday and not (
					-- no espionage buildings for a non-espionage game
					( _bEspionageDisabled and building.IsEspionage )
					-- Has obsolete tech?
					or ( _bCiv5 and building.ObsoleteTech and activeTeamTechs:HasTech( GameInfoTypes[building.ObsoleteTech] ) )
				)
				if canBuildSomeday or nExisting > 0 or nBuilds > 0 then
					local totalResource = (nExisting + nBuilds) * nResource
					local tip = "[COLOR_YIELD_FOOD]" .. tostring( building._Name ) .. "[ENDCOLOR]"
					if canBuildSomeday then
						local tech = GameInfo.Technologies[ building.PrereqTech ]
						if tech and not activeTeamTechs:HasTech( tech.ID ) then
							tip = format( "%s [COLOR_CYAN]%s[ENDCOLOR]", tip, tostring( tech._Name ) )
						end
						local policyBranch = _bCiv5BNW and GameInfo.PolicyBranchTypes[ building.PolicyBranchType ]
						if policyBranch and not activePlayer:GetPolicyBranchChosen( policyBranch.ID ) then
							tip = format( "%s [COLOR_MAGENTA]%s[ENDCOLOR]", tip, tostring( policyBranch._Name ) )
						end
						if _bCivBE then
							-- Affinity Level Requirements
							for affinityPrereq in GameInfo.Building_AffinityPrereqs{ BuildingType = building.Type } do
								local affinityInfo = (tonumber( affinityPrereq.Level) or 0 ) > 0 and GameInfo.Affinity_Types[ affinityPrereq.AffinityType ]
								if affinityInfo and activePlayer:GetAffinityLevel( affinityInfo.ID ) < affinityPrereq.Level then
									tip = format("%s [%s]%i%s%s[ENDCOLOR]", tip, tostring( affinityInfo.ColorType ), tostring( affinityPrereq.Level ), tostring( affinityInfo.IconString ), tostring( affinityInfo._Name ) )
								end
							end
						end
					end
					if totalResource > 0 then
						tipIndex = tipIndex+1
						insert( tips, tipIndex, "[ICON_BULLET]" .. totalResource .. tostring( resource.IconString ) .. " = " ..  nExisting .. " (+" .. nBuilds .. ") " .. tip )
					else
						insert( tips, "[ICON_BULLET] (" .. nResource .. "/" .. tip .. ")" )
					end
				end
			end
		end
		local nHappinessFromLuxury = resource.Happiness or 0
		if nHappinessFromLuxury > 0 and activePlayer:GetNumResourceAvailable( resourceID, true ) < 2 then
			local excessHappiness = activePlayer:GetExcessHappiness()
			if not activePlayer:IsEmpireUnhappy() then
				insert( tips, format( "%+i[ICON_HAPPINESS_1] (%i[ICON_HAPPINESS_1])", nHappinessFromLuxury, excessHappiness ) )
			elseif activePlayer:IsEmpireVeryUnhappy() then
				insert( tips, format( "%+i[ICON_HAPPINESS_1] (%i[ICON_HAPPINESS_4])", nHappinessFromLuxury, -excessHappiness ) )
			else
				insert( tips, format( "%+i[ICON_HAPPINESS_1] (%i[ICON_HAPPINESS_3])", nHappinessFromLuxury, -excessHappiness ) )
			end
		end
		for city in activePlayer:Cities() do
			if city:GetResourceDemanded() == resourceID and city:GetWeLoveTheKingDayCounter() < 1 then
				insert( tips, "[ICON_CITIZEN] " .. city:GetName() )
			end
		end
		for minorPlayerID = MAX_MAJOR_CIVS, MAX_CIV_PLAYERS_M1 do
			local minorPlayer = Players[minorPlayerID]
			if minorPlayer:IsAlive() and ( _bCiv5notVanilla or minorPlayer:GetActiveQuestForPlayer()==MINOR_CIV_QUEST_CONNECT_RESOURCE ) and minorPlayer:GetQuestData1(activePlayerID, MINOR_CIV_QUEST_CONNECT_RESOURCE) == resourceID then
				insert( tips, "[ICON_CITY_STATE] " .. minorPlayer:GetCivilizationShortDescription() )
			end
		end
		----------------------------
		-- Available for Import
		----------------------------
		tipIndex = #tips
		local totalResource = 0
		for playerID = 0, MAX_CIV_PLAYERS_M1 do

			local player = Players[playerID]
			local isMinorCiv = player:IsMinorCiv()

			-- Valid player? - Can't be us, has to be alive, and has to be met
			if playerID ~= activePlayerID
				and player:IsAlive()
				and activeTeam:IsHasMet( player:GetTeam() )
				and not (isMinorCiv and player:IsAllies(activePlayerID))
			then
				local nResource = ( isMinorCiv and player:GetNumResourceTotal(resourceID, false) + player:GetResourceExport( resourceID ) )
					or ( ScratchDeal:IsPossibleToTradeItem(playerID, activePlayerID, TRADE_ITEM_RESOURCES, resourceID, 1) and player:GetNumResourceAvailable(resourceID, false) ) or 0
				if nResource > 0 then
					totalResource = totalResource + nResource
					insert( tips, "[ICON_BULLET]" .. player:GetCivilizationShortDescription() .. " " .. nResource .. tostring( resource.IconString ) )
				end
			end
		end
		if #tips > tipIndex then
			insert( tips, tipIndex+1, L( "[NEWLINE]----------------[NEWLINE]{1} {TXT_KEY_EO_RESOURCES_AVAILBLE}", totalResource ) )
		end
		return ShowItemToolTipAndPicture( concat( tips, "[NEWLINE]" ), resource.PortraitIndex, resource.IconAtlas )
	end
end

LuaEvents.ResourceToolTip.Add( function( control )
	ShowResourceToolTip( control:GetVoid1(), {} )
end)

--==========================================================
-- Civilization Tooltips
--==========================================================
do

local function ShowCivilizationToolTip( toolTip, playerID )
	_cCivilizationTooltip.Text:SetText( toolTip )
	_cCivilizationTooltip.Grid:DoAutoSize()
	local isMinorCiv, isMajorCiv
	local player = Players[ playerID ]
	if player then
		if player:IsMinorCiv() then
			local minorCivInfo = GameInfo.MinorCivilizations[ player:GetMinorCivType() ]
			if minorCivInfo and _bShowCityStateLeaderIcon then
				local textureKey = "TXT_KEY_CSL_ICON_"..tostring( minorCivInfo.Type )
				if HasTextKey( textureKey ) then
--					_cCivilizationTooltip.Leader:SetTextureSizeVal( 200, 200 )
--					_cCivilizationTooltip.Leader:SetTextureOffsetVal( 0, 0 )
					isMinorCiv = _cCivilizationTooltip.Leader:SetTexture( L(textureKey) )
--[[
				else
					local row = GameInfo.Civilization_CityNames{ CityName = "TXT_KEY_CITY_NAME"..minorCivInfo.Type:sub(10,99) }()
--print( minorCivInfo.Type, row and row.CityName )
					local leader = row and GameInfo.Civilization_Leaders{ CivilizationType = row.CivilizationType }()
					leader = leader and GameInfo.Leaders[ leader.LeaderheadType ]
--print( minorCivInfo.Type, leader and leader.Type )
					if leader then
						_cCivilizationTooltip.Leader:SetTextureSizeVal( 254, 254 )
						isMinorCiv = IconHookup( leader.PortraitIndex, 256, leader.IconAtlas, _cCivilizationTooltip.Leader )
					end
--]]
				end
			end
		else
			local leader = GameInfo.Leaders[ player:GetLeaderType() ]
			isMajorCiv = leader and IconHookup( leader.PortraitIndex, _cCivilizationTooltip.Portrait:GetSizeY(), leader.IconAtlas, _cCivilizationTooltip.Portrait )
			CivIconHookup( playerID, _cCivilizationTooltip.CivIconBG:GetSizeY(), _cCivilizationTooltip.CivIcon, _cCivilizationTooltip.CivIconBG, _cCivilizationTooltip.CivIconShadow, false, true )
		end
	end
	_cCivilizationTooltip.MajorCiv:SetHide( not isMajorCiv )
	_cCivilizationTooltip.MinorCiv:SetHide( not isMinorCiv )
end

local function TooltipWithRemainingTurns( toolTip, remainingTurns )
	toolTip = L( toolTip )
	if remainingTurns and remainingTurns > 0 then
		toolTip =  L( "{2} {TXT_KEY_STR_TURNS})", remainingTurns, toolTip )
	end
	return toolTip
end

local function TooltipAndGetRemainingTurns( toolTip, tradeableItemID, fromPlayerID, toPlayerID )
	PushScratchDeal()
	local activePlayerID = GetActivePlayer()
	for i = 0, UI.GetNumCurrentDeals( activePlayerID ) - 1 do
		UI.LoadCurrentDeal( activePlayerID, i )
		if not toPlayerID or toPlayerID == activePlayerID or toPlayerID == ScratchDeal:GetOtherPlayer( activePlayerID ) then
			ScratchDeal:ResetIterator()
			local itemID
			repeat
				local item = { ScratchDeal:GetNextItem() }
				itemID = item[1]
				if itemID == tradeableItemID and item[#item] == fromPlayerID then
					PopScratchDeal()
					return TooltipWithRemainingTurns( toolTip, item[3] - Game.GetGameTurn() + 1 )
				end
			until not itemID
		end
	end
	PopScratchDeal()
	return L(toolTip)
end

local function Pledge( playerID )
	local player = Players[ playerID ]
	if player and player.CanMajorWithdrawProtection then
		local toolTip = L( "TXT_KEY_NOTIFICATION_SUMMARY_QUEST_COMPLETE_PLEDGE_TO_PROTECT", player:GetCivilizationShortDescriptionKey() )
		if player:CanMajorWithdrawProtection( GetActivePlayer() ) then
			return L( "{1}[NEWLINE]{TXT_KEY_POP_CSTATE_REVOKE_PROTECTION_TT}", toolTip )
		else
			return L( "{2}[NEWLINE]{TXT_KEY_POP_CSTATE_REVOKE_PROTECTION_DISABLED_COMMITTED_TT}", player:GetTurnLastPledgedProtectionByMajor( GetActivePlayer() ) + 10 - Game.GetGameTurn(), toolTip )
		end
	else
		return L"TXT_KEY_POP_CSTATE_PLEDGE_TO_PROTECT"
	end
end

local function CivilizationStatusToolTip( playerID )
	local player = Players[ playerID ]
	if player:IsMinorCiv() then
		return GetCityStateStatusToolTip( GetActivePlayer(), playerID, true )
	else
		return GetMoodInfo( playerID, true )
	end
end

local CivilizationToolTips = {

	Button = CivilizationStatusToolTip,

	Quests = function( playerID )
		return GetActiveQuestToolTip( GetActivePlayer(), playerID )
	end;

	Ally = function( playerID )
		return GetAllyToolTip( GetActivePlayer(), playerID )
	end;

	Pledge1 = Pledge,
	Pledge2 = Pledge,

	Spy = function( playerID )
		local player = Players[ playerID ]
		local activePlayer = Players[ GetActivePlayer() ]
		if player and activePlayer then
			local spy
			for _, s in ipairs( activePlayer:GetEspionageSpies() ) do
				local plot = GetPlot( s.CityX, s.CityY )
				local city = plot and plot:GetPlotCity()
				if city and city:GetOwner() == playerID then
					spy = s
					break
				end
			end
			if spy then
				return L( "TXT_KEY_CITY_SPY_CITY_STATE_TT", spy.Rank, spy.Name, player:GetCivilizationShortDescriptionKey(), spy.Rank, spy.Name)
			end
		end
	end;

	DeclarationOfFriendship = function( playerID )
		local toolTipKey = "TXT_KEY_DIPLOMACY_FRIENDSHIP_ADV_QUEST"
		local activePlayer = Players[ GetActivePlayer() ]
		if activePlayer and activePlayer.GetDoFCounter then
			return TooltipWithRemainingTurns( toolTipKey, _iRelationshipDuration - activePlayer:GetDoFCounter( playerID ) )
		else
			return L(toolTipKey)
		end
	end;

	ResearchAgreement = function( playerID )
		return TooltipAndGetRemainingTurns( "TXT_KEY_DO_RESEARCH_AGREEMENT", TradeableItems.TRADE_ITEM_RESEARCH_AGREEMENT, playerID )
	end;

	DefenseAgreement = function( playerID )
		return TooltipAndGetRemainingTurns( "TXT_KEY_DO_PACT", TradeableItems.TRADE_ITEM_DEFENSIVE_PACT, playerID )
	end;

	TheirBordersClosed = function()
		return L"TXT_KEY_EUI_CLOSED_BORDERS_THEIR"
	end;

	OurBordersClosed = function()
		return L"TXT_KEY_EUI_CLOSED_BORDERS_YOUR"
	end;

	TheirBordersOpen = function( playerID )
		local toolTip = "TXT_KEY_EUI_OPEN_BORDERS_THEIR"
		if not HasTextKey( toolTip ) then
			toolTip = L( "TXT_KEY_DO_THEY_PROVIDE", "TXT_KEY_DO_OPEN_BORDERS" )
		end
		return TooltipAndGetRemainingTurns( toolTip, TradeableItems.TRADE_ITEM_OPEN_BORDERS, playerID )
	end;

	OurBordersOpen = function( playerID )
		local toolTip = "TXT_KEY_EUI_OPEN_BORDERS_YOUR"
		if not HasTextKey( toolTip ) then
			toolTip = L( "TXT_KEY_DO_WE_PROVIDE", "TXT_KEY_DO_OPEN_BORDERS" )
		end
		return TooltipAndGetRemainingTurns( toolTip, TradeableItems.TRADE_ITEM_OPEN_BORDERS, GetActivePlayer(), playerID )
	end;

	ActivePlayer = function()
		return L"TXT_KEY_YOU"
	end;

	War = function( playerID )
		local player = Players[ playerID ]
		local activeTeam = Teams[ GetActiveTeam() ]
		if player and activeTeam then
			local tips = { L( "TXT_KEY_AT_WAR_WITH", player:GetCivilizationShortDescriptionKey() ) }
			local teamID = player:GetTeam()
			local lockedWarTurns = activeTeam:GetNumTurnsLockedIntoWar( teamID )
			if lockedWarTurns > 0 then
				insert( tips, L( "TXT_KEY_DIPLO_NEGOTIATE_PEACE_BLOCKED_TT", lockedWarTurns ) )
			elseif not activeTeam:CanChangeWarPeace( teamID ) then
				insert( tips, L"TXT_KEY_PEACE_BLOCKED" )
			end
-- todo TradeableItems.TRADE_ITEM_THIRD_PARTY_WAR & permanent war
			return concat( tips, "[NEWLINE]" )
		end
	end;

	Score = function( playerID )
		local player = Players[ playerID ]
		if player then
			local tips = { L"TXT_KEY_POP_SCORE" .. " " .. player:GetScore(),	--TXT_KEY_VP_SCORE
						"----------------",
						L( "TXT_KEY_DIPLO_MY_SCORE_CITIES", player:GetScoreFromCities() ),
						L( "TXT_KEY_DIPLO_MY_SCORE_POPULATION", player:GetScoreFromPopulation() ),
						L( "TXT_KEY_DIPLO_MY_SCORE_LAND", player:GetScoreFromLand() ),
						L( "TXT_KEY_DIPLO_MY_SCORE_WONDERS", player:GetScoreFromWonders() ) }
			--CPP
			if player.GetScoreFromMinorAllies then
				insert( tips, L( "TXT_KEY_DIPLO_MY_SCORE_ALLIES", player:GetScoreFromMinorAllies() ) )
			end
			--CPP
			if player.GetScoreFromMilitarySize then
				insert( tips, L( "TXT_KEY_DIPLO_MY_SCORE_MILITARY", player:GetScoreFromMilitarySize() ) )
			end

			if _bScienceEnabled then
				insert( tips, L("TXT_KEY_DIPLO_MY_SCORE_TECH", player:GetScoreFromTechs() ) )
				insert( tips, L("TXT_KEY_DIPLO_MY_SCORE_FUTURE_TECH", player:GetScoreFromFutureTech() ) )
			end
			if _bReligionEnabled then
				insert( tips, L("TXT_KEY_DIPLO_MY_SCORE_RELIGION", player:GetScoreFromReligion() ) )
			end
			if _bPoliciesEnabled and player.GetScoreFromPolicies then
				insert( tips, L("TXT_KEY_DIPLO_MY_SCORE_POLICIES", player:GetScoreFromPolicies() ) )
			end
			if player.GetScoreFromGreatWorks then
				insert( tips, L("TXT_KEY_DIPLO_MY_SCORE_GREAT_WORKS", player:GetScoreFromGreatWorks() ) )
			end
			for i = 1, 4 do
				local s = "TXT_KEY_DIPLO_MY_SCORE_SCENARIO"..i
				local f = player["GetScoreFromScenario"..i]
				if f and HasTextKey( s ) then
					insert( tips, L( s, f(player) ) )
				end
			end
			return concat( tips, "[NEWLINE]" )
		end
	end;

	Gold = function( playerID )
		local player = Players[ playerID ]
		if player then
			local team = Teams[ player:GetTeam() ]
			if team and team:IsAtWar( GetActiveTeam() ) then
				return L"TXT_KEY_DIPLO_MAJOR_CIV_DIPLO_STATE_WAR"
			elseif not player.IsDoF or player:IsDoF( GetActivePlayer() ) then
				return L"TXT_KEY_REPLAY_DATA_TOTALGOLD"
			else
				return L"TXT_KEY_REPLAY_DATA_GOLDPERTURN"
			end
		end
	end;

	TheirTradeItems = function( playerID )
		local player = Players[ playerID ]
		if player then
			-- Resources available from them
			local activePlayerID = GetActivePlayer()
			local tips = { L( "TXT_KEY_DIPLO_ITEMS_LABEL", player:GetCivilizationAdjective() ) }
			for usage = RESOURCEUSAGE_LUXURY, RESOURCEUSAGE_STRATEGIC, RESOURCEUSAGE_STRATEGIC - RESOURCEUSAGE_LUXURY do
				for resource in GameInfo.Resources{ ResourceUsage = usage } do
					local resourceID = resource.ID
					-- IsPossibleToTradeItem includes check on min quantity, banned luxes and obsolete strategics
					if ScratchDeal:IsPossibleToTradeItem( playerID, activePlayerID, TRADE_ITEM_RESOURCES, resourceID, 1 ) then
						local a, b = player:GetNumResourceAvailable( resourceID, true ), player:GetNumResourceAvailable( resourceID )
						insert( tips, format( a == b and "%i%s%s" or "%i%s%s (%i)", a, tostring( resource.IconString ), tostring( resource._Name ), b ) )
						for city in Players[ activePlayerID ]:Cities() do
							if city:GetResourceDemanded() == resourceID and city:GetWeLoveTheKingDayCounter() < 1 then
								insert( tips, "[ICON_CITIZEN] " .. city:GetName() )
							end
						end
						for minorPlayerID = MAX_MAJOR_CIVS, MAX_CIV_PLAYERS_M1 do
							local minorPlayer = Players[ minorPlayerID ]
							if minorPlayer:IsAlive() and ( _bCiv5notVanilla or minorPlayer:GetActiveQuestForPlayer()==MINOR_CIV_QUEST_CONNECT_RESOURCE ) and minorPlayer:GetQuestData1(activePlayerID, MINOR_CIV_QUEST_CONNECT_RESOURCE) == resourceID then
								insert( tips, "[ICON_CITY_STATE] " .. minorPlayer:GetCivilizationShortDescription() )
							end
						end
					end
				end
			end
			return concat( tips, "[NEWLINE]" )
		end
	end;

	OurTradeItems = function( playerID )
		local player = Players[ playerID ]
		if player then
			local activePlayerID = GetActivePlayer()
			local activePlayer = Players[ activePlayerID ]
			local tips = { L"TXT_KEY_DIPLO_YOUR_ITEMS_LABEL" }
			-- Resources available from us
			for usage = RESOURCEUSAGE_LUXURY, RESOURCEUSAGE_STRATEGIC, RESOURCEUSAGE_STRATEGIC - RESOURCEUSAGE_LUXURY do
				for resource in GameInfo.Resources{ ResourceUsage = usage } do
					-- IsPossibleToTradeItem includes check on min quantity, banned luxes and obsolete strategics
					if ScratchDeal:IsPossibleToTradeItem( activePlayerID, playerID, TRADE_ITEM_RESOURCES, resource.ID, 1 )
						and player:GetNumResourceAvailable( resource.ID, true ) <= player:GetNumCities() -- game limit on AI trading of strategics; no effect on luxes
					then
						local a, b = activePlayer:GetNumResourceAvailable( resource.ID, true ), activePlayer:GetNumResourceAvailable( resource.ID )
						insert( tips, format( a == b and "%i%s%s" or "%i%s%s (%i)", a, tostring( resource.IconString ), tostring( resource._Name ), b ) )
					end
				end
			end
			return concat( tips, "[NEWLINE]" ), activePlayerID
		end
	end;

	Host = function()
		return L"TXT_KEY_HOST"
	end;

	Connection = function( playerID )
		local player = Players[ playerID ]
		if player then
			local toolTip
			if Network.IsPlayerHotJoining(playerID) then
				toolTip = L"TXT_KEY_MP_PLAYER_CONNECTING"
			elseif player:IsConnected() then
				toolTip = L"TXT_KEY_MP_PLAYER_CONNECTED"
			else
				toolTip = L"TXT_KEY_MP_PLAYER_NOTCONNECTED"
			end
			if Matchmaking.GetHostID() == playerID then
				toolTip = L"TXT_KEY_HOST" .. ", "..toolTip
			end
			local playerInfo
			local ping = ""
			if playerID == GetActivePlayer() then
				playerInfo = Network.GetLocalTurnSliceInfo()
			else
				playerInfo = Network.GetPlayerTurnSliceInfo( playerID )
			end
			if PreGame.IsInternetGame() then
				ping = Network.GetPingTime( playerID )
				if ping < 0 then
					ping = ""
				elseif ping == 0 then
					ping= L"TXT_KEY_STAGING_ROOM_UNDER_1_MS"
				elseif ping < 1000 then
					ping = ping .. L"TXT_KEY_STAGING_ROOM_TIME_MS"
				else
					ping = ("%.2f"):format( ping / 1000) .. L"TXT_KEY_STAGING_ROOM_TIME_S"
				end
				if ping>"" then
					ping = L"TXT_KEY_ACTION_PING".." "..ping.." "
				end
			end
			return toolTip .. "[NEWLINE][NEWLINE]"..ping.."Network turn slice: "
				.. playerInfo.Shortest .. " ("
				.. playerInfo.Average .. ") "
				.. playerInfo.Longest
		end
	end;

	Diplomacy = function( playerID )
		if UI.ProposedDealExists( playerID, GetActivePlayer() ) then
			return L"TXT_KEY_DIPLO_REQUEST_INCOMING"
		elseif UI.ProposedDealExists( GetActivePlayer(), playerID ) then
			return L"TXT_KEY_DIPLO_REQUEST_OUTGOING"
		end
	end;
}-- /CivilizationToolTips

LuaEvents.CivilizationToolTips.Add( function( control, playerID )
	local toolTip, ID = TooltipSelect( CivilizationToolTips, control, playerID )
	ShowCivilizationToolTip( toolTip, ID or playerID )
end)

LuaEvents.CivilizationStatusToolTip.Add( function( playerID )
	ShowCivilizationToolTip( CivilizationStatusToolTip( playerID ), playerID )
end)

end

--==========================================================
-- Unit Action Tooltip
--==========================================================
LuaEvents.UnitActionToolTip.Add( function( button )

	local unit = GetHeadSelectedUnit()
	local unitPlayerID = unit and unit:GetOwner()
	local unitPlayer = Players[ unitPlayerID ]
	local unitTeamID = unitPlayer and unitPlayer:GetTeam()
	local unitTeam = Teams[ unitTeamID ]
	local actionID = button:GetVoid1()
	local action = GameInfoActions[actionID]

	if unitTeam and action then
		local unitTechs = unitTeam:GetTeamTechs()
		local actionType = action.Type

		-- Location info
		local unitPlot = unit:GetPlot()
		local x = unit:GetX()
		local y = unit:GetY()

		-- Able to perform action
		local gameCanHandleAction = Game.CanHandleAction( actionID, unitPlot, false )

		-- Cannned help text
		local toolTip = { LL( action.Help ) }
		local disabledTip = { LL( not gameCanHandleAction and action.DisabledHelp ) }

		-- Build data
		local isBuild = action.SubType == ACTIONSUBTYPE_BUILD
		local buildID = action.MissionData
		local build = GameInfo.Builds[ buildID ]
		local strBuildTurnsString = ""

		-- Improvement data
		local improvement = build and GameInfo.Improvements[ build.ImprovementType ]
		local improvementID = improvement and improvement.ID

		-- Feature data
		local featureID = unitPlot:GetFeatureType()
		local feature = GameInfo.Features[ featureID ]

		-- Route data
		local route = build and GameInfo.Routes[ build.RouteType ]

		if actionType == "MISSION_FOUND" then
			_cUnitActionTooltip.UnitActionIcon:SetTextureOffsetVal( 0, 0 )
			_cUnitActionTooltip.UnitActionIcon:SetTexture( "BuildCity64.dds" )
		else
			local info = _tInfoSource[ action.SubType ]
			info = info and info[ actionType ]
			if info then
				IconHookup( info.IconIndex or info.PortraitIndex, 64, info.IconAtlas, _cUnitActionTooltip.UnitActionIcon )
			end
		end

		-- Upgrade unit
		if actionType == "COMMAND_UPGRADE" then

			local nUpgradeUnitType = unit:GetUpgradeUnitType()
			local nUpgradePrice = unit:UpgradePrice(nUpgradeUnitType)
			local unitUpgradeInfo = GameInfo.Units[nUpgradeUnitType]

			if unitUpgradeInfo then
				insert( toolTip, L( "TXT_KEY_UPGRADE_HELP", "[COLOR_UNIT_TEXT]"..tostring( unitUpgradeInfo._Name ).."[ENDCOLOR]", nUpgradePrice ) )
				insert( toolTip, "----------------" )
				insert( toolTip, GetHelpTextForUnit( nUpgradeUnitType, true ) )
			end

			if not gameCanHandleAction then
				insert( toolTip, "----------------" )

				-- Can't upgrade because we're outside our territory
				if unitPlot:GetOwner() ~= unit:GetOwner() then
					insert( disabledTip, L"TXT_KEY_UPGRADE_HELP_DISABLED_TERRITORY" )
				end

				-- Can't upgrade because we're outside of a city
				if unit:GetDomainType() == DOMAIN_AIR and not unitPlot:IsCity() then
					insert( disabledTip, L"TXT_KEY_UPGRADE_HELP_DISABLED_CITY" )
				end

				-- Can't upgrade because we lack the Gold
				if nUpgradePrice > unitPlayer:GetGold() then
					insert( disabledTip, L"TXT_KEY_UPGRADE_HELP_DISABLED_GOLD" )
				end

				-- Can't upgrade because we lack the Resources
				local resourcesNeeded = {}
				for resource in GameInfo.Resources() do
					local nResourceNeededToUpgrade = unit:GetNumResourceNeededToUpgrade(resource.ID)
					if nResourceNeededToUpgrade > 0 and nResourceNeededToUpgrade > unitPlayer:GetNumResourceAvailable(resource.ID) then
						insert( resourcesNeeded, nResourceNeededToUpgrade .. " " .. tostring( resource.IconString ) .. " " .. tostring( resource._Name ) )
					end
				end
				if #resourcesNeeded > 0 then
					insert( disabledTip, L( "TXT_KEY_UPGRADE_HELP_DISABLED_RESOURCES", concat( resourcesNeeded, ", " ) ) )
				end

				-- if we can't upgrade due to stacking
				if unitPlot:GetNumFriendlyUnitsOfType(unit) > 1 then
					insert( disabledTip, L"TXT_KEY_UPGRADE_HELP_DISABLED_STACKING" )
				end
			end

		elseif actionType == "MISSION_ALERT" and not unit:IsEverFortifyable() then

			insert( disabledTip, L"TXT_KEY_MISSION_ALERT_NO_FORTIFY_HELP" )

		elseif actionType == "MISSION_HEAL" then

			toolTip = { L( "TXT_KEY_MISSION_HEAL_HELP_2", ( GetUnitHealProgress( unit, unitPlot ) ) ) } -- overwrite canned help text

		-- Golden Age
		elseif actionType == "MISSION_GOLDEN_AGE" then

			toolTip = { L( "TXT_KEY_MISSION_START_GOLDENAGE_HELP", unit:GetGoldenAgeTurns() ) } -- overwrite canned help text

		-- Spread Religion -- gk+ only
		elseif actionType == "MISSION_SPREAD_RELIGION" then
			if unit.GetMajorityReligionAfterSpread then
				local eMajorityReligion = unit:GetMajorityReligionAfterSpread()
				insert( toolTip, L("TXT_KEY_MISSION_SPREAD_RELIGION_RESULT", Game.GetReligionName(unit:GetReligion()), unit:GetNumFollowersAfterSpread() ) .. " " ..
						( eMajorityReligion < RELIGION_PANTHEON and L"TXT_KEY_MISSION_MAJORITY_RELIGION_NONE" or L("TXT_KEY_MISSION_MAJORITY_RELIGION", Game.GetReligionName(eMajorityReligion) ) ) )
			end
		-- Create Great Work -- bnw only
		elseif actionType == "MISSION_CREATE_GREAT_WORK" then
			if unit.GetGreatWorkSlotType then
				local eGreatWorkSlotType = unit:GetGreatWorkSlotType()
				local building = GameInfo.Buildings[ unitPlayer:GetBuildingOfClosestGreatWorkSlot(x, y, eGreatWorkSlotType) ]
				local city = unitPlayer:GetCityOfClosestGreatWorkSlot(x, y, eGreatWorkSlotType)
				if building and city then
					insert( toolTip, L( "TXT_KEY_MISSION_CREATE_GREAT_WORK_RESULT", building.Description, city:GetNameKey() ) )
				end
			end

		-- Paradrop
		elseif actionType == "INTERFACEMODE_PARADROP" then -- MISSION_PARADROP
			toolTip = { L( "TXT_KEY_INTERFACEMODE_PARADROP_HELP_WITH_RANGE", unit:GetDropRange() ) } -- overwrite canned help text

		-- Sell Exotic Goods -- bnw only
		elseif actionType == "MISSION_SELL_EXOTIC_GOODS" then
			if unit.GetExoticGoodsGoldAmount then
				insert( toolTip, "+" .. unit:GetExoticGoodsGoldAmount() .. ICON_GOLD )
				insert( toolTip, L( "TXT_KEY_EXPERIENCE_POPUP", unit:GetExoticGoodsXPAmount() ) )
			end

		-- Great Scientist
		elseif actionType == "MISSION_DISCOVER" then
			if unit.GetDiscoverAmount then
				insert( toolTip, "+" .. unit:GetDiscoverAmount() .. "[ICON_RESEARCH]" )
			end

		-- Great Engineer
		elseif actionType == "MISSION_HURRY" then
			if gameCanHandleAction and unit.GetHurryProduction then
				insert( toolTip, "+" .. unit:GetHurryProduction(unitPlot) .. "[ICON_PRODUCTION]" )
			end

		-- Great Merchant
		elseif actionType == "MISSION_TRADE" then
			if gameCanHandleAction then
				if unit.GetTradeInfluence then
					insert( toolTip, "+" .. unit:GetTradeInfluence(unitPlot) .. "[ICON_INFLUENCE]" )
				end
				insert( toolTip, "+" .. unit:GetTradeGold(unitPlot) .. ICON_GOLD )
			end

		-- Great Writer, bnw only
		elseif actionType == "MISSION_GIVE_POLICIES" then
			if unit.GetGivePoliciesCulture then
				insert( toolTip, "+" .. unit:GetGivePoliciesCulture() .. "[ICON_CULTURE]" )
			end

		-- Great Musician, bnw only
		elseif actionType == "MISSION_ONE_SHOT_TOURISM" then
			if unit.GetBlastTourism then
				insert( toolTip, "+" .. unit:GetBlastTourism() .. "[ICON_TOURISM]" )
			end

		-- Delete unit
		elseif actionType == "COMMAND_DELETE" then
			insert( toolTip, L( "TXT_KEY_SCRAP_HELP", unit:GetScrapGold() ) )

		end

		-- Is this a Worker build?
		if isBuild then

			local nTurnsRemaining = GetUnitBuildProgress( unit, unitPlot, buildID )
			if nTurnsRemaining > 0 then
				strBuildTurnsString = L(" ... {TXT_KEY_STR_TURNS}", nTurnsRemaining )
			end

			-- Extra Yield from this build

			for yieldID = 0, NUM_YIELD_TYPES_M1 do
				local yieldChange = unitPlot:GetYieldWithBuild( buildID, yieldID, false, unitPlayerID ) - unitPlot:CalculateYield(yieldID)

				if yieldChange > 0 then
					insert( toolTip, "[COLOR_POSITIVE_TEXT]+" .. L( _tYieldStrings[yieldID], yieldChange) )
				elseif  yieldChange < 0 then
					insert( toolTip, "[COLOR_NEGATIVE_TEXT]" .. L( _tYieldStrings[yieldID], yieldChange) )
				end
			end

			-- Resource connection
			if improvement then
				local resourceID = unitPlot:GetResourceType( unitTeamID )
				local resource = GameInfo.Resources[resourceID]
				if resource
					and unitPlot:IsResourceConnectedByImprovement( improvementID )
					and GetResourceUsageType(resourceID) ~= RESOURCEUSAGE_BONUS
				then
					insert( toolTip, L( "TXT_KEY_BUILD_CONNECTS_RESOURCE", tostring( resource.IconString ), tostring( resource.Description ) ) )
				end
			end

			-- Production for clearing a feature
			if feature and unitPlot:IsBuildRemovesFeature(buildID) then
				local tip = L( "TXT_KEY_BUILD_FEATURE_CLEARED", tostring( feature.Description ) )
				local featureProduction = unitPlot:GetFeatureProduction( buildID, unitTeamID )
				if featureProduction > 0 then
					tip = tip .. L( "TXT_KEY_BUILD_FEATURE_PRODUCTION", featureProduction )
					local city = unitPlot:GetWorkingCity()
					if city then
						tip = tip .. " (".. city:GetName()..")"
					end
				end
				insert( toolTip, tip )
			end

			if not gameCanHandleAction then

				-- Don't have Tech for Build?
				if improvement or route then
					-- Figure out what the name of the thing is that we're looking at
					local strImpRouteKey = (improvement and improvement.Description) or (route and route.Description) or ""

					local prereqTech = GameInfo.Technologies[build.PrereqTech]
					if prereqTech and not unitTechs:HasTech(prereqTech.ID) then
						insert( disabledTip, L( "TXT_KEY_BUILD_BLOCKED_PREREQ_TECH", prereqTech.Description, strImpRouteKey ) )
					end

					if improvement then
						-- Trying to build something and are not adjacent to our territory? gk+ only
						if improvement.InAdjacentFriendly and unitPlot:GetTeam() ~= unitTeamID and not unitPlot:IsAdjacentTeam(unitTeamID, true) then
							insert( disabledTip, L( "TXT_KEY_BUILD_BLOCKED_NOT_IN_ADJACENT_TERRITORY", strImpRouteKey ) )
						end
						-- Trying to build something in a City-State's territory? bnw only
						if improvement.OnlyCityStateTerritory then
							local unitPlotOwner = Players[unitPlot:GetOwner()]
							if not( unitPlotOwner and unitPlotOwner:IsMinorCiv() ) then
								insert( disabledTip, L( "TXT_KEY_BUILD_BLOCKED_NOT_IN_CITY_STATE_TERRITORY", strImpRouteKey ) )
							end
						end
						-- Trying to build something outside of our territory?
						if improvement.OutsideBorders == false and unitPlot:GetTeam() ~= unitTeamID then
							insert( disabledTip, L( "TXT_KEY_BUILD_BLOCKED_OUTSIDE_TERRITORY", strImpRouteKey ) )
						end
						-- Trying to build something that requires an adjacent luxury? bnw only
						if improvement.AdjacentLuxury then
							local adjacentPlot
							for direction = 0, 5 do  -- DirectionTypes.NUM_DIRECTION_TYPES-1
								adjacentPlot = PlotDirection(x, y, direction)
								if adjacentPlot then
									local eResourceType = adjacentPlot:GetResourceType()
									if eResourceType ~= -1 then
										if GetResourceUsageType(eResourceType) == RESOURCEUSAGE_LUXURY then
											insert( disabledTip, L( "TXT_KEY_BUILD_BLOCKED_NO_ADJACENT_LUXURY", strImpRouteKey ) )
											break
										end
									end
								end
							end
						end
						-- Trying to build something where we can't have two adjacent? bnw only
						if improvement.NoTwoAdjacent then
							local adjacentPlot
							for direction = 0, 5 do -- DirectionTypes.NUM_DIRECTION_TYPES-1
								adjacentPlot = PlotDirection(x, y, direction)
								if adjacentPlot then
									if adjacentPlot:GetImprovementType() == improvementID or adjacentPlot:GetBuildProgress(buildID) > 0 then
										insert( disabledTip, L( "TXT_KEY_BUILD_BLOCKED_CANNOT_BE_ADJACENT", strImpRouteKey ) )
										break
									end
								end
							end
						end
					end -- improvement
				end -- improvement or route

				-- Build blocked by a feature here?
				if unitPlayer:IsBuildBlockedByFeature(buildID, featureID) then
					for row in GameInfo.BuildFeatures{ BuildType = build.Type, FeatureType = feature.Type } do
						local pFeatureTech = GameInfo.Technologies[row.PrereqTech]
						insert( disabledTip, L( "TXT_KEY_BUILD_BLOCKED_BY_FEATURE", pFeatureTech.Description, feature.Description ) )
					end
				end
			end
		elseif not gameCanHandleAction then
			if actionType == "MISSION_FOUND" and unitPlayer:IsEmpireVeryUnhappy() then
				insert( disabledTip, L"TXT_KEY_MISSION_BUILD_CITY_DISABLED_UNHAPPY" )

			elseif actionType == "MISSION_CULTURE_BOMB" and unitPlayer:GetCultureBombTimer() > 0 then
				insert( disabledTip, L( "TXT_KEY_MISSION_CULTURE_BOMB_DISABLED_COOLDOWN", unitPlayer:GetCultureBombTimer() ) )
			end
		end

		if #disabledTip > 0 then
			insert( toolTip, "[COLOR_WARNING_TEXT]" .. concat( disabledTip, "[NEWLINE]" ) .. "[ENDCOLOR]" )
		end

		-- Tooltip
		_cUnitActionTooltip.UnitActionHelp:SetText( concat( toolTip, "[NEWLINE]" ) )

		-- Title
		_cUnitActionTooltip.UnitActionText:SetText( "[COLOR_POSITIVE_TEXT]" .. L( tostring( action.TextKey or actionType ) ) .. "[ENDCOLOR]".. strBuildTurnsString )

		-- HotKey
		if action.HotKey and action.HotKey ~= "" and action.SubType ~= ACTIONSUBTYPE_PROMOTION then
			_cUnitActionTooltip.UnitActionHotKey:SetText( "("..tostring(action.HotKey)..")" )
		else
			_cUnitActionTooltip.UnitActionHotKey:SetText()
		end

		-- Autosize tooltip
		_cUnitActionTooltip.UnitActionMouseover:DoAutoSize()
		local mouseoverSizeX = _cUnitActionTooltip.UnitActionMouseover:GetSizeX()
		if mouseoverSizeX < 350 then
			_cUnitActionTooltip.UnitActionMouseover:SetSizeX( 350 )
		end

	else
		_cUnitActionTooltip.UnitActionMouseover:SetHide( true )
	end
end)

--==========================================================
-- Unit Tooltips
--==========================================================
do
local function UnitToolTip( unit )
	if unit then
		local controls = _cUnitTooltip
		local toolTipString = ShortUnitTip( unit )
		local playerID = unit:GetOwner()
		if playerID == GetActivePlayer() and ( unit:IsCombatUnit() or unit:CanAirAttack() ) then
			toolTipString = toolTipString .."[NEWLINE]".. L( "TXT_KEY_UNIT_EXPERIENCE_INFO", unit:GetLevel(), unit:GetExperience(), unit:ExperienceNeeded() ):gsub("%[NEWLINE%]"," ")
		end
		controls.Text:SetText( toolTipString )
--		controls.Details:SetText( playerID == GetActivePlayer() and L"TXT_KEY_UPANEL_CLICK_TO_SELECT" )
		local i = 0
		local promotionText = {}
		local promotionIcon
		_PromotionIconIM:ResetInstances()
		if not( unit.IsTrade and unit:IsTrade() ) then
			for unitPromotion in GameInfo.UnitPromotions() do
				if unit:IsHasPromotion(unitPromotion.ID) and unitPromotion.ShowInUnitPanel ~= false then
					promotionIcon = _PromotionIconIM:GetInstance()
					IconHookup( unitPromotion.PortraitIndex, 32, unitPromotion.IconAtlas, promotionIcon.Image )
					insert( promotionText, tostring( unitPromotion._Name ) )
				end
			end
		end
		if _bShowUnitIcon then
			local iconIndex, iconAtlas = GetUnitPortraitIcon( unit )
			IconHookup( iconIndex, 256, iconAtlas, controls.UnitPortrait )
			CivIconHookup( playerID, 64, controls.CivIcon, controls.CivIconBG, controls.CivIconShadow, false, true )
			controls.PortraitFrame:SetHide( true )
			controls.PortraitFrame:SetAnchor( GetMousePos() > 300 and "L,T" or "R,T" )
		end
		controls.Details:SetHide( true )
		controls.PromotionText:SetText( concat( promotionText, "[NEWLINE]" ) )
		controls.PromotionText:SetHide( #promotionText ~= 1 )
		controls.IconStack:SetWrapWidth( ceil( i / ceil( i / 10 ) ) * 26 )
		controls.IconStack:CalculateSize()
		controls.Grid:ReprocessAnchoring()
		controls.Grid:DoAutoSize()
		_cUnitTooltipTimer:SetToBeginning()
		_cUnitTooltipTimer:Reverse()
	end
end
LuaEvents.UnitToolTip.Add( UnitToolTip )
LuaEvents.UnitFlagToolTip.Add( function( button )
	local player = Players[ button:GetVoid1() ]
	UnitToolTip( player and player:GetUnitByID( button:GetVoid2() ) )
end)

local UnitToolTips = {
	Button = UnitToolTip,
	MovementPip = function( unit )
		return ShowTextToolTip( unit and format( "%s %.3g / %g [ICON_MOVES]", L"TXT_KEY_UPANEL_MOVEMENT", unit:MovesLeft() / MOVE_DENOMINATOR, unit:MaxMoves() / MOVE_DENOMINATOR )
--[[
.." GetActivityType="..(function(a) for k, v in pairs( ActivityTypes ) do if v==a then return k end end return "unknown" end)(unit:GetActivityType())
.." GetFortifyTurns="..tostring(unit:GetFortifyTurns())
.." HasMoved="..tostring(unit:HasMoved())
.." IsReadyToMove="..tostring(unit:IsReadyToMove())
.." IsWaiting="..tostring(unit:IsWaiting())
.." IsAutomated="..tostring(unit:IsAutomated())
--]]
		)
	end,
	Mission = function( unit )
		local status = "Unkown unit activity"
		if unit then
			local buildID = unit:GetBuildType()
			if buildID ~= -1 then -- this is a worker who is actively building something
				status = tostring( (GameInfo.Builds[ buildID ]or {})._Name ).. " (".. (GetUnitBuildProgress( unit, unit:GetPlot(), buildID )) ..")"

			elseif unit:IsEmbarked() then
				status = L"TXT_KEY_MISSION_EMBARK_HELP" --"TXT_KEY_UNIT_STATUS_EMBARKED"

			elseif unit:IsAutomated() then
				if unit:IsWork() then
					status = L"TXT_KEY_ACTION_AUTOMATE_BUILD"
				elseif unit.IsTrade and unit:IsTrade() then
					status = L"TXT_KEY_ACTION_AUTOMATE_TRADE"
				else
					status = L"TXT_KEY_ACTION_AUTOMATE_EXPLORE"
				end

			else
				local activityType = unit:GetActivityType()
				local info = _tActivityMissions[ activityType ]
				if not info then
					if unit:MovesLeft() > 0 then
						if info == false then
							info = GameInfo.Missions.MISSION_SKIP
						elseif unit:IsGarrisoned() then
							info = GameInfo.Missions.MISSION_GARRISON
						elseif unit:IsEverFortifyable() then
--							info = GameInfo.Missions.MISSION_FORTIFY
							status = format( "%s %+i%%[ICON_STRENGTH]", L"TXT_KEY_UNIT_STATUS_FORTIFIED", unit:FortifyModifier() )
						else
							info = GameInfo.Missions.MISSION_SLEEP
						end
					else
						info = GameInfo.Missions.MISSION_MOVE_TO
					end
				end
				if info then
					status = L(info.Help)
				end
			end
		else
			status = "Error - cannot find unit"
		end
		return ShowTextToolTip( status )
	end,
}
LuaEvents.UnitToolTips.Add( function( ... ) return TooltipSelect( UnitToolTips, ... ) end )

end
--==========================================================
-- Unit Type Tooltip
--==========================================================
LuaEvents.UnitPanelItemTooltip.Add( function( _, itemID ) -- _ is control
	return ShowItemToolTipAndPicture( GetHelpTextForUnit( itemID, true ), GetUnitPortraitIcon( itemID, GetActivePlayer() ) )
end)

--==========================================================
-- City Banner & Ribbon Tooltips
--==========================================================

local function CityIsCapital( city )
	local ownerID = city:GetOwner()
	local owner = Players[ ownerID ]
	local originalOwnerID = city:GetOriginalOwner()
	local originalOwner = Players[ originalOwnerID ]
	local activePlayerID = GetActivePlayer()
	local cityNameKey = city:GetNameKey()
	if city:IsOriginalCapital() then
		if ownerID == originalOwnerID then
			if ownerID == activePlayerID then
				return L( "TXT_KEY_VP_DIPLO_TT_YOU_CONTROL_YOUR_CAPITAL", cityNameKey )
			else
				return L( "TXT_KEY_VP_DIPLO_TT_SOMEONE_CONTROLS_THEIR_CAPITAL", owner:GetName(), cityNameKey )
			end
		end
	else
		for playerID, player in pairs( Players ) do
			for city in player:Cities() do
				if city:IsOriginalCapital() and city:GetOriginalOwner() == originalOwnerID then
					cityNameKey = city:GetNameKey()
					ownerID = playerID
					owner = player
					player = nil
					break
				end
			end
			if not player then
				break
			end
		end
	end
	if ownerID == activePlayerID then
		return L( "TXT_KEY_VP_DIPLO_TT_YOU_CONTROL_OTHER_PLAYER_CAPITAL", cityNameKey, originalOwner:GetCivilizationShortDescriptionKey() )
	elseif originalOwnerID == activePlayerID then
		return L( "TXT_KEY_VP_DIPLO_TT_OTHER_PLAYER_CONTROLS_YOUR_CAPITAL", owner:GetName(), cityNameKey )
	else
		return L( "TXT_KEY_VP_DIPLO_TT_OTHER_PLAYER_CONTROLS_OTHER_PLAYER_CAPITAL", owner:GetName(), cityNameKey, originalOwner:GetCivilizationShortDescriptionKey() )
	end
end

local function CityResist( city )
	return city:IsRazing() and L( "TXT_KEY_CITY_BURNING", city:GetRazingTurns() ) or city:IsResistance() and L( "TXT_KEY_CITY_RESISTANCE", city:GetResistanceTurns() )
end

local function CityProduction( city )
	local tip, iconIndex, iconAtlas
	local orderID, itemID = city:GetOrderFromQueue()
	local isProducing = true
	local bHideMeters = false
	if orderID == ORDER_TRAIN then
		iconIndex, iconAtlas = GetUnitPortraitIcon( itemID, city:GetOwner() )
		tip = GetHelpTextForUnit( itemID, true )

	elseif orderID == ORDER_CONSTRUCT then
		iconIndex, iconAtlas = GetItemPortraitIcon( GameInfo.Buildings, itemID )
		tip = GetHelpTextForBuilding( itemID, false, false, city:GetNumFreeBuilding(itemID) > 0, city )

	elseif orderID == ORDER_CREATE then
		iconIndex, iconAtlas = GetItemPortraitIcon( GameInfo.Projects, itemID )
		tip = GetHelpTextForProject( itemID, true )

	elseif orderID == ORDER_MAINTAIN then
		iconIndex, iconAtlas = GetItemPortraitIcon( GameInfo.Processes, itemID )
		tip = GetHelpTextForProcess( itemID, true )
		isProducing = false
	else
		tip = L( "TXT_KEY_CITY_NOT_PRODUCING", city:GetName() )
		isProducing = false
		bHideMeters = true
	end
	local change = city:GetCurrentProductionDifferenceTimes100( false, false )	-- bIgnoreFood, bool bOverflow
	_cCityProductionTooltip.Meters:SetHide( bHideMeters )
	return ShowProgressToolTip( _cCityProductionTooltip, 256, iconIndex, iconAtlas, tip,
		isProducing and city:GetProductionTurnsLeft(),
		city:GetProductionNeeded() * 100,
		city:GetProductionTimes100() + city:GetCurrentProductionDifferenceTimes100( false, true ) - change,	-- bIgnoreFood, bool bOverflow
		change )
end

local CityToolTips = {
	-- CityBanner ToolTip
	CityBannerButton = function( city )
		if city then
			local nPlayer = city:GetOwner()
			local player = Players[ nPlayer ]
			local cityTeamID = city:GetTeam()
			local activeTeamID = GetActiveTeam()
			local activeTeam = Teams[ activeTeamID ]
			local tip = ""

			-- city resources
			local resources = {}
			for plot in CityPlots( city ) do
				if plot	and plot:IsRevealed( activeTeamID )
				then
					local resourceID = plot:GetResourceType( activeTeamID )
					local nResource = plot:GetNumResource()
					if nResource > 0 then
						if not plot:IsCity() and (plot:IsImprovementPillaged() or not plot:IsResourceConnectedByImprovement( plot:GetImprovementType() )) then
							nResource = nResource / 65536
						end
						resources[ resourceID ] = ( resources[ resourceID ] or 0 ) + nResource
					end
				end
			end
			for resourceID, nResource in pairs( resources ) do
				local resource = GameInfo.Resources[ resourceID ]
				if resource then
					local nConnected, nNotConnected = modf( nResource )
					nNotConnected = nNotConnected * 65536
					local usageID = GetResourceUsageType( resourceID )
					if usageID == RESOURCEUSAGE_STRATEGIC
						or usageID == RESOURCEUSAGE_LUXURY
					then
						if nConnected > 0 then
							tip = tip .. " [COLOR_POSITIVE_TEXT]" .. nConnected .. "[ENDCOLOR]" .. tostring( resource.IconString )
						end
						if nNotConnected > 0 then
							tip = tip .. " [COLOR_WARNING_TEXT]" .. nNotConnected .. "[ENDCOLOR]" .. tostring( resource.IconString )
						end
					end
				end
			end

			if cityTeamID == activeTeamID then

				local cultureStored = city:GetJONSCultureStored()
				local cultureNeeded = city:GetJONSCultureThreshold()
				local nTotalCulturePerTurn = city:GetJONSCulturePerTurn()
				if nTotalCulturePerTurn > 0 then
					tip = L( "{2}[NEWLINE][COLOR_MAGENTA]{TXT_KEY_CITYVIEW_TURNS_TILL_TILE_TEXT}[ENDCOLOR]", max(ceil((cultureNeeded - cultureStored ) / nTotalCulturePerTurn), 1), tip )
				else
					tip = tip .. " 0 [ICON_CULTURE]"
				end

				if city.GetReligiousMajority and city:GetReligiousMajority() < 0 then
					local religionTip =  GetReligionTooltip( city )
					if religionTip and religionTip>"" then
						tip = tip .. "[NEWLINE]" .. religionTip
					end
				end

				if _bBasicHelp then
					if nPlayer == GetActivePlayer() then
						tip = L( "{1}[NEWLINE]{TXT_KEY_CITY_ENTER_CITY_SCREEN}", tip )
					else
						tip = L( "{1}[NEWLINE]{TXT_KEY_CITY_TEAMMATE}", tip )
					end
				end

			elseif activeTeam:IsHasMet( cityTeamID ) then
				if city.GetReligiousMajority and city:GetReligiousMajority() < 0 then
					local religionTip =  GetReligionTooltip( city )
					if religionTip and religionTip>"" then
						tip = tip .. "[NEWLINE]" .. religionTip
					end
				end
				if player.GetWarmongerPreviewString and activeTeam:IsAtWar( cityTeamID ) then
					tip = tip .. "[NEWLINE]"----------------[NEWLINE]"
							.. player:GetWarmongerPreviewString( city:GetOwner(), city, GetActivePlayer() ) --CPP
					if city:GetOriginalOwner() ~= city:GetOwner() then
						tip = tip .. "[NEWLINE]"----------------[NEWLINE]"
								.. player:GetLiberationPreviewString( city:GetOriginalOwner(), city, GetActivePlayer() ) --CPP
					end
				elseif _bAlwaysWar then
					tip = L( "{1}[NEWLINE]{TXT_KEY_ALWAYS_AT_WAR_WITH_CITY}", tip )
				end
			end
			return tip
		end
	end,
	CityBannerRightBackground = function( city )
		local nPlayer = city and city:GetOwner()
		local player = Players[ nPlayer ]
		local activeTeam = Teams[ GetActiveTeam() ]
		if player then
			if activeTeam and activeTeam:IsHasMet( player:GetTeam() ) then
				local tip
				if player:IsMinorCiv() then
					tip = GetCityStateStatusToolTip( GetActivePlayer(), nPlayer, true )
				else
					tip = GetMoodInfo( nPlayer, true )
				end
				if _bBasicHelp then
					tip = L( "{TXT_KEY_TALK_TO_PLAYER}[NEWLINE][NEWLINE]{1}", tip )
				end
				return tip
			else
				-- Players we have not met
				return L"TXT_KEY_HAVENT_MET"
			end
		end
	end,
	BuildGrowth = function( city )
		return CityResist( city ) or L( "{TXT_KEY_CITY_CURRENTLY_PRODUCING_TT}[NEWLINE]----------------[NEWLINE]{4}", city:GetName(), city:GetProductionNameKey(), city:GetProductionTurnsLeft(), GetProductionTooltip( city ) )
	end,
	CityGrowth = function( city )
		local tip
		local foodPerTurnTimes100 = city:FoodDifferenceTimes100()
		if city:IsRazing() then
			return L( "TXT_KEY_CITY_BURNING", city:GetRazingTurns() )
		elseif foodPerTurnTimes100 < 0 then
			tip = L( "TXT_KEY_NTFN_CITY_STARVING", city:GetName() )
		elseif city:IsForcedAvoidGrowth() then
			tip = L"TXT_KEY_CITYVIEW_FOCUS_AVOID_GROWTH_TEXT"
		elseif city:IsFoodProduction() or foodPerTurnTimes100 == 0 then
			tip = L"TXT_KEY_CITYVIEW_STAGNATION_TEXT"
		else
			tip = L( "TXT_KEY_CITYVIEW_TURNS_TILL_CITIZEN_TEXT", city:GetFoodTurnsLeft() )
		end
		return ShowTextToolTip( tip, GetFoodTooltip( city ) )
	end,
	BorderGrowth = function( city )
		return CityResist( city ) or ShowTextToolTip( L("TXT_KEY_CITYVIEW_TURNS_TILL_TILE_TEXT", ceil( (city:GetJONSCultureThreshold() - city:GetJONSCultureStored()) / city:GetJONSCulturePerTurn() ) ), GetCultureTooltip( city ) )
	end,
	CityReligion = function( city )
		return city and GetReligionTooltip( city )
	end,
	CityFocus = function( city )
		return city and _tCityFocusTooltips[city:GetFocusType()]
	end,
	CityQuests = function( city )
		if city then
			local nPlayer = city:GetOwner()
			local player = Players[ nPlayer ]
			if player and player:IsMinorCiv() then
				return GetActiveQuestToolTip( GetActivePlayer(), nPlayer )
			else
				-- We love the king
				local resource = GameInfo.Resources[ city:GetResourceDemanded() ]
				local weLoveTheKingDayCounter = city:GetWeLoveTheKingDayCounter()
				if weLoveTheKingDayCounter > 0 then
					return L( "TXT_KEY_CITYVIEW_WLTKD_COUNTER", weLoveTheKingDayCounter )
				elseif resource then
					return ShowResourceToolTip( resource.ID, { L( "{TXT_KEY_CITYVIEW_RESOURCE_DEMANDED} {2}", tostring( resource.IconString ), tostring( resource._Name ) ) } )
				end
			end
		end
	end,
	CityIsPuppet = function( city )
		local nPlayer = city and city:GetOwner()
		local player = Players[ nPlayer ]
		if player then
			if player.MayNotAnnex and player:MayNotAnnex() or nPlayer ~= GetActivePlayer() then
				return L"TXT_KEY_CITY_PUPPET"
			else
				return L"{TXT_KEY_CITY_PUPPET}[NEWLINE][NEWLINE]{TXT_KEY_CITY_ANNEX_TT}"
			end
		end
	end,
	CityIsRazing = function( city )
		return city and L( "TXT_KEY_CITY_BURNING", city:GetRazingTurns() )
	end,
	CityIsResistance = function( city )
		return city and L( "TXT_KEY_CITY_RESISTANCE", city:GetResistanceTurns() )
	end,
	CityIsConnected = function( city )
		local player = city and Players[ city:GetOwner() ]
		if player then
			local i = (not city:IsCapital() and player:IsCapitalConnectedToCity(city) and ( player:GetHappinessPerTradeRoute() / _iHappinessPerTradeRouteFactor ) or 0)
			return L( "{TXT_KEY_CITY_CONNECTED}[NEWLINE]{TXT_KEY_TP_HAPPINESS_CONNECTED_CITIES}", ((player.GetRouteGoldTimes100 or player.GetCityConnectionRouteGoldTimes100)( player, city ) / 100) ..ICON_GOLD..(i>0 and " & "..i.."[ICON_HAPPINESS_1]" or "") )
		end
	end,
	CityIsBlockaded = function()
		return L"TXT_KEY_CITY_BLOCKADED"
	end,
	CityIsOccupied = function()
		return L"TXT_KEY_CITY_OCCUPIED"
	end,
	CivIndicator = function( city )
		local nPlayer = city:GetOwner()
		local originalCityOwnerID = city:GetOriginalOwner()
		if nPlayer == originalCityOwnerID then
			return GetAllyToolTip( GetActivePlayer(), nPlayer )
		else
			return L( "TXT_KEY_POPUP_CITY_CAPTURE_INFO_LIBERATE", Players[originalCityOwnerID]:GetCivilizationShortDescription() )
		end
	end,
	CityPopulation = function( city )
		local foodStored100 = city:GetFoodTimes100()
		local foodPerTurn100 = city:FoodDifferenceTimes100( true )
		local turnsToCityGrowth = city:GetFoodTurnsLeft()
		local iconIndex = 0
		if foodPerTurn100 < 0 then
			turnsToCityGrowth = floor( foodStored100 / -foodPerTurn100 ) + 1
			iconIndex = 5
		end
		return ShowProgressToolTip( _cCityGrowthTooltip, 256, iconIndex, "CITIZEN_ATLAS",
			city:GetPopulation(),
			turnsToCityGrowth,
			city:GrowthThreshold() * 100,
			foodStored100,
			foodPerTurn100
		)
	end,
	CityResistanceTurns = CityResist,
	CityIsCapital = CityIsCapital,
	CityIsOriginalCapital = CityIsCapital,
	CityProductionBG = CityProduction,
	Button = CityProduction,
}

LuaEvents.CityToolTips.Add( function( control, city )
	if city then
		local tip = TooltipSelect( CityToolTips, control, city )
		if tip then
			ShowTextToolTip( tip ) --city:GetName(),
		end
	end
end)

--==========================================================
-- City View Tooltips
--==========================================================

LuaEvents.CityViewBuildingToolTip.Add( function( control )
	local buildingID = control:GetVoid1()
	local building = GameInfo.Buildings[ buildingID ]
	local city = GetHeadSelectedCity()
	return ShowItemToolTipAndPicture( city and GetHelpTextForBuilding( buildingID, false, false, city:GetNumFreeBuilding(buildingID) > 0, city ), building and building.PortraitIndex, building and building.IconAtlas )
end)

local function CityOrderItemTooltip( city, isDisabled, purchaseYieldID, orderID, itemID, _, isRepeat )
	local itemInfo, tip, strDisabledInfo, item, iconIndex, iconAtlas, isRealRepeat
	if city then
		local nPlayer = city:GetOwner()
		if orderID == ORDER_TRAIN then
			itemInfo = GameInfo.Units
			iconIndex, iconAtlas = GetUnitPortraitIcon( itemID, nPlayer )
			tip = GetHelpTextForUnit( itemID, true )
			isRealRepeat = isRepeat

			if isDisabled then
				if purchaseYieldID == YIELD_GOLD then
					strDisabledInfo = city:GetPurchaseUnitTooltip(itemID)
				elseif purchaseYieldID == YIELD_FAITH then
					strDisabledInfo = city:GetFaithPurchaseUnitTooltip(itemID)
				else
					strDisabledInfo = city:CanTrainTooltip(itemID)
				end
			end

		elseif orderID == ORDER_CONSTRUCT then
			itemInfo = GameInfo.Buildings
			tip = GetHelpTextForBuilding( itemID, false, false, city:GetNumFreeBuilding(itemID) > 0, city )
			if isDisabled then
				if purchaseYieldID == YIELD_GOLD then
--					cash = player:GetGold() - city:GetBuildingPurchaseCost(itemID)
--					icon = ICON_GOLD
					strDisabledInfo = city:GetPurchaseBuildingTooltip(itemID)
				elseif purchaseYieldID == YIELD_FAITH then
--					cash = player:GetFaith() - city:GetBuildingFaithPurchaseCost(itemID)
--					icon = "[ICON_PEACE]"
					strDisabledInfo = city:GetFaithPurchaseBuildingTooltip(itemID)
				else
					strDisabledInfo = city:CanConstructTooltip(itemID)
				end
			end

		elseif orderID == ORDER_CREATE then
			itemInfo = GameInfo.Projects
			tip = GetHelpTextForProject( itemID, true )
		elseif orderID == ORDER_MAINTAIN then
			itemInfo = GameInfo.Processes
			tip = GetHelpTextForProcess( itemID, true )
			isRealRepeat = true
		else
			tip = L"TXT_KEY_PRODUCTION_NO_PRODUCTION"
		end
		if tip then
			if isRealRepeat then
				tip = "[ICON_TURNS_REMAINING]" .. tip
			end
			if strDisabledInfo and #strDisabledInfo > 0 then
				strDisabledInfo = (strDisabledInfo:gsub("^%[NEWLINE%]","")):gsub("^%[NEWLINE%]","")
--				if cash and cash < 0 then
--					strDisabledInfo = ("%s (%+i%s)"):format( strDisabledInfo, cash, icon )
--				end
				tip = "[COLOR_WARNING_TEXT]" .. strDisabledInfo .. "[ENDCOLOR][NEWLINE][NEWLINE]"..tip
			elseif purchaseYieldID then
				if not isDisabled then
					tip = L( "[COLOR_YELLOW]{TXT_KEY_CITYVIEW_PURCHASE_TT}[ENDCOLOR][NEWLINE][NEWLINE]{1}", tip )
				end
			elseif isDisabled then
				tip = L( "[COLOR_YIELD_FOOD]{TXT_KEY_CITYVIEW_QUEUE_PROD_TT}[ENDCOLOR][NEWLINE][NEWLINE]{1}", tip )
			end
		end
		item = itemInfo and itemInfo[itemID]
	end
	return ShowItemToolTipAndPicture( tip, iconIndex or (item and item.PortraitIndex), iconAtlas or (item and item.IconAtlas) )
end

LuaEvents.CityOrderItemTooltip.Add( CityOrderItemTooltip )

local CityViewToolTips = {
	HappinessBox = function( city )
		local player = Players[ city and city:GetOwner() ]
		local tips = { L"TXT_KEY_TP_HAPPINESS_EXPLANATION", "" }
		if player then
			insert( tips, L( "{TXT_KEY_TOPIC_HAPPINESS}: {1}[ICON_HAPPINESS_1]", GetCityHappiness( player, city ) ) )
			-- Local City Happiness
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_CITIES", city.GetLocalHappiness and city:GetLocalHappiness() )
			-- City Buildings
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_BUILDINGS", city:GetHappiness() )
			local nBuilding, nBuildingClass
			for building in GameInfo.Buildings() do
				nBuilding = building.ID
				if city:IsHasBuilding( nBuilding ) then
					nBuildingClass = GameInfoTypes[ building.BuildingClass ]
					insertLocalizedIfNonZero( tips, "      {1}[ICON_HAPPINESS_1] {2}", (tonumber(building.Happiness) or 0)
												+ (tonumber(building.UnmoddedHappiness) or 0)
												+ player:GetExtraBuildingHappinessFromPolicies( nBuilding )
												+ (nBuildingClass and player.GetPlayerBuildingClassHappiness and player:GetPlayerBuildingClassHappiness( nBuildingClass ) or 0)
												+ (nBuildingClass and city.GetReligionBuildingClassHappiness and city:GetReligionBuildingClassHappiness( nBuildingClass ) or 0)
												, tostring( building._Name ) )
				end
			end
			-- City Religion
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_DIPLO_MY_SCORE_RELIGION", city.TODO and city:TODO() )
			-- Free Happiness per City
			insertLocalizedBulletIfNonZero( tips, "{1} {TXT_KEY_FREE_HAPP_PER_CITY}.", player:GetExtraHappinessPerCity() )
			-- Connected to Capital
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_CONNECTED_CITIES", not city:IsCapital() and player:IsCapitalConnectedToCity(city) and ( player:GetHappinessPerTradeRoute() / _iHappinessPerTradeRouteFactor ) )
			-- Garrisoned Unit
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_GARRISONED_UNITS", city:GetGarrisonedUnit() and player:GetHappinessPerGarrisonedUnit() )

--[[
			-- Natural wonders & hooked luxuries
			local i = #tips+1
			local tLuxuries = {}
			local nCityInBorderHappiness = 0
			local nCityHappinessFromLuxuries = 0
			local nTeam = city:GetTeam()
			for plot in CityPlots( city ) do
				-- Happiness from terrain
				local feature = GameInfo.Features[ plot:GetFeatureType() ]
				if feature then
					local nInBorderHappiness = floor( ( tonumber(feature.InBorderHappiness) or 0 ) * ( 100 + player:GetNaturalWonderYieldModifier() ) / 100 )
					nCityInBorderHappiness = nCityInBorderHappiness + nInBorderHappiness
					insertLocalizedIfNonZero( tips, "      {1}[ICON_HAPPINESS_1] {2}", nInBorderHappiness, tostring( feature._Name ) )
				end
				-- Happiness from luxuries
				local resourceID = plot:GetResourceType( nTeam )
				local resource =  player:GetNumResourceAvailable( resourceID, true ) > 0 and GameInfo.Resources[ resourceID ]
				if resource and not tLuxuries[ resource ] then
					local nHappinessFromLuxury = player:GetHappinessFromLuxury( resourceID ) or tonumber(resource.Happiness) or 0
					if nHappinessFromLuxury > 0 and ( plot:IsCity() or not plot:IsImprovementPillaged() and plot:IsResourceConnectedByImprovement( plot:GetRevealedImprovementType( nTeam ) ) ) then
						tLuxuries[ resource ] = nHappinessFromLuxury
						nCityHappinessFromLuxuries = nCityHappinessFromLuxuries + nHappinessFromLuxury
					end
				end
			end
			-- Happiness from terrain
			if nCityInBorderHappiness > 0 then
				insert( tips, i, "[ICON_BULLET]" .. L( "TXT_KEY_TP_HAPPINESS_NATURAL_WONDERS", nCityInBorderHappiness ) ) -- insert before !
			end

			-- City Happiness
			insert( tips, 3, L( "{TXT_KEY_TOPIC_HAPPINESS}: {1}[ICON_HAPPINESS_1]", GetCityHappiness( player, city ) + nCityHappinessFromLuxuries + nCityInBorderHappiness ) ) -- insert on top !

			-- Happiness from luxuries
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_FROM_RESOURCES", nCityHappinessFromLuxuries )
			for resource, nHappinessFromLuxury in pairs( tLuxuries ) do
				insert( tips, L( "      {1}[ICON_HAPPINESS_1] {3}{2}", nHappinessFromLuxury, tostring( resource._Name ), tostring( resource.IconString ) ) )
			end

			-- Unhappiness
			insert( tips, "" )
			local nPopulation = city:GetPopulation()
			local nCityUnhappiness, nPublicOpinionUnhappiness = GetCityUnhappiness( player, city )
			local rHandicap = GameInfo.HandicapInfos[ player:GetHandicapType() ] or {}
			insert( tips, L( "{TXT_KEY_UNHAPPINESS}: {1}[ICON_HAPPINESS_4]", nCityUnhappiness ) )

			-- Unhappiness bonus from Specialists
			if player:IsHalfSpecialistUnhappiness() then
				insert( tips, L"[ICON_BULLET]{TXT_KEY_UNHAPPINESS_MOD_SPECIALIST}" ) -- TXT_KEY_TP_UNHAPPINESS_SPECIALISTS
				for nSpecialist = 0, _iNum_SpecialistsM1 do
					if nSpecialist ~= DEFAULT_SPECIALIST then
						nPopulation = nPopulation - city:GetSpecialistCount( nSpecialist ) * .5
					end
				end
			end
			if city:IsOccupied() and not city:IsNoOccupiedUnhappiness() then
--				insert( tips, L"[ICON_BULLET]{TXT_KEY_EO_CITY_IS_OCCUPIED}" )
				-- Population unhappiness
				insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_OCCUPIED_POPULATION", UNHAPPINESS_PER_OCCUPIED_POPULATION
							* floor(nPopulation)
							* ( 100 + player:GetOccupiedPopulationUnhappinessMod() )
							* ( tonumber(rHandicap.PopulationUnhappinessMod) or 100 )
							/ 1e4 )
				-- City count unhappiness
				insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_CAPTURED_CITY_COUNT", UNHAPPINESS_PER_CAPTURED_CITY
							* ( 100 + player:GetCityCountUnhappinessMod() + player:GetTraitCityUnhappinessMod() )
							* ( tonumber(rHandicap.NumCitiesUnhappinessMod) or 100 )
							* Game.GetWorldNumCitiesUnhappinessPercent()
							/ 1e6 )
			else
				-- Population unhappiness
				insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_POPULATION", UNHAPPINESS_PER_POPULATION
							* floor(nPopulation)
							* ( city:IsCapital() and ( 100 + player:GetCapitalUnhappinessMod() ) or 100 )
							* ( 100 + player:GetUnhappinessMod() )
							* ( 100 + player:GetTraitPopUnhappinessMod() )
							* ( tonumber(rHandicap.PopulationUnhappinessMod) or 100 )
							/ 1e8 )
				-- Capital modifier
				insertLocalizedIfNonZero( tips, "    Capital modifier: {1}%", city:IsCapital() and player:GetCapitalUnhappinessMod() )
				-- Player modifier
				insertLocalizedIfNonZero( tips, "    Player modifier: {1}%", player:GetUnhappinessMod() )
				-- Player trait modifier
				insertLocalizedIfNonZero( tips, "    Player trait modifier: {1}%", player:GetTraitPopUnhappinessMod() )
				-- Player trait modifier
				insertLocalizedIfNonZero( tips, "    Handicap modifier: {1}%", (tonumber(rHandicap.PopulationUnhappinessMod)or 0)-100 )

				-- City count unhappiness
				insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_CITY_COUNT", UNHAPPINESS_PER_CITY
							* ( 100 + player:GetCityCountUnhappinessMod() + player:GetTraitCityUnhappinessMod() )
							* ( tonumber(rHandicap.NumCitiesUnhappinessMod) or 100 )
							* Game.GetWorldNumCitiesUnhappinessPercent()
							/ 1e6 )
			end
			-- Public opinion unhappiness
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_CO_OPINION_TT_UNHAPPINESS_LINE1", nPublicOpinionUnhappiness )
--]]
		end
		return concat( tips, "[NEWLINE]" )
	end,
	ProdBox = GetProductionTooltip,
	FoodBox = GetFoodTooltip,
	PopulationBox = GetFoodTooltip,
	PopulationPortraitButton = GetFoodTooltip,
	GoldBox = GetGoldTooltip,
	ScienceBox = GetScienceTooltip,
	CultureBox = GetCultureTooltip,
	CulturePlot = GetCultureTooltip,
	FaithBox = GetFaithTooltip,
	TourismBox = GetTourismTooltip,
	ProductionPortraitButton = GetProductionTooltip, --function() CityOrderItemTooltip( GetHeadSelectedCity(), false, false, GetHeadSelectedCity():GetOrderFromQueue( 0 ) ) end,
}

LuaEvents.CityViewToolTips.Add( function( control )
	local city = GetHeadSelectedCity()
	return ShowTextToolTip( city and TooltipSelect( CityViewToolTips, control, city ) )
end)


--==========================================================
-- Tech Tooltips
--==========================================================

LuaEvents.TechButtonTooltip.Add( function( orderID, itemID )
	local tip = "no tip found"
	local item, iconIndex, iconAtlas
	if orderID == ORDER_TRAIN then
		iconIndex, iconAtlas = GetUnitPortraitIcon( itemID, GetActivePlayer() )
		tip = GetHelpTextForUnit( itemID, true )

	elseif orderID == ORDER_CONSTRUCT then
		iconIndex, iconAtlas = GetItemPortraitIcon( GameInfo.Buildings, itemID )
		tip = GetHelpTextForBuilding( itemID )

	elseif orderID == ORDER_CREATE then
		iconIndex, iconAtlas = GetItemPortraitIcon( GameInfo.Projects, itemID )
		tip = GetHelpTextForProject( itemID, true )

	elseif orderID == ORDER_MAINTAIN then
		iconIndex, iconAtlas = GetItemPortraitIcon( GameInfo.Processes, itemID )
		tip = GetHelpTextForProcess( itemID, true )

	elseif orderID == 11 then
		iconIndex, iconAtlas = GetItemPortraitIcon( GameInfo.Resources, itemID )
		tip = L( "TXT_KEY_REVEALS_RESOURCE_ON_MAP", tostring( (GameInfo.Resources[itemID] or {})._Name ) )

	elseif orderID == 12 then
		local build = GameInfo.Builds[ itemID ]
		if build then
			tip = tostring( build._Name )
			item = GameInfo.Improvements[ build.ImprovementType ]
			if item then
				tip = GetHelpTextForImprovement( item.ID )
			else
				item = GameInfo.Routes[ build.RouteType ]
				if not item then
					item = GameInfo.BuildFeatures{ BuildType = build.Type }()
					item = item and GameInfo.Features[ item.FeatureType ]
				end
			end
			if item then
				iconIndex, iconAtlas = item.PortraitIndex, item.IconAtlas
			end
		end

	elseif orderID == 13 then
		item = GameInfo.Missions[ itemID ]
		if item then
			local entry = item.Type
			if entry == "MISSION_EMBARK" then
				item = GameInfo.Concepts.CONCEPT_MOVEMENT_EMBARKING
			elseif entry == "MISSION_ROUTE_TO" then
				item = GameInfo.Concepts.CONCEPT_WORKERS_ROADS_TRADE_ROUTES
			elseif entry == "MISSION_ESTABLISH_TRADE_ROUTE" then
				item = GameInfo.Concepts.CONCEPT_TRADE_ROUTES
			end
			if item then
				tip = tostring( item._Name )
			end
		end

	elseif orderID == 14 then
		item = GameInfo.Terraform[ itemID ]
		if item then
			local entry = item.Type
			if entry == "TERRAFORM_ADD_MIASMA" then
				item = GameInfo.Concepts.CONCEPT_WORKERS_PLACE
			elseif entry == "TERRAFORM_CLEAR_MIASMA" then
				item = GameInfo.Concepts.CONCEPT_WORKERS_REMOVE
			else
				item = GameInfo.Features[ item.FeatureTypeChange ] or GameInfo.Terrains[ item.TerrainTypeChange ]
			end
			if item then
				tip = tostring( item._Name )
			end
		end
	elseif orderID == 15 then
		tip = GetHelpTextForPlayerPerk( itemID, true )
	end
	return ShowItemToolTipAndPicture( tip, iconIndex, iconAtlas )
--	return ShowItemToolTipAndPicture( "This is button tooltip for order "..orderID.." item "..itemID.." icon "..tostring(iconIndex)..":"..tostring(iconAtlas).."[NEWLINE]"..tip, iconIndex, iconAtlas )
end)

LuaEvents.TechTooltip.Add( function( nCurrentResearch )
	return ShowItemToolTipAndPicture( GetHelpTextForTech( nCurrentResearch, Players[ GetActivePlayer() ]:CanResearch( nCurrentResearch ) ), GetItemPortraitIcon( GameInfo.Technologies, nCurrentResearch ) )
end)

--==========================================================
-- Policy Tooltips
--==========================================================

LuaEvents.PolicyTooltip.Add( function( control )
	local policyID = control:GetVoid1()
	local policyInfo = GameInfo.Policies[ policyID ]
	local player = Players[ GetActivePlayer() ]

	if policyInfo and player then

		-- Tooltip
		local tip = L( policyInfo.Help )

		-- Player already has Policy
		if player:HasPolicy( policyID ) then
			if player:IsPolicyBlocked( policyID ) then
				tip = tip .. "[NEWLINE][NEWLINE]" .. L("TXT_KEY_POLICY_BRANCH_BLOCKED")
			end

		-- Can adopt the Policy right now
		elseif player:CanAdoptPolicy( policyID ) then

		-- Policy is unlocked, but we lack culture
		elseif player:CanAdoptPolicy( policyID, true ) then
			-- Tooltip
			tip = tip .. "[NEWLINE][NEWLINE]" .. L("TXT_KEY_POLICY_BRANCH_CANNOT_UNLOCK_CULTURE", player:GetNextPolicyCost())
		else
			-- Tooltip
			tip = tip .. "[NEWLINE][NEWLINE]" .. L("TXT_KEY_POLICY_CANNOT_UNLOCK")
		end
		return ShowItemToolTipAndPicture( tip, policyInfo.PortraitIndex, policyInfo.IconAtlas )
	end
end)

LuaEvents.PolicyBranchTooltip.Add( function( control )
	local policyBranchID = control:GetVoid1()
	local policyBranchInfo = GameInfo.PolicyBranchTypes[ policyBranchID ]
	local player = Players[ GetActivePlayer() ]

	if policyBranchInfo and player then

		local tip = L( policyBranchInfo.Help )

		-- Branch is unlocked
		if player:IsPolicyBranchUnlocked( policyBranchID ) then
			-- Branch is blocked by another branch
			if player:IsPolicyBranchBlocked( policyBranchID ) then
				tip = tip .. "[NEWLINE][NEWLINE]" .. L("TXT_KEY_POLICY_BRANCH_BLOCKED")
			end

		-- Cannot adopt this branch right now
		elseif policyBranchInfo.LockedWithoutReligion and not _bReligionEnabled then
			tip = tip .. "[NEWLINE][NEWLINE]" .. L("TXT_KEY_POLICY_BRANCH_CANNOT_UNLOCK_RELIGION");

		-- Can adopt this branch right now
		elseif player:CanUnlockPolicyBranch( policyBranchID ) then
			tip = tip .. "[NEWLINE][NEWLINE]" .. L("TXT_KEY_POLICY_BRANCH_UNLOCK_SPEND", player:GetNextPolicyCost())

		-- Branch is not yet unlocked
		else
			tip = tip .. "[NEWLINE][NEWLINE]" .. L("TXT_KEY_POLICY_BRANCH_CANNOT_UNLOCK")
			local eraPrereq = GameInfoTypes[ policyBranchInfo.EraPrereq ]
			-- Not in prereq Era
			if eraPrereq and Teams[player:GetTeam()]:GetCurrentEra() < eraPrereq then
				tip = tip .. " " .. L("TXT_KEY_POLICY_BRANCH_CANNOT_UNLOCK_ERA", GameInfo.Eras[eraPrereq].Description)
			-- Don't have enough Culture Yet
			else
				tip = tip .. " " .. L("TXT_KEY_POLICY_BRANCH_CANNOT_UNLOCK_CULTURE", player:GetNextPolicyCost())
			end
		end
		return ShowTextToolTip( tip )
	end
end)

LuaEvents.TenetToolTip.Add(	function ( control )
	local player = Players[ GetActivePlayer() ]
	local tip = "???"
	if player then
		local tenetID = control:GetVoid1()
		local tenetLevel = control:GetVoid2()
		local tenetInfo = GameInfo.Policies[ tenetID ]
		if tenetInfo then
			tip = L( tenetInfo.Help )
		else
			if tenetID == -1 then
				tip = L"TXT_KEY_POLICYSCREEN_ADD_TENET"
			elseif tenetID == -2 then
				tip = L( "TXT_KEY_POLICY_BRANCH_CANNOT_UNLOCK_CULTURE", player:GetNextPolicyCost() )
			elseif tenetID == -3 then
				tip = "[ICON_LOCKED]" .. L( "TXT_KEY_POLICYSCREEN_NEED_L"..(tenetLevel-1).."_TENETS_TOOLTIP" )
			elseif tenetID == -4 then
				tip = "[ICON_LOCKED][COLOR_WARNING_TEXT]" .. L( "TXT_KEY_POLICYSCREEN_IDEOLOGY_LEVEL"..tenetLevel ) .. "[ENDCOLOR]"
			end
			local tips = { tip }
			for _,tenetID in ipairs( player:GetAvailableTenets( tenetLevel ) ) do
				tenetInfo = GameInfo.Policies[ tenetID ]
				if tenetInfo then
					insert( tips, L(tenetInfo.Help or tenetInfo.Description or "???") )
				end
			end
			tip = concat( tips, "[NEWLINE][NEWLINE]" )
		end
	end
	return ShowTextToolTip( tip )
end)


--==========================================================
-- TopPanel Tooltips
--==========================================================

local function ScienceTooltip()

	local tips = {}
	local tech, sciencePerTurn, researchTurnsLeft, researchCost, researchProgress, reseachLost

	if _bScienceEnabled then

		local tip
		local activePlayerID = GetActivePlayer()
		local activeTeamID = GetActiveTeam()
		local activePlayer = Players[activePlayerID]
		local activeTeam = Teams[activeTeamID]
		local activeTeamTechs = activeTeam:GetTeamTechs()

		local nScienceTimes100 = activePlayer:GetScienceTimes100()
		local nCurrentResearch = activePlayer:GetCurrentResearch()
		local nLastTechAcquired = activeTeamTechs:GetLastTechAcquired()

		if _bCiv5BNW and activePlayer:IsAnarchy() then
			insert( tips, L( "{TXT_KEY_TP_ANARCHY}[NEWLINE]", activePlayer:GetAnarchyNumTurns() ) )
		end

		tech = GameInfo.Technologies[ nCurrentResearch ]
		-- Are we researching something right now?
		if tech then
			researchTurnsLeft = activePlayer:GetResearchTurnsLeft( nCurrentResearch, true )
			researchCost = activePlayer:GetResearchCost( nCurrentResearch )
			researchProgress = activePlayer:GetResearchProgress( nCurrentResearch )
			insert( tips, L( "{TXT_KEY_PROGRESS_TOWARDS}[ENDCOLOR]: {2} / {3}[ICON_RESEARCH]", _sScienceTextColor .. ToUpper( tostring( tech._Name ) ), researchProgress, researchCost ) )
			if nScienceTimes100 > 0 then
				local scienceOverflowTimes100 = nScienceTimes100 * researchTurnsLeft + (researchProgress - researchCost) * 100
				tip =  L( "{2}{TXT_KEY_STR_TURNS}[ENDCOLOR]: {3}[ICON_RESEARCH]", researchTurnsLeft, _sScienceTextColor, scienceOverflowTimes100 / 100 )
				if researchTurnsLeft > 1 then
					tip = L( "{TXT_KEY_STR_TURNS}: {2}[ICON_RESEARCH], {3}", researchTurnsLeft -1, (scienceOverflowTimes100 - nScienceTimes100) / 100, tip )
				end
				insert( tips, tip )
			end
		else
			-- maybe we just finished something
			tech = GameInfo.Technologies[ nLastTechAcquired ]
			if tech then
				insert( tips, L( "{TXT_KEY_RESEARCH_FINISHED} {1}{2:upper}[ENDCOLOR], {TXT_KEY_NOTIFICATION_SUMMARY_NEW_RESEARCH}", _sScienceTextColor, tostring( tech._Name ) ) )
			end
		end

		sciencePerTurn = nScienceTimes100 / 100
		reseachLost = activePlayer:GetScienceFromBudgetDeficitTimes100() / 100

		insert( tips, L( "[NEWLINE]{1}{2: number +0.##;[COLOR_RED]-0.##}[ENDCOLOR] {TXT_KEY_REPLAY_DATA_SCIENCEPERTURN}", _sScienceTextColor , sciencePerTurn ) )

		-- Science LOSS from Budget Deficits
		insertLocalizedIfNonZero( tips, "TXT_KEY_TP_SCIENCE_FROM_BUDGET_DEFICIT", reseachLost )

		-- Science from Cities
		insertLocalizedIfNonZero( tips, "TXT_KEY_TP_SCIENCE_FROM_CITIES", activePlayer:GetScienceFromCitiesTimes100(true) / 100 )

		-- Science from Trade Routes
		insertLocalizedIfNonZero( tips, "TXT_KEY_TP_SCIENCE_FROM_ITR", ( activePlayer:GetScienceFromCitiesTimes100(false) - activePlayer:GetScienceFromCitiesTimes100(true) ) / 100 )

		-- Science from Other Players
		insertLocalizedIfNonZero( tips, "TXT_KEY_TP_SCIENCE_FROM_MINORS", activePlayer:GetScienceFromOtherPlayersTimes100() / 100 )

		if _bCiv5 then
			-- Science from Happiness
			insertLocalizedIfNonZero( tips, "TXT_KEY_TP_SCIENCE_FROM_HAPPINESS", activePlayer:GetScienceFromHappinessTimes100() / 100 )

			-- Science from Vassals / Compatibility with Putmalk's Civ IV Diplomacy Features Mod
			if activePlayer.GetScienceFromVassalTimes100 then
				insertLocalizedIfNonZero( tips, "TXT_KEY_TP_SCIENCE_VASSALS", activePlayer:GetScienceFromVassalTimes100() / 100 )
			end

			-- Compatibility with Gazebo's City-State Diplomacy Mod (CSD) for Brave New World v23
			if activePlayer.GetScienceRateFromMinorAllies then
				insertLocalizedIfNonZero( tips, "TXT_KEY_MINOR_SCIENCE_FROM_LEAGUE_ALLIES", activePlayer:GetScienceRateFromMinorAllies() )
			end
			if activePlayer.GetScienceRateFromLeagueAid then
				insertLocalizedIfNonZero( tips, "TXT_KEY_SCIENCE_FUNDING_FROM_LEAGUE", activePlayer:GetScienceRateFromLeagueAid() )
			end

			-- Science from Research Agreements
			insertLocalizedIfNonZero( tips, "TXT_KEY_TP_SCIENCE_FROM_RESEARCH_AGREEMENTS", activePlayer:GetScienceFromResearchAgreementsTimes100() / 100 )

			-- Show Research Agreements

			local itemType, duration, finalTurn, data1, data2, data3, flag1, fromPlayerID
			local gameTurn = Game.GetGameTurn() - 1
			local researchAgreementCounters = {}

			PushScratchDeal()
			for i = 0, UI.GetNumCurrentDeals( activePlayerID ) - 1 do
				UI.LoadCurrentDeal( activePlayerID, i )
				ScratchDeal:ResetIterator()
				repeat
					if _bCiv5BNWorBE then
						itemType, duration, finalTurn, data1, data2, data3, flag1, fromPlayerID = ScratchDeal:GetNextItem()
					else
						itemType, duration, finalTurn, data1, data2, fromPlayerID = ScratchDeal:GetNextItem()
					end
--local itemKey for k,v in pairs( TradeableItems ) do if itemType == v then itemKey = k break end end
--print( "Deal #", i, "item type", itemType, itemKey, "duration", duration, "finalTurn", finalTurn, "data1", data1, "data2", data2, "fromPlayerID", fromPlayerID)
					if itemType == TradeableItems.TRADE_ITEM_RESEARCH_AGREEMENT and fromPlayerID ~= activePlayerID then
						researchAgreementCounters[fromPlayerID] = finalTurn - gameTurn
						break
					end
				until not itemType
			end
			PopScratchDeal()

			local tipIndex = #tips

			for playerID = 0, MAX_MAJOR_CIVS-1 do

				local player = Players[playerID]
				local teamID = player:GetTeam()

				if playerID ~= activePlayerID and player:IsAlive() and activeTeam:IsHasMet(teamID) then

					-- has reseach agreement ?
					if activeTeam:IsHasResearchAgreement(teamID) then
						tip = "[ICON_BULLET][COLOR_POSITIVE_TEXT]" .. player:GetName() .. "[ENDCOLOR]"
						if researchAgreementCounters[playerID] then
							tip = L( "{2} {3}{TXT_KEY_STR_TURNS}[ENDCOLOR]", researchAgreementCounters[playerID] , tip, _sScienceTextColor )
						end
						insert( tips, tip )
					else
						insert( tips, "[ICON_BULLET][COLOR_WARNING_TEXT]" .. player:GetName() .. "[ENDCOLOR]" )
					end
				end
			end

			if #tips > tipIndex then
				insert( tips, tipIndex+1, L"[NEWLINE]{TXT_KEY_DO_RESEARCH_AGREEMENT}" )
			end
		else
			-- Science from Health
			insertLocalizedIfNonZero( tips, "TXT_KEY_TP_SCIENCE_FROM_HEALTH", activePlayer:GetScienceFromHealthTimes100() / 100 )

			-- Science from Culture Rate
			insertLocalizedIfNonZero( tips, "TXT_KEY_TP_SCIENCE_FROM_CULTURE", activePlayer:GetScienceFromCultureTimes100() / 100 )

			-- Science from Diplomacy Rate
			local scienceFromDiplomacy = activePlayer:GetScienceFromDiplomacyTimes100() / 100
			if scienceFromDiplomacy > 0 then
				insert( tips, L( "TXT_KEY_TP_SCIENCE_FROM_DIPLOMACY", scienceFromDiplomacy ) )
			elseif scienceFromDiplomacy < 0 then
				insert( tips, L( "TXT_KEY_TP_NEGATIVE_SCIENCE_FROM_DIPLOMACY", -scienceFromDiplomacy ) )
			end
		end

		-- Let people know that building more cities makes techs harder to get
		if _bCiv5BNWorBE then
			insert( tips, L( "[NEWLINE]{TXT_KEY_TP_TECH_CITY_COST}", _bCivBE and Game.GetNumCitiesTechCostMod() * ( 100 + activePlayer:GetNumCitiesResearchCostDiscount() ) / 100 or Game.GetNumCitiesTechCostMod() ) )
		end
	else
		insert( tips, L"{TXT_KEY_TOP_PANEL_SCIENCE_OFF}: {TXT_KEY_TOP_PANEL_SCIENCE_OFF_TOOLTIP}" )
	end

	ShowProgressToolTip( _cTechProgressToolTip, 256, tech and tech.PortraitIndex, tech and tech.IconAtlas,
		concat( tips, "[NEWLINE]" ),
		researchTurnsLeft,
		researchCost,
		researchProgress,
		sciencePerTurn,
		reseachLost )
end

-------------------------------------------------
-- Faith Tooltip (GK & BNW)
-------------------------------------------------
local function FaithTooltip()

	if _bReligionEnabled then
		local player = Players[GetActivePlayer()]

		local tip
		local tips = {}
		if _bCiv5BNWorBE and player:IsAnarchy() then
			insert( tips, L( "{TXT_KEY_TP_ANARCHY}[NEWLINE]", player:GetAnarchyNumTurns() ) )
		end

		local nFaith = player:GetFaith() 
		local nTotalFaithPerTurn = player:GetTotalFaithPerTurn()
		local nNextFaithCost
		local sNextFaithItem

		local nReligionsStillToFound = Game.GetNumReligionsStillToFound()
		local nFaithPurchaseType = player:GetFaithPurchaseType()
		local nMinimumFaithNextGreatProphet = player:GetMinimumFaithNextGreatProphet()
		local capital = player:GetCapitalCity()
		if nFaithPurchaseType == FAITH_PURCHASE_UNIT then
			local row = GameInfo.Units[ player:GetFaithPurchaseIndex() ]
			if row then --and player:IsCanPurchaseAnyCity( false, false, row.ID, -1, YIELD_FAITH ) then
				sNextFaithItem = row._Name
				nNextFaithCost = capital and capital:GetUnitFaithPurchaseCost( row.ID, true )
				tip = GetHelpTextForUnit( row.ID )
			end
		elseif nFaithPurchaseType == FAITH_PURCHASE_BUILDING then
			local row = GameInfo.Buildings[ player:GetFaithPurchaseIndex() ]
			if row then --and player:IsCanPurchaseAnyCity( false, false, -1, row.ID, YIELD_FAITH ) then -- false = /bTestPurchaseCost, false = /bTestTrainable
				sNextFaithItem = row._Name
				nNextFaithCost = capital and capital:GetBuildingFaithPurchaseCost(row.ID, true)
				tip = GetHelpTextForBuilding( row.ID )
			end
		elseif player:HasCreatedReligion() or player:HasCreatedPantheon() and nReligionsStillToFound > 0 then
			if not nNextFaithCost or nMinimumFaithNextGreatProphet < nNextFaithCost and player:GetCurrentEra() < GameInfoTypes.ERA_INDUSTRIAL then
				nNextFaithCost = nMinimumFaithNextGreatProphet
				sNextFaithItem = "[COLOR_WHITE]{TXT_KEY_UNIT_GREAT_PROPHET:upper}"
				if player:HasCreatedReligion() then
					tip = L( "TXT_KEY_RO_STATUS_FOUNDER", Game.GetReligionName( player:GetReligionCreatedByPlayer() ) )
				else
					tip = GameInfo.Beliefs[ player:GetBeliefInPantheon() ]
					tip = L( "{TXT_KEY_RO_STATUS_CREATED_PANTHEON}: {2}.[NEWLINE][NEWLINE]{TXT_KEY_TP_FAITH_RELIGIONS_LEFT}", nReligionsStillToFound, tostring(tip and tip._Name) )
				end
			end
		elseif player:HasCreatedPantheon() then
			tip = GameInfo.Beliefs[ player:GetBeliefInPantheon() ]
			tip = L("{TXT_KEY_RO_STATUS_CREATED_PANTHEON}: {1}.[NEWLINE][NEWLINE]{2}.", tostring(tip and tip._Name), (L"TXT_KEY_RO_STATUS_TOO_LATE"):gsub( L"TXT_KEY_RELIGION_PANTHEON", L"TXT_KEY_EO_RELIGION" ) )
		elseif player:CanCreatePantheon( true ) then
			tip = L"TXT_KEY_RO_STATUS_CAN_CREATE_PANTHEON"
		elseif player:CanCreatePantheon() and player:GetCurrentEra() < GameInfoTypes.ERA_INDUSTRIAL then
			nNextFaithCost = Game.GetMinimumFaithNextPantheon()
			sNextFaithItem = "[COLOR_WHITE]{TXT_KEY_RELIGION_PANTHEON:upper}"
			tip = L( "TXT_KEY_TP_FAITH_NEXT_PANTHEON", nNextFaithCost )
		else
			tip = L"{TXT_KEY_RO_STATUS_TOO_LATE}[NEWLINE][NEWLINE]{TXT_KEY_TP_FAITH_PANTHEONS_LOCKED}"
		end

		if nNextFaithCost and nNextFaithCost > 0 then
			insert( tips, L( "{TXT_KEY_PROGRESS_TOWARDS}[ENDCOLOR]: {2} / {3}[ICON_PEACE]", tostring(sNextFaithItem), nFaith, nNextFaithCost ) )
			local nTurnsRemaining = 0
			if nNextFaithCost > nFaith and nTotalFaithPerTurn > 0 then
				nTurnsRemaining = ceil( (nNextFaithCost - nFaith) / nTotalFaithPerTurn )
			end
			if nTotalFaithPerTurn > 0 then
				local nOverflow = nTotalFaithPerTurn * nTurnsRemaining + nFaith - nNextFaithCost
				local tip = L( "[COLOR_WHITE]{TXT_KEY_STR_TURNS}[ENDCOLOR]: {2}[ICON_PEACE]", nTurnsRemaining, nOverflow )
				if nTurnsRemaining > 1 then
					tip = L( "{TXT_KEY_STR_TURNS}: {2}[ICON_PEACE], {3}", nTurnsRemaining -1, nOverflow - nTotalFaithPerTurn, tip )
				end
				insert( tips, tip )
			end
		else
			insert( tips, L( "TXT_KEY_TP_FAITH_ACCUMULATED", nFaith ) )
		end
		-- Total faith per turn
		insert( tips, L( "[NEWLINE][COLOR_WHITE]{1: number +0.##;[COLOR_RED]-0.##}[ENDCOLOR] {TXT_KEY_YIELD_FAITH}[ICON_PEACE] {TXT_KEY_GOLD_PERTURN_HEADING4_TITLE}", nTotalFaithPerTurn ) )
		-- Faith from Cities
		insertLocalizedIfNonZero( tips, "TXT_KEY_TP_FAITH_FROM_CITIES", player:GetFaithPerTurnFromCities() )
		-- Faith from Outposts
		insertLocalizedIfNonZero( tips, "TXT_KEY_TP_FAITH_FROM_OUTPOSTS", _bCivBE and player:GetFaithPerTurnFromOutposts() )
		-- Faith from Minor Civs
		insertLocalizedIfNonZero( tips, "TXT_KEY_TP_FAITH_FROM_MINORS", player:GetFaithPerTurnFromMinorCivs() )
		-- Faith from Religion
		insertLocalizedIfNonZero( tips, "TXT_KEY_TP_FAITH_FROM_RELIGION", player:GetFaithPerTurnFromReligion() )

		if tip then
			insert( tips, "" )
			insert( tips, tip )
		end

		-- New World Deluxe Scenario ( you still need to delete TopPanel.lua from ...\Steam\SteamApps\common\sid meier's civilization v\assets\DLC\DLC_07\Scenarios\Conquest of the New World Deluxe\UI )
		if _bNewWorldDeluxeScenario then
			tip = L"[NEWLINE]{TXT_KEY_NEWWORLD_SCENARIO_TP_RELIGION_TOOLTIP}"
		end

		return concat( tips, "[NEWLINE]" )
	else
		return L"TXT_KEY_TOP_PANEL_RELIGION_OFF_TOOLTIP"	--TXT_KEY_TOP_PANEL_RELIGION_OFF
	end
end

local TopPanelTooltips = {
	SciencePerTurn = ScienceTooltip,
	TechIcon = ScienceTooltip,
	GoldPerTurn = function()
		local activePlayerID = GetActivePlayer()
		local activeTeamID = GetActiveTeam()
		local activePlayer = Players[activePlayerID]
		local activeTeam = Teams[activeTeamID]

		local tips = {}

		local goldPerTurnFromDiplomacy = activePlayer:GetGoldPerTurnFromDiplomacy()
		local goldPerTurnFromOtherPlayers = max(0,goldPerTurnFromDiplomacy) * 100
		local goldPerTurnToOtherPlayers = -min(0,goldPerTurnFromDiplomacy)

		local goldPerTurnFromReligion = _bCiv5notVanilla and activePlayer:GetGoldPerTurnFromReligion() * 100 or 0
		local goldPerTurnFromCities = activePlayer:GetGoldFromCitiesTimes100()
		local cityConnectionGold = activePlayer:GetCityConnectionGoldTimes100()
		local playerTraitGold = 0
		local tradeRouteGold = 0
		local goldPerTurnFromPolicies = 0

		local unitCost = activePlayer:CalculateUnitCost()
		local unitSupply = activePlayer:CalculateUnitSupply()
		local buildingMaintenance = activePlayer:GetBuildingGoldMaintenance()
		local improvementMaintenance = activePlayer:GetImprovementGoldMaintenance()
		local vassalMaintenance = activePlayer.GetVassalGoldMaintenance and activePlayer:GetVassalGoldMaintenance() or 0	-- Compatibility with Putmalk's Civ IV Diplomacy Features Mod
		local routeMaintenance = 0
		local beaconEnergyDelta = 0

		if _bCiv5BNWorBE then
			tradeRouteGold = activePlayer:GetGoldFromCitiesMinusTradeRoutesTimes100()
			goldPerTurnFromCities, tradeRouteGold = tradeRouteGold, goldPerTurnFromCities - tradeRouteGold
			playerTraitGold = activePlayer:GetGoldPerTurnFromTraits() * 100
			if activePlayer:IsAnarchy() then
				insert( tips, L( "{TXT_KEY_TP_ANARCHY}[NEWLINE]", activePlayer:GetAnarchyNumTurns() ) )
			end
		end

		-- Total gold
		local totalIncome, totalWealth
		local explicitIncome = goldPerTurnFromCities + goldPerTurnFromOtherPlayers + cityConnectionGold + goldPerTurnFromReligion + tradeRouteGold + playerTraitGold
		if _bCiv5 then
			totalWealth = activePlayer:GetGold()
			totalIncome = explicitIncome
		else
			totalWealth = activePlayer:GetEnergy()
			totalIncome = activePlayer:CalculateGrossGoldTimes100() + goldPerTurnToOtherPlayers * 100
			goldPerTurnFromPolicies = activePlayer:GetGoldPerTurnFromPolicies()
			explicitIncome = explicitIncome + goldPerTurnFromPolicies
			routeMaintenance = activePlayer:GetRouteEnergyMaintenance()
			beaconEnergyDelta = activePlayer:GetBeaconEnergyCostPerTurn()
		end
		insert( tips, L( "TXT_KEY_TP_AVAILABLE_GOLD", totalWealth ) )
		local totalExpenses = unitCost + unitSupply + buildingMaintenance + improvementMaintenance + goldPerTurnToOtherPlayers + vassalMaintenance + routeMaintenance + beaconEnergyDelta

		-- Gold per turn

		insert( tips, L( format( "[NEWLINE][COLOR_YELLOW]%+g[ENDCOLOR] {TXT_KEY_REPLAY_DATA_%sPERTURN}", activePlayer:CalculateGoldRateTimes100() / 100, GOLD ) ) )

		-- Science LOSS from Budget Deficits

		insertLocalizedIfNonZero( tips, "[NEWLINE]{TXT_KEY_TP_SCIENCE_FROM_BUDGET_DEFICIT}", activePlayer:GetScienceFromBudgetDeficitTimes100() / 100 )

		-- Income

		insert( tips, L("[NEWLINE][COLOR_WHITE]{TXT_KEY_TP_TOTAL_INCOME}", totalIncome / 100 ) )
		insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_CITY_OUTPUT", goldPerTurnFromCities / 100 )

		if _bCiv5BNWorBE then
			insertLocalizedBulletIfNonZero( tips, format("TXT_KEY_TP_%s_FROM_CITY_CONNECTIONS", GOLD), cityConnectionGold / 100 )
			insertLocalizedBulletIfNonZero( tips, _bCiv5 and "TXT_KEY_TP_GOLD_FROM_ITR" or "TXT_KEY_TP_ENERGY_FROM_TRADE_ROUTES", tradeRouteGold / 100 )
			insertLocalizedBulletIfNonZero( tips, format("TXT_KEY_TP_%s_FROM_TRAITS", GOLD), playerTraitGold / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_ENERGY_FROM_POLICIES", goldPerTurnFromPolicies / 100 )
		else
			insertLocalizedBulletIfNonZero( tips, format("TXT_KEY_TP_%s_FROM_TR", GOLD), cityConnectionGold / 100 )
		end

		insertLocalizedBulletIfNonZero( tips, format("TXT_KEY_TP_%s_FROM_OTHERS", GOLD), goldPerTurnFromOtherPlayers / 100 )
		insertLocalizedBulletIfNonZero( tips, format("TXT_KEY_TP_%s_FROM_RELIGION", GOLD), goldPerTurnFromReligion / 100 )
		insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_YIELD_FROM_UNCATEGORIZED", (totalIncome - explicitIncome) / 100 )
		insert( tips, "[ENDCOLOR]" )

		-- Spending

		insert( tips, L( "[COLOR:255:150:150:255]{TXT_KEY_TP_TOTAL_EXPENSES}", totalExpenses ) )
		insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNIT_MAINT", unitCost )
		insertLocalizedBulletIfNonZero( tips, format("TXT_KEY_TP_%s_UNIT_SUPPLY", GOLD), unitSupply )
		insertLocalizedBulletIfNonZero( tips, format("TXT_KEY_TP_%s_BUILDING_MAINT", GOLD), buildingMaintenance )
		insertLocalizedBulletIfNonZero( tips, format("TXT_KEY_TP_%s_TILE_MAINT", GOLD), improvementMaintenance )
		insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_ENERGY_ROUTE_MAINT", routeMaintenance )
		insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_GOLD_VASSAL_MAINT", vassalMaintenance )	-- Compatibility with Putmalk's Civ IV Diplomacy Features Mod
		insertLocalizedBulletIfNonZero( tips, format("TXT_KEY_TP_%s_TO_OTHERS", GOLD ), goldPerTurnToOtherPlayers )
		insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_ENERGY_TO_BEACON", beaconEnergyDelta )

		-- show gold available for trade to the active player
		local tipIndex = #tips
		for playerID = 0, MAX_MAJOR_CIVS-1 do

			local player = Players[playerID]

			-- Valid player? - Can't be us, has to be alive, and has to be met
			if playerID ~= activePlayerID and player:IsAlive() and activeTeam:IsHasMet( player:GetTeam() ) then
				insert( tips, "[ICON_BULLET]" .. player:GetName() .. format("  %i%s(%+i)",
						ScratchDeal:GetGoldAvailable(playerID, -1), ICON_GOLD, player:CalculateGoldRate() ) )
			end
		end
		if #tips > tipIndex then
			insert( tips, tipIndex+1, L"[ENDCOLOR][NEWLINE]{TXT_KEY_EO_RESOURCES_AVAILBLE}" )
		end

		-- Basic explanation

		if _bBasicHelp then
			insert( tips, L( format("[ENDCOLOR][NEWLINE]{TXT_KEY_TP_%s_EXPLANATION}", GOLD) ) )
		end

		return concat( tips, "[NEWLINE]" )
	end,
	GpIcon = function()
		local gp = ScanGP( Players[ GetActivePlayer() ] )
		if gp then
			local icon = GreatPeopleIcons and GreatPeopleIcons[ gp.Class.Type ] or "[ICON_GREAT_PEOPLE]"
			return L( "{TXT_KEY_PROGRESS_TOWARDS}[ENDCOLOR]: {2} / {3}{4}", "[COLOR_YIELD_FOOD]" .. ToUpper( tostring( gp.Class._Name ) ), gp.Progress, gp.Threshold, icon )
					..L( "[NEWLINE]{2} {3: number +0.##;[COLOR_RED]-0.##}{4} {TXT_KEY_GOLD_PERTURN_HEADING4_TITLE} [COLOR_YIELD_FOOD]{TXT_KEY_STR_TURNS}[ENDCOLOR]", gp.Turns, gp.City:GetName(), gp.Change, icon )
		else
			return "No Great Person found..."
		end
	end,
	-------------------------------------------------
	-- Happiness Tooltip
	-------------------------------------------------
	HappinessString = function()

		if _bHappinessEnabled then
			local activePlayerID = GetActivePlayer()
			local activeTeamID = GetActiveTeam()
			local activePlayer = Players[activePlayerID]
			local activeTeam = Teams[activeTeamID]

			local tips = {}

			local excessHappiness = activePlayer:GetExcessHappiness()

			if not activePlayer:IsEmpireUnhappy() then
				insert( tips, L("TXT_KEY_TP_TOTAL_HAPPINESS", excessHappiness) )
			elseif activePlayer:IsEmpireVeryUnhappy() then
				insert( tips, L("TXT_KEY_TP_TOTAL_UNHAPPINESS", "[ICON_HAPPINESS_4]", -excessHappiness) )
			else
				insert( tips, L("TXT_KEY_TP_TOTAL_UNHAPPINESS", "[ICON_HAPPINESS_3]", -excessHappiness) )
			end

			local nHappinessFromPolicies = activePlayer:GetHappinessFromPolicies()
			local nHappinessFromBuildings = activePlayer:GetHappinessFromBuildings()
			local nHappinessFromResources = activePlayer:GetHappinessFromResources() -- includes GetHappinessFromResourceVariety
--			local nHappinessFromResourceVariety = activePlayer:GetHappinessFromResourceVariety() -- the sum of nExtraHappinessPerLuxury
--			local nExtraHappinessPerLuxury = activePlayer:GetExtraHappinessPerLuxury()

			local nHappinessFromCities = 0
			local nHappinessFromGarrisonedUnits = 0
			local nHappinessFromMinorCivs = 0
			local nHappinessFromReligion = 0
			if _bCiv5notVanilla then
				nHappinessFromCities = activePlayer:GetHappinessFromCities()
				nHappinessFromMinorCivs = activePlayer:GetHappinessFromMinorCivs()
				nHappinessFromReligion = activePlayer:GetHappinessFromReligion()
			else
				nHappinessFromGarrisonedUnits = activePlayer:GetHappinessFromGarrisonedUnits()
				for minorPlayerID = MAX_MAJOR_CIVS, MAX_CIV_PLAYERS_M1 do
					nHappinessFromMinorCivs = nHappinessFromMinorCivs + activePlayer:GetHappinessFromMinor(minorPlayerID)
				end
			end
			local nTotalUnhappiness = activePlayer:GetHappiness()
			local nHappinessFromTradeRoutes = activePlayer:GetHappinessFromTradeRoutes()
			local nHappinessFromNaturalWonders = activePlayer:GetHappinessFromNaturalWonders()
			local nExtraHappinessPerCity = activePlayer:GetExtraHappinessPerCity() * activePlayer:GetNumCities()
			local nHappinessFromLeagues = activePlayer.GetHappinessFromLeagues and activePlayer:GetHappinessFromLeagues() or 0 -- _bCiv5BNWorBE
			local nEventHappiness = activePlayer.GetEventHappiness and activePlayer:GetEventHappiness() or 0 --CPP
			local nHappinessFromVassals = activePlayer.GetHappinessFromVassals and activePlayer:GetHappinessFromVassals() or 0	-- Compatibility with Putmalk's Civ IV Diplomacy Features Mod
			local handicapHappiness = nTotalUnhappiness - nHappinessFromPolicies - nHappinessFromResources - nHappinessFromCities - nHappinessFromBuildings - nHappinessFromGarrisonedUnits - nHappinessFromMinorCivs - nHappinessFromTradeRoutes - nHappinessFromReligion - nHappinessFromNaturalWonders - nExtraHappinessPerCity - nHappinessFromLeagues - nHappinessFromVassals - nEventHappiness	-- Compatibility with Putmalk's Civ IV Diplomacy Features Mod & CPP

			if activePlayer:IsEmpireSuperUnhappy() then
				insert( tips, "[COLOR:255:60:60:255]" .. L"TXT_KEY_TP_EMPIRE_SUPER_UNHAPPY" .. "[ENDCOLOR]" )
			elseif activePlayer:IsEmpireVeryUnhappy() then
				insert( tips, "[COLOR:255:60:60:255]" .. L"TXT_KEY_TP_EMPIRE_VERY_UNHAPPY" .. "[ENDCOLOR]" )
			elseif activePlayer:IsEmpireUnhappy() then
				insert( tips, "[COLOR:255:60:60:255]" .. L"TXT_KEY_TP_EMPIRE_UNHAPPY" .. "[ENDCOLOR]" )
			end

			-- Basic explanation of Happiness
			if _bBasicHelp then
				insert( tips, L"[NEWLINE]{TXT_KEY_TP_HAPPINESS_EXPLANATION}" )
			end

			-- Individual Resource Info
			local nHappinessFromLuxuries = 0
			local nHappinessLuxuries = 0
			local sAvailableHappinessLuxuries = "  "
			local sMissingHappinessLuxuries = sAvailableHappinessLuxuries
			local Resources = GameInfo.Resources
			local luxuries = { ResourceUsage = RESOURCEUSAGE_LUXURY }

			for resource in Resources( luxuries ) do
				local resourceID = resource.ID
				local nResourceAvailable = activePlayer:GetNumResourceAvailable( resource.ID, true ) -- true = include imports

				if nResourceAvailable > 0 then
					local nHappinessFromLuxury = activePlayer.GetHappinessFromLuxury and activePlayer:GetHappinessFromLuxury( resourceID ) or tonumber(resource.Happiness) or 0
					if nHappinessFromLuxury > 0 then
						sAvailableHappinessLuxuries = sAvailableHappinessLuxuries
							.. " [COLOR_POSITIVE_TEXT]"
							.. nResourceAvailable
							.. "[ENDCOLOR]"
							.. tostring( resource.IconString )
						nHappinessLuxuries = nHappinessLuxuries + 1
						nHappinessFromLuxuries = nHappinessFromLuxuries + nHappinessFromLuxury
					end
				elseif nResourceAvailable == 0 then
					sMissingHappinessLuxuries = sMissingHappinessLuxuries .. tostring( resource.IconString )
				else
					sMissingHappinessLuxuries = sMissingHappinessLuxuries
						.. " [COLOR_WARNING_TEXT]"
						.. nResourceAvailable
						.. "[ENDCOLOR]"
						.. tostring( resource.IconString )
				end
			end

			------------
			-- Happiness
			insert( tips, L( "[ENDCOLOR][NEWLINE][COLOR:150:255:150:255]{TXT_KEY_TP_HAPPINESS_SOURCES}", nTotalUnhappiness ) )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_DIFFICULTY_LEVEL", handicapHappiness )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_POLICIES", max(nHappinessFromPolicies,0) )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_STATE_RELIGION", nHappinessFromReligion )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_CITY_COUNT", nExtraHappinessPerCity )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_CITIES", nHappinessFromCities )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_BUILDINGS", nHappinessFromBuildings )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_CONNECTED_CITIES", nHappinessFromTradeRoutes )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_GARRISONED_UNITS", nHappinessFromGarrisonedUnits )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_NATURAL_WONDERS", nHappinessFromNaturalWonders )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_LEAGUES", nHappinessFromLeagues )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_CITY_STATE_FRIENDSHIP", nHappinessFromMinorCivs )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_VASSALS", nHappinessFromVassals )	-- Compatibility with Putmalk's Civ IV Diplomacy Features Mod
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_EVENT", nEventHappiness )-- Happiness from events (CPP)
			insert( tips, L( "[ICON_BULLET]{TXT_KEY_TP_HAPPINESS_FROM_RESOURCES}{2}", nHappinessFromResources, sAvailableHappinessLuxuries ) )-- includes Happiness from Luxury Variety
-- incomprehensible jibber jabber
--			insertLocalizedIfNonZero( tips, "          {TXT_KEY_TP_HAPPINESS_RESOURCE_VARIETY}", nHappinessFromResourceVariety ) -- Happiness from Luxury Variety
--			insertLocalizedIfNonZero( tips, "          {TXT_KEY_TP_HAPPINESS_EXTRA_PER_RESOURCE}", nExtraHappinessPerLuxury, nHappinessLuxuries )
--			insertLocalizedIfNonZero( tips, "          {TXT_KEY_TP_HAPPINESS_OTHER_SOURCES}", nHappinessFromResources - nHappinessFromLuxuries - nHappinessFromResourceVariety )

			--------------
			-- Unhappiness
--			local nUnhappinessFromPuppetCityPopulation = activePlayer:GetUnhappinessFromPuppetCityPopulation() -- not accurate
--			local nUnhappinessFromCitySpecialists = activePlayer:GetUnhappinessFromCitySpecialists() -- not accurate

			insert( tips, L( "[NEWLINE][COLOR:255:150:150:255]{TXT_KEY_TP_UNHAPPINESS_TOTAL}", activePlayer:GetUnhappiness() ) )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_CITY_COUNT", activePlayer:GetUnhappinessFromCityCount() / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_POPULATION", activePlayer:GetUnhappinessFromCityPopulation() / 100 ) -- - nUnhappinessFromCitySpecialists - nUnhappinessFromPuppetCityPopulation ) / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_CAPTURED_CITY_COUNT", activePlayer:GetUnhappinessFromCapturedCityCount() / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_OCCUPIED_POPULATION", activePlayer:GetUnhappinessFromOccupiedCities() / 100 )
--			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_PUPPET_CITIES", nUnhappinessFromPuppetCityPopulation / 100 )
--			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_SPECIALISTS", nUnhappinessFromCitySpecialists / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_UNITS", activePlayer:GetUnhappinessFromUnits() / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HAPPINESS_POLICIES", max(-nHappinessFromPolicies,0) )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHAPPINESS_PUBLIC_OPINION", activePlayer.GetUnhappinessFromPublicOpinion and activePlayer:GetUnhappinessFromPublicOpinion() or 0 )

			----------------------------
			-- Local Resources in Cities
			local tip = ""
			for resource in Resources( luxuries ) do
				local resourceID = resource.ID
				local quantity = activePlayer:GetNumResourceTotal( resourceID, false ) + activePlayer:GetResourceExport( resourceID )
				if quantity > 0 then
					tip = tip .. " " .. ColorizeAbs( quantity ) .. tostring( resource.IconString )
				end
			end
			insert( tips, L( "[ENDCOLOR][NEWLINE]{TXT_KEY_EO_LOCAL_RESOURCES}{1}", tip ) )
			local tipIndex =#tips
			for city in activePlayer:Cities() do
				local nConnectedResource = {}
				local nUnconnectedResource = {}
				for plot in CityPlots( city ) do
					local resourceID = plot:GetResourceType( activeTeamID )
					local nResource = plot:GetNumResource()
					if nResource > 0
						and GetResourceUsageType( resourceID ) == RESOURCEUSAGE_LUXURY
					then
						if plot:IsCity() or (not plot:IsImprovementPillaged() and plot:IsResourceConnectedByImprovement( plot:GetImprovementType() )) then
							nConnectedResource[resourceID] = (nConnectedResource[resourceID] or 0) + nResource
						else
							nUnconnectedResource[resourceID] = (nUnconnectedResource[resourceID] or 0) + nResource
						end
					end
				end
				local tip = ""
				for resource in Resources( luxuries ) do
					local resourceID = resource.ID
					if (nConnectedResource[resourceID] or 0) > 0 then
						tip = tip .. " " .. ColorizeAbs( nConnectedResource[resourceID] ) .. tostring( resource.IconString )
					end
					if (nUnconnectedResource[resourceID] or 0) > 0 then
						tip = tip .. " " .. ColorizeAbs( -nUnconnectedResource[resourceID] ) .. tostring( resource.IconString )
					end
				end
				if #tip > 0 then
					insert( tips, "[ICON_BULLET]" .. city:GetName() .. tip )
				end
			end
			if #tips <= tipIndex then
				insert( tips, L"[ICON_BULLET]{TXT_KEY_TP_NO_RESOURCES_DISCOVERED}" )
			end

			----------------------------
			-- Import & Export Breakdown
			local itemType, duration, finalTurn, data1, data2, data3, flag1, fromPlayerID
			local gameTurn = Game.GetGameTurn()-1
			local Exports = {}
			local Imports = {}
			for playerID = 0, MAX_MAJOR_CIVS-1 do
				Exports[ playerID ] = {}
				Imports[ playerID ] = {}
			end
			PushScratchDeal()
			for i = 0, UI.GetNumCurrentDeals( activePlayerID ) - 1 do
				UI.LoadCurrentDeal( activePlayerID, i )
				local otherPlayerID = ScratchDeal:GetOtherPlayer( activePlayerID )
				ScratchDeal:ResetIterator()
				repeat
					if _bCiv5BNWorBE then
						itemType, duration, finalTurn, data1, data2, data3, flag1, fromPlayerID = ScratchDeal:GetNextItem()
					else
						itemType, duration, finalTurn, data1, data2, fromPlayerID = ScratchDeal:GetNextItem()
					end
					-- data1 is resourceID, data2 is quantity

					if data2 and itemType == TRADE_ITEM_RESOURCES and GetResourceUsageType( data1 ) == RESOURCEUSAGE_LUXURY then
						local trade
						if fromPlayerID == activePlayerID then
							trade = Exports[otherPlayerID]
						else
							trade = Imports[fromPlayerID]
						end
						local resourceTrade = trade[ data1 ]
						if not resourceTrade then
							resourceTrade = {}
							trade[ data1 ] = resourceTrade
						end
						resourceTrade[finalTurn] = (resourceTrade[finalTurn] or 0) + data2
					end
				until not itemType
			end
			PopScratchDeal()

			----------------------------
			-- Imports
			tip = ""
			for resource in Resources( luxuries ) do
				local resourceID = resource.ID
				local quantity = activePlayer:GetResourceImport( resourceID ) + activePlayer:GetResourceFromMinors( resourceID )
				if quantity > 0 then
					tip = tip .. " " .. ColorizeAbs( quantity ) .. tostring( resource.IconString )
				end
			end
			if #tip > 0 then
				insert( tips, L( "[NEWLINE]{TXT_KEY_RESOURCES_IMPORTED}{1}", tip ) )
				for playerID, array in pairs( Imports ) do
					tip = ""
					for resourceID, row in pairs( array ) do
						for turn, quantity in pairs(row) do
							if quantity > 0 then
								tip = tip .. " " .. quantity .. tostring( (Resources[ resourceID ] or {}).IconString ) .. "(" .. turn - gameTurn .. ")"
							end
						end
					end
					if #tip > 0 then
						insert( tips, "[ICON_BULLET]" .. Players[ playerID ]:GetCivilizationShortDescription() .. tip )
					end
				end
				for minorID = MAX_MAJOR_CIVS, MAX_CIV_PLAYERS_M1 do
					local minor = Players[ minorID ]
					if minor and minor:IsAlive() and minor:GetAlly() == activePlayerID then
						tip = ""
						for resource in Resources( luxuries ) do
							local quantity = minor:GetResourceExport(resource.ID)
							if quantity > 0 then
								tip = tip .. " " .. quantity .. tostring( resource.IconString )
							end
						end
						if #tip > 0 then
							insert( tips, "[ICON_BULLET]" .. minor:GetCivilizationShortDescription() .. tip )
						end
					end
				end
			end

			----------------------------
			-- Exports
			tip = ""
			for resource in Resources( luxuries ) do
				local resourceID = resource.ID
				local quantity = activePlayer:GetResourceExport( resourceID )
				if quantity > 0 then
					tip = tip .. " " .. ColorizeAbs( quantity ) .. tostring( resource.IconString )
				end
			end
			if #tip > 0 then
				insert( tips, L( "[NEWLINE]{TXT_KEY_RESOURCES_EXPORTED}{1}", tip ) )
				for playerID, array in pairs( Exports ) do
					tip = ""
					for resourceID, row in pairs( array ) do
						for turn, quantity in pairs( row ) do
							if quantity > 0 then
								tip = tip .. " " .. quantity .. tostring( (Resources[ resourceID ] or {}).IconString ) .. "(" .. turn - gameTurn .. ")"
							end
						end
					end
					if #tip > 0 then
						insert( tips, "[ICON_BULLET]" .. Players[ playerID ]:GetCivilizationShortDescription() .. tip )
					end
				end
			end
			-- show resources available for trade to the active player

--			insert( tips, L"TXT_KEY_DIPLO_ITEMS_LUXURY_RESOURCES" )
--			insert( tips, sMissingHappinessLuxuries )

			insert( tips, L"[NEWLINE]{TXT_KEY_EO_RESOURCES_AVAILBLE}" )
			tipIndex =#tips
			----------------------------
			-- Available for Import
			for resource in Resources( luxuries ) do
				local resourceID = resource.ID
				local resources = {}
				for playerID = 0, MAX_CIV_PLAYERS_M1 do

					local player = Players[playerID]
					local isMinorCiv = player:IsMinorCiv()

					-- Valid player? - Can't be us, has to be alive and met, can't be allied city state
					if playerID ~= activePlayerID
						and player:IsAlive()
						and activeTeam:IsHasMet( player:GetTeam() )
						and not (isMinorCiv and player:IsAllies( activePlayerID ))
					then


						local nResource = ( isMinorCiv and player:GetNumResourceTotal(resourceID, false) + player:GetResourceExport( resourceID ) )
							or ( ScratchDeal:IsPossibleToTradeItem( playerID, activePlayerID, TRADE_ITEM_RESOURCES, resourceID, 1 ) and player:GetNumResourceAvailable(resourceID, false) )
							or 0
						if nResource > 0 then
							insert( resources, player:GetCivilizationShortDescription() .. " " .. nResource .. tostring( resource.IconString ) )
						end
					end
				end
				if #resources > 0 then
					insert( tips, "[ICON_BULLET]" .. tostring( resource._Name ) .. ": " .. concat( resources, ", " ) )
				end
			end
			if #tips <= tipIndex then
				insert( tips, L"[ICON_BULLET]{TXT_KEY_TP_NO_RESOURCES_DISCOVERED}" )
			end

			return concat( tips, "[NEWLINE]" )
		else
			return L"TXT_KEY_TOP_PANEL_HAPPINESS_OFF_TOOLTIP"
		end
	end,
	-------------------------------------------------
	-- Golden Age Tooltip
	-------------------------------------------------
	GoldenAgeString = function()

		if _bHappinessEnabled then

			local activePlayerID = GetActivePlayer()
			local activePlayer = Players[activePlayerID]

			local tips = {}
			local goldenAgeTurns = activePlayer:GetGoldenAgeTurns()
			local happyProgress = activePlayer:GetGoldenAgeProgressMeter()
			local happyNeeded = activePlayer:GetGoldenAgeProgressThreshold()

			if goldenAgeTurns > 0 then
				if _bCiv5BNW and activePlayer:GetGoldenAgeTourismModifier() > 0 then
					insert( tips, ToUpper"TXT_KEY_UNIQUE_GOLDEN_AGE_ANNOUNCE" )
				else
					insert( tips, ToUpper"TXT_KEY_GOLDEN_AGE_ANNOUNCE" )
				end
				insert( tips, L( "TXT_KEY_TP_GOLDEN_AGE_NOW", goldenAgeTurns ) )
			else
				insert( tips, L( "{TXT_KEY_PROGRESS_TOWARDS}[ENDCOLOR]: {2} / {3}[ICON_HAPPINESS_1]", "[COLOR_YELLOW]{TXT_KEY_SPECIALISTSANDGP_GOLDENAGE_HEADING4_TITLE:upper}", happyProgress, happyNeeded ) )
				local excessHappiness = activePlayer:GetExcessHappiness()
				if excessHappiness > 0 then
					insert( tips, L( "TXT_KEY_TP_GOLDEN_AGE_ADDITION", excessHappiness ) )
					insert( tips, L( "{TXT_KEY_MISSION_START_GOLDENAGE}: [COLOR_YELLOW]{TXT_KEY_STR_TURNS}[ENDCOLOR]", ceil((happyNeeded - happyProgress) / excessHappiness) ) )
				elseif excessHappiness < 0 then
					insert( tips, L( "[COLOR_WARNING_TEXT]{TXT_KEY_TP_GOLDEN_AGE_LOSS}[ENDCOLOR]", -excessHappiness ) )
				end
			end

			if _bBasicHelp then
				if _bCiv5notVanilla and activePlayer:IsGoldenAgeCultureBonusDisabled() then
					insert( tips, L"[NEWLINE]{TXT_KEY_TP_GOLDEN_AGE_EFFECT_NO_CULTURE}" )
				else
					insert( tips, L"[NEWLINE]{TXT_KEY_TP_GOLDEN_AGE_EFFECT}" )
				end
				if _bCiv5BNW and activePlayer:GetGoldenAgeTurns() > 0 and activePlayer:GetGoldenAgeTourismModifier() > 0 then
					insert( tips, L"[NEWLINE]{TXT_KEY_TP_CARNIVAL_EFFECT}" )
				end
			end

			return concat( tips, "[NEWLINE]" )
		else
			return L"TXT_KEY_TOP_PANEL_HAPPINESS_OFF_TOOLTIP"
		end
	end,
	-------------------------------------------------
	-- Culture Tooltip
	-------------------------------------------------
	CultureString = function()
		if _bPoliciesEnabled then
			local activePlayerID = GetActivePlayer()
			local activePlayer = Players[activePlayerID]

			local tips = {}
			local nCulture, nTotalCulturePerTurn, nCulturePerTurnForFree, nCulturePerTurnFromCities, nCulturePerTurnFromExcessHappiness, nCulturePerTurnFromTraits
			-- Firaxis Cleverness...
			if _bCiv5 then
				nCulture = activePlayer:GetJONSCulture()
				nTotalCulturePerTurn = activePlayer:GetTotalJONSCulturePerTurn()
				nCulturePerTurnForFree = activePlayer:GetJONSCulturePerTurnForFree()
				nCulturePerTurnFromCities = activePlayer:GetJONSCulturePerTurnFromCities()
				nCulturePerTurnFromExcessHappiness = activePlayer:GetJONSCulturePerTurnFromExcessHappiness()
				nCulturePerTurnFromTraits = _bCiv5BNW and activePlayer:GetJONSCulturePerTurnFromTraits() or 0
			else
				nCulture = activePlayer:GetCulture()
				nTotalCulturePerTurn = activePlayer:GetTotalCulturePerTurn()
				nCulturePerTurnForFree = activePlayer:GetCulturePerTurnForFree()
				nCulturePerTurnFromCities = activePlayer:GetCulturePerTurnFromCities()
				nCulturePerTurnFromExcessHappiness = activePlayer:GetCulturePerTurnFromExcessHealth()
				nCulturePerTurnFromTraits = activePlayer:GetCulturePerTurnFromTraits()
			end
			local nNextPolicyCost = activePlayer:GetNextPolicyCost()
			local nTurnsRemaining = 0
			if nNextPolicyCost > nCulture and nTotalCulturePerTurn > 0 then
				nTurnsRemaining = ceil( (nNextPolicyCost - nCulture) / nTotalCulturePerTurn)
			end

			if _bCiv5BNWorBE and activePlayer:IsAnarchy() then
				insert( tips, L("{TXT_KEY_TP_ANARCHY}[NEWLINE]", activePlayer:GetAnarchyNumTurns()) )
			end

			insert( tips, L( "{TXT_KEY_PROGRESS_TOWARDS}[ENDCOLOR]: {2} / {3}[ICON_CULTURE]", "[COLOR_MAGENTA]{TXT_KEY_ADVISOR_SCREEN_SOCIAL_POLICY_DISPLAY:upper}", nCulture, nNextPolicyCost ) )

			if nTotalCulturePerTurn > 0 then
				local nOverflow = nTotalCulturePerTurn * nTurnsRemaining + nCulture - nNextPolicyCost
				local tip = L( "[COLOR_MAGENTA]{TXT_KEY_STR_TURNS}[ENDCOLOR]: {2}[ICON_CULTURE]", nTurnsRemaining, nOverflow )
				if nTurnsRemaining > 1 then
					tip = L( "{TXT_KEY_STR_TURNS}: {2}[ICON_CULTURE], {3}", nTurnsRemaining -1, nOverflow - nTotalCulturePerTurn, tip )
				end
				insert( tips, tip )
			end

			insert( tips, L( "[NEWLINE][COLOR_MAGENTA]{1: number +0.##;[COLOR_RED]-0.##}[ENDCOLOR] {TXT_KEY_REPLAY_DATA_CULTUREPERTURN}", nTotalCulturePerTurn ) )

			-- Culture for Free
			insertLocalizedIfNonZero( tips, "TXT_KEY_TP_CULTURE_FOR_FREE", nCulturePerTurnForFree )

			-- Culture from Cities
			insertLocalizedIfNonZero( tips, "TXT_KEY_TP_CULTURE_FROM_CITIES", nCulturePerTurnFromCities )

			-- Culture from Excess Happiness / Health
			insertLocalizedIfNonZero( tips, "TXT_KEY_TP_CULTURE_FROM_" .. HAPPINESS, nCulturePerTurnFromExcessHappiness )

			-- Culture from Traits
			insertLocalizedIfNonZero( tips, "TXT_KEY_TP_CULTURE_FROM_TRAITS", nCulturePerTurnFromTraits )

			if _bCiv5 then
				-- Culture from Minor Civs
				local culturePerTurnFromMinorCivs = activePlayer:GetJONSCulturePerTurnFromMinorCivs()
				insertLocalizedIfNonZero( tips, "TXT_KEY_TP_CULTURE_FROM_MINORS", culturePerTurnFromMinorCivs )

				-- Culture from Religion
				local culturePerTurnFromReligion = _bCiv5notVanilla and activePlayer:GetCulturePerTurnFromReligion() or 0
				insertLocalizedIfNonZero( tips, "TXT_KEY_TP_CULTURE_FROM_RELIGION", culturePerTurnFromReligion )

				-- Culture from bonus turns (League Project)
				local culturePerTurnFromBonusTurns = 0
				if _bCiv5BNW then
					culturePerTurnFromBonusTurns = activePlayer:GetCulturePerTurnFromBonusTurns()
					insertLocalizedIfNonZero( tips, "TXT_KEY_TP_CULTURE_FROM_BONUS_TURNS", culturePerTurnFromBonusTurns, activePlayer:GetCultureBonusTurns() )
				end

				-- Culture from Vassals / Compatibility with Putmalk's Civ IV Diplomacy Features Mod
				local culturePerTurnFromVassals = activePlayer.GetJONSCulturePerTurnFromVassals and activePlayer:GetJONSCulturePerTurnFromVassals() or 0
				insertLocalizedIfNonZero( tips, "TXT_KEY_TP_CULTURE_VASSALS", culturePerTurnFromVassals )

				-- Culture from Golden Age
				insertLocalizedIfNonZero( tips, "TXT_KEY_TP_CULTURE_FROM_GOLDEN_AGE", nTotalCulturePerTurn - nCulturePerTurnForFree - nCulturePerTurnFromCities - nCulturePerTurnFromExcessHappiness - culturePerTurnFromMinorCivs - culturePerTurnFromReligion - nCulturePerTurnFromTraits - culturePerTurnFromBonusTurns - culturePerTurnFromVassals )	-- Compatibility with Putmalk's Civ IV Diplomacy Features Mod
			else
				-- Uncategorized Culture
				insertLocalizedIfNonZero( tips, "TXT_KEY_TP_YIELD_FROM_UNCATEGORIZED", nTotalCulturePerTurn - nCulturePerTurnForFree - nCulturePerTurnFromCities - nCulturePerTurnFromExcessHappiness - nCulturePerTurnFromTraits )
			end

			-- Let people know that building more cities makes policies harder to get
			insert( tips, L( "[NEWLINE]{TXT_KEY_TP_CULTURE_CITY_COST}", Game.GetNumCitiesPolicyCostMod() * ( 100 + ( _bCivBE and activePlayer:GetNumCitiesPolicyCostDiscount() or 0 ) ) / 100 ) )

			return concat( tips, "[NEWLINE]" )
		else
			return L"TXT_KEY_TOP_PANEL_POLICIES_OFF_TOOLTIP"
		end
	end,
	FaithString = FaithTooltip,
	FaithIcon = FaithTooltip,
	-------------------------------------------------
	-- Tourism Tooltip (BNW)
	-------------------------------------------------
	TourismString = function()
		local player = Players[GetActivePlayer()]

		local totalGreatWorks = player:GetNumGreatWorks()
		local totalSlots = player:GetNumGreatWorkSlots()

		local tipText = L( "{TXT_KEY_TOP_PANEL_TOURISM_TOOLTIP_1}[NEWLINE]{2}", totalGreatWorks, L( "TXT_KEY_TOP_PANEL_TOURISM_TOOLTIP_2", totalSlots - totalGreatWorks ) )

		local cultureVictory = GameInfo.Victories.VICTORY_CULTURAL
		if cultureVictory and PreGame.IsVictory(cultureVictory.ID) then
			tipText = L( "{2}[NEWLINE]{TXT_KEY_TOP_PANEL_TOURISM_TOOLTIP_3}", L( "TXT_KEY_CO_VICTORY_INFLUENTIAL_OF", player:GetNumCivsInfluentialOn(), player:GetNumCivsToBeInfluentialOn() ), tipText )
		end
		return tipText
	end,
	-------------------------------------------------
	-- International Trade Routes Tooltip (BNW)
	-------------------------------------------------
	InternationalTradeRoutes = function()
		local player = Players[GetActivePlayer()]

		local tipText = ""

		local nAvailableTradeUnits = player:GetNumAvailableTradeUnits(DOMAIN_LAND)
		if nAvailableTradeUnits > 0 then
			local tradeUnitType = player:GetTradeUnitType(DOMAIN_LAND)
			tipText = tipText .. L("TXT_KEY_TOP_PANEL_INTERNATIONAL_TRADE_ROUTES_TT_UNASSIGNED", nAvailableTradeUnits, tostring( GameInfo.Units[ tradeUnitType ]._Name ) ) .. "[NEWLINE]"
		end

		nAvailableTradeUnits = player:GetNumAvailableTradeUnits(DOMAIN_SEA)
		if nAvailableTradeUnits > 0 then
			local tradeUnitType = player:GetTradeUnitType(DOMAIN_SEA)
			tipText = tipText .. L("TXT_KEY_TOP_PANEL_INTERNATIONAL_TRADE_ROUTES_TT_UNASSIGNED", nAvailableTradeUnits, tostring( GameInfo.Units[ tradeUnitType ]._Name ) ) .. "[NEWLINE]"
		end

		local usedTradeRoutes = player:GetNumInternationalTradeRoutesUsed()
		local availableTradeRoutes = player:GetNumInternationalTradeRoutesAvailable()

		if #tipText > 0 then
			tipText = tipText .. "[NEWLINE]"
		end
		tipText = L("TXT_KEY_TOP_PANEL_INTERNATIONAL_TRADE_ROUTES_TT", usedTradeRoutes, availableTradeRoutes)

		local strYourTradeRoutes = player:GetTradeYourRoutesTTString()
		if #strYourTradeRoutes > 0 then
			tipText = tipText .. "[NEWLINE][NEWLINE]"
					.. L"TXT_KEY_TOP_PANEL_ITR_ESTABLISHED_BY_PLAYER_TT"
					.. "[NEWLINE]"
					.. strYourTradeRoutes
		end

		local strToYouTradeRoutes = player:GetTradeToYouRoutesTTString()
		if #strToYouTradeRoutes > 0 then
			tipText = tipText .. "[NEWLINE][NEWLINE]"
					.. L"TXT_KEY_TOP_PANEL_ITR_ESTABLISHED_BY_OTHER_TT"
					.. "[NEWLINE]"
					.. strToYouTradeRoutes
		end

		return tipText
	end,
	-------------------------------------------------
	-- Health Tooltip (CivBE)
	-------------------------------------------------
	HealthString = function()
		if _bHealthEnabled then
			local activePlayerID = GetActivePlayer()
			local activePlayer = Players[activePlayerID]

			local excessHealth = activePlayer:GetExcessHealth()
			local healthLevel = activePlayer:GetCurrentHealthLevel()
			local healthLevelInfo = GameInfo.HealthLevels[healthLevel]
			local colorPrefixText = "[COLOR_GREEN]"
			local iconStringText = "[ICON_HEALTH]"
			local rangeFactor = 1
			if excessHealth < 0 then
				colorPrefixText = "[COLOR_RED]"
				iconStringText = "[ICON_UNHEALTH]"
				rangeFactor = -1
			end
			local tips = { L("TXT_KEY_TP_HEALTH_SUMMARY", iconStringText, colorPrefixText, excessHealth * rangeFactor) }
			if healthLevelInfo.Help then
				insert( tips, L( healthLevelInfo.Help ) )
			end
			insert( tips, activePlayer:IsEmpireUnhealthy() and "[COLOR_WARNING_TEXT]" or "[COLOR_POSITIVE_TEXT]" )
			local cityYieldMods = {}
			local combatMod = 0
			local cityGrowthMod = 0
			local outpostGrowthMod = 0
			local cityIntrigueMod = 0
			for info in GameInfo.HealthLevels() do
				local healthLevelID = info.ID
				if activePlayer:IsAffectedByHealthLevel(healthLevelID) then
					for yieldID = 0, NUM_YIELD_TYPES_M1 do
						cityYieldMods[yieldID] = (cityYieldMods[yieldID] or 0) + Game.GetHealthLevelCityYieldModifier(healthLevelID, excessHealth, yieldID)
					end
					combatMod = combatMod + (info.CombatModifier or 0)
					cityGrowthMod = cityGrowthMod + Game.GetHealthLevelCityGrowthModifier(healthLevelID, excessHealth)
					outpostGrowthMod = outpostGrowthMod + Game.GetHealthLevelCityGrowthModifier(healthLevelID, excessHealth)
					cityIntrigueMod = cityIntrigueMod + Game.GetHealthLevelCityIntrigueModifier(healthLevelID, excessHealth)
				end
			end
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_LEVEL_EFFECT_COMBAT_MODIFIER", combatMod )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_LEVEL_EFFECT_CITY_GROWTH_MODIFIER", cityGrowthMod )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_LEVEL_EFFECT_OUTPOST_GROWTH_MODIFIER", outpostGrowthMod )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_LEVEL_EFFECT_CITY_INTRIGUE_MODIFIER", cityIntrigueMod )
			for yieldID = 0, NUM_YIELD_TYPES_M1 do
				local yieldInfo = GameInfo.Yields[ yieldID ]
				insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_LEVEL_EFFECT_CITY_YIELD_MODIFIER", yieldInfo and cityYieldMods[yieldID] or 0, tostring( yieldInfo.IconString ), tostring( yieldInfo._Name ) )
			end
--			insert( tips, "[ENDCOLOR]" )

			--*** HEALTH Breakdown ***--
			local totalHealth		= activePlayer:GetHealth()
			local handicapInfo		= GameInfo.HandicapInfos[activePlayer:GetHandicapType()]
			local handicapHealth		= handicapInfo.BaseHealthRate
			local healthFromCities		= activePlayer:GetHealthFromCities()
			local extraCityHealth		= activePlayer:GetExtraHealthPerCity() * activePlayer:GetNumCities()
			local healthFromPolicies	= activePlayer:GetHealthFromPolicies()
			local healthFromTradeRoutes	= activePlayer:GetHealthFromTradeRoutes()
			--local healthFromNationalSecurityProject	= activePlayer:GetHealthFromNationalSecurityProject(); WRM: Add this in when we have a text string for it

			insert( tips, "[COLOR_WHITE]" )
			insert( tips, L( "TXT_KEY_TP_HEALTH_SOURCES", totalHealth ) )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_CITIES", healthFromCities )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_POLICIES", healthFromPolicies )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_CONNECTED_CITIES", healthFromTradeRoutes )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_CITY_COUNT", extraCityHealth )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_DIFFICULTY_LEVEL", handicapHealth )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_HEALTH_OTHER_SOURCES", totalHealth - handicapHealth - healthFromPolicies - healthFromCities - healthFromTradeRoutes - extraCityHealth )
			insert( tips, "[ENDCOLOR]" )

			--*** UNHEALTH Breakdown ***--
			local totalUnhealth			= activePlayer:GetUnhealth()
			local unhealthFromCities		= activePlayer:GetUnhealthFromCities()
			local unhealthFromUnits			= activePlayer:GetUnhealthFromUnits()
			local unhealthFromCityCount		= activePlayer:GetUnhealthFromCityCount()
			local unhealthFromConqueredCityCount	= activePlayer:GetUnhealthFromConqueredCityCount()
			local unhealthFromPupetCities		= activePlayer:GetUnhealthFromPuppetCityPopulation()
			local unhealthFromSpecialists		= activePlayer:GetUnhealthFromCitySpecialists()
			local unhealthFromPop			= activePlayer:GetUnhealthFromCityPopulation() - unhealthFromSpecialists - unhealthFromPupetCities
			local unhealthFromConqueredCities	= activePlayer:GetUnhealthFromConqueredCities()

			insert( tips, "[COLOR:255:150:150:255]" )
			insert( tips, L( "TXT_KEY_TP_UNHEALTH_TOTAL", totalUnhealth ) )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHEALTH_CITIES", unhealthFromCities / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHEALTH_CITY_COUNT", unhealthFromCityCount / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHEALTH_CAPTURED_CITY_COUNT", unhealthFromConqueredCityCount / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHEALTH_POPULATION", unhealthFromPop / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHEALTH_PUPPET_CITIES", unhealthFromPupetCities / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHEALTH_SPECIALISTS", unhealthFromSpecialists / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHEALTH_OCCUPIED_POPULATION", unhealthFromConqueredCities / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHEALTH_UNITS", unhealthFromUnits / 100 )
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_YIELD_FROM_UNCATEGORIZED", totalUnhealth - ( unhealthFromCities + unhealthFromCityCount + unhealthFromConqueredCityCount + unhealthFromPop + unhealthFromPupetCities + unhealthFromSpecialists + unhealthFromConqueredCities + unhealthFromUnits ) / 100 )

			-- Overall Unhealth Mod
			local unhealthMod = activePlayer:GetUnhealthMod()
			if unhealthMod > 0 then -- Positive mod means more Unhealth - this is a bad thing!
				insert( tips, "[ENDCOLOR][COLOR:255:150:150:255]" )
			else
				insert( tips, "[ENDCOLOR]" )
			end
			insertLocalizedBulletIfNonZero( tips, "TXT_KEY_TP_UNHEALTH_MOD", unhealthMod )

			-- Basic explanation of Health
			insert( tips, L( "[ENDCOLOR][NEWLINE]{TXT_KEY_TP_HEALTH_EXPLANATION}", totalUnhealth ) )

			return concat( tips, "[NEWLINE]" )
		else
			return L"TXT_KEY_TOP_PANEL_HEALTH_OFF_TOOLTIP"
		end
	end,
	-------------------------------------------------
	-- Affinity Tooltips (CivBE)
	-------------------------------------------------
	Harmony = function() return GetHelpTextForAffinity( GameInfoTypes.AFFINITY_TYPE_HARMONY, Players[GetActivePlayer()] ) end,
	Purity = function() return GetHelpTextForAffinity( GameInfoTypes.AFFINITY_TYPE_PURITY, Players[GetActivePlayer()] ) end,
	Supremacy = function() return GetHelpTextForAffinity( GameInfoTypes.AFFINITY_TYPE_SUPREMACY, Players[GetActivePlayer()] ) end,
}

LuaEvents.TopPanelTooltips.Add( function( control )
	return ShowTextToolTip( TooltipSelect( TopPanelTooltips, control ) )
end)
