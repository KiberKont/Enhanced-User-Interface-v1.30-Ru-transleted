--==========================================================
-- EUI context
-- Hosts game info cache, interface settings and tooltip server
-- Written by bc1 using Notepad++
--==========================================================

local ipairs = ipairs
local pairs = pairs
local print = print
local tostring = tostring
local insert = table.insert
local format = string.format
local concat = table.concat
local sort = table.sort

local ContentManager = ContentManager
local ContentTypeGAMEPLAY = ContentType.GAMEPLAY
local Locale = Locale
local Modding = Modding

-- Print game DLC and MOD configuration for debug
local t= { "DLC/MOD configuration" }
for _, v in pairs( ContentManager.GetAllPackageIDs() ) do
	insert( t, format( "%s DLC: \t%s %s", ContentManager.IsActive(v, ContentTypeGAMEPLAY) and "Active" or "Disabled", v, Locale.Lookup(ContentManager.GetPackageDescription(v)) ) )
end
for _, v in pairs( Modding.GetActivatedMods() ) do
	insert( t, format( "Active MOD: \t%s %s v%s", v.ID, Modding.GetModProperty(v.ID, v.Version, "Name"), v.Version ) )
end
print( concat( t,"\n\t" ) )

if Game then
	local slotStatus = {} for k, v in pairs( SlotStatus ) do slotStatus[ v ] = k end
	local gameTypes = {} for k, v in pairs( GameTypes ) do gameTypes[ v ] = k end
	local t = {}
	local activePlayerID = Game.GetActivePlayer()
	for playerID, player in ipairs(Players) do
		if player:IsEverAlive() then
			insert( t, format( "\n%s\tplayer %-4iteam %-4i%-22s%-14sciv %-4i%s", playerID == activePlayerID and "*" or "",
				playerID, PreGame.GetTeam( playerID ), GameInfo.HandicapInfos[ PreGame.GetHandicap( playerID ) ].Type,
				slotStatus[ PreGame.GetSlotStatus( playerID ) ], PreGame.GetCivilization( playerID ), player:GetCivilizationShortDescription() ) )
		end
	end
	local m = PreGame.GetNumMinorCivs()
	local s = Game.GetStartTurn()
	print( format( "%s turn %i[%i-%i] with %i players and %i minor civs", gameTypes[ PreGame.GetGameType() ], Game.GetGameTurn(), s, s+Game.GetMaxTurns(), #t-m-1, m ), concat(t) )

	include "EUI_InfoCache" -- warning! booleans are true, not 1, and use iterator ONLY with table field conditions, NOT string SQL query
	MapModData.EUI_GameInfoCache = GameInfoCache
	print "EUI game info cache loaded."
	include "EUI_SettingsCache"
	MapModData.EUI_UserInterfaceSettings = UserInterfaceSettings
	print "EUI settings cache loaded."
	include "EUI_TooltipServer"
	print "EUI tooltip server loaded."
end
