if not IconHookup then
	include "IconHookup"
end
local IconHookup = IconHookup
local GetMousePos = UIManager.GetMousePos
--local ScreenWidth = UIManager.GetScreenSizeVal()

local two_pi = math.pi * 2
local cos = math.cos
local sin = math.sin
local min = math.min

local function SetMark( line, size, percent, label, text )
	local r1 = size * 0.43
	local r2 = size * 0.47
	local angle = percent * two_pi
	local x = sin( angle )
	local y = -cos( angle )
	line:SetEndVal( r1 * x, r1 * y )
	label:SetOffsetVal( r2 * x, r2 * y )
	label:SetText( text )
end
function ShowProgress( size, LossMeter, ProgressMeter, Line1, Label1, Line2, Label2, turnsRemaining, cost, progress, change, loss )
	local bLine1, bLine2, bLossMeter, bProgressMeter
	if cost and progress and change and cost > 0 then
		bProgressMeter = true
		local progressNext = progress + change
		if turnsRemaining and change ~= 0 then
			local overflow = change * turnsRemaining + progress - cost
			if change > 0 then
				SetMark( Line2, size, overflow / cost, Label2, turnsRemaining )
				bLine2 = true
				if turnsRemaining > 1 and change/cost > .03 then
					SetMark( Line1, size, ( overflow - change ) / cost, Label1, turnsRemaining - 1 )
					bLine1 = true
				end
			else
				SetMark( Line1, size, overflow / cost, Label1, turnsRemaining )
				bLine1 = true
				if turnsRemaining > 1 and change/cost < -.03 then
					SetMark( Line2, size, ( overflow - change ) / cost, Label2, turnsRemaining - 1 )
					bLine2 = true
				end
				loss = change
				progress = progressNext
			end
		end
		ProgressMeter:SetPercents( min(1, progress / cost), min(1, progressNext / cost ) )
		bLossMeter = loss and loss < 0
		if bLossMeter then
			LossMeter:SetPercent( min(1, ( progressNext - loss ) / cost ) )
		end
	end
	LossMeter:SetHide( not bLossMeter )
	ProgressMeter:SetHide( not bProgressMeter )
	Line1:SetHide( not bLine1 )
	Label1:SetHide( not bLine1 )
	Line2:SetHide( not bLine2 )
	Label2:SetHide( not bLine2 )
end
local ShowProgress = ShowProgress

function ShowProgressToolTip( controls, size, portraitOffset, portraitAtlas, text, ... )
	controls.ItemPortrait:SetHide( not ( portraitAtlas and IconHookup( portraitOffset, size, portraitAtlas, controls.ItemPortrait ) ) )
	if controls.Text then
		controls.Text:SetText( text )
		if controls.Grid then
			controls.Grid:DoAutoSize()
		end
	end
	if controls.Meters then
		controls.Meters:SetAnchor( GetMousePos() > 300 and "L,T" or "R,T" )
	end
	return ShowProgress( size, controls.LossMeter, controls.ProgressMeter, controls.Line1, controls.Label1, controls.Line2, controls.Label2, ... )
end
