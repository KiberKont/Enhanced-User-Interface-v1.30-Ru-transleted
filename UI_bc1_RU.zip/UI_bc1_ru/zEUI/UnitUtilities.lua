-- Written by bc1 using Notepad++

local GameInfo = GameInfoCache -- warning! booleans are true, not 1, and use iterator ONLY with table field conditions, NOT string SQL query

local ceil = math.ceil
local max = math.max
local format = string.format
local tostring = tostring
local pairs = pairs

local IsMultiplayerGame = PreGame.IsMultiplayerGame
local GetActivePlayer = Game.GetActivePlayer
local GetActiveTeam = Game.GetActiveTeam
local IsDebugMode = Game.IsDebugMode
local GetReligionName = Game.GetReligionName
local L = Locale.ConvertTextKey
local Players = Players
local Teams = Teams
local PlotDirection = Map.PlotDirection

local DOMAIN_AIR = DomainTypes.DOMAIN_AIR
local ACTIVITY_HEAL = ActivityTypes.ACTIVITY_HEAL
local MOVE_DENOMINATOR = tonumber(GameDefines.MOVE_DENOMINATOR) or 60
local ENEMY_HEAL_RATE = tonumber(GameDefines.ENEMY_HEAL_RATE) or 10
local NEUTRAL_HEAL_RATE = tonumber(GameDefines.NEUTRAL_HEAL_RATE) or 10
local FRIENDLY_HEAL_RATE = tonumber(GameDefines.FRIENDLY_HEAL_RATE) or 20
local CITY_HEAL_RATE = tonumber(GameDefines.CITY_HEAL_RATE) or 25

local HealTechs
if Game.GetReligionName then
	HealTechs = {}
	for row in GameInfo.Technologies() do
		local h = row.UnitBaseHealModifier
		if h and h > 0 then
			HealTechs[row.ID] = h
		end
	end
end

--==========================================================
-- Short Unit Tip
function ShortUnitTip( unit )
	local activePlayerID = GetActivePlayer()
	local activeTeamID = GetActiveTeam()
	local activeTeam = Teams[activeTeamID]

	local unitOwnerID = unit:GetOwner()
	local unitOwner = Players[unitOwnerID]
	local unitTeamID = unit:GetTeam()

	local civAdjective = unitOwner:GetCivilizationAdjective()
	local nickName = unitOwner:GetNickName()

	local unitTip
	if activeTeamID == unitTeamID or ( unitOwner:IsMinorCiv() and unitOwner:IsAllies( activePlayerID ) ) then
		unitTip = "[COLOR_POSITIVE_TEXT]"
	elseif activeTeam:IsAtWar( unitTeamID ) then
		unitTip = "[COLOR_NEGATIVE_TEXT]"
	else
		unitTip = "[COLOR_WHITE]"
	end
	unitTip = unitTip .. L(unit:GetNameKey()) .. "[ENDCOLOR]"

	-- Player using nickname
	if IsMultiplayerGame() and nickName and #nickName > 0 then

		unitTip = L( "TXT_KEY_MULTIPLAYER_UNIT_TT", nickName, civAdjective, unitTip )

	elseif activeTeam:IsHasMet( unitTeamID ) then

		unitTip = L( "TXT_KEY_PLOTROLL_UNIT_DESCRIPTION_CIV", civAdjective, unitTip )
		if unit:HasName() then
			unitTip = L(unit:GetNameNoDesc()) .. " (" .. unitTip .. ")"
		end
	end

	local originalOwnerID = unit:GetOriginalOwner()
	local originalOwner = originalOwnerID and Players[originalOwnerID]
	if originalOwner and originalOwnerID ~= unitOwnerID and activeTeam:IsHasMet( originalOwner:GetTeam() ) then
		unitTip = unitTip .. " (" .. originalOwner:GetCivilizationAdjective() .. ")"
	end

	-- Debug stuff
	if IsDebugMode() then
		unitTip = unitTip .. " (".. tostring(unitOwnerID) ..":" .. tostring(unit:GetID()) .. ")"
	end

	-- Moves & Combat Strength
	local unitMoves = 0
	local unitMovesLeft
	local unitStrength = unit.GetBaseCombatStrength and unit:GetBaseCombatStrength() or unit:GetCombatStrength() --BE stupid function name change
	-- todo unit:GetMaxDefenseStrength()
	local rangedStrength = unit.GetBaseRangedCombatStrength and unit:GetBaseRangedCombatStrength() or unit:GetRangedCombatStrength() --BE stupid function name change

	if unit:GetDomainType() == DOMAIN_AIR then
		unitStrength = rangedStrength
		rangedStrength = 0
		unitMoves = unit:Range()
	else
		unitMoves = unit:MaxMoves() / MOVE_DENOMINATOR
		if unitOwnerID == activePlayerID then
			unitMovesLeft = unit:MovesLeft() / MOVE_DENOMINATOR
		end
	end

	-- In Orbit?
	if unit.IsInOrbit and unit:IsInOrbit() then
		unitTip = unitTip .. " " .. "[COLOR_CYAN]" .. L"TXT_KEY_PLOTROLL_ORBITING" .. "[ENDCOLOR]"

	else
		-- Moves
		if unitMoves > 0 then
			if unitMovesLeft and unitMovesLeft < unitMoves then
				unitTip = format("%s %.3g/%g[ICON_MOVES]", unitTip, unitMovesLeft, unitMoves )
			else
				unitTip = format("%s %.3g[ICON_MOVES]", unitTip, unitMoves )
			end
		end

		-- Strength
		if unitStrength > 0 then
			local adjustedUnitStrength = (max(100 + unit:GetStrategicResourceCombatPenalty(), 10) * unitStrength) / 100
			--todo other modifiers eg unhappy...
			if adjustedUnitStrength < unitStrength then
				adjustedUnitStrength = format(" [COLOR_NEGATIVE_TEXT]%.3g[ENDCOLOR]", adjustedUnitStrength )
			end
			unitTip = unitTip .. " " .. adjustedUnitStrength .. "[ICON_STRENGTH]"
		end

		-- Ranged Strength
		if rangedStrength > 0 then
			unitTip = unitTip .. " " .. rangedStrength .. "[ICON_RANGE_STRENGTH]"..unit:Range()
		end

		-- Religious Fervor
		if unit.GetReligion then
			local religionID = unit:GetReligion()
			if religionID > 0 then
				local spreadsLeft = unit:GetSpreadsLeft()
				unitTip = unitTip .. " "
				if spreadsLeft > 0 then
					unitTip = unitTip .. spreadsLeft
				end
				unitTip = unitTip .. ((GameInfo.Religions[ religionID ] or {}).IconString or "?") .. L( GetReligionName( religionID ) )
			end
		end

		-- Hit Points
		if unit:IsHurt() then
			unitTip = unitTip .. " " .. L( "TXT_KEY_PLOTROLL_UNIT_HP", unit:GetCurrHitPoints() )
		end
	end

	-- Embarked?
	if unit:IsEmbarked() then
		unitTip = unitTip .. " " .. L"TXT_KEY_PLOTROLL_EMBARKED"
	end
	
	return unitTip
end

--==========================================================
-- Unit Building Progress
function GetUnitBuildProgress( unit, plot, buildID )
	local unitOwner = unit:GetOwner()
	local buildProgress = plot:GetBuildProgress( buildID )
	local nominalWorkRate = unit:WorkRate( true )
	-- take into account unit.cpp "wipe out all build progress also" game bug
	local buildTime = plot:GetBuildTime( buildID, unitOwner ) - nominalWorkRate
	local buildTurnsLeft
	if buildProgress == 0 then
		buildTurnsLeft = plot:GetBuildTurnsLeft( buildID, unitOwner, nominalWorkRate - unit:WorkRate() )
	else
		buildProgress = buildProgress - nominalWorkRate
		buildTurnsLeft = plot:GetBuildTurnsLeft( buildID, unitOwner, -unit:WorkRate() )
	end
	if buildTurnsLeft > 99999 then
		return ceil( ( buildTime - buildProgress ) / nominalWorkRate ), buildProgress, buildTime
	else
		return buildTurnsLeft, buildProgress, buildTime
	end
end

--==========================================================
-- Unit Heal Progress
function GetUnitHealProgress( unit, plot )
	local unitPlayerID = unit:GetOwner()
	local unitPlayer = Players[ unitPlayerID ]
	local unitTeamID = unitPlayer and unitPlayer:GetTeam()
	local unitTeam = Teams[ unitTeamID ]
	if plot and unitTeam and ( unit:CanHeal( plot ) or unit:GetActivityType() == ACTIVITY_HEAL ) then
		local x = plot:GetX()
		local y = plot:GetY()
		local city = plot:GetPlotCity()
		local adjacentCity = city
		local baseHeal = 0
		local extraHeal = 0
		local modHeal = 0
		-- extra healing from friendly units in same plot
		local p, u, h
		for i = 0, plot:GetNumUnits() - 1 do
			u = plot:GetUnit(i)
			if u and u:GetTeam() == unitTeamID then
				h = u:GetSameTileHeal()
				if h > extraHeal then
					extraHeal = h
				end
			end
		end
		-- extra healing from friendly units in adjacent plots
		for direction = 0, 5 do  -- 0 to DirectionTypes.NUM_DIRECTION_TYPES-1
			p = PlotDirection( x, y, direction )
			if p then
				for i = 0, p:GetNumUnits() - 1 do
					u = p:GetUnit(i)
					if u and u:GetTeam() == unitTeamID then
						h = u:GetAdjacentTileHeal()
						if h > extraHeal then
							extraHeal = h
						end
					end
				end
			end
			if not adjacentCity then
				adjacentCity = p:GetPlotCity()
			end
		end
		-- healing in friendly territory
		if plot:IsFriendlyTerritory( unitPlayerID ) then
			baseHeal = FRIENDLY_HEAL_RATE
			extraHeal = extraHeal + unit:GetExtraFriendlyHeal()
			-- extra healing from religion
			if adjacentCity and unitPlayer.HasCreatedReligion and unitPlayer:HasCreatedReligion() and adjacentCity:GetOwner() == unitPlayerID then
				local religionID = adjacentCity:GetReligiousMajority()
				local beliefs
				if religionID == 0 then
					beliefs = { unitPlayer:GetBeliefInPantheon() }
				elseif religionID > 0 and religionID == unitPlayer:GetReligionCreatedByPlayer() then
					beliefs = Game.GetBeliefsInReligion( religionID )
				end
				if beliefs then
					for _,v in pairs(beliefs) do
						local belief = GameInfo.Beliefs[v]
						if belief then
							extraHeal = extraHeal + (belief.FriendlyHealChange or 0)
						end
					end
				end
			end
		-- healing in enemy territory
		elseif unitTeam:IsAtWar( plot:GetTeam() ) then
			baseHeal = ENEMY_HEAL_RATE
			extraHeal = extraHeal + unit:GetExtraEnemyHeal()
		-- healing in neutral territory
		else
			baseHeal = NEUTRAL_HEAL_RATE
			extraHeal = extraHeal + unit:GetExtraNeutralHeal()
		end
		-- healing inside city
		if city then
			baseHeal = CITY_HEAL_RATE
			-- extraHeal = extraHeal + city:GetHealRate() -- missing from lua API
		end
		-- extra healing from technologies
		if HealTechs then
			local unitTechs = unitTeam:GetTeamTechs()
			for ID, h in pairs( HealTechs ) do
				if unitTechs:HasTech( ID ) then
					modHeal = modHeal + h
				end
			end
		end
		local healRate = baseHeal*(100+modHeal)/100 + extraHeal
		if healRate > 0 then
			if unit:HasMoved() and not unit:IsAlwaysHeal() then
				return ceil( unit:GetDamage() / healRate ) + 1, healRate
			else
				return ceil( unit:GetDamage() / healRate ), healRate
			end
		end
	end
	return 0, 0
end