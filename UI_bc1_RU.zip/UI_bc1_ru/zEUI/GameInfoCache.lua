--==========================================================
-- Written by bc1 using Notepad++
--==========================================================

if not GameInfoCache and MapModData then
	local p = ContextPtr:LookUpControl("..")
	local s = p and p:GetID()
	if s and not MapModData.EUI_GameInfoCache and s:lower()=="ingame" then
		print( "LoadNewContext EUI Context into", s, "Context" )
		p:LoadNewContext'EUI_Context'
	end
	GameInfoCache = MapModData.EUI_GameInfoCache
end
if not GameInfoCache then
	print "Include EUI_InfoCache"
	include'EUI_InfoCache'
end
