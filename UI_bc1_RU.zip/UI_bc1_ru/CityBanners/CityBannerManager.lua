--==========================================================
-- CityBannerManager
-- Re-written by bc1 using Notepad++
-- code is common using _bCiv5GK and _bCiv5BNW switches
--==========================================================

Events.SequenceGameInitComplete.Add(function()

include "GameInfoCache" -- warning! booleans are true, not 1, and use iterator ONLY with table field conditions, NOT string SQL query
local GameInfo = GameInfoCache

include "UserInterfaceSettings"
local UserInterfaceSettings = UserInterfaceSettings

include "IconHookup"
local IconHookup = IconHookup
local CivIconHookup = CivIconHookup
local PrimaryColors = PrimaryColors
local BackgroundColors = BackgroundColors
local ColorGreen = Color( 0, 1, 0, 1 )
local ColorYellow = Color( 1, 1, 0, 1 )
local ColorRed = Color( 1, 0, 0, 1 )
local ColorCulture = Color( 1, 0, 1, 1 )

include "CityStateStatusHelper"
local GetCityStateStatusRow = GetCityStateStatusRow
local GetActiveQuestText = GetActiveQuestText

--==========================================================
-- Minor lua optimizations
--==========================================================

local ipairs = ipairs
local floor = math.floor
local max = math.max
local min = math.min
local sqrt = math.sqrt
local pairs = pairs
local print = print
local insert = table.insert
local remove = table.remove
local format = string.format

local ButtonPopupTypes = ButtonPopupTypes
local CAN_CITY_USE_INDIRECT_FIRE = GameDefines.CAN_CITY_USE_INDIRECT_FIRE == 1
local CITY_ATTACK_RANGE = GameDefines.CITY_ATTACK_RANGE or 2
local CITY_ATTACK_RANGE_AREA = (CITY_ATTACK_RANGE+1) * CITY_ATTACK_RANGE * 3
local CITY_PLOTS_RADIUS = GameDefines.CITY_PLOTS_RADIUS or 2
local CityUpdateTypes = CityUpdateTypes
local ContextPtr = ContextPtr
local Controls = Controls
local Events = Events
local EventsClearHexHighlightStyle = Events.ClearHexHighlightStyle.Call
local EventsSerialEventHexHighlight = Events.SerialEventHexHighlight.Call
local GetActivePlayer = Game.GetActivePlayer
local GetActiveTeam = Game.GetActiveTeam
local GetPlot = Map.GetPlot
local GetPlotByIndex = Map.GetPlotByIndex
local GetUnitPortraitIcon = UI.GetUnitPortraitIcon
local GridToWorld = GridToWorld
local HexToWorld = HexToWorld
local InStrategicView = InStrategicView or function() end
local InterfaceModeTypes = InterfaceModeTypes
local IsCivilianYields = OptionsManager.IsCivilianYields
local IsDebugMode = Game.IsDebugMode
local IsNetworkMultiPlayer = Game.IsNetworkMultiPlayer()
local IsProcessingMessages = Game.IsProcessingMessages
local L = Locale.ConvertTextKey
local LuaEvents = LuaEvents
local MAX_CITY_HIT_POINTS = GameDefines.MAX_CITY_HIT_POINTS or 200
local MinorCivQuestTypes = MinorCivQuestTypes
local Mouse = Mouse
local Players = Players
local SendUpdateCityCitizens = Network.SendUpdateCityCitizens
local Teams = Teams
local ToGridFromHex = ToGridFromHex
local ToHexFromGrid = ToHexFromGrid
local ToUpper = Locale.ToUpper
local UI = UI
local UnitMoving = UnitMoving
local YieldDisplayTypesAREA = YieldDisplayTypes.AREA
local YieldDisplayTypesCITY_OWNED = YieldDisplayTypes.CITY_OWNED

--==========================================================
-- Globals
--==========================================================

local RefreshCityBanner -- function

local _bCiv5GK = Game.GetReligionName ~= nil
local _bCiv5BNW = Game.GetActiveLeague ~= nil

local _iActivePlayer = GetActivePlayer()
local _pActivePlayer = Players[ _iActivePlayer ]
local _iActiveTeam = GetActiveTeam()
local _pActiveTeam = Teams[ _iActiveTeam ]

local _tCityBanners = {}
local _tStrikeButtons = {}

local _tScrapTeamBanners = {}
local _tScrapOtherBanners = {}
local _tScrapSVStrikeButtons = {}

local _iWorldPositionOffsetZ = InStrategicView and 35 or 55

local _iPlotHexHighlight

--local IsCivBE = Game.GetAvailableBeliefs ~= nil
--local g_CovertOpsBannerContainer = IsCivBE and ContextPtr:LookUpControl( "../CovertOpsBannerContainer" )
--local g_CovertOpsIntelReportContainer = IsCivBE and ContextPtr:LookUpControl( "../CovertOpsIntelReportContainer" )

local _tCityFocusIcons = {
--[CityAIFocusTypes.NO_CITY_AI_FOCUS_TYPE or -9] = "",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_FOOD or -9] = "[ICON_FOOD]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PRODUCTION or -9] = "[ICON_PRODUCTION]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GOLD or -9] = "[ICON_GOLD]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_SCIENCE or -9] = "[ICON_RESEARCH]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_CULTURE or -9] = "[ICON_CULTURE]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GREAT_PEOPLE or -9] = "[ICON_GREAT_PEOPLE]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_FAITH or -9] = "[ICON_PEACE]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PROD_GROWTH or -9] = "[ICON_PRODUCTION][ICON_FOOD]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GOLD_GROWTH or -9] = "[ICON_GOLD][ICON_FOOD]",
[-9] = nil }

local _tCityFocusTooltips = {
[CityAIFocusTypes.NO_CITY_AI_FOCUS_TYPE or -9] = L"TXT_KEY_CITYVIEW_FOCUS_BALANCED_TEXT",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_FOOD or -9] = L"TXT_KEY_CITYVIEW_FOCUS_FOOD_TEXT",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PRODUCTION or -9] = L"TXT_KEY_CITYVIEW_FOCUS_PROD_TEXT",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GOLD or -9] = L"TXT_KEY_CITYVIEW_FOCUS_GOLD_TEXT",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_SCIENCE or -9] = L"TXT_KEY_CITYVIEW_FOCUS_RESEARCH_TEXT",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_CULTURE or -9] = L"TXT_KEY_CITYVIEW_FOCUS_CULTURE_TEXT",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GREAT_PEOPLE or -9] = L"TXT_KEY_CITYVIEW_FOCUS_GREAT_PERSON_TEXT",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_FAITH or -9] = L"TXT_KEY_CITYVIEW_FOCUS_FAITH_TEXT",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_PROD_GROWTH or -9] = "[ICON_PRODUCTION][ICON_FOOD]",
[CityAIFocusTypes.CITY_AI_FOCUS_TYPE_GOLD_GROWTH or -9] = "[ICON_GOLD][ICON_FOOD]",
[-9] = nil }

local function IsTurnActive( player )
	return player and player:IsTurnActive() and not IsProcessingMessages()
end

local function HexRadius( a )
	return ( sqrt( 1 + 4*a/3 ) - 1 ) / 2
end

local function BannerError( where, arg )
	if IsDebugMode() then
		local txt = ""
		if arg and arg.PlotIndex then
			txt = "city banner"
			arg = arg and GetPlotByIndex(arg.PlotIndex)
		end
		if arg and arg.GetPlotCity then
			txt = "plot " .. (arg:IsCity() and "with" or "without") .. " city"
			arg = arg:GetPlotCity()
		end
		if arg and arg.GetCityPlotIndex then
			txt = "city " .. arg:GetName()
		end
		print( "glitch", where, txt, debug and debug.traceback and debug.traceback() )
	end
end

--==========================================================
-- Clear Hex Highlighting
--==========================================================

local function ClearHexHighlights()
	EventsClearHexHighlightStyle( "CityFireRange" )
	EventsClearHexHighlightStyle( "CityLimits" )
	EventsClearHexHighlightStyle( "CityBorders" )
	_iPlotHexHighlight = nil
end

--==========================================================
-- Show/hide the garrison frame icon
--==========================================================

local function HideGarrisonFrame( instance, isHide )
	-- Only the active team has a Garrison ring
	if instance and instance[1] then
		instance.GarrisonFrame:SetHide( isHide )
	end
end

--==========================================================
-- Show/hide the range strike icon
--==========================================================

local function UpdateRangeIcons( iPlot, city, instance )

	if city and instance then

		local hideRangeStrikeButton = city:GetOwner() ~= _iActivePlayer or not city:CanRangeStrikeNow()
		if instance.CityRangeStrikeButton then
			instance.CityRangeStrikeButton:SetHide( hideRangeStrikeButton )
		end

		instance = _tStrikeButtons[ iPlot ]
		if instance then
			instance.CityRangeStrikeButton:SetHide( hideRangeStrikeButton )
		end
	end
end

--==========================================================
-- Refresh the City Damage bar
--==========================================================

local function RefreshCityDamage( city, instance, iCityDamage )

	if instance then

		local iMaxCityHitPoints = city and city.GetMaxHitPoints and city:GetMaxHitPoints() or MAX_CITY_HIT_POINTS
		local iHealthPercent = 1 - iCityDamage / iMaxCityHitPoints

		instance.CityBannerHealthBar:SetPercent(iHealthPercent)
		instance.CityBannerHealthBar:SetToolTipString( format("%g / %g", iMaxCityHitPoints - iCityDamage, iMaxCityHitPoints) )

		---- Health bar color based on amount of damage
		local tColor
		if iHealthPercent > 0.66 then
			tColor = ColorGreen
		elseif iHealthPercent > 0.33 then
			tColor = ColorYellow
		else
			tColor = ColorRed
		end
		instance.CityBannerHealthBar:SetFGColor( tColor )

		-- Show or hide the Health Bar as necessary
		instance.CityBannerHealthBarBase:SetHide( iCityDamage == 0 )
	end
end

--==========================================================
-- Click On City State Quest Info
--==========================================================

local questKillCamp = MinorCivQuestTypes.MINOR_CIV_QUEST_KILL_CAMP
local IsActiveQuestKillCamp
if _bCiv5BNW then
	IsActiveQuestKillCamp = function( minorPlayer )
		return minorPlayer and minorPlayer:IsMinorCivDisplayedQuestForPlayer( _iActivePlayer, questKillCamp )
	end
elseif _bCiv5GK then
	IsActiveQuestKillCamp = function( minorPlayer )
		return minorPlayer and minorPlayer:IsMinorCivActiveQuestForPlayer( _iActivePlayer, questKillCamp )
	end
else
	IsActiveQuestKillCamp = function( minorPlayer )
		return minorPlayer and minorPlayer:GetActiveQuestForPlayer( _iActivePlayer ) == questKillCamp
	end
end

local function OnQuestInfoClicked( iPlot )
	local plot = GetPlotByIndex( iPlot )
	local city = plot and plot:GetPlotCity()
	local pPlayer = city and Players[ city:GetOwner() ]
	if pPlayer and pPlayer:IsMinorCiv() and IsActiveQuestKillCamp( pPlayer ) then
		local x = pPlayer:GetQuestData1( _iActivePlayer, questKillCamp )
		local y = pPlayer:GetQuestData2( _iActivePlayer, questKillCamp )
		local plot = GetPlot( x, y )
		if plot then
			UI.LookAt( plot )
			local hex = ToHexFromGrid{ x=x, y=y }
			Events.AddPopupTextEvent( HexToWorld( hex ), L( "TXT_KEY_NOTIFICATION_SUMMARY_QUEST_KILL_CAMP", pPlayer:GetCivilizationShortDescriptionKey() ) )
			return Events.GameplayFX( hex.x, hex.y, -1 )
		end
	end
end

local function AnnexPopup( iPlot )
	local plot = GetPlotByIndex( iPlot )
	local city = plot and plot:GetPlotCity()
	if city and city:GetOwner() == _iActivePlayer and not( _pActivePlayer.MayNotAnnex and _pActivePlayer:MayNotAnnex() ) then
		Events.SerialEventGameMessagePopup{
			Type = ButtonPopupTypes.BUTTONPOPUP_ANNEX_CITY,
			Data1 = city:GetID(),
			Data2 = -1,
			Data3 = -1,
			Option1 = false,
			Option2 = false
		}
	end
end

local function EspionagePopup( iPlot )
	local plot = GetPlotByIndex( iPlot )
	local city = plot and plot:GetPlotCity()
	if city and not Players[city:GetOwner()]:IsMinorCiv() then
		ClearHexHighlights()
		UI.SetInterfaceMode( InterfaceModeTypes.INTERFACEMODE_SELECTION )
		UI.DoSelectCityAtPlot( plot )
	else
		Events.SerialEventGameMessagePopup{ Type = ButtonPopupTypes.BUTTONPOPUP_ESPIONAGE_OVERVIEW }
	end
end

--==========================================================
-- Click on City Range Strike Button
--==========================================================

local function OnCityRangeStrikeButtonClick( iPlot )
	local plot = GetPlotByIndex( iPlot )
	local city = plot and plot:GetPlotCity()

	if city and city:GetOwner() == _iActivePlayer then
		UI.ClearSelectionList()
		UI.SelectCity( city )
		UI.SetInterfaceMode( InterfaceModeTypes.INTERFACEMODE_CITY_RANGE_ATTACK )
--		Events.InitCityRangeStrike( city:GetOwner(), city:GetID() )
	end
end

--==========================================================
-- Left Click on city banner
--==========================================================

local function OnBannerClick( iPlot )
	local plot = GetPlotByIndex( iPlot )
	local city = plot and plot:GetPlotCity()
	if city then
		UI.SetInterfaceMode( InterfaceModeTypes.INTERFACEMODE_SELECTION )
		local iPlayer = city:GetOwner()
		local pPlayer = Players[ iPlayer ]

		-- Active player city
		if iPlayer == _iActivePlayer then

			-- always open city screen, puppets are not that special
			ClearHexHighlights()
			UI.DoSelectCityAtPlot( plot )

		-- Observers get to look at anything
		elseif IsDebugMode() or _pActivePlayer:IsObserver() then
			UI.SelectCity( city )
			UI.LookAt( plot )
			UI.SetCityScreenUp( true )

		-- Other player, which has been met
		elseif _pActiveTeam:IsHasMet( city:GetTeam() ) then

			if pPlayer:IsMinorCiv() then
				UI.DoSelectCityAtPlot( plot )
			elseif IsTurnActive( _pActivePlayer ) then
				if pPlayer:IsHuman() then
					Events.OpenPlayerDealScreenEvent( iPlayer )
				elseif not pPlayer:IsBarbarian() then
					UI.SetRepeatActionPlayer( iPlayer )
					UI.ChangeStartDiploRepeatCount(1)
					pPlayer:DoBeginDiploWithHuman()
				end
			end
		end
	else
		BannerError( "OnBannerClick", plot )
	end
end

--==========================================================
-- Destroy City Banner
--==========================================================

local function DestroyCityBanner( iPlot, instance )

	-- Release city banner
	if instance then
		insert( instance[1] and _tScrapTeamBanners or _tScrapOtherBanners, instance )
		_tCityBanners[ iPlot or -1 ] = nil
		instance.Anchor:ChangeParent( Controls.Scrap )
	end

	-- Release sv strike button
	instance = _tStrikeButtons[ iPlot ]
	if instance then
		instance.Anchor:ChangeParent( Controls.Scrap )
		insert( _tScrapSVStrikeButtons, instance )
		_tStrikeButtons[ iPlot ] = nil
	end
end

--==========================================================
-- City banner mouse over
--==========================================================

local function OnBannerMouseExit()
	if not UI.IsCityScreenUp() then
		LuaEvents.ShowWorkingHexes()
		LuaEvents.RequestYieldDisplay()
		ClearHexHighlights()
	end
end

local function OnBannerMouseEnter( iPlot )
	local plot = GetPlotByIndex( iPlot )
	if plot then
		_iPlotHexHighlight = UserInterfaceSettings.CityBannerHighlights ~=0 and iPlot
		local city = plot:GetPlotCity()
		if city and city:GetOwner() == _iActivePlayer and not( IsNetworkMultiPlayer and _pActivePlayer:HasReceivedNetTurnComplete() ) then -- required to prevent turn interrupt
			SendUpdateCityCitizens( city:GetID() ) -- does not always trigger a RefreshCityBanner
--			Events.SpecificCityInfoDirty( city:GetOwner(), city:GetID(), CityUpdateTypes.CITY_UPDATE_TYPE_BANNER )
		end
		return RefreshCityBanner( city )
	end
end

local CityTooltip = LuaEvents.CityToolTips.Call
local TeamCityTooltips = {
	CityBannerButton = "EUI_ItemTooltip",
	CityBannerRightBackground = "EUI_ItemTooltip",
	BuildGrowth = "EUI_ItemTooltip",
	CityGrowth = "EUI_ItemTooltip",
--	BorderGrowth = "EUI_ItemTooltip",
	CityReligion = "EUI_ItemTooltip",
	CityFocus = "EUI_ItemTooltip",
	CityQuests = "EUI_ItemTooltip",
	CityIsPuppet = "EUI_ItemTooltip",
	CityIsRazing = "EUI_ItemTooltip",
	CityIsResistance = "EUI_ItemTooltip",
	CityResistanceTurns = "EUI_ItemTooltip",
	CityIsConnected = "EUI_ItemTooltip",
	CityIsBlockaded = "EUI_ItemTooltip",
	CityIsOccupied = "EUI_ItemTooltip",
	CityIsCapital = "EUI_ItemTooltip",
	CityIsOriginalCapital = "EUI_ItemTooltip",
	CivIndicator = "EUI_ItemTooltip",
	CityProductionBG = "EUI_CityProductionTooltip",
	CityPopulation = "EUI_CityGrowthTooltip",
}
local OtherCityTooltips = {
	CityBannerButton = "EUI_ItemTooltip",
	CityBannerRightBackground = "EUI_ItemTooltip",
--	BuildGrowth = "EUI_ItemTooltip",
--	CityGrowth = "EUI_ItemTooltip",
--	BorderGrowth = "EUI_ItemTooltip",
	CityReligion = "EUI_ItemTooltip",
--	CityFocus = "EUI_ItemTooltip",
	CityQuests = "EUI_ItemTooltip",
	CityIsPuppet = "EUI_ItemTooltip",
	CityIsRazing = "EUI_ItemTooltip",
	CityIsResistance = "EUI_ItemTooltip",
--	CityIsConnected = "EUI_ItemTooltip",
	CityIsBlockaded = "EUI_ItemTooltip",
	CityIsOccupied = "EUI_ItemTooltip",
	CityIsCapital = "EUI_ItemTooltip",
	CityIsOriginalCapital = "EUI_ItemTooltip",
	CivIndicator = "EUI_ItemTooltip",
--	CityProductionBG = "EUI_CityProductionTooltip",
--	CityPopulation = "EUI_CityGrowthTooltip",
}
local function InitBannerCallbacks( instance, tooltips )
	local button = instance.CityBannerButton
	button:RegisterCallback( Mouse.eLClick, OnBannerClick )
	button:RegisterCallback( Mouse.eMouseEnter, OnBannerMouseEnter )
	button:RegisterCallback( Mouse.eMouseExit, OnBannerMouseExit )
--	instance.CityName:SetColor( Color( 0, 0, 0, 0.5 ), 1 )	-- #1 = shadow color
--	instance.CityName:SetColor( Color( 1, 1, 1, 0.5 ), 2 )	-- #2 = soft color
	instance.CityDiplomat:RegisterCallback( Mouse.eLClick, EspionagePopup )
	instance.CitySpy:RegisterCallback( Mouse.eLClick, EspionagePopup )
	-- Setup Tootip Callbacks
	for controlID, toolTipType in pairs( tooltips ) do
		instance[ controlID ]:SetToolTipCallback( function( control )
			control:SetToolTipCallback( function( control ) return CityTooltip( control, GetPlotByIndex( button:GetVoid1() ):GetPlotCity() ) end )
			control:SetToolTipType( toolTipType )
		end)
	end
end

--==========================================================
-- Update banners to reflect latest city info
--==========================================================

function RefreshCityBanner( city )
--print( "RefreshCityBanner", city and city:GetName() )
	if city then

		local bDebug = IsDebugMode() or _pActivePlayer:IsObserver()
		local plot = city:Plot()
		local iPlot = plot:GetPlotIndex()
		local instance = _tCityBanners[ iPlot ]
		local iPlayer = city:GetOwner()
		local pPlayer = Players[ iPlayer ]
		local iTeam = city:GetTeam()
		local bActiveTeam = bDebug or iTeam == _iActiveTeam
		local bActivePlayer = iPlayer == _iActivePlayer

		-- Incompatible banner type ? Destroy !
		if instance and bActiveTeam ~= instance[1] then
			DestroyCityBanner( iPlot, instance )
			instance = nil
		end

		---------------------
		-- Create City Banner
		if not instance then
			local worldX, worldY, worldZ = GridToWorld( plot:GetX(), plot:GetY() )
			if bActiveTeam then
				-- create a strike button for stategic view
				instance = remove( _tScrapSVStrikeButtons )
				if instance then
					instance.Anchor:ChangeParent( Controls.StrategicViewStrikeButtons )
				else
					instance = {}
					ContextPtr:BuildInstanceForControl( "SVRangeStrikeButton", instance, Controls.StrategicViewStrikeButtons )
					instance.CityRangeStrikeButton:RegisterCallback( Mouse.eLClick, OnCityRangeStrikeButtonClick )
				end
				instance.Anchor:SetWorldPositionVal( worldX, worldY, worldZ )
				instance.CityRangeStrikeButton:SetVoid1( iPlot )
				_tStrikeButtons[ iPlot ] = instance

				-- create a team type city banner
				instance = remove( _tScrapTeamBanners )
				if instance then
					instance.Anchor:ChangeParent( Controls.CityBanners )
				else
					instance = {}
					ContextPtr:BuildInstanceForControl( "TeamCityBanner", instance, Controls.CityBanners )
					instance.CityRangeStrikeButton:RegisterCallback( Mouse.eLClick, OnCityRangeStrikeButtonClick )
					instance.CityIsPuppet:RegisterCallback( Mouse.eLClick, AnnexPopup )
					InitBannerCallbacks( instance, TeamCityTooltips )
				end
				instance.CityIsPuppet:SetVoid1( iPlot )
				instance.CityRangeStrikeButton:SetVoid1( iPlot )
			else
				-- create a foreign type city banner
				instance = remove( _tScrapOtherBanners )
				if instance then
					instance.Anchor:ChangeParent( Controls.CityBanners )
				else
					instance = {}
					ContextPtr:BuildInstanceForControl( "OtherCityBanner", instance, Controls.CityBanners )
					instance.CityQuests:RegisterCallback( Mouse.eLClick, OnQuestInfoClicked )
					InitBannerCallbacks( instance, OtherCityTooltips )
				end
				instance.CityQuests:SetVoid1( iPlot )
			end

			instance.CityBannerButton:SetVoid1( iPlot )
			instance.Anchor:SetWorldPositionVal( worldX, worldY, worldZ + _iWorldPositionOffsetZ )

			instance[1] = bActiveTeam
			_tCityBanners[ iPlot ] = instance
		end
		-- /Create City Banner
		---------------------

		-- Refresh the damage bar
		RefreshCityDamage( city, instance, city:GetDamage() )

		-- Colors
		local color = PrimaryColors[ iPlayer ]
		local backgroundColor = BackgroundColors[ iPlayer ]

		-- Update name
		local cityName = city:GetName()
		local upperCaseCityName = ToUpper( cityName )

		local originalCityOwnerID = city:GetOriginalOwner()
		local originalCityOwner = Players[ originalCityOwnerID ]
		local iOtherCiv, fOtherCivAlpha
		local isRazing = city:IsRazing()
		local isResistance = city:IsResistance()
		local isPuppet = city:IsPuppet()

		-- Update capital icon
		instance.CityIsCapital:SetHide( not city:IsCapital() or pPlayer:IsMinorCiv() )
		instance.CityIsOriginalCapital:SetHide( city:IsCapital() or not city:IsOriginalCapital() )

		instance.CityName:SetText( upperCaseCityName )
		instance.CityName:SetColor( color, 0 )			-- #0 = main color

		-- Update strength
		instance.CityStrength:SetText( floor(city:GetStrengthValue() / 100) )

		-- Update population
		instance.CityPopulationValue:SetText( city:GetPopulation() )

		-- Being Razed ?
		instance.CityIsRazing:SetHide( not isRazing )

		-- In Resistance ?
		instance.CityIsResistance:SetHide( not isResistance or isRazing )

		-- Puppet ?
		instance.CityIsPuppet:SetHide( not isPuppet )

		-- Occupied ?
		instance.CityIsOccupied:SetHide( not city:IsOccupied() or city:IsNoOccupiedUnhappiness() )

		-- Blockaded ?
		instance.CityIsBlockaded:SetHide( not city:IsBlockaded() )

		-- Garrisoned ?
		instance.GarrisonFrame:SetHide( not ( plot:IsActiveVisible( true ) and city:GetGarrisonedUnit() ) )

		instance.CityBannerBackground:SetColor( backgroundColor )
		instance.CityBannerRightBackground:SetColor( backgroundColor )
		instance.CityBannerLeftBackground:SetColor( backgroundColor )

		if bActiveTeam then

			instance.CityBannerBGLeftHL:SetColor( backgroundColor )
			instance.CityBannerBGRightHL:SetColor( backgroundColor )
			instance.CityBannerBackgroundHL:SetColor( backgroundColor )

			-- Update Growth
			local foodStored100 = city:GetFoodTimes100()
			local foodPerTurn100 = city:FoodDifferenceTimes100( true )
			local foodStoredPercent = 0
			local foodStoredNextTurnPercent = 0

			if isRazing then
				foodPerTurn100 = -1
			else
				local foodThreshold100 = city:GrowthThreshold() * 100
				if foodThreshold100 > 0 then
					foodStoredPercent = foodStored100 / foodThreshold100
					foodStoredNextTurnPercent = ( foodStored100 + foodPerTurn100 ) / foodThreshold100
					if foodPerTurn100 < 0 then
						foodStoredPercent, foodStoredNextTurnPercent = foodStoredNextTurnPercent, foodStoredPercent
					end
				end
			end
			instance.CityResistanceTurns:SetText( isRazing and city:GetRazingTurns() or isResistance and city:GetResistanceTurns() )

			-- Update Growth Meter
			instance.GrowthBar:SetPercent( max(min( foodStoredPercent, 1),0))
			instance.GrowthBarShadow:SetPercent( max(min( foodStoredNextTurnPercent, 1),0))
			instance.GrowthBarStarve:SetHide( foodPerTurn100 >= 0 )

			-- Update Growth Time
			local sGrowth

			if foodPerTurn100 < 0 then
				sGrowth = "[COLOR_WARNING_TEXT]" .. min( floor( foodStored100 / -foodPerTurn100 ) + 1, 99 ) .. "[ENDCOLOR]"
			elseif city:IsForcedAvoidGrowth() then
				sGrowth = "[ICON_LOCKED]"
			elseif foodPerTurn100 == 0 then
				sGrowth = "-"
			else
				sGrowth = min( city:GetFoodTurnsLeft(),99 )
			end

			instance.CityGrowth:SetText( sGrowth )

			local productionPerTurn100 = city:GetCurrentProductionDifferenceTimes100(false, false)	-- food = false, overflow = false
			local productionStored100 = city:GetProductionTimes100() + city:GetCurrentProductionDifferenceTimes100(false, true) - productionPerTurn100
			local productionNeeded100 = city:GetProductionNeeded() * 100
			local productionStoredPercent = 0
			local productionStoredNextTurnPercent = 0

			if productionNeeded100 > 0 then
				productionStoredPercent = productionStored100 / productionNeeded100
				productionStoredNextTurnPercent = (productionStored100 + productionPerTurn100) / productionNeeded100
			end

			instance.ProductionBar:SetPercent( max(min( productionStoredPercent, 1),0))
			instance.ProductionBarShadow:SetPercent( max(min( productionStoredNextTurnPercent, 1),0))

			-- Update Production Time
			if city:IsProduction()
				and not city:IsProductionProcess()
				and productionPerTurn100 > 0
			then
				instance.BuildGrowth:SetText( city:GetProductionTurnsLeft() )
			else
				instance.BuildGrowth:SetText( "-" )
			end

			-- Update Production icon
			local unitProductionID = city:GetProductionUnit()
			local buildingProductionID = city:GetProductionBuilding()
			local projectProductionID = city:GetProductionProject()
			local processProductionID = city:GetProductionProcess()
			local portraitIndex, portraitAtlas
			local item

			if unitProductionID ~= -1 then
				item = GameInfo.Units[unitProductionID]
				if item then portraitIndex, portraitAtlas = GetUnitPortraitIcon( item.ID, iPlayer ) end
			elseif buildingProductionID ~= -1 then
				item = GameInfo.Buildings[buildingProductionID]
			elseif projectProductionID ~= -1 then
				item = GameInfo.Projects[projectProductionID]
			elseif processProductionID ~= -1 then
				item = GameInfo.Processes[processProductionID]
			end

			if item then
				instance.CityProduction:SetHide( not( item and IconHookup( portraitIndex or item.PortraitIndex, 45, portraitAtlas or item.IconAtlas, instance.CityProduction )))
			else
				instance.CityProduction:SetTexture( "CityBannerGrowthBackground.dds" )--"yieldproduction64.dds"  "CityBannerProductionImage.dds"
				instance.CityProduction:SetTextureOffsetVal( -6, 10 ) --9, 9 )
			end

			-- Focus?
			if isRazing or isResistance or isPuppet then
				instance.CityFocus:SetHide( true )
			else
				instance.CityFocus:SetText( _tCityFocusIcons[city:GetFocusType()] )
				instance.CityFocus:SetHide( false )
			end

			-- Connected to capital?
			instance.CityIsConnected:SetHide( city:IsCapital() or not pPlayer:IsCapitalConnectedToCity( city ) )

			-- Demand resource / King day ?
			local resource = GameInfo.Resources[ city:GetResourceDemanded() ]
			local weLoveTheKingDayCounter = city:GetWeLoveTheKingDayCounter()
			-- We love the king
			if weLoveTheKingDayCounter > 0 then
				instance.CityQuests:SetText( "[ICON_HAPPINESS_1]" )
				instance.CityQuests:SetHide( false )

			elseif resource then
				instance.CityQuests:SetText( resource.IconString )
				instance.CityQuests:SetHide( false )
			else
				instance.CityQuests:SetHide( true )
			end

			-- update range strike button (if it is the active player's city)

			UpdateRangeIcons( iPlot, city, instance )

		-- not active team city
		else
			local isMinorCiv = pPlayer:IsMinorCiv()
			if isMinorCiv then
				-- Update Quests
				if city:IsCapital() then
					instance.CityQuests:SetText( GetActiveQuestText( _iActivePlayer, iPlayer ) )
				end
				local info = GetCityStateStatusRow( _iActivePlayer, iPlayer )
				instance.StatusIconBG:SetTexture( info and info.StatusIcon )
				instance.StatusIcon:SetTexture( (GameInfo.MinorCivTraits[ (GameInfo.MinorCivilizations[ pPlayer:GetMinorCivType() ] or {}).MinorCivTrait ] or {}).TraitIcon )
				-- Update Pledge
				if _bCiv5GK then
					local pledge = _pActivePlayer:IsProtectingMinor( iPlayer )
					local free = pledge and pPlayer:CanMajorWithdrawProtection( _iActivePlayer )
					instance.Pledge1:SetHide( not pledge or free )
					instance.Pledge2:SetHide( not free )
				end
				-- Update Allies
				local iAlly = pPlayer:GetAlly()
				local pAlly = Players[ iAlly ]
				if pAlly then
				-- Set left banner icon to pAlly flag
					fOtherCivAlpha = 1
					iOtherCiv = _pActiveTeam:IsHasMet( pAlly:GetTeam() ) and iAlly or -1
				end
			else
				CivIconHookup( iPlayer, 45, instance.OwnerIcon, instance.OwnerIconBG, instance.OwnerIconShadow, false, true )
			end
			instance.CityQuests:SetHide( not isMinorCiv )
			instance.StatusIconBG:SetHide( not isMinorCiv )
			instance.OwnerIconBG:SetHide( isMinorCiv )
		end
		instance.MinorCivIndicator:SetHide( true )
		if originalCityOwner and (originalCityOwnerID ~= iPlayer) then --has priority over pAlly (iOtherCiv)
		-- Set left banner icon to city state flag
			if originalCityOwner:IsMinorCiv() then
				instance.MinorTraitIcon:SetTexture( (GameInfo.MinorCivTraits[ (GameInfo.MinorCivilizations[ originalCityOwner:GetMinorCivType() ] or {}).MinorCivTrait ] or {}).TraitIcon )
				instance.CityIsOriginalCapital:SetHide( true )
				instance.MinorCivIndicator:SetHide( false )
			else
				fOtherCivAlpha = 0.5
				iOtherCiv = originalCityOwnerID
			end
		end
		if iOtherCiv then
			CivIconHookup( iOtherCiv, 32, instance.CivIcon, instance.CivIconBG, instance.CivIconShadow, false, true )
			instance.CivIndicator:SetAlpha( fOtherCivAlpha )
		end
		instance.CivIndicator:SetHide( not iOtherCiv )

		-- Spy & Religion
		if _bCiv5GK then
			local spy
			local x = city:GetX()
			local y = city:GetY()

			for _, s in ipairs( _pActivePlayer:GetEspionageSpies() ) do
				if s.CityX == x and s.CityY == y then
					spy = s
					break
				end
			end

			if spy then
				if spy.IsDiplomat then
					instance.CityDiplomat:SetVoid1( spy.EstablishedSurveillance and iPlot or -1 )
					instance.CityDiplomat:LocalizeAndSetToolTip( "TXT_KEY_CITY_DIPLOMAT_OTHER_CIV_TT", spy.Rank, spy.Name, cityName, spy.Rank, spy.Name, spy.Rank, spy.Name )
					instance.CityDiplomat:SetHide( false )
					instance.CitySpy:SetHide( true )
				else
					instance.CitySpy:SetHide( false )
					instance.CitySpy:SetVoid1( spy.EstablishedSurveillance and iPlot or -1 )
					if bActivePlayer then
						instance.CitySpy:LocalizeAndSetToolTip( "TXT_KEY_CITY_SPY_YOUR_CITY_TT", spy.Rank, spy.Name, cityName, spy.Rank, spy.Name )
					elseif pPlayer:IsMinorCiv() then
						instance.CitySpy:LocalizeAndSetToolTip( "TXT_KEY_CITY_SPY_CITY_STATE_TT", spy.Rank, spy.Name, cityName, spy.Rank, spy.Name)
					else
						instance.CitySpy:LocalizeAndSetToolTip( "TXT_KEY_CITY_SPY_OTHER_CIV_TT", spy.Rank, spy.Name, cityName, spy.Rank, spy.Name, spy.Rank, spy.Name)
					end
					instance.CityDiplomat:SetHide( true )
				end
			else
				instance.CitySpy:SetHide( true )
				instance.CityDiplomat:SetHide( true )
			end

			local row = GameInfo.Religions[city:GetReligiousMajority()]
			if row then
				IconHookup( row.PortraitIndex, 32, row.IconAtlas, instance.CityReligion )
				IconHookup( row.PortraitIndex, 32, row.IconAtlas, instance.ReligiousIconShadow )
				instance.ReligiousIconContainer:SetHide( false )
			else
				instance.ReligiousIconContainer:SetHide( true )
			end
		end

		-- Change the width of the banner so it looks good with the length of the city name

		instance.NameStack:CalculateSize()
		local bannerWidth = instance.NameStack:GetSizeX() - 64
		local bAtWar = _pActiveTeam:IsAtWar( iTeam )
		instance.CityBannerButton:SetSizeX( bannerWidth + 64 )
		instance.CityBannerBackground:SetSizeX( bannerWidth )
		instance.CityBannerBackgroundHL:SetSizeX( bannerWidth )
		if bActiveTeam then
			instance.CityBannerBackgroundIcon:SetSizeX( bannerWidth )
			instance.CityBannerButtonGlow:SetSizeX( bannerWidth )
			instance.CityBannerButtonBase:SetSizeX( bannerWidth )
		else
			instance.CityBannerBaseFrame:SetSizeX( bannerWidth )
			instance.CityAtWar:SetSizeX( bannerWidth )
			instance.CityAtWar:SetHide( not bAtWar )
		end

		instance.CityBannerButton:ReprocessAnchoring()
		instance.NameStack:ReprocessAnchoring()
		instance.IconsStack:CalculateSize()
		instance.IconsStack:ReprocessAnchoring()

		if _iPlotHexHighlight == iPlot then

			local iCity = city:GetID()
			local hexPos, p
			local GetCityPurchaseID = plot.GetCityPurchaseID
			local iCityPlots = city:GetNumCityPlots() - 1
			local iCityRange = bAtWar and CITY_ATTACK_RANGE_AREA or -1
			if bActiveTeam then
				LuaEvents.ShowWorkingHexes( Controls.CityButtons, city )
				LuaEvents.RequestYieldDisplay( YieldDisplayTypesAREA, HexRadius( iCityPlots ), city:GetX(), city:GetY() )
			else
				LuaEvents.RequestYieldDisplay( YieldDisplayTypesCITY_OWNED, city:GetX(), city:GetY() )
			end
			for i = 0, InStrategicView() and -1 or GetCityPurchaseID and 90 or iCityPlots do	-- 90 = city plot ownership can extend up to ring 5
				p = city:GetCityIndexPlot( i )
				if p then
					hexPos = ToHexFromGrid{ x=p:GetX(), y=p:GetY() }
					-- Show city limits
					if i <= iCityPlots then
						EventsSerialEventHexHighlight( hexPos, true, nil, "CityLimits" )
					end
					-- Show city strike zone
					if i <= iCityRange then
						if CAN_CITY_USE_INDIRECT_FIRE or plot:CanSeePlot( p, iTeam, CITY_ATTACK_RANGE-1, -1 ) then
							EventsSerialEventHexHighlight( hexPos, true, nil, "CityFireRange" )
						end
					end
					-- Show city territory
					if p:GetOwner() == iPlayer and GetCityPurchaseID and GetCityPurchaseID(p) == iCity then
						EventsSerialEventHexHighlight( hexPos , true, nil, "CityBorders" )
					end
				end
			end
		end
	end
end

local function RefreshCityBannerAtPlot( plot )
	return plot and RefreshCityBanner( plot:GetPlotCity() )
end

--==========================================================
-- Register Events
--==========================================================

------------------
-- On City Created
Events.SerialEventCityCreated.Add( function( hexPos, iPlayer, iCity, cultureType, eraType, continent, populationSize, size, fowState )
	-- fowState 0 is invisible
	if fowState ~= 0 or IsDebugMode() or _pActivePlayer:IsObserver() then
		return RefreshCityBannerAtPlot( GetPlot( ToGridFromHex( hexPos.x, hexPos.y ) ) )
	end
end)

------------------
-- On City Updated
Events.SerialEventCityInfoDirty.Add( function()
--print "Events.SerialEventCityInfoDirty"
	-- Don't know which city, so update all visible city banners
	for iPlot in pairs( _tCityBanners ) do
		RefreshCityBannerAtPlot( GetPlotByIndex( iPlot ) )
	end
end)

--------------------
-- On City Destroyed
Events.SerialEventCityDestroyed.Add(
function( hexPos ) --, iPlayer, iCity, newPlayerID )
	local plot = GetPlot( ToGridFromHex( hexPos.x, hexPos.y ) )
	if plot then
		local iPlot = plot:GetPlotIndex()
		return DestroyCityBanner( iPlot, _tCityBanners[ iPlot ] )
	end
end)

---------------------
-- On City Set Damage
Events.SerialEventCitySetDamage.Add( function( iPlayer, iCity, iCityDamage, previousDamage )
	local pPlayer = Players[ iPlayer ]
	if pPlayer then
		local city = pPlayer:GetCityByID( iCity )
		if city then
			return RefreshCityDamage( city, _tCityBanners[ city:Plot():GetPlotIndex() ], iCityDamage )
		end
	end
end)

---------------------------
-- On Specific City changed
Events.SpecificCityInfoDirty.Add( function( iPlayer, iCity, updateType )
	local pPlayer = Players[ iPlayer ]
	if pPlayer then
		local city = pPlayer:GetCityByID( iCity )
		if city then
			local iPlot = city:Plot():GetPlotIndex()
			local instance = _tCityBanners[ iPlot ]
			if instance then
				if updateType == CityUpdateTypes.CITY_UPDATE_TYPE_ENEMY_IN_RANGE then
					return UpdateRangeIcons( iPlot, city, instance )
				elseif updateType == CityUpdateTypes.CITY_UPDATE_TYPE_BANNER or updateType == CityUpdateTypes.CITY_UPDATE_TYPE_GARRISON then
					return RefreshCityBanner( city )
				end
			end
		end
	end
end)

-------------------------
-- On Improvement Created
Events.SerialEventImprovementCreated.Add( function( hexX, hexY, cultureID, continentID, iPlayer )--, improvementID, rawResourceID, improvementEra, improvementState )
	if iPlayer == _iActivePlayer then
		local plot = GetPlot( ToGridFromHex( hexX, hexY ) )
		if plot then
			return RefreshCityBanner( plot:GetWorkingCity() )
		end
	end
end)

---------------------------
-- On Road/Railroad Created
Events.SerialEventRoadCreated.Add( function( hexX, hexY, iPlayer, iRoadStatus )
	if iPlayer == _iActivePlayer and iRoadStatus == 0 then -- 0 = new road, 6 is used in tutorial 3 for connection but comes one turn later
		for city in _pActivePlayer:Cities() do
			RefreshCityBanner( city )
		end
	end
end)

--[[
-----------------------
-- On city range strike
Events.InitCityRangeStrike.Add( function( iPlayer, iCity )
	if iPlayer == _iActivePlayer then
		local city = _pActivePlayer:GetCityByID( iCity )
		if city and city == UI.GetHeadSelectedCity() then
			UI.SetInterfaceMode( InterfaceModeTypes.INTERFACEMODE_CITY_RANGE_ATTACK )
		end
	end
end)
--]]

-------------------
-- On Unit Garrison
Events.UnitGarrison.Add( function( iPlayer, iUnit, isGarrisoned )
	if isGarrisoned then
		local player = Players[ iPlayer ]
		if player then
			local unit = player:GetUnitByID( iUnit )
			if unit then
				local city = unit:GetGarrisonedCity()
				if city then
					return HideGarrisonFrame( _tCityBanners[ city:Plot():GetPlotIndex() ], UnitMoving( iPlayer, iUnit ) )
				end
			end
		end
	end
end)

-----------------------------
-- On Unit Move Queue Changed
Events.UnitMoveQueueChanged.Add( function( iPlayer, iUnit, hasRemainingMoves )
	local player = Players[ iPlayer ]
	if player then
		local unit = player:GetUnitByID( iUnit )
		if unit then
			local city = unit:GetGarrisonedCity()
			if city then
				return HideGarrisonFrame( _tCityBanners[ city:Plot():GetPlotIndex() ], not hasRemainingMoves )
			end
		end
	end
end)

--[[
---------------------------
-- On interface mode change
Events.InterfaceModeChanged.Add( function( oldInterfaceMode, newInterfaceMode )
	local disableBanners = newInterfaceMode ~= InterfaceModeTypes.INTERFACEMODE_SELECTION
	for _, instance in pairs( _tCityBanners ) do
		instance.CityBannerButton:SetDisabled( disableBanners )
		instance.CityBannerButton:EnableToolTip( not disableBanners )
	end
end)
--]]

---------------------------
-- On strategic view change
Events.StrategicViewStateChanged.Add( function(isStrategicView, showCityBanners)
	local showBanners = showCityBanners or not isStrategicView
	Controls.CityBanners:SetHide( not showBanners )
	return Controls.StrategicViewStrikeButtons:SetHide( showBanners )
end)

-----------------------
-- On fog of war change
Events.HexFOWStateChanged.Add( function( hexPos, fowType, isWholeMap )
--print( "Events.HexFOWStateChanged", hexPos.x, hexPos.y, fowType, isWholeMap )
	if isWholeMap then
		 -- fowState 0 is invisible
		if fowType == 0 then
			for iPlot, instance in pairs( _tCityBanners ) do
				DestroyCityBanner( iPlot, instance )
			end
		else
			for _, player in pairs(Players) do
				if player and player:IsAlive() then
					for city in player:Cities() do
						RefreshCityBanner( city )
					end
				end
			end
		end
	else
		local plot = GetPlot( ToGridFromHex( hexPos.x, hexPos.y ) )
		if plot then
			-- fowType 0 is invisible
			if fowType == 0 then
				local iPlot = plot:GetPlotIndex()
				return DestroyCityBanner( iPlot, _tCityBanners[ iPlot ] )
			else
				return RefreshCityBannerAtPlot( plot )
			end
		end
	end
end)

---------------------------
-- On War Declared
Events.WarStateChanged.Add(
function( iTeam1, iTeam2 )--, bAtWar )
	if iTeam1 == _iActiveTeam then
		iTeam1 = iTeam2
	elseif iTeam2 ~= _iActiveTeam then
		return
	end
	for _, player in pairs(Players) do
		if player and player:IsAlive() and player:GetTeam() == iTeam1 then
			for city in player:Cities() do
				if city:Plot():IsRevealed( _iActiveTeam ) then
					RefreshCityBanner( city )
				end
			end
		end
	end
end)

--==========================================================
-- 'Active' (local human) player has changed:
-- Check for City Banner Active Type change
--==========================================================
Events.GameplaySetActivePlayer.Add( function( iActivePlayer, iPreviousActivePlayer )
	-- update globals

	_iActivePlayer = GetActivePlayer()
	_pActivePlayer = Players[ _iActivePlayer ]
	_iActiveTeam = GetActiveTeam()
	_pActiveTeam = Teams[ _iActiveTeam ]
	ClearHexHighlights()
	local bDebug = IsDebugMode() or _pActivePlayer:IsObserver()
	-- Update all city banners
	for _, player in pairs(Players) do
		if player and player:IsAlive() then
			for city in player:Cities() do
				local plot = city:Plot()
				if bDebug or plot:IsRevealed( _iActiveTeam ) then
					RefreshCityBanner( city )
				-- If city banner is hidden, destroy the banner
				else
					local iPlot = plot:GetPlotIndex()
					DestroyCityBanner( iPlot, _tCityBanners[ iPlot ] )
				end
			end
		end
	end
end)

--==========================================================
-- Hide Garrisson Ring during Animated Combat
--==========================================================
if _bCiv5GK then

	local function HideGarrisonRing( x, y, hideGarrisonRing )

		local plot = GetPlot( x, y )
		local city = plot and plot:GetPlotCity()
		local instance = city and _tCityBanners[ plot:GetPlotIndex() ]
		return instance and HideGarrisonFrame( instance, hideGarrisonRing or not city:GetGarrisonedUnit() )
	end

	Events.RunCombatSim.Add( function(
				attackerPlayerID,
				attackerUnitID,
				attackerUnitDamage,
				attackerFinalUnitDamage,
				attackerMaxHitPoints,
				defenderPlayerID,
				defenderUnitID,
				defenderUnitDamage,
				defenderFinalUnitDamage,
				defenderMaxHitPoints,
				attackerX,
				attackerY,
				defenderX,
				defenderY,
				bContinuation)
--print( "CityBanner CombatBegin", attackerX, attackerY, defenderX, defenderY )

		HideGarrisonRing(attackerX, attackerY, true)
		HideGarrisonRing(defenderX, defenderY, true)
	end)

	Events.EndCombatSim.Add( function(
				attackerPlayerID,
				attackerUnitID,
				attackerUnitDamage,
				attackerFinalUnitDamage,
				attackerMaxHitPoints,
				defenderPlayerID,
				defenderUnitID,
				defenderUnitDamage,
				defenderFinalUnitDamage,
				defenderMaxHitPoints,
				attackerX,
				attackerY,
				defenderX,
				defenderY )

--print( "CityBanner CombatEnd", attackerX, attackerY, defenderX, defenderY )

		HideGarrisonRing(attackerX, attackerY, false)
		HideGarrisonRing(defenderX, defenderY, false)
	end)

end -- _bCiv5GK

--==========================================================
-- The active player's turn has begun, make sure their range strike icons are correct
--==========================================================
Events.ActivePlayerTurnStart.Add( function()
	for iPlot, instance in pairs( _tCityBanners ) do
		UpdateRangeIcons( iPlot, GetPlotByIndex( iPlot ):GetPlotCity(), instance )
	end
end)

Events.SerialEventUnitDestroyed.Add( function( iPlayer )--, iUnit )
	local player = Players[ iPlayer ]
	if player and _pActiveTeam:IsAtWar( player:GetTeam() ) then
		local iPlot
		for city in _pActivePlayer:Cities() do
			iPlot = city:Plot():GetPlotIndex()
			UpdateRangeIcons( iPlot, city, _tCityBanners[ iPlot ] )
		end
	end
end)

--==========================================================
-- Initialize all Visible City Banners
--==========================================================
local bDebug = IsDebugMode() or _pActivePlayer:IsObserver()
for _, player in pairs(Players) do
	if player and player:IsEverAlive() then
		for city in player:Cities() do
			if city:Plot():IsRevealed( _iActiveTeam ) or bDebug then
				RefreshCityBanner( city )
			end
		end
	end
end

end)
