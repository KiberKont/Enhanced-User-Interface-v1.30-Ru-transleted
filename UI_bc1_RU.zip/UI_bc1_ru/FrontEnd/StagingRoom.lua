if not PreGame.GameStarted() or PreGame.IsMultiplayerGame() then
	include "StagingScreen"
end