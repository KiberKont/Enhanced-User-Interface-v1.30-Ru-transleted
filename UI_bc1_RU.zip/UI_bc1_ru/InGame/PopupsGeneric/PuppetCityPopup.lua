-- CAPTURE CITY POPUP
-- This popup occurs when a city is capture and must be annexed or puppeted.
-- Modified by bc1 from 1.0.3.144 code using Notepad++

PopupLayouts[ButtonPopupTypes.BUTTONPOPUP_CITY_CAPTURED] = function(popupInfo)

	local cityID				= popupInfo.Data1
	local iCaptureGold			= popupInfo.Data2 or 0
	local liberatedPlayerID		= popupInfo.Data5 or popupInfo.Data4 or popupInfo.Data3 or -1 -- BNW / G&K / vanilla
	local iCaptureCulture		= popupInfo.Data4 and popupInfo.Data3 or 0 -- G&K and BNW
	local iCaptureGreatWorks	= popupInfo.Data5 and popupInfo.Data4 or 0 -- BNW only
	local isMinorCivBuyout		= popupInfo.Option1 -- G&K and BNW
	local isConquest			= popupInfo.Option2 -- BNW only

	local activePlayerID = Game.GetActivePlayer()
	local activePlayer = Players[ activePlayerID ]
	local city = activePlayer and cityID and activePlayer:GetCityByID( cityID )
	
	if city then
		local iPreviousOwner = city:GetPreviousOwner();
		local popupText, strToolTip
		local warmongerTooltip = isConquest == true and activePlayer.GetWarmongerPreviewString and city:GetOriginalOwner() ~= activePlayerID
												and "[NEWLINE][NEWLINE]" .. activePlayer:GetWarmongerPreviewString( iPreviousOwner, city, Game.GetActivePlayer() ) or "" --CPP

		-- Initialize popup text.	
		local cityNameKey = city:GetNameKey();
		if iCaptureCulture >0 or iCaptureGreatWorks > 0 then
			popupText = L("TXT_KEY_POPUP_GOLD_AND_CULTURE_CITY_CAPTURE", iCaptureGold, iCaptureCulture, iCaptureGreatWorks, cityNameKey);
		elseif iCaptureGold > 0 then
			popupText = L("TXT_KEY_POPUP_GOLD_CITY_CAPTURE", iCaptureGold, cityNameKey);
		else
			popupText = L("TXT_KEY_POPUP_NO_GOLD_CITY_CAPTURE", cityNameKey);
		end
		-- Ask the player what he wants to do with this City
		SetPopupText( popupText .. "  " .. L("TXT_KEY_POPUP_CITY_CAPTURE_INFO") )

		-- Calculate Happiness info
		local iUnhappinessNoCity = activePlayer:GetUnhappiness();
		local iUnhappinessForPuppeting = activePlayer:GetUnhappinessForecast( nil, city ) - iUnhappinessNoCity	-- pAssumeCityAnnexed, pAssumeCityPuppeted
			-- For minor civ buyout (Austria UA), there are no unhappiness benefits of annexing because the city is not occupied
		local iUnhappinessForAnnexing = isMinorCivBuyout and iUnhappinessForPuppeting or activePlayer:GetUnhappinessForecast( city, nil ) - iUnhappinessNoCity	-- pAssumeCityAnnexed, pAssumeCityPuppeted

		-- Initialize 'Liberate' button.
		local liberatedPlayer = Players[liberatedPlayerID]
		if liberatedPlayer then
			if Players[liberatedPlayerID]:IsAlive() then
				strToolTip = L("TXT_KEY_POPUP_CITY_CAPTURE_INFO_LIBERATE", liberatedPlayer:GetNameKey() )
			elseif activePlayer.GetLiberationPreviewString then -- BNW only
				strToolTip = L("TXT_KEY_POPUP_CITY_CAPTURE_INFO_LIBERATE", liberatedPlayer:GetNameKey())
							.. "[NEWLINE][NEWLINE]" .. activePlayer:GetLiberationPreviewString( liberatedPlayerID, city, Game.GetActivePlayer() ) --CPP
			else
				strToolTip = L("TXT_KEY_POPUP_CITY_CAPTURE_INFO_LIBERATE_RESURRECT", liberatedPlayer:GetNameKey() )
			end
			AddButton( L"TXT_KEY_POPUP_LIBERATE_CITY",
				function()
					Network.SendLiberateMinor( liberatedPlayerID, cityID )
				end, strToolTip )
		end
	
		-- Initialize 'Annex' button.
		if not( activePlayer.MayNotAnnex and activePlayer:MayNotAnnex() ) then
			AddButton( L"TXT_KEY_POPUP_ANNEX_CITY",
				function()
					Network.SendDoTask( cityID, TaskTypes.TASK_ANNEX_PUPPET, -1, -1, false, false, false, false )
					city:ChooseProduction();
				end, L("TXT_KEY_POPUP_CITY_CAPTURE_INFO_ANNEX", iUnhappinessForAnnexing) .. warmongerTooltip )
		end
		
		-- Initialize 'Puppet' button.
		AddButton( L"TXT_KEY_POPUP_PUPPET_CAPTURED_CITY",
				function()
					Network.SendDoTask( cityID, TaskTypes.TASK_CREATE_PUPPET, -1, -1, false, false, false, false )
				end, L("TXT_KEY_POPUP_CITY_CAPTURE_INFO_PUPPET", iUnhappinessForPuppeting) .. warmongerTooltip )
	
		-- Initialize 'Raze' button.
		if activePlayer:CanRaze( city ) then
			AddButton( L"TXT_KEY_POPUP_RAZE_CAPTURED_CITY",
				function()
					Network.SendDoTask( cityID, TaskTypes.TASK_RAZE, -1, -1, false, false, false, false )
				end, L("TXT_KEY_POPUP_CITY_CAPTURE_INFO_RAZE", iUnhappinessForAnnexing) .. warmongerTooltip )

		end

		-- CITY SCREEN CLOSED - Don't look, Marc
		local function CityScreenClosed()
			UIManager:DequeuePopup( Controls.EmptyPopup )
			Events.SerialEventExitCityScreen.Remove( CityScreenClosed )
		end
	
		-- Initialize 'View City' button.
		local function OnViewCityClicked()
			-- Queue up an empty popup at a higher priority so that it prevents other cities from appearing while we're looking at this one!
			UIManager:QueuePopup( Controls.EmptyPopup, PopupPriority.GenericPopup+1 )
			Events.SerialEventExitCityScreen.Add( CityScreenClosed )
			UI.SetCityScreenViewingMode( true )
			UI.DoSelectCityAtPlot( city:Plot() )
		end
	
		AddButton( L"TXT_KEY_POPUP_VIEW_CITY", OnViewCityClicked, L"TXT_KEY_POPUP_VIEW_CITY_DETAILS", true );	-- true is bPreventClose
	else
		return false;
	end

end
