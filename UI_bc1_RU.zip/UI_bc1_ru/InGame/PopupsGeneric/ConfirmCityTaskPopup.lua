-- CONFIRM CITY TASK POPUP
-- This popup occurs when an action needs confirmation.
-- Modified by bc1 from 1.0.3.276 code using Notepad++

if PopupLayouts then
	PopupLayouts[ButtonPopupTypes.BUTTONPOPUP_CONFIRM_CITY_TASK or -1] = function( popupInfo )
		local iCity = popupInfo.Data1
		local iTask = popupInfo.Data2
		local city = UI.GetHeadSelectedCity()
		SetTopImage( "AncientRuinsPopupTop300.dds", -22 )
		SetTopIcon( "EnemyCity128.dds", 20 )
		if city and city:GetID() == iCity and iTask then
			local bAnnex = iTask == TaskTypes.TASK_ANNEX_PUPPET
			SetPopupTitle( city:GetName():upper() )
			SetPopupText( iTask == TaskTypes.TASK_RAZE and L"TXT_KEY_POPUP_ARE_YOU_SURE_RAZE" or popupInfo.Text or L"TXT_KEY_POPUP_ARE_YOU_SURE" )
			AddButton( L"TXT_KEY_POPUP_YES",
			function()
				Network.SendDoTask( iCity, iTask, -1, -1, false, false, false, false )
				if bAnnex then
					Network.SendDoTask( iCity, TaskTypes.TASK_CLEAR_ORDERS, -1, -1, false, false, false, false ) -- clear production queue
					local a = UserInterfaceSettings and tonumber(UserInterfaceSettings.DefaultCityFocus)
					if a and a>=0 and a<=CityAIFocusTypes.NUM_CITY_AI_FOCUS_TYPES then
						Network.SendSetCityAIFocus( iCity, a )
					end
					local sTooltip = L( "TXT_KEY_NOTIFICATION_NEW_CONSTRUCTION", city:GetName() )
					Players[city:GetOwner()]:AddNotification( NotificationTypes.NOTIFICATION_PRODUCTION, sTooltip, sTooltip, city:GetX(), city:GetY(), -1, -1 )
				end
			end )
		end
		return AddButton( L"TXT_KEY_POPUP_NO" )
	end
end