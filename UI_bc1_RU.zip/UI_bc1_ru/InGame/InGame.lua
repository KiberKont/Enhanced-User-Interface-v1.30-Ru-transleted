--==========================================================
-- Game View
-- this is the parent of both WorldView and CityView
-- This is the final lua message handler that will be
-- processed in the processing chain, after this is
-- it is in engine side C++
-- Re-written by bc1 using Notepad++
-- WorldView is merged into InGame
--==========================================================

Events.SequenceGameInitComplete.Add(function()

include "UserInterfaceSettings"
local UserInterfaceSettings = UserInterfaceSettings

include "GameInfoCache" -- warning! booleans are true, not 1, and use iterator ONLY with table field conditions, NOT string SQL query
local GameInfoUnits = GameInfoCache.Units
local GameInfoInterfaceModes = GameInfoCache.InterfaceModes

include "FLuaVector"
local _tColorMoveRange = Color( .2, .4, 1, .8 ) --Cyan
local _tColorUnitTile = Color( 1, 1, 0, 1 ) --Yellow
local _tColorGiftTileImprovement = Color( 1, 0, 1, 1 ) --Magenta

include "InstanceStackManager"

--==========================================================
-- Minor lua optimizations
--==========================================================

local print = print
local debug_print = print
local type = type
local ceil = math.ceil
local max = math.max
local min = math.min
local sqrt = math.sqrt
local huge = math.huge

local UI = UI
local AIR_UNIT_REBASE_RANGE_MULTIPLIER = GameDefines.AIR_UNIT_REBASE_RANGE_MULTIPLIER / 100
local BY_HOST = NetKicked.BY_HOST
local BulkHideUI = SystemUpdateUIType.BulkHideUI
local BulkShowUI = SystemUpdateUIType.BulkShowUI
local ButtonPopupTypes = ButtonPopupTypes
local CAN_CITY_USE_INDIRECT_FIRE = GameDefines.CAN_CITY_USE_INDIRECT_FIRE == 1
local CITY_ATTACK_RANGE = GameDefines.CITY_ATTACK_RANGE or 2
local CITY_PLOTS_RADIUS = GameDefines.CITY_PLOTS_RADIUS or 2
local CITY_UPDATE_TYPE_BANNER = CityUpdateTypes.CITY_UPDATE_TYPE_BANNER
local COMMAND_CANCEL_ALL = CommandTypes.COMMAND_CANCEL_ALL
local ContextPtr = ContextPtr
local Controls = Controls
local DOMAIN_AIR = DomainTypes.DOMAIN_AIR
local DOMAIN_LAND = DomainTypes.DOMAIN_LAND
local DOMAIN_SEA = DomainTypes.DOMAIN_SEA
local Events = Events
local EventsClearHexHighlightStyle = Events.ClearHexHighlightStyle.Call
local EventsGenericWorldAnchor = Events.GenericWorldAnchor.Call
local EventsRemoveAllArrowsEvent = Events.RemoveAllArrowsEvent.Call
local EventsRequestYieldDisplay = Events.RequestYieldDisplay.Call
local EventsSerialEventHexHighlight = Events.SerialEventHexHighlight.Call
local EventsSerialEventMouseOverHex = Events.SerialEventMouseOverHex
local EventsSpawnArrowEvent = Events.SpawnArrowEvent.Call
local GAMEMESSAGE_DO_COMMAND = GameMessageTypes.GAMEMESSAGE_DO_COMMAND
local GAMEMESSAGE_DO_TASK = GameMessageTypes.GAMEMESSAGE_DO_TASK
local GAMEMESSAGE_PUSH_MISSION = GameMessageTypes.GAMEMESSAGE_PUSH_MISSION
local GAMEVIEW_NONE = GameViewTypes.GAMEVIEW_NONE
local Game = Game
local GameData_DIRTY_BIT = InterfaceDirtyBits.GameData_DIRTY_BIT
local GameInfoTypes = GameInfoTypes
local GetGameViewRenderType = GetGameViewRenderType
local GetHeadSelectedCity = UI.GetHeadSelectedCity
local GetHeadSelectedUnit = UI.GetHeadSelectedUnit
local GetInterfaceMode = UI.GetInterfaceMode
local GetMouseOverHex = UI.GetMouseOverHex
local GetNumPlots = Map.GetNumPlots
local GetPlot = Map.GetPlot
local GetPlotByIndex = Map.GetPlotByIndex
local GetPlotXY = Map.GetPlotXY
local GridToWorld = GridToWorld
local INTERFACEMODE_CITY_RANGE_ATTACK = InterfaceModeTypes.INTERFACEMODE_CITY_RANGE_ATTACK
local INTERFACEMODE_MOVE_TO = InterfaceModeTypes.INTERFACEMODE_MOVE_TO
local INTERFACEMODE_SELECTION = InterfaceModeTypes.INTERFACEMODE_SELECTION
local InGameMenu = PopupPriority.InGameMenu
local InStrategicView = InStrategicView or function() end
local InterfaceModeTypes = InterfaceModeTypes
local IsTouchScreenEnabled = UI.IsTouchScreenEnabled
local KeyEvents = KeyEvents
local Keys = Keys
local MAX_MAJOR_CIVS = GameDefines.MAX_MAJOR_CIVS
local MINOR_CIV_RESOURCE_SEARCH_RADIUS = GameDefines.MINOR_CIV_RESOURCE_SEARCH_RADIUS
local MIN_CITY_RANGE = GameDefines.MIN_CITY_RANGE
local MissionTypes = MissionTypes
local Mouse = Mouse
local MouseEvents = MouseEvents
local Network = Network
local OptionsManager = OptionsManager
local Players = Players
local PlotDistance = Map.PlotDistance
local PreGame = PreGame
local ProcessStrategicViewMouseClick = ProcessStrategicViewMouseClick
local SetInterfaceMode = UI.SetInterfaceMode
local TASK_RANGED_ATTACK = TaskTypes.TASK_RANGED_ATTACK
local ToHexFromGrid = ToHexFromGrid
local ToggleStrategicView = ToggleStrategicView
local UIManager = UIManager
local WORLD_ANCHOR_SETTLER = GenericWorldAnchorTypes.WORLD_ANCHOR_SETTLER
local WORLD_ANCHOR_WORKER = GenericWorldAnchorTypes.WORLD_ANCHOR_WORKER
local YieldDisplayTypes = YieldDisplayTypes

local _bCiv5GK = Game.GetReligionName ~= nil

local _bPathShown, _bArrowSpawned, _bCityOutlineShown, _bWorkerSuggestHighlightPlots, _bFounderSuggestHighlightPlots, _bUnitPredictiveStrikeRange, _bTileRecommendations, _bFastAutoUnitCycle, _bHideUnitFlags, _bHideCityBanners, g_EatNextUp

local _tInterfaceModeNames = {} for k,v in pairs(InterfaceModeTypes) do _tInterfaceModeNames[v]=k end
local _tInterfaceModeCursors = {}
local _tInterfaceModeMessageHandler = {}
local _tNewInterfaceModeChangeHandler = {}
local _tOldInterfaceModeChangeHandler = {}

--local FoundCityIcon, MiniMapOptionsPanel
local MiniMapOptionsPanel = ContextPtr:LookUpControl( "WorldView/MiniMapPanel/OptionsPanel" )
local FoundCityIcon = ContextPtr:LookUpControl( "YieldIconManager/CityAnchor" )
local _tHighlightsUsed = { BuyFill = 1, BuyOutline = 1, OverlapOutline = 1, OverlapFill = 1, OwnedOutline = 1, OwnedFill = 1 }


--==========================================================
-- Game Messages
--==========================================================
local _fTotalTime = 0
local _fNextTimeOut
local _AlertIM = InstanceStackManager( "AlertMessageInstance", "AlertMessageLabel", Controls.AlertStack )
local _PopupIM = InstanceStackManager( "PopupText", "Anchor", Controls.PopupTextContainer )

local function UpdateGameplayAlertMessages(fTime)
	if fTime > 0 then
		_fTotalTime = _fTotalTime + fTime
		if _fTotalTime >= _fNextTimeOut then
			for _ = 1, _AlertIM.GetInstanceCount() do
				_fNextTimeOut = _AlertIM[1].Timeout
				if _fTotalTime < _fNextTimeOut then
					return
				end
				_AlertIM:ReleaseInstance( _AlertIM[1] )
			end
			_fNextTimeOut = nil
			ContextPtr:ClearUpdate()
		end
	end
end

local function GameplayAlertMessage( text )
	local instance = _AlertIM:GetInstance()
	instance.AlertMessageLabel:SetText( text )
	Controls.AlertStack:ReprocessAnchoring()
	instance.Timeout = _fTotalTime + 8
	if not _fNextTimeOut then
		_fNextTimeOut = _fTotalTime + 8
		ContextPtr:SetUpdate( UpdateGameplayAlertMessages )
	end
end
Events.GameplayAlertMessage.Add( GameplayAlertMessage )

local function AddPopupTextEvent( worldPosition, text, delay )
	local instance = _PopupIM:GetInstance()
	instance.Anchor:SetWorldPosition( worldPosition )
	instance.Text:SetText( text )
	instance.AlphaAnimOut:RegisterAnimCallback( function() return _PopupIM:ReleaseInstance( instance ) end ) -- KillPopupText
	instance.Anchor:BranchResetAnimation()
	instance.SlideAnim:SetPauseTime( delay )
	instance.AlphaAnimIn:SetPauseTime( delay )
	instance.AlphaAnimOut:SetPauseTime( delay + .8 ) -- 0.75
end
Events.AddPopupTextEvent.Add( AddPopupTextEvent )

Events.GameplaySetActivePlayer.Add( function() --( iActivePlayer, iPrevActivePlayer )
	_AlertIM:ResetInstances()
	_PopupIM:ResetInstances()
end)

--==========================================================
-- Utilities
--==========================================================

--usage1: IndexPlot( plot, hexAreaPlotIndex )
--OR usage2: IndexPlot( plot, ringPlotIndex, ringDistanceFromPlot )
local function IndexPlot( plot, i, r )
	-- determine if input parameters are valid - you can delete this part for a tiny performance boost
	if not plot or not i or i<0 or (r and (r<0 or i>6*r)) then
		return print("IndexPlot error - invalid parameters")
	end
	-- area plot index mode ?
	if not r then
		-- area plot index 0 is a special case
		if i == 0 then
			return plot
		else
			-- which ring are we on ?
			r = ceil( ( sqrt( 12*i + 9 ) - 3 ) / 6 )
			-- determine ring plot index (substract inside area)
			i = i - ( 3 * (r-1) * r ) - 1
		end
	end

	-- determine coordinate offsets corresponding to ring index
	local x, y
	if i <= 2*r then
		x = min( i, r )
	elseif i<= 4*r then
		x = 3*r-i
	else
		x = max( i-6*r, -r )
	end
	if i <= 3*r then
		y = max( r-i, -r )
	else
		y = min( i-4*r, r )
	end

	-- return plot offset from initial plot
	return GetPlotXY( plot:GetX(), plot:GetY(), x, y )
end

-- Returns the number of plots in hexagonal area of specified radius, excluding center plot
local function CountHexPlots( r )
	return (r+1) * r * 3
end

local function CallIfNotNil( f, ... )
	if f then return f( ... ) end
end

local function SetInterfaceModeSelection()
	return SetInterfaceMode( INTERFACEMODE_SELECTION )
end

local function SetInterfaceModeSelectionTrue()
	SetInterfaceModeSelection()
	return true
end

local function AssignInterfaceModeMessageHandler( interfaceMode, action )
	local t = {}
	t[ MouseEvents.LButtonUp ] = action
	t[ MouseEvents.RButtonUp ] = action
	if IsTouchScreenEnabled() then
		t[ MouseEvents.PointerUp ] = action
	end
	_tInterfaceModeMessageHandler[ interfaceMode ] = t
end

local function AssignInterfaceMode( interfaceMode, action, new, old )
	if interfaceMode then
		_tNewInterfaceModeChangeHandler[ interfaceMode ] = new
		_tOldInterfaceModeChangeHandler[ interfaceMode ] = old
		local actionType = type(action)
		if actionType == "function" then
			return AssignInterfaceModeMessageHandler( interfaceMode, action )
		elseif actionType == "table" then
			_tInterfaceModeMessageHandler[ interfaceMode ] = action
		end
	end
end

local function ClearUnitMovementRange()
	--debug_print("ClearUnitMovementRange")
	EventsClearHexHighlightStyle( "AMRBorder" )
	EventsClearHexHighlightStyle( "MovementRangeBorder" )
	return EventsClearHexHighlightStyle( "GUHB" )
end

local function ShowUnitMovementRange( unit )
	if unit and unit:CanMove() then
		--debug_print("Events.ShowMovementRange")
		return Events.ShowMovementRange( unit:GetOwner(), unit:GetID() )
	else
		return ClearUnitMovementRange()
	end
end

Events.ClearUnitMoveHexRange.Add( ClearUnitMovementRange )
Events.StartUnitMoveHexRange.Add( ClearUnitMovementRange )
Events.AddUnitMoveHexRangeHex.Add( function( i, j, k, attackMove )
	if attackMove then
		return EventsSerialEventHexHighlight( {x=i, y=j}, true, nil, "AMRBorder" )
	elseif InStrategicView() then
		return EventsSerialEventHexHighlight( {x=i, y=j}, true, _tColorMoveRange, "GUHB" )
	else
		return EventsSerialEventHexHighlight( {x=i, y=j}, true, nil, "MovementRangeBorder" )
	end
end)

local function plotIsLand( plot )
	return not plot:IsWater()
end

local function returnTrue()
	return true
end

local function ClearStrikeRange()
	--debug_print( "ClearStrikeRange" )
	EventsClearHexHighlightStyle( "ValidFireTargetBorder" )
	return EventsClearHexHighlightStyle( "FireRangeBorder" )
end

local function DisplayStrikeRange( attacker, fromPlot, range, isIndirectFireAllowed, isDomainOnly, domainID, isRevealed )
	ClearStrikeRange()
	--debug_print( "DisplayStrikeRange", attacker:GetName(), "x", fromPlot:GetX(), "y", fromPlot:GetY(), "range", range, "isIndirectFireAllowed", isIndirectFireAllowed, "isDomainOnly", isDomainOnly, "isRevealed", isRevealed )
	local plot, x, y, hex
	local iTeam = attacker:GetTeam()
	local testDomain = isDomainOnly and ( (domainID == DOMAIN_LAND and plotIsLand) or (domainID == DOMAIN_SEA and fromPlot.IsWater) ) or returnTrue
	local testCanSeePlot = (isIndirectFireAllowed or domainID == DOMAIN_AIR) and returnTrue or fromPlot.CanSeePlot
	local testVisibility = isRevealed and fromPlot.IsRevealed or fromPlot.IsVisible
	local isNoncombatAllowed = GetInterfaceMode()~=INTERFACEMODE_SELECTION and GetInterfaceMode()~=INTERFACEMODE_MOVE_TO
	-- highlight the bombardable plots
	for i = 0, CountHexPlots( range ) do
		plot = IndexPlot( fromPlot, i )
		if plot and testVisibility( plot, iTeam ) and testDomain( plot ) and testCanSeePlot( fromPlot, plot, iTeam, range-1, -1 ) then -- -1 = no direction
			x, y = plot:GetX(), plot:GetY()
			hex = ToHexFromGrid{ x=x, y=y }
			EventsSerialEventHexHighlight( hex, true, nil, "FireRangeBorder" )
			if attacker:CanRangeStrikeAt( x, y, true, isNoncombatAllowed ) then -- true = NeedWar
				EventsSerialEventHexHighlight( hex, true, nil, "ValidFireTargetBorder" )
			end
		end
	end
end

local function DisplayUnitStrikeRange( unit, plot, isRevealed )
	return DisplayStrikeRange( unit, plot or unit:GetPlot(), unit:Range(), unit:IsRangeAttackIgnoreLOS(), unit:IsRangeAttackOnlyInDomain(), unit:GetDomainType(), isRevealed )
end

local function ClearRangeStrikeArrow()
	if _bArrowSpawned then
		_bArrowSpawned = false
		return EventsRemoveAllArrowsEvent()
	end
end

local function DisplayCityRangeStrikeArrow( x, y )
	local city = GetHeadSelectedCity()
	if city and city:CanRangeStrikeAt( x, y ) then
		_bArrowSpawned = true
		return EventsSpawnArrowEvent( city:GetX(), city:GetY(), x, y )
	else
		return ClearRangeStrikeArrow()
	end
end

local function DisplayUnitRangeStrikeArrow( x, y )
	local unit = GetHeadSelectedUnit()
	if unit and unit:CanMove() and ( unit:CanRangeStrikeAt( x, y, true, GetInterfaceMode()~=INTERFACEMODE_SELECTION and GetInterfaceMode()~=INTERFACEMODE_MOVE_TO ) or unit:CanNukeAt( x, y ) ) then -- true = NeedWar, false = not isNoncombatAllowed
		_bArrowSpawned = true
		return EventsSpawnArrowEvent( unit:GetX(), unit:GetY(), x, y )
	else
		return ClearRangeStrikeArrow()
	end
end

local function BeginRangeStrikeAttack( f )
	EventsSerialEventMouseOverHex.Add( f )
	return f( GetMouseOverHex() )
end

local function EndRangeStrikeAttack( f )
	EventsSerialEventMouseOverHex.Remove( f )
	ClearRangeStrikeArrow()
	return ClearStrikeRange()
end

local function EndUnitRangeStrikeAttack()
	return EndRangeStrikeAttack( DisplayUnitRangeStrikeArrow )
end

local function BeginUnitRangeStrikeAttack() -- isAlreadySelectionMode )
	local unit = GetHeadSelectedUnit()
	if unit then
		if unit:IsCanAttackRanged() and not unit:IsEmbarked() then
			DisplayUnitStrikeRange( unit )
			if unit:CanRangeStrike() then -- or unit:CanNuke()
				return BeginRangeStrikeAttack( DisplayUnitRangeStrikeArrow )
			end
		else
			ClearStrikeRange()
		end
	end
	return SetInterfaceModeSelection()
end

local function DoUnitRangeStrikeAttack()
	local x, y = GetMouseOverHex()
	local plot = GetPlot( x, y )
	local unit = GetHeadSelectedUnit()
	--debug_print( "RangedAttack", unit and unit:GetName() )
	-- Don't let the user do a ranged attack on a plot that contains some fighting.
	if not unit or not plot or plot:IsFighting() then
	-- should handle the case of units bombarding tiles when they are already at war
	elseif unit:CanRangeStrikeAt( x, y, true, true ) then -- bNeedWar, bNoncombatAllowed
		Game.SelectionListGameNetMessage( GAMEMESSAGE_PUSH_MISSION, unit:GetDomainType() == DOMAIN_AIR and MissionTypes.MISSION_MOVE_TO or MissionTypes.MISSION_RANGE_ATTACK, x, y, 0, false, UI.ShiftKeyDown() ) -- Air strikes are moves... yep
--		ClearRangeStrikeArrow()
	-- Unit Range Strike - special case for declaring war with range strike
	elseif unit:CanRangeStrikeAt( x, y, false, true ) then -- bNeedWar, bNoncombatAllowed
		-- Is there someone here that we COULD capture or bombard, perhaps?
		local rivalTeamID = unit:GetDeclareWarRangeStrike( plot )
		if rivalTeamID ~= -1 then
			UIManager:SetUICursor( 0 )
			Events.SerialEventGameMessagePopup{
				Type  = ButtonPopupTypes.BUTTONPOPUP_DECLAREWARRANGESTRIKE,
				Data1 = rivalTeamID,
				Data2 = x,
				Data3 = y,
			}
		end
	end
	return true
end

local function RequestYieldDisplay()
	if not UI.IsCityScreenUp() then
		if OptionsManager.IsCivilianYields() then
			local unit = GetHeadSelectedUnit()
			if ( UI.CanSelectionListWork() or UI.CanSelectionListFound() ) and not( unit and (GameInfoUnits[unit:GetUnitType()]or{}).DontShowYields ) then
				return EventsRequestYieldDisplay( YieldDisplayTypes.EMPIRE )
--			elseif unit and UI.CanSelectionListFound() then
--				return EventsRequestYieldDisplay( YieldDisplayTypes.AREA, CITY_PLOTS_RADIUS, unit:GetX(), unit:GetY() )
			end
		end
-- Yield icons off by default
		EventsRequestYieldDisplay( YieldDisplayTypes.AREA, 0 )
	end
end
LuaEvents.RequestYieldDisplay.Add( function(...)
	if ... then
		EventsRequestYieldDisplay( ... )
	else
		return RequestYieldDisplay()
	end
end)

local function DisplayCityOutline( x, y )
	--debug_print( "DisplayCityOutline", x, y )
	local targetPlot = GetPlot( x, y )
	local player = Players[ Game.GetActivePlayer() ]
	EventsClearHexHighlightStyle( "BuyFill" )
	EventsClearHexHighlightStyle( "BuyOutline" )
	if player and targetPlot and targetPlot:IsRevealed( player:GetTeam() ) then
		if player:CanFound( x,y ) then
			EventsRequestYieldDisplay( YieldDisplayTypes.AREA, CITY_PLOTS_RADIUS, x, y )
			local plot, a, b, c, hex
			if FoundCityIcon then
				a, b, c = GridToWorld( x, y )
				FoundCityIcon:SetWorldPositionVal( a, b, c )
				FoundCityIcon:SetHide( false  )
			end
			a = CountHexPlots( MIN_CITY_RANGE )
			b = CountHexPlots( CITY_PLOTS_RADIUS )
			for i=0, max(a, b) do
				plot = IndexPlot( targetPlot, i )
				if plot then
					hex = ToHexFromGrid{ x=plot:GetX(), y=plot:GetY() }
					if i<=a then
						EventsSerialEventHexHighlight( hex, true, nil, "BuyFill" )
					end
					if i<=b then
						EventsSerialEventHexHighlight( hex, true, nil, "BuyOutline" )
					end
				end
			end
			return
		end
	end
	if FoundCityIcon then
		FoundCityIcon:SetHide( true )
	end
	return RequestYieldDisplay()
end

local function ShowCitiesOutline()
	--debug_print( "ShowCitiesOutline" )
	if not _bCityOutlineShown and not InStrategicView() then
		_bCityOutlineShown = true
		local iActiveTeam = Game.GetActiveTeam()
		local iActivePlayer = Game.GetActivePlayer()
		local EventsSerialEventHexHighlight = EventsSerialEventHexHighlight
		local ToHexFromGrid = ToHexFromGrid
		local hex, plot, sFilled, sSpline, b
		local mouseX, mouseY = GetMouseOverHex()
		local distance = PlotDistance
		local a = CountHexPlots( MIN_CITY_RANGE )
		for iPlayer, player in pairs(Players) do
			if player:IsAlive() then
				if iPlayer == iActivePlayer then
					sSpline = "OwnedOutline"
					sFilled = "OwnedFill"
				else
					sSpline = "OverlapOutline"
					sFilled = "OverlapFill"
				end
				for city in player:Cities() do
					if city:Plot():IsRevealed( iActiveTeam ) and distance( mouseX, mouseY, city:GetX(), city:GetY() ) < 25 then
						b = city:GetNumCityPlots()-1
						for i=0, max(a,b) do
							plot = city:GetCityIndexPlot( i )
							if plot then
								hex = ToHexFromGrid{ x=plot:GetX(), y=plot:GetY() }
								if i<=a then
									EventsSerialEventHexHighlight(  hex, true, nil, sFilled )
								end
								if i<=b then
									EventsSerialEventHexHighlight(  hex, true, nil, sSpline )
								end
							end
						end
					end
				end
			end
		end
		EventsSerialEventMouseOverHex.Add( DisplayCityOutline )
		return DisplayCityOutline( GetMouseOverHex() )
	end
end

local function HideCitiesOutline()
	--debug_print( "HideCitiesOutline" )
	if _bCityOutlineShown then
		EventsSerialEventMouseOverHex.Remove( DisplayCityOutline )
		_bCityOutlineShown = false
		for s in pairs( _tHighlightsUsed ) do
			EventsClearHexHighlightStyle( s )
		end
		if FoundCityIcon then
			FoundCityIcon:SetHide( true )
		end
		return RequestYieldDisplay()
	end
end

local function DisplayUnitPath( x, y )
	--debug_print( "DisplayUnitPath", x, y )
	UI.SendPathfinderUpdate()
	Events.DisplayMovementIndicator( true )
	if InStrategicView() then
	elseif _bUnitPredictiveStrikeRange or UI.AltKeyDown() then
		local unit = GetHeadSelectedUnit()
		if unit and unit:IsCanAttackRanged() then -- or unit:CanNuke()
			local plot = GetPlot( x, y )
			local domainID = unit:GetDomainType()
			local isWater = plot:IsWater()
			if plot and plot:IsRevealed( unit:GetTeam() ) and ( plot:IsCity() or isWater and domainID ~= DOMAIN_LAND or not isWater and domainID ~= DOMAIN_SEA ) then
				-- DisplayUnitPredictiveStrikeRange
				return DisplayUnitStrikeRange( unit, plot, plot ~= unit:GetPlot() )
			end
			return ClearStrikeRange()
		end
	end
end

local function ShowUnitPath()
	--debug_print( "ShowUnitPath", "_bPathShown", _bPathShown )
	if not _bPathShown then
		_bPathShown = true
		if UI.CanSelectionListFound() then
			ShowCitiesOutline()
		end
		EventsSerialEventMouseOverHex.Add( DisplayUnitPath )
		return DisplayUnitPath( GetMouseOverHex() )
	end
end

local function HideUnitPath()
	--debug_print( "HideUnitPath", "_bPathShown=", _bPathShown )
	if _bPathShown then
		_bPathShown = false
		EventsSerialEventMouseOverHex.Remove( DisplayUnitPath )
		Events.DisplayMovementIndicator( false )
		return HideCitiesOutline()
	end
end

local function ClickSelect()
	-- Give the strategic view a chance to process the click first
	if InStrategicView() and ProcessStrategicViewMouseClick() then
		return
	else
		local plot = GetPlot( GetMouseOverHex() )
		if plot then
			UI.LocationSelect( plot, UI.CtrlKeyDown(), UI.AltKeyDown(), UI.ShiftKeyDown() )
			return true
		end
	end
end

--[[
UI.CenterCamera
CameraProjectionChanged; CameraViewChanged;
Events.SerialEventCameraBack; Events.SerialEventCameraCenter; Events.SerialEventCameraForward; Events.SerialEventCameraLeft; Events.SerialEventCameraRight; 
Events.SerialEventCameraSetCenterAndZoom{x=-1280,y=720,z=zoom};
Events.CameraStopPitchingDown(), Events.CameraStartPitchingUp(), Events.CameraStopPitchingUp(), Events.CameraStartPitchingDown()
Events.SerialEventCameraSetCenterAndZoom.Add(
function(...)
	local s = "SerialEventCameraSetCenterAndZoom"
	for _, v in pairs{...} do
		s = s ..", "..tostring(v)
	end
	Events.GameplayAlertMessage( s )
end)
	[Keys.VK_DIVIDE] = function( b )
		local x, y = GridToWorld( GetMouseOverHex() )
		if b then
			Events.SerialEventCameraSetCenterAndZoom{x=x,y=y,z=70}
		else
			Events.SerialEventCameraSetCenterAndZoom{x=x,y=y,z=1800}
		end
	end,
--]]

--==========================================================
-- Default Key Down Handler
--==========================================================
local DefaultKeyDownFunction = {
	[Keys.VK_LEFT] = function( b )
		if b then
			Events.CameraStopRotatingCW()
			return Events.CameraStartRotatingCCW()
		else
			Events.SerialEventCameraStopMovingRight()
			return Events.SerialEventCameraStartMovingLeft()
		end
	end,
	[Keys.VK_RIGHT] = function( b )
		if b then
			Events.CameraStopRotatingCCW()
			return Events.CameraStartRotatingCW()
		else
			Events.SerialEventCameraStopMovingLeft()
			return Events.SerialEventCameraStartMovingRight()
		end
	end,
	[Keys.VK_UP] = function( b )
		if b then
			return Events.SerialEventCameraForward()
		else
			Events.SerialEventCameraStopMovingBack()
			return Events.SerialEventCameraStartMovingForward()
		end
	end,
	[Keys.VK_DOWN] = function( b )
		if b then
			return Events.SerialEventCameraBack()
		else
			Events.SerialEventCameraStopMovingForward()
			return Events.SerialEventCameraStartMovingBack()
		end
	end,
	[Keys.VK_NEXT] = function()
		return Events.SerialEventCameraOut{ x=0, y=0 }
	end,
	[Keys.VK_PRIOR] = function()
		return Events.SerialEventCameraIn{ x=0, y=0 }
	end,
	[Keys.VK_ESCAPE] = function()
		if MiniMapOptionsPanel and not MiniMapOptionsPanel:IsHidden() then
			return MiniMapOptionsPanel:SetHide( true )
		elseif _bPathShown or GetInterfaceMode() ~= INTERFACEMODE_SELECTION then
			return SetInterfaceModeSelection()
		elseif InStrategicView() then
			return ToggleStrategicView()
		else
			return UIManager:QueuePopup( Controls.GameMenu, InGameMenu )
		end
	end,
	[Keys.VK_OEM_3] = function() -- ~ en_us ù fr_azerty
		if UI.DebugFlag() then
			if UI.ShiftKeyDown() and PreGame.IsMultiplayerGame() then
				return Controls.NetworkDebug:SetHide( not Controls.NetworkDebug:IsHidden() )
			elseif not PreGame.IsMultiplayerGame() and not PreGame.IsHotSeatGame() then
				return Controls.DebugMenu:SetHide( not Controls.DebugMenu:IsHidden() )
			end
		end
	end,
	[Keys.Z] = function()
		if UI.CtrlKeyDown() and UI.DebugFlag() and not PreGame.IsMultiplayerGame() and not PreGame.IsHotSeatGame() then
			Game.ToggleDebugMode()
			local plot
			local team = Game.GetActiveTeam()
			local bIsDebug = Game.IsDebugMode()
			for iPlotLoop = 0, GetNumPlots()-1, 1 do
				plot = GetPlotByIndex(iPlotLoop)
				if plot:GetVisibilityCount() > 0 then
					plot:ChangeVisibilityCount( team, -1, -1, true, true )
				end
				plot:SetRevealed( team, false )
				plot:ChangeVisibilityCount( team, 1, -1, true, true )
				plot:SetRevealed( team, bIsDebug )
			end
		end
	end,
	[Keys.G] = UI.ToggleGridVisibleMode,
	[Keys.X] = ShowCitiesOutline,
}
local function DefaultKeyDownHandler( wParam )
	if DefaultKeyDownFunction[ wParam ] then
		DefaultKeyDownFunction[ wParam ]( UI.ShiftKeyDown() )
		return true
	end
end

--==========================================================
-- Default Key Up Handler
--==========================================================
local DefaultKeyUpFunction = {
	[Keys.VK_LEFT] = function()
		Events.CameraStopRotatingCCW()
		return Events.SerialEventCameraStopMovingLeft()
	end,
	[Keys.VK_RIGHT] = function()
		Events.CameraStopRotatingCW()
		return Events.SerialEventCameraStopMovingRight()
	end,
	[Keys.VK_UP] = Events.SerialEventCameraStopMovingForward.Call,
	[Keys.VK_DOWN] = Events.SerialEventCameraStopMovingBack.Call,
	[Keys.X] = HideCitiesOutline,
}
local function DefaultKeyUpHandler( wParam )
	if DefaultKeyUpFunction[ wParam ] then
		DefaultKeyUpFunction[ wParam ]()
		return true
	end
end
-- Emergency key up handler
-- Events.KeyUpEvent.Add( DefaultKeyUpHandler )

--==========================================================
-- Default Input Handler
--==========================================================
local DefaultMessageHandler = {
	[KeyEvents.KeyDown] = DefaultKeyDownHandler,
	[KeyEvents.KeyUp] = DefaultKeyUpHandler,
	[MouseEvents.LButtonUp] = ClickSelect,
	[MouseEvents.PointerUp] = IsTouchScreenEnabled() and SetInterfaceModeSelectionTrue or nil,
	[MouseEvents.PointerDown] = IsTouchScreenEnabled() and function()
		if UIManager:GetNumPointers() > 1 then
			return SetInterfaceModeSelectionTrue()
		end
	end or nil,
}

--==========================================================
-- Default Mission Handler
--==========================================================
for row in GameInfoInterfaceModes() do
	_tInterfaceModeCursors[ row.ID ] = GameInfoTypes[ row.CursorType ]
	local interfaceModeMission = GameInfoTypes[ row.Mission ]
	if interfaceModeMission and interfaceModeMission ~= MissionTypes.NO_MISSION then
		AssignInterfaceModeMessageHandler( row.ID,
		function()
			--debug_print( "DefaultMissionHandler", _tInterfaceModeNames[ GetInterfaceMode() ] )
			local x, y = GetMouseOverHex()
			if GetPlot(x, y) and UI.CanDoInterfaceMode(interfaceModeMission) then
				Game.SelectionListGameNetMessage( GAMEMESSAGE_PUSH_MISSION, interfaceModeMission, x, y, 0, false, UI.ShiftKeyDown() )
			end
			return SetInterfaceModeSelectionTrue()
		end)
	end
end

--==========================================================
-- Debug
--==========================================================
do
	local unitPlopper, resourcePlopper, improvementPlopper
	local plopperSettings =
	{
		Player = -1,
		Plopper = unitPlopper,
		EnabledWhenInTab = false
	}

	unitPlopper =
	{
		UnitType = -1,
		Embarked = false,
		Plop =
		function( plot )
			if plopperSettings.Player ~= -1 and unitPlopper.UnitType ~= -1 then
				local player = Players[plopperSettings.Player]
				if player then
					--debug_print( "plop", unitPlopper.UnitNameOffset, player.InitUnitWithNameOffset )
					local unit

					if unitPlopper.UnitNameOffset and player.InitUnitWithNameOffset then
						unit = player:InitUnitWithNameOffset(unitPlopper.UnitType, unitPlopper.UnitNameOffset, plot:GetX(), plot:GetY())
					else
						unit = player:InitUnit(unitPlopper.UnitType, plot:GetX(), plot:GetY())
					end

					if unitPlopper.Embarked then
						unit:Embark()
					end
				end
			end
		end,
		Deplop =
		function( plot )
			for i = 0, plot:GetNumUnits() - 1 do
				local unit = plot:GetUnit(i)
				if unit then
					unit:Kill( true, -1 )
				end
			end
		end
	}

	resourcePlopper =
	{
		ResourceType = -1,
		ResourceAmount = 1,
		Plop =
		function(plot)
			if resourcePlopper.ResourceType ~= -1 then
				plot:SetResourceType( resourcePlopper.ResourceType, resourcePlopper.ResourceAmount )
			end
		end,
		Deplop =
		function(plot)
			plot:SetResourceType(-1)
		end
	}

	improvementPlopper =
	{
		ImprovementType = -1,
		Pillaged = false,
		HalfBuilt = false,
		Plop =
		function( plot )
			if improvementPlopper.ImprovementType ~= -1 then
				plot:SetImprovementType(improvementPlopper.ImprovementType)
				plot:SetImprovementPillaged( improvementPlopper.Pillaged )
			end
		end,
		Deplop =
		function( plot )
			plot:SetImprovementType(-1)
		end
	}

	g_CityPlopper =
	{
		Plop =
		function( plot )
			if plopperSettings.Player ~= -1 then
				local player = Players[plopperSettings.Player]
				if player then
					player:InitCity(plot:GetX(), plot:GetY())
				end
			end
		end,
		Deplop =
		function( plot )
			local city = plot:GetPlotCity()
			if city then
				city:Kill()
			end
		end
	}

	AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_DEBUG,
		{[MouseEvents.LButtonUp] = function()
			local x, y = GetMouseOverHex()
			local plot = GetPlot( x, y )
			local pActivePlayer = Players[Game.GetActivePlayer()]
			local debugItem1 = UI.GetInterfaceModeDebugItemID1()
			local debugItem2 = UI.GetInterfaceModeDebugItemID2()
			if debugItem1 == 0 then
				pActivePlayer:InitCity( x, y )
			elseif debugItem1 == 1 then
				pActivePlayer:InitUnit( debugItem2, x, y )
			elseif debugItem1 == 2 then
				plot:SetImprovementType( debugItem2 )
			elseif debugItem1 == 3 then
				plot:SetRouteType( debugItem2 )
			elseif debugItem1 == 4 then
				plot:SetFeatureType( debugItem2 )
			elseif debugItem1 == 5 then
				plot:SetResourceType( debugItem2, 5 )
			-- Plopper
			elseif debugItem1 == 6
				and type(plopperSettings) == "table"
				and type(plopperSettings.Plopper) == "table"
				and type(plopperSettings.Plopper.Plop) == "function"
			then
				plopperSettings.Plopper.Plop( plot )
				return true -- Do not allow the interface mode to be set back to INTERFACEMODE_SELECTION
			end
			return SetInterfaceModeSelectionTrue()
		end,
		[MouseEvents.RButtonDown] = function()
			local plot = GetPlot( GetMouseOverHex() )
			local debugItem1 = UI.GetInterfaceModeDebugItemID1()
			-- Plopper
			if debugItem1 == 6
				and type(plopperSettings) == "table"
				and type(plopperSettings.Plopper) == "table"
				and type(plopperSettings.Plopper.Plop) == "function"
			then
				plopperSettings.Plopper.Plop( plot )
			end
			return true
		end,
		[MouseEvents.LButtonDown] = function() return true end, -- Trap LButtonDown
		[MouseEvents.RButtonUp] = function() return true end, -- Trap RButtonUp
	})
	g_PlopperSettings, g_UnitPlopper, g_ResourcePlopper, g_ImprovementPlopper = plopperSettings, unitPlopper, resourcePlopper, improvementPlopper
end
--==========================================================
-- Selection & Moveto
--==========================================================
local function EndMovement()
	--debug_print( "EndMovement" )
--[[
	if g_EatNextUp == true then
		g_EatNextUp = false
		return
	end
--]]
	if IsTouchScreenEnabled() then
		SetInterfaceModeSelection()
	end
	Events.DisplayMovementIndicator( false )
	local shiftKeyDown = UI.ShiftKeyDown()
	local altKeyDown = UI.AltKeyDown()
	local ctrlKeyDown = UI.CtrlKeyDown()
	local x, y = GetMouseOverHex()
	local plot = GetPlot( x, y )
	local unit = GetHeadSelectedUnit()

	if plot and unit then
		if UI.IsCameraMoving() and not Game.GetAllowRClickMovementWhileScrolling() then
			--debug_print( "Blocked by moving camera" )
			--Events.ClearHexHighlights()
--			HideUnitPath()
			return false
		end

		Game.SetEverRightClickMoved( true )

		-- Is there someone here that we COULD bombard perhaps?
		local rivalTeamID = unit:GetDeclareWarRangeStrike( plot )
		if rivalTeamID ~= -1 then
			UIManager:SetUICursor( 0 )
			Events.SerialEventGameMessagePopup{
				Type  = ButtonPopupTypes.BUTTONPOPUP_DECLAREWARRANGESTRIKE,
				Data1 = rivalTeamID,
				Data2 = x,
				Data3 = y
			}
			return true
		-- Visible enemy... bombardment?
		elseif plot:IsVisibleEnemyUnit( unit:GetOwner() ) or plot:IsEnemyCity( unit ) then

			-- Already some combat going on in there, just exit
			if plot:IsFighting() then
				return true
			elseif unit:CanRangeStrikeAt( x, y, true, false ) then -- true = NeedWar, false = not isNoncombatAllowed
				Game.SelectionListGameNetMessage( GAMEMESSAGE_PUSH_MISSION, unit:GetDomainType() == DOMAIN_AIR and MissionTypes.MISSION_MOVE_TO or MissionTypes.MISSION_RANGE_ATTACK, x, y, 0, false, shiftKeyDown) -- Air strikes are moves... yep
				return true
			end
		end

		if not _bCiv5GK then
			-- Garrison in a city
			local city = plot:GetPlotCity()
			if city and city:GetOwner() == unit:GetOwner() and unit:IsCanAttack() then
				local cityOwner = Players[city:GetOwner()]
				if not cityOwner:IsMinorCiv() and not city:GetGarrisonedUnit() and unit:GetDomainType() == DOMAIN_LAND then
					Game.SelectionListGameNetMessage( GAMEMESSAGE_PUSH_MISSION, MissionTypes.MISSION_GARRISON, x, y, 0, false, shiftKeyDown )
					return true
				end
			end
		end

		-- Is unit already in target plot ?
		if not shiftKeyDown and unit:AtPlot( plot ) then
			--debug_print("Game.SelectionListGameNetMessage( GAMEMESSAGE_DO_COMMAND, COMMAND_CANCEL_ALL )")
			Game.SelectionListGameNetMessage( GAMEMESSAGE_DO_COMMAND, COMMAND_CANCEL_ALL )
		-- No visible enemy to bombard, just move
		else
			--debug_print("Game.SelectionListMove( plot,", altKeyDown, shiftKeyDown, ctrlKeyDown )
			Game.SelectionListMove( plot, altKeyDown, shiftKeyDown, ctrlKeyDown )
		end
	end
	return true
end

local function BeginSelectionMode()
	ShowUnitMovementRange( GetHeadSelectedUnit() )
	return BeginUnitRangeStrikeAttack() -- true )
end

local function EndSelectionMode()
	EndUnitRangeStrikeAttack()
	return ClearUnitMovementRange()
end

AssignInterfaceMode( INTERFACEMODE_SELECTION,
	{
		[MouseEvents.RButtonDown] = ShowUnitPath,
		[MouseEvents.RButtonUp] = function() EndMovement() return HideUnitPath() end,
	},
	BeginSelectionMode,
	EndSelectionMode )

AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_MOVE_TO,
	{
		[MouseEvents.LButtonUp] = function() EndMovement() return SetInterfaceModeSelectionTrue() end,
		[MouseEvents.RButtonUp] = EndMovement,
	},
	function()
		ShowUnitMovementRange( GetHeadSelectedUnit() )
		return ShowUnitPath()
	end,
	function()
		ClearUnitMovementRange()
		return HideUnitPath()
	end)

if IsTouchScreenEnabled() then
	_tInterfaceModeMessageHandler[InterfaceModeTypes.INTERFACEMODE_MOVE_TO][MouseEvents.PointerUp] = 
	function()
		if g_EatNextUp then
			g_EatNextUp = nil
			return
		end
		return EndMovement()
	end
	_tInterfaceModeMessageHandler[INTERFACEMODE_SELECTION][MouseEvents.PointerUp] = ClickSelect
	_tInterfaceModeMessageHandler[INTERFACEMODE_SELECTION][MouseEvents.LButtonDoubleClick] =
	function()
		if GetHeadSelectedUnit() then
			SetInterfaceMode( InterfaceModeTypes.INTERFACEMODE_MOVE_TO )
			g_EatNextUp = true
		end
	end
end
--==========================================================
-- Attack
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_ATTACK,
	function()
		--debug_print("Calling attack into tile")
		local plot = GetPlot( GetMouseOverHex() )
		if plot and plot:IsActiveVisible() then
			local unit = GetHeadSelectedUnit()
			if unit and plot:IsVisibleEnemyUnit( unit:GetOwner() ) or plot:IsEnemyCity( unit ) then
				Game.SelectionListMove( plot, false, false, false )
				return true
			end
		end
		return true
	end,
	function()
		local unit = GetHeadSelectedUnit()
		if unit then
			return Events.ShowAttackTargets( unit:GetOwner(), unit:GetID() )
		else
			return SetInterfaceModeSelection()
		end
	end,
	ClearUnitMovementRange)

--==========================================================
-- City Ranged Attack
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_CITY_RANGE_ATTACK,
	function()
		--debug_print( "City Ranged Attack" )
		local x, y = GetMouseOverHex()
		local plot = GetPlot( x, y )
		-- Don't let the user do a ranged attack on a plot that contains some fighting.
		if plot and not plot:IsFighting() then
			local city = GetHeadSelectedCity()
			if city and city:CanRangeStrikeAt( x, y ) then
				Game.SelectedCitiesGameNetMessage( GAMEMESSAGE_DO_TASK, TASK_RANGED_ATTACK, x, y )
				Events.SpecificCityInfoDirty( city:GetOwner(), city:GetID(), CITY_UPDATE_TYPE_BANNER )
				SetInterfaceModeSelection()
			end
		end
		return true
	end,
	function()
		local city = GetHeadSelectedCity()
		--debug_print("Begin City Range Attack",city and city:GetName())
		if city and city:CanRangeStrike() then
			Events.SerialEventCityInfoDirty.Add( function() if GetHeadSelectedCity() ~= city then return SetInterfaceModeSelection() end end) -- Still selected?
			DisplayStrikeRange( city, city:Plot(), CITY_ATTACK_RANGE, CAN_CITY_USE_INDIRECT_FIRE )
			return BeginRangeStrikeAttack( DisplayCityRangeStrikeArrow )
		end
		return SetInterfaceModeSelection()
	end,
	function()
		--debug_print("End City Range Attack")
		UI.ClearSelectedCities() -- required for events to be processed properly
		Events.SerialEventCityInfoDirty.RemoveAll()
		return EndRangeStrikeAttack( DisplayCityRangeStrikeArrow )
	end)

--==========================================================
-- Air Strike
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_AIRSTRIKE,
	DoUnitRangeStrikeAttack, BeginUnitRangeStrikeAttack, EndUnitRangeStrikeAttack )

--==========================================================
-- Ranged Attack
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_RANGE_ATTACK,
	DoUnitRangeStrikeAttack, BeginUnitRangeStrikeAttack, EndUnitRangeStrikeAttack )

_tInterfaceModeMessageHandler[InterfaceModeTypes.INTERFACEMODE_RANGE_ATTACK][KeyEvents.KeyDown] = function( wParam )
	if wParam == Keys.VK_NUMPAD1 or wParam == Keys.VK_NUMPAD3 or wParam == Keys.VK_NUMPAD4 or wParam == Keys.VK_NUMPAD6 or wParam == Keys.VK_NUMPAD7 or wParam == Keys.VK_NUMPAD8 then
		SetInterfaceModeSelection()
	end
	return DefaultKeyDownHandler( wParam )
end

--==========================================================
-- Nuke
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_NUKE,
	nil,
	function()
		local unit = GetHeadSelectedUnit()
		if unit and unit:CanNuke() and not unit:IsOutOfAttacks() then
			-- highlight nukable plots
			local fromPlot = unit:GetPlot()
			local plot, x, y
			for i = 0, CountHexPlots( unit:Range() ) do
				plot = IndexPlot( fromPlot, i )
				if plot then
					x = plot:GetX()
					y = plot:GetY()
					if unit:CanNukeAt( x, y ) then
						EventsSerialEventHexHighlight( ToHexFromGrid{ x=x, y=y }, true, nil, "FireRangeBorder" )
					end
				end
			end
			EventsSerialEventMouseOverHex.Add( DisplayUnitRangeStrikeArrow )
			return DisplayUnitRangeStrikeArrow( GetMouseOverHex() )
		end
		return SetInterfaceModeSelection()
	end,
	EndUnitRangeStrikeAttack)

--==========================================================
-- Embark, Disembark
--==========================================================
do
	local function doBark( test, mission )
		--debug_print( "Embark/Disembark", mission )
		local x, y = GetMouseOverHex()
		local plot = GetPlot( x, y )
		local unit = plot and GetHeadSelectedUnit()
		if unit and test( unit, plot ) then
			Game.SelectionListGameNetMessage( GAMEMESSAGE_PUSH_MISSION, mission, x, y, 0, false, UI.ShiftKeyDown() )
		end
		return true
	end
	local function showBark( test )
		local unit = GetHeadSelectedUnit()
		if unit then
			local plot
			local unitPlot = unit:GetPlot()
			local unitTeam = unit:GetTeam()
			for i = 1, 6 do
				plot = IndexPlot( unitPlot, i )
				if plot and plot:IsRevealed( unitTeam ) and test( unit, plot ) then
					EventsSerialEventHexHighlight( ToHexFromGrid{ x=plot:GetX(), y=plot:GetY() }, true, _tColorUnitTile, "GUHB" )
				end
			end
		else
			return SetInterfaceModeSelection()
		end
	end
	local function testEmbark( unit, plot )
		return unit:CanEmbarkOnto( unit:GetPlot(), plot )
	end
	local function testDisembark( unit, plot )
		return unit:CanDisembarkOnto( plot )
	end
	AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_EMBARK,
		function() doBark( testEmbark, MissionTypes.MISSION_EMBARK ) end,
		function() showBark( testEmbark ) end,
		ClearUnitMovementRange )
	AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_DISEMBARK,
		function() doBark( testDisembark, MissionTypes.MISSION_DISEMBARK ) end,
		function() showBark( testDisembark ) end,
		ClearUnitMovementRange )
end

--==========================================================
-- Place Unit
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_PLACE_UNIT,
	function()
		--debug_print( "EjectHandler" )
		local x, y = GetMouseOverHex()
		local plot = GetPlot( x, y )
		--debug_print("INTERFACEMODE_PLACE_UNIT")
		local unit = UI.GetPlaceUnit()
		UI.ClearPlaceUnit()
		if unit and plot then
			--debug_print("INTERFACEMODE_PLACE_UNIT - got placed unit")
			local city = unit:GetPlot():GetPlotCity()
			if city then
				--debug_print("INTERFACEMODE_PLACE_UNIT - not nil city")
				if UI.CanPlaceUnitAt(unit, plot) then
					--debug_print("INTERFACEMODE_PLACE_UNIT - Can eject unit")
					--Network.SendCityEjectGarrisonChoice(city:GetID(), x, y )
				end
			end
		end
		return true
	end)

--==========================================================
-- Gift Unit
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_GIFT_UNIT,
	function()
		--debug_print( "GiftUnit" )
		local plot = GetPlot( GetMouseOverHex() )
		local iActivePlayer = Game.GetActivePlayer()
		local minorPlayerID = UI.GetInterfaceModeValue()
		if Players[iActivePlayer] then
			local unit
			for i = 0, plot:GetNumUnits() - 1 do
				local u = plot:GetUnit(i)
				if u:GetOwner() == iActivePlayer then
					unit = u
					break
				end
			end
			if unit and unit:CanDistanceGift(minorPlayerID) then
				--debug_print( "Gift unit player ID", iActivePlayer, "Other player ID", UI.GetInterfaceModeValue(), "UnitID", unit:GetID(), unit:GetName() )
				Events.SerialEventGameMessagePopup{
					Type = ButtonPopupTypes.BUTTONPOPUP_GIFT_CONFIRM,
					Data1 = iActivePlayer,
					Data2 = minorPlayerID,
					Data3 = unit:GetID(),
				}
				SetInterfaceModeSelection()
			end
		end
		return true
	end,
	function()
		local pActivePlayer = Players[Game.GetActivePlayer()]
		if pActivePlayer then
			local minorPlayerID = UI.GetInterfaceModeValue()
			for unit in pActivePlayer:Units() do
				if unit:CanDistanceGift(minorPlayerID) then
					EventsSerialEventHexHighlight( ToHexFromGrid{ x=unit:GetX(), y=unit:GetY() }, true, _tColorUnitTile, "GUHB" )
				end
			end
		else
			return SetInterfaceModeSelection()
		end
	end,
	ClearUnitMovementRange)

--==========================================================
-- Gift Tile Improvement
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_GIFT_TILE_IMPROVEMENT,
	function()
		local x, y = GetMouseOverHex()
		local plot = GetPlot( x, y )
		if plot then
			local iActivePlayer = Game.GetActivePlayer()
			local minorPlayerID = UI.GetInterfaceModeValue()
			local minorPlayer = Players[minorPlayerID]
			if minorPlayer then
				if minorPlayer:CanMajorGiftTileImprovementAtPlot(iActivePlayer, x, y) then
					Game.DoMinorGiftTileImprovement(iActivePlayer, minorPlayerID, x, y)
				end
				SetInterfaceModeSelection()
			end
		end
		return true
	end,
	function()
		local iActivePlayer = Game.GetActivePlayer()
		local minorPlayer = Players[UI.GetInterfaceModeValue()]
		if minorPlayer then
			local city = minorPlayer:GetCapitalCity()
			if city then
				local cityPlot = city:Plot()
				local plot, x, y
				-- highlight the improvable plots
				for i = 0, CountHexPlots( MINOR_CIV_RESOURCE_SEARCH_RADIUS ) do
					plot = IndexPlot( cityPlot, i )
					if plot then
						x = plot:GetX()
						y = plot:GetY()
						if minorPlayer:CanMajorGiftTileImprovementAtPlot(iActivePlayer, x, y) then
							EventsSerialEventHexHighlight( ToHexFromGrid{ x=x, y=y }, true, _tColorGiftTileImprovement, "GUHB" )
						end
					end
				end
				return
			end
		end
		return SetInterfaceModeSelection()
	end,
	ClearUnitMovementRange)

--==========================================================
-- Airlift
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_AIRLIFT,
	nil,
	function()
		local unit = GetHeadSelectedUnit()
		if unit then
			local unitPlot = unit:GetPlot()
			local tAirliftHighlight = InStrategicView() and "GUHB" or "MovementRangeBorder"
			if unit:CanAirlift(unitPlot, false) then
				for iPlotLoop = 0, GetNumPlots()-1, 1 do
					local plot = GetPlotByIndex(iPlotLoop)
					local x = plot:GetX()
					local y = plot:GetY()
					if unit:CanAirliftAt(unitPlot, x, y) then
						EventsSerialEventHexHighlight( ToHexFromGrid{ x=x, y=y }, true, _tColorUnitTile, tAirliftHighlight )
					end
				end
				return
			end
		end
		return SetInterfaceModeSelection()
	end,
	ClearUnitMovementRange)

--==========================================================
-- Paradrop
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_PARADROP,
	nil,
	function()
		local unit = GetHeadSelectedUnit()
		if unit then
			local unitPlot = unit:GetPlot()
			local plot, x, y
			local tParadropHighlight = InStrategicView() and "GUHB" or "MovementRangeBorder"
			if unit:CanParadrop(unitPlot, false) then
			for i = 0, CountHexPlots( unit:GetDropRange() ) do
					plot = IndexPlot( unitPlot, i )
					if plot then
						x, y = plot:GetX(), plot:GetY()
						if unit:CanParadropAt(unitPlot,x,y) then
							EventsSerialEventHexHighlight( ToHexFromGrid{ x=x, y=y }, true, _tColorUnitTile, tParadropHighlight )
						end
					end
				end
				return
			end
		end
		return SetInterfaceModeSelection()
	end,
	ClearUnitMovementRange)

--==========================================================
-- Airsweep
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_AIR_SWEEP,
	nil, BeginUnitRangeStrikeAttack, EndUnitRangeStrikeAttack )

--==========================================================
-- Rebase
--==========================================================
AssignInterfaceMode( InterfaceModeTypes.INTERFACEMODE_REBASE,
	nil,
	function()
		local unit = GetHeadSelectedUnit()
		if unit then
			local unitPlot = unit:GetPlot()
			local plot, x, y, hex
			local tRebaseHighlight = InStrategicView() and "GUHB" or "MovementRangeBorder"
			for i = 0, CountHexPlots( unit:Range() * AIR_UNIT_REBASE_RANGE_MULTIPLIER ) do
				plot = IndexPlot( unitPlot, i )
				if plot then
					x, y = plot:GetX(), plot:GetY()
					hex = ToHexFromGrid{ x=x, y=y }
					EventsSerialEventHexHighlight( hex, true, _tColorMoveRange, tRebaseHighlight )
					if unit:CanRebaseAt( unitPlot, x, y ) then
						EventsSerialEventHexHighlight( hex, true, _tColorUnitTile, "GUHB" )
					end
				end
			end
		else
			return SetInterfaceModeSelection()
		end
	end,
	ClearUnitMovementRange)

--==========================================================
-- Input Handling
--==========================================================
do
	local uiMsgName = {}
	for k, v in pairs(MouseEvents) do uiMsgName[v]=k end
	for k, v in pairs(KeyEvents) do uiMsgName[v]=k end
	uiMsgName[512]=nil
	local wParamName = {}
	for k, v in pairs(Keys) do wParamName[v]=k end

	ContextPtr:SetInputHandler( function( uiMsg, wParam )
	--	if uiMsgName[uiMsg] then print("input handler:", uiMsgName[uiMsg], uiMsg, wParamName[wParam], wParam ) end
		local currentInterfaceModeHandler = _tInterfaceModeMessageHandler[ GetInterfaceMode() ]
		return CallIfNotNil( currentInterfaceModeHandler and currentInterfaceModeHandler[uiMsg] or DefaultMessageHandler[uiMsg], wParam )
	end)
end

--==========================================================
-- Process Interface Mode Change
--==========================================================
local function UpdateCursor( interfaceMode )
	-- update the cursor to reflect this mode - these cursor are defined in Civ5CursorInfo.xml
	return UIManager:SetUICursor( _tInterfaceModeCursors[ interfaceMode ] or 0 ) -- 0 is default cursor
end

Events.InterfaceModeChanged.Add( function( oldInterfaceMode, newInterfaceMode )
	--debug_print("Interface Mode Changed from", _tInterfaceModeNames[oldInterfaceMode], "to", _tInterfaceModeNames[newInterfaceMode])
	CallIfNotNil( _tOldInterfaceModeChangeHandler[oldInterfaceMode] )
	CallIfNotNil( _tNewInterfaceModeChangeHandler[newInterfaceMode] )
	return UpdateCursor( newInterfaceMode )
end)

Events.ActivePlayerTurnEnd.Add( function()
	return UIManager:SetUICursor(1) -- busy
end)

Events.ActivePlayerTurnStart.Add( function()
	return UpdateCursor( GetInterfaceMode() )
end)

local function HideRecommendations()
	-- workers - clear old list first
	if _bWorkerSuggestHighlightPlots then
		for _, v in pairs(_bWorkerSuggestHighlightPlots) do
			if v.plot then
				EventsGenericWorldAnchor( WORLD_ANCHOR_WORKER, false, v.plot:GetX(), v.plot:GetY(), v.buildType )
			end
		end
	end
	_bWorkerSuggestHighlightPlots = nil

	-- founders - clear old list first
	if _bFounderSuggestHighlightPlots then
		for _, v in pairs(_bFounderSuggestHighlightPlots) do
			EventsGenericWorldAnchor( WORLD_ANCHOR_SETTLER, false, v:GetX(), v:GetY(), -1 )
		end
	end
	_bFounderSuggestHighlightPlots = nil
end

local function UpdateRecommendations( isSelected )
	--debug_print("UpdateRecommendations	isSelected", isSelected)
	HideRecommendations()
	if isSelected and _bTileRecommendations then
		local iActivePlayer = Game.GetActivePlayer()
		local pActivePlayer = Players[iActivePlayer]
		if UI.CanSelectionListWork() then
			_bWorkerSuggestHighlightPlots = pActivePlayer:GetRecommendedWorkerPlots()
			for _, v in pairs(_bWorkerSuggestHighlightPlots) do
				if v.plot then
					EventsGenericWorldAnchor( WORLD_ANCHOR_WORKER, true, v.plot:GetX(), v.plot:GetY(), v.buildType )
				end
			end
		end
		if UI.CanSelectionListFound() and pActivePlayer:GetNumCities() > 0 then
			_bFounderSuggestHighlightPlots = pActivePlayer:GetRecommendedFoundCityPlots()
			for _, v in pairs(_bFounderSuggestHighlightPlots) do
				EventsGenericWorldAnchor( WORLD_ANCHOR_SETTLER, true, v:GetX(), v:GetY(), -1 )
			end
		end
	end
	return RequestYieldDisplay()
end

local function RefreshUnit()
	--debug_print( "RefreshUnit", _tInterfaceModeNames[GetInterfaceMode()], "GetHeadSelectedCity", GetHeadSelectedCity() and  GetHeadSelectedCity():GetName(), "GetHeadSelectedUnit", GetHeadSelectedUnit()and GetHeadSelectedUnit():GetName(), "Last unit", _pLastUnit and _pLastUnit:GetName() )
	local unit = GetHeadSelectedUnit()
	local interfaceMode = GetInterfaceMode()
	if unit then
		if interfaceMode == INTERFACEMODE_SELECTION then
			BeginSelectionMode()
		elseif unit:IsOutOfAttacks() or unit:MovesLeft()<=0 then
			SetInterfaceModeSelection()
		end
		return UpdateRecommendations( unit )
	elseif interfaceMode == INTERFACEMODE_SELECTION then
		return EndSelectionMode()
	elseif interfaceMode ~= INTERFACEMODE_CITY_RANGE_ATTACK then
		return SetInterfaceModeSelection()
	end
end
Events.SerialEventUnitInfoDirty.Add( RefreshUnit )

local function UpdateOptions()
	_bUnitPredictiveStrikeRange = UserInterfaceSettings.PredictiveRange ~= 0
	_bTileRecommendations = not OptionsManager.IsNoTileRecommendations()
	_bFastAutoUnitCycle = OptionsManager.GetAutoUnitCycle() and OptionsManager.GetQuickSelectionAdvanceEnabled()
	UpdateRecommendations( GetHeadSelectedUnit() )
	return SetInterfaceModeSelection()
end
UpdateOptions()
Events.GameOptionsChanged.Add( UpdateOptions )

--==========================================================
-- City Screen
--==========================================================
Events.SerialEventEnterCityScreen.Add( function()
	-- Can get to city screen by C++ which bypasses lua selection code
	SetInterfaceModeSelection()
	HideRecommendations()
	HideCitiesOutline()
	_bHideUnitFlags = Controls.UnitFlagManager:IsHidden()
	_bHideCityBanners = Controls.CityBannerManager:IsHidden()
	Controls.UnitFlagManager:SetHide( true )
	Controls.CityBannerManager:SetHide( true )
	Controls.CityView:SetHide( false )
	Controls.WorldView:SetHide( true )
	Controls.ScreenEdgeScrolling:SetHide( true )
	-- Grid is always shown in city screen (even if user currently has it off).
	if not OptionsManager.GetGridOn() then
		Events.SerialEventHexGridOn()
	end
end)

Events.SerialEventExitCityScreen.Add( function()
	-- Just in case...
	SetInterfaceModeSelection()
	Controls.UnitFlagManager:SetHide( _bHideUnitFlags )
	Controls.CityBannerManager:SetHide( _bHideCityBanners )
	Controls.CityView:SetHide( true )
	Controls.WorldView:SetHide( false )
	Controls.ScreenEdgeScrolling:SetHide( not OptionsManager.GetFullscreen() )
	-- Grid is hidden when leaving the city screen (unless the user had it turned on when entering the city screen)
	if not OptionsManager.GetGridOn() then
		Events.SerialEventHexGridOff()
	end
	UI.SetDirty( GameData_DIRTY_BIT, true )
	return RequestYieldDisplay()
end)

--==========================================================
--==========================================================
Controls.ScrollTop:RegisterCallback( Mouse.eMouseEnter, Events.SerialEventCameraStartMovingForward.Call )
Controls.ScrollTop:RegisterCallback( Mouse.eMouseExit, Events.SerialEventCameraStopMovingForward.Call )
Controls.ScrollBottom:RegisterCallback( Mouse.eMouseEnter, Events.SerialEventCameraStartMovingBack.Call )
Controls.ScrollBottom:RegisterCallback( Mouse.eMouseExit, Events.SerialEventCameraStopMovingBack.Call )
Controls.ScrollLeft:RegisterCallback( Mouse.eMouseEnter, Events.SerialEventCameraStartMovingLeft.Call )
Controls.ScrollLeft:RegisterCallback( Mouse.eMouseExit, Events.SerialEventCameraStopMovingLeft.Call )
Controls.ScrollRight:RegisterCallback( Mouse.eMouseEnter, Events.SerialEventCameraStartMovingRight.Call )
Controls.ScrollRight:RegisterCallback( Mouse.eMouseExit, Events.SerialEventCameraStopMovingRight.Call )

--==========================================================
--==========================================================
Events.SystemUpdateUI.Add( function( eType )
	if eType == BulkHideUI then
		Controls.BulkUI:SetHide( true )
	elseif eType == BulkShowUI then
		Controls.BulkUI:SetHide( false )
	end
end)

--==========================================================
ContextPtr:SetShowHideHandler( function( bIsHide )
	if not bIsHide then
		Controls.ScreenEdgeScrolling:SetHide( not OptionsManager.GetFullscreen() )
		Controls.WorldViewControls:SetHide( false )
		-- Check to see if we've been kicked.  It's possible that we were kicked while loading into the game.
		if Network.IsPlayerKicked(Game.GetActivePlayer()) then
			-- Display kicked popup.
			Events.SerialEventGameMessagePopup{ Type = ButtonPopupTypes.BUTTONPOPUP_KICKED, Data1 = BY_HOST }
			return SetInterfaceModeSelection()
		end
	end
end)

--==========================================================
-- Check to see if the world view controls should be hidden
--==========================================================
Events.GameViewTypeChanged.Add( function() --( eNewType )
	local bWorldViewHide = GetGameViewRenderType() == GAMEVIEW_NONE
	Controls.WorldViewControls:SetHide( bWorldViewHide )
	Controls.StagingRoom:SetHide( not bWorldViewHide )
end)

--==========================================================
-- 'Active' (local human) player has changed
--==========================================================
do
	local g_PerPlayerStrategicViewSettings = {}
	Events.GameplaySetActivePlayer.Add( function(iActivePlayer, iPrevActivePlayer)
		if iPrevActivePlayer ~= -1 then
			g_PerPlayerStrategicViewSettings[ iPrevActivePlayer ] = InStrategicView()
		end
		if iActivePlayer ~= -1 and not g_PerPlayerStrategicViewSettings[ iActivePlayer ] == InStrategicView() then
			ToggleStrategicView()
		end
		return SetInterfaceModeSelection()
	end)
end

--==========================================================
Events.MultiplayerGameAbandoned.Add( function( eReason )
	Events.SerialEventGameMessagePopup{ Type  = ButtonPopupTypes.BUTTONPOPUP_KICKED, Data1 = eReason }
	return SetInterfaceModeSelection()
end)

--==========================================================
Events.MultiplayerGameLastPlayer.Add( function()
	UI.AddPopup{ Type = ButtonPopupTypes.BUTTONPOPUP_TEXT, Data1 = 800, Option1 = true, Text = "TXT_KEY_MP_LAST_PLAYER" }
	return SetInterfaceModeSelection()
end)

--==========================================================
end)

--==========================================================
-- Support for Modded Add-in UI's
--==========================================================
do
	g_uiAddins = {}
	local Modding = Modding
	local insert = table.insert
	local uiAddins = g_uiAddins
	for addin in Modding.GetActivatedModEntryPoints("InGameUIAddin") do
		local addinFile = Modding.GetEvaluatedFilePath(addin.ModID, addin.Version, addin.File)
		if addinFile then
			print( "Loading MOD InGameUIAddin\n", Modding.GetModProperty(addin.ModID, addin.Version, "Name"), addin.File )
			insert( uiAddins, ContextPtr:LoadNewContext( addinFile.EvaluatedPath:match("(.*)%..*") ) )
		end
	end
end